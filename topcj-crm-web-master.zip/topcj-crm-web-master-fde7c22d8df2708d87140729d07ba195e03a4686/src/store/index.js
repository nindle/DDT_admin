import Vue from 'vue'
import Vuex from 'vuex'
import { storage, deepcopy } from '../assets/js/tool'
import { http } from '../assets/js/http'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    token: null,
    managerInfo: {},
    userDetail: {},
    baseData: {
      //导航树
      navigationTree: [],
      navigationList: [],
      //员工导航列表
      managerNavigation: [],
      //部门树
      groupTree: [],
      //员工部门树
      authGroupTree: [],
      //分公司部门树
      corpGroupTree: [],
      //分公司列表
      corpList: [],
      //员工列表
      managerList: [],
      //部门列表
      groupList: [],
      //标签列表
      tagList: [],
      //来源列表
      secTypeList: [],
      //渠道列表
      resChannelList: [],
      //指数列表
      indexList: [],
      //股票列表
      stockList: [],
      //板块列表
      plateList: [],
      //企业微信列表
      qywxList: [],
      //策略指标列表
      strategyIndexList: [],
      strategyIndexValueList: [],
      //标签列表
      tagTreeList: [],
      //风险定义
      riskDictionary: [],
      //证券日报相关分类
      categoryList: [],
    },
    //系统状态
    sysMode: 1,
    //窗口状态
    window: {
      //是否在线
      onLine: true,
      //是否聚焦在窗口
      isFocus: true,
      //是否允许消息通知
      isAllow: true
    },
    nav: {},
    topNav: [],
    topNavBase: ''
  },
  mutations: {
    //设置token
    setToken(state, data) {
      storage.local('token', data)
      state.token = data

      if(!data) {
        state.topNav.splice(0, state.topNav.length)
        state.managerInfo = {}
      }
    },
    //设置管理员信息
    setManagerInfo(state, data) {
      state.managerInfo = { 
        ...state.managerInfo, 
        ...data 
      }
    },
    setBaseData(state, data) {
      for(let k in data) {
        state.baseData[k].splice(0, state.baseData[k].length, ...data[k])
      }
    },
    setUserDetail(state, data) {
      state.userDetail[data.userId] = { 
        ...(state.userDetail[data.userId] ?? {}),
        ...data.data, 
        updateTime: Date.now()
      }
    },
    //设置窗口状态
    setWindow(state, data) {
      state.window = { 
        ...state.window, 
        ...data 
      }
    },
    //设置系统状态
    setSysMode(state, data) {
      state.sysMode = data
    },
    setNav(state, data) {
      state.nav = data
    },
    setTopNav(state, data) {
      if(!data) {
        state.topNav.splice(0, state.topNav.length)
        storage.local(`${state.topNavBase}nav2chche${state.managerInfo.id}`, null)
        return
      }

      const list = [data].flat()

      list.forEach(data => {
        let index = state.topNav.findIndex(e => e.path === data.path)

        if(data.add) {
          //新增
          if(index === -1) {
            //没有则直接新增
            state.topNav.push({
              path: data.path,
              title: data.title,
              name: data.name,
              disabled: false,
              dev: window.location.hostname === 'localhost'
            })
          }else if(state.topNav[index].disabled){
            //处于冷冻中
            state.topNav[index].disabled = false
          }
        }else if(data.refresh) {
          if(index !== -1) {
            //禁用
            state.topNav[index].disabled = true
          }
        }else{
          if(index !== -1) {
            //禁用
            state.topNav.splice(index, 1)
          }
        }
      })

      storage.local(`${state.topNavBase}nav2chche${state.managerInfo.id}`, state.topNav)
    },
    initTopNav(state, data) {
      state.topNavBase = data
      let list = storage.local(`${data}nav2chche${state.managerInfo.id}`) || []
      list.forEach(data => {
        let index = state.topNav.findIndex(e => e.path === data.path)
        if(index === -1) {
          state.topNav.push(data)
        }
      })
    },
  },
  actions: {
    //获取用户详情
    async getUserDetail(context, user) {
      let userId,path = '%CRM%/user/get_user_profile.sdcrm',corpId
      if(typeof user === 'object'){
        userId = user.userId
        path = user.path
        corpId = user.corpId
      }else{
        userId = user
      }
      let userDetail = context.state.userDetail[userId]

      if(userDetail && Date.now() - userDetail.updateTime < 60000) {
        return userDetail
      }

      let data = await http({
        mode: 'all',
        all: [
          {
            url: path,
            data: {
              token: true,
              userId: userId,
              corpId
            }
          },
          {
            url: '%CRM%/tags/get_user_tag.sdcrm',
            data: {
              token: true,
              managerId: context.state.managerInfo.id,
              userId: userId
            },
          },
          {
            url: '%CRM%/user/get_user_attach.sdcrm',
            data: {
              token: true,
              userId: userId
            },
          }
        ]
      })

      userDetail = data[0].result ?? {}

      if(userDetail.showTags) {
        if(typeof userDetail.showTags === 'string') {
          let showTags = {
            specTag: {},
            tags: []
          }
          if(userDetail.showTags) {
            let s = userDetail.showTags.split(',')
          
            userDetail.specTag = {
              tagTitle: s[2]
            }
            showTags.tags = []
            if(s[0]) {
              showTags.tags.push({
                tagId: 1,
                groupId: 1,
                tagTitle: s[0]
              })
            }
            if(s[1]) {
              showTags.tags.push({
                tagId: 2,
                groupId: 2,
                tagTitle: s[1]
              })
            }
          }
          userDetail.showTags = showTags
        }
      }else{
        userDetail.showTags = {
          specTag: {},
          tags: []
        }
      }

      if(userDetail.saveSimpTag) {
        let s = userDetail.saveSimpTag.split(',')[3]
        switch(s) {
          case '新入资源': userDetail.step = 0; break
          case '第一阶段': userDetail.step = 1; break
          case '第二阶段': userDetail.step = 2; break
          case '第三阶段': userDetail.step = 3; break
        } 
      }

      userDetail.tagIdsList = userDetail.tagsList ? userDetail.tagsList.map(e => e.id) : []

      userDetail.tagsList = data[1].result.tagIds

      userDetail.mobileauth = ''

      userDetail.attachList = data[2].result

      context.commit('setUserDetail', {
        userId,
        corpId,
        data: userDetail
      })

      return userDetail
    },
    //获取菜单列表
    async getNavigation(context) {
      let data = await http({
        mode: 'all',
        all: [
          {
            mode: 'get',
            url: '%CRM%/role/get_navigation_list.sdcrm',
            data: {
              token: true
            }
          },
          {
            url: '%CRM%/role/get_manager_navigation.sdcrm',
            data: {
              token: true
            }
          }
        ]
      })

      let navigationList = data[0].result
      let managerNavigation = data[1].result.filter(e => {
        if(e.remark && e.remark.indexOf('%$%') > -1) {
          let l = JSON.parse(e.remark.split('%$%')[1])

          return !l.m.length || l.m.includes(context.state.managerInfo.id)
        }

        return true
      })

      navigationList.forEach(e => {
        e.selected = false
        e.actionType = e.actionType.split(',').map(e => {
          return {
            type: Number(e),
            selected: false
          }
        })
        navigationList.forEach(a => {
          if(e.id === a.parentId) {
            if(!e.children) e.children = []
            e.children.push(a)
          }
        })
      })
      let navigationTree = navigationList.filter(e => e.parentId === 0)

      const recursion = (data, lv) => {
        for(let e of data) {
          e.level = lv
          if(e.children && e.children.length) {
            recursion(e.children, lv + 1)
          }
        }
      }

      recursion(navigationTree, 0)

      const setOrder = data => {
        data = data.sort((a, b) => a.sortId - b.sortId)
        data.forEach(e => {
          if(e.children && e.children.length) {
            e.children = setOrder(e.children)
          }
        })

        return data
      }

      navigationTree = setOrder(navigationTree)

      context.commit('setBaseData', {
        navigationTree,
        navigationList,
        managerNavigation,
      })
    },
    //获取员工列表
    async getManagerList(context) {
      let data = await http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/manager/get_manager_list.sdcrm',
            data: {
              token: true,
              showIsLock: 1
            }
          },
          {
            url: '%CRM%/manager/get_group_list.sdcrm',
            data: {
              token: true
            }
          },
          {
            mode: 'get',
            url: '%CRM%/setting/get_corp.sdcrm',
            data: {
              token: true
            }
          }
        ]
      })

      let manager = data[0].result
      let group = data[1].result.sort((a,b) => a.groupSort - b.groupSort)
      let corp = data[2].result
      let groupTree = deepcopy(group)

      groupTree.forEach(g => {
        g.managerList = []
        g.groupChildren = []
        manager.forEach(m => {
          if(g.id === m.groupId) {
            m.groupName = g.groupName
            g.managerList.push(m)
          }
        })
      })

      groupTree.forEach(e => {
        groupTree.forEach(a => {
          if(e.id === a.parentId) {
            e.groupChildren.unshift(a)
          }
        })
      })

      groupTree = groupTree.filter(e => e.groupLevel === 0)

      
      let search = function(data, id) {
        for(let i in data) {
          if(data[i].id === id) {
            return data[i]
          }else if (data[i].groupChildren.length) {
            let g = search(data[i].groupChildren, id)
            if(g) {
              return g
            }
          }
        }
        return false
      }

      let authGroupTree = [search(deepcopy(groupTree), context.state.managerInfo.dataGroupId)]
      let corpGroupTree = [search(deepcopy(groupTree), corp.find(e => e.id === context.state.managerInfo.corpId)?.rootGroupId)]

      let groupList = []
      const recursion = (data, lv) => {
        for(let i in data) {
          let e = data[i]
          groupList.push({
            ...e,
            name: lv ? `${'└'.padStart(lv, '　')} ${e.groupName}` : e.groupName
          })
          if(e.groupChildren && e.groupChildren.length) {
            recursion(e.groupChildren, lv + 1)
          }
        }
      }
      recursion(groupTree, 0)

      context.commit('setBaseData', {
        groupTree,
        authGroupTree,
        corpGroupTree,
        corpList: corp,
        managerList: manager,
        groupList
      })
    },
    //获取标签列表
    async getTagList(context) {
      let data = await http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/tags/get_tag.sdcrm',
            data: {
              token: true,
              managerId: context.state.managerInfo.id
            }
          },
          {
            url: '%CRM%/tags/get_tag_rename.sdcrm',
            data: {
              token: true
            }
          }
        ]
      })

      let groups = data[0].result.groups

      groups = groups.map(e => {
        e.tags = e.tags.map(e => {
          for(let i in data[1].result) {
            let a = data[1].result[i]
            if(e.id === a.tagId) {
              e.tagTitle = a.name
              break
            }
          }
          return e
        })
        return e
      })


      context.commit('setBaseData', {
        tagList: groups
      })
    },
    //获取所有来源
    async getSecTypeList(context) {
      let { result } = await http({
        url: '%CRM%/user/get_sec_types.sdcrm',
        mode: 'get',
        data: {
          token: true
        }
      })

      context.commit('setBaseData', {
        secTypeList: result
      })
    },
    //获取所有渠道
    async getResChannelList(context) {
      let { result } = await http({
        url: '%CRM%/user/get_res_channel.sdcrm',
        mode: 'get',
        data: {
          token: true
        }
      })

      context.commit('setBaseData', {
        resChannelList: result
      })
    },
    //获取股票列表
    async getStockList(context) {
      let stockInfo = storage.local('stockInfo')
      if(stockInfo && Date.now() - stockInfo.time <= 24 * 60 * 60 * 1000) {
        context.commit('setBaseData', {
          stockList: stockInfo.stockList,
          indexList: stockInfo.indexList,
        })
        return
      }

      let { result } = await http({
        mode: 'get',
        url: '%SDSS%/v2/stock_info',
      })

      stockInfo = {
        time: Date.now(),
        stockList: [],
        indexList: []
      }

      const getMarketType = (code) => {
        switch(code) {
          case 'XSHE': return 2
          case 'XSHG': return 1
        }
      }

      result.forEach(e => {
        let s2 = e.code.substring(0, 2)
        let markettype = getMarketType(e.code.split('.')[1])
        if((markettype === 1 && (s2 === '60' || s2 === '68')) || (markettype === 2 && (s2 === '00' || s2 === '30'))) {
          const r = {
            la: e.la,
            markettype,
            scode: e.code.split('.')[0],
            scodename: e.code_name
          }
          stockInfo.stockList.push(r)
        }else{
          const r = {
            la: e.la,
            markettype,
            scode: e.code.split('.')[0],
            scodename: e.code_name
          }
          stockInfo.indexList.push(r)
        }
      })

      storage.local('stockInfo', stockInfo)

      context.commit('setBaseData', {
        stockList: stockInfo.stockList,
        indexList: stockInfo.indexList,
      })
    },
    //获取板块列表
    async getPlateList(context) {
      let { result } = await http({
        mode: 'get',
        url: '%SDSS%/v1/stock_block',
      })

      context.commit('setBaseData', {
        plateList: result.map(e => {
          return {
            bcode: e.code.split('.')[0],
            blocktype: `${e.block_type}`,
            bname: e.code_name
          }
        })
      })
    },
    //获取企业微信列表
    async getQywxList(context) {
      let { result } = await http({
        mode: 'get',
        url: '%CRM%/setting/get_qy_wx.sdcrm',
        data: {
          token: true
        }
      })

      let qywxList = result

      if(context.state.managerInfo.corpId){
        qywxList = qywxList.filter(e => e.corpId === context.state.managerInfo.corpId)
      }

      context.commit('setBaseData', {
        qywxList
      })
    },
    //获取指标列表
    async getStrategyIndexList(context) {
      let data = await http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/strategy/get_index_list.sdcrm',
            data: {
              token: true,
              transactionType: 1,
              showValue: 1
            }
          },
          {
            url: '%CRM%/strategy/get_index_group_list.sdcrm',
            data: {
              token: true,
              transactionType: 2,
              showValue: 1
            }
          }
        ]
      })

      let list = []

      const sumbolList = [
        { label: '<', value: 3 },
        { label: '>', value: 2 },
        { label: '=', value: 1 },
        { label: '<=', value: 5 },
        { label: '>=', value: 4 }
      ]

      data[0].result.map(e => {
        if(e.values && e.values.length) {
          e.values.forEach(a => {
            a.indexCode = e.variCode
            a.indexName = e.variName
            a.symbolName = sumbolList.find(e => e.value === a.defaultSymbolType).label + a.defaultValue

            a.codeList = []

            a.codeList.push({
              groupId: a.indexId,
              indexId: a.indexId,
              valueId: a.id,
              variCode: a.variCode,
              symbolType: a.defaultSymbolType,
              value: a.defaultValue
            })
            if(a.secondSymbolType) {
              a.codeList.push({
                groupId: a.indexId,
                indexId: a.indexId,
                valueId: a.id,
                variCode: a.variCode,
                symbolType: a.secondSymbolType,
                value: a.secondValue
              })
            }
          })
        }else{
          e.values = []
        }
        list.push(e)
      })

      data[1].result.map(e => {
        let s = {
          ctime: e.ctime,
          description: e.description,
          id: e.id + 900000,
          parentId: -1,
          status: e.status,
          transactionType: e.transactionType,
          type: 999,
          utime: e.utime,
          variName: e.groupName,
          vipLevel: 0,
          codeNameString: e.values.map(e => e.variName).join('<br>'),
          values: [
            {
              ctime: e.ctime,
              description: e.description,
              id: e.id + 900000,
              indexId: e.id + 900000,
              indexName: e.groupName,
              status: e.status,
              utime: e.utime,
              variName: e.groupName,
              codeList: []
            }
          ]
        }

        e.values.forEach(a => {
          s.values[0].codeList.push({
            groupId: e.id + 900000,
            indexId: a.indexId,
            valueId: a.id,
            variCode: a.variCode,
            symbolType: a.defaultSymbolType,
            value: a.defaultValue
          })
          if(a.secondSymbolType) {
            s.values[0].codeList.push({
              groupId: e.id + 900000,
              indexId: a.indexId,
              valueId: a.id,
              variCode: a.variCode,
              symbolType: a.secondSymbolType,
              value: a.secondValue
            })
          }
        })

        list.push(s)
      })

      // let { result } = await http({
      //   url: '%CRM%/strategy/get_index_list.sdcrm',
      //   data: {
      //     token: true,
      //     showValue: 1
      //   }
      // })

     

      // let list = []

      // result = result.filter(e => {
      //   if(e.values && e.values.length) {
      //     e.values.forEach(a => {
      //       a.indexCode = e.variCode
      //       a.indexName = e.variName
      //     })
      //     list.push(...e.values)
      //     return true
      //   }

      //   return false
      // })


      context.commit('setBaseData', {
        strategyIndexList: list,
        // strategyIndexValueList: list,
      })
    },
    //获取标签配置
    async getTagConfig(context) {
      let data = await http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/label/get_label_tree.sdcrm',
            data: {
              token: true
            }
          },
          {
            mode: 'get',
            url: '%CRM%/manager/get_qy_config.sdcrm',
            data: {
              token: true
            }
          }
        ]
      })

      context.commit('setBaseData', {
        tagTreeList: data[0].result
      })

      context.commit('setSysMode', data[1].result.sysMode)
    },
    //获取风险定义
    async getRiskDictionary(context) {
      let { result } = await http({
        mode: 'get',
        url: '%CRM%/risk/get_risk_dictionary.sdcrm',
        data: {
          token: true
        }
      })
      
      context.commit('setBaseData', {
        riskDictionary: result
      })
    },
    // async getCategoryList(context) {
    //   let { result } = await http({
    //     url: '%MS%/srs/config/get_rpt_category_list',
    //     data: {
    //       token: true
    //     }
    //   })
    //   context.commit('setBaseData', {
    //     categoryList: result
    //   })
    // },
  },
  modules: {
  }
})
