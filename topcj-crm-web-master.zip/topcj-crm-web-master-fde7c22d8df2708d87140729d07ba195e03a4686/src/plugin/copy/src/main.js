import log from '../../log/index'
import store from '../../../store/index'

const openDirective = {
  bind(el, binding) {
    el.__openValue__ = binding.value
    el.__openHandler__ = () => {
      if(!el.__openValue__) return false

      openPrototype(el.__openValue__)
    }
    el.addEventListener('click', el.__openHandler__)
  },
  update(el, binding) {
    el.__openValue__ = binding.value
  },
  unbind(el) {
    el.removeEventListener('click', el.__openHandler__)
    delete el.__openValue__
    delete el.__openHandler__
  }
}

const openPrototype = function(url) {
  if(url) {
    log(5, 14, 1, store.state.nav.id, undefined, undefined, url)
    if(url.indexOf('http') !== 0) {
      global.open(`http://${url}`)
    }else{
      global.open(url)
    }
  }
}

const copyDirective = {
  bind(el, binding) {
    el.__copyValue__ = binding.value
    el.__copyHandler__ = () => {
      let value = el.__copyValue__ ?? (binding.arg === 'html' ? el.innerHTML.replace(/ data-v-[0-9a-zA-Z]+(="")?/g, '') : el.innerText)
      if(!value) return false
      if(binding.modifiers.nowrap)
        value = value.replace(/\f|\n|\r/g, ' ')

        copyPrototype(value, defalutConfig.afterVCopy)
    }
    el.addEventListener('click', el.__copyHandler__)
  },
  update(el, binding) {
    el.__copyValue__ = binding.value
  },
  unbind(el) {
    el.removeEventListener('click', el.__copyHandler__)
    delete el.__copyValue__
    delete el.__copyHandler__
  }
}

const copyPrototype = function(value, callback, isLog = true) {
  const input = document.createElement('textarea')
  input.readOnly = 'readonly'
  input.style.position = 'absolute'
  input.style.left = '-9999px'
  input.value = value
  document.body.appendChild(input)
  input.select()
  document.execCommand('copy')
  document.body.removeChild(input)

  if(isLog) {
    log(5, 13, 1, store.state.nav.id, undefined, undefined, `${value}`)
  }

  if(typeof callback === 'function') callback(value)
  else if(typeof defalutConfig.afterCopy === 'function') defalutConfig.afterCopy(value)
}

copyPrototype.nowrap = function(value, callback) {
  value = value.replace(/\f|\n|\r/g, ' ')  
  if(/<.*?>.*?<\/.*?>/.test(value)) {
    value = value.replace(/>(\s+?)</g, '><').trim()
  }
  copyPrototype(value, callback)
}

const defalutConfig = {
  afterVCopy: null,
  afterCopy: null
}

export { copyDirective, copyPrototype, defalutConfig, openDirective, openPrototype }