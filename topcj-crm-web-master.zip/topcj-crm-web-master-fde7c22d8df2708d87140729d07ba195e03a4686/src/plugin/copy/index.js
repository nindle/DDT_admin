import { copyDirective, copyPrototype, defalutConfig, openDirective, openPrototype } from './src/main'

let index = {}
index.install = function(Vue) {
  Vue.directive('copy', copyDirective)
  Vue.directive('open', openDirective)
  Vue.prototype.$copy = copyPrototype
  Vue.prototype.$open = openPrototype
}
index.default = function(config) {
  defalutConfig.afterVCopy = config.afterVCopy
  defalutConfig.afterCopy = config.afterCopy
}

export default index
