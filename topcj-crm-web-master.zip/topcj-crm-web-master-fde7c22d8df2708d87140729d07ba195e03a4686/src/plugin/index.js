import elPagePro from './el-page-pro/index'
import elDialogPro from './el-dialog-pro/index'
import elLayoutPro from './el-layout-pro/index'
import elTablePro from './el-table-pro/index'
import elFormPro from './el-form-pro/index'
import elScreenPro from './el-screen-pro/index'
import elScrollbarPro from './el-scrollbar-pro/index'

import tableList from './el-table-pro/table'

import log from './log/index'
import store from '../store/index'

let index = {}
index.install = function(Vue) {
  Vue.component('elPagePro', elPagePro)
  Vue.component('elDialogPro', elDialogPro)
  Vue.component('elLayoutPro', elLayoutPro)
  Vue.component('elTablePro', elTablePro)
  Vue.component('elFormPro', elFormPro)
  Vue.component('elScreenPro', elScreenPro)
  Vue.component('elScrollbarPro', elScrollbarPro)

  Vue.prototype.$copyExcel = async function(vm, excelName) {
    let list = [...tableList]
    let result = []
    const p = function(v) {
      if(!list.length) return
      if(list.includes(v)) {
        list.splice(list.indexOf(v), 1)
        result.push(v)
      }
      v.$children.forEach(e => {
        p(e)
      })
    }
    p(vm)

    if(!result.length) return

    let table = []

    for(let i in result) {
      let v = result[i]

      v.excelMode = true
      await v.$nextTick()

      v.init()

      table.push(`
        ${v.$refs.table.$el.querySelector('.el-table__header-wrapper thead').innerHTML}
        ${v.$refs.table.$el.querySelector('.el-table__body-wrapper tbody').innerHTML}
        ${v.$refs.table.$el.querySelector('.el-table__footer-wrapper tbody')?.innerHTML.replace(/rowspan="(\d.?)"/g, 'rowspan="1"') ?? ''}
      `.replace(/>(\s+?)</g, '><').trim())

      v.excelMode = false
      await v.$nextTick()

      v.init()
    }
    table = `<table>${table.join('<tr></tr>')}</table>`

    // vm.$copy(table, undefined, false)

    if(!excelName) return table

    const { download } = await import('../assets/js/excel')

    download(table, excelName.replace(/\\|\/|\?|\*|\[|\]/g, ','))

    log(5, 14, 1, store.state.nav.id, undefined, undefined, '导出Excel')
  }

  Vue.prototype.$log = log

  //时间格式化
  Date.prototype.timeFormat = function(fmt = 'yyyy-MM-dd hh:mm:ss') {
    var o = {
      'M+': this.getMonth() + 1,
      'd+': this.getDate(),
      'h+': this.getHours(),
      'm+': this.getMinutes(),
      's+': this.getSeconds(),
      'W': `星期${'日一二三四五六'.charAt(this.getDay())}`   
    }
    if(/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length))
    for(var k in o)
        if(new RegExp('(' + k + ')').test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length ===1 ) ? (o[k]) : (('00'+ o[k]).substr(('' + o[k]).length)))
    return fmt
  }

  /*时间格式化过滤器*/
  Vue.filter('timeFormat', function(value, fmt = 'yyyy-MM-dd hh:mm:ss') {
    let d = new Date(value)
    if(d.toString() === 'Invalid Date') {
      return '/'
    }else{
      return d.timeFormat(fmt)
    }
  })

  /*秒过滤器
  * h 时 m 分 s 秒
  * + 补零 () 为零不展示
  */
  Vue.filter('secondFormat', function(value, fmt = '+h:+m:+s') {
    let h = 0, m = 0, s = 0
    if(fmt.indexOf('h') > -1) {
      h = Math.floor(value / (60 * 60))
      m = Math.floor((value - (60 * 60 * h)) / 60)
      s = Math.floor(value - (60 * 60 * h) - (60 * m))
    }else if(fmt.indexOf('m') > -1) {
      m = Math.floor(value / 60)
      s = Math.floor(value - (60 * m))
    }else{
      s = Math.floor(value)
    }

    if(!h) { fmt = fmt.replace(/\(.*?h.*?\)/g, '') }
    if(!m & !h) { fmt = fmt.replace(/\(.*?m.*?\)/g, '') }
    if(!s & !m & !h) { fmt = fmt.replace(/\(.*?s.*?\)/g, '') }

    return fmt.replace(/\+h/g, `${h}`.padStart(2, '0')).replace(/\+m/g, `${m}`.padStart(2, '0')).replace(/\+s/g, `${s}`.padStart(2, '0')).replace(/h/g, h).replace(/m/g, m).replace(/s/g, s).replace(/\(|\)/g, '')
  })

  //时间距离格式化
  const timeOption = {
    today: 'hh:mm',
    lastday: '昨天 hh:mm',
    week: 'W hh:mm',
    year: 'MM-dd hh:mm',
    lastyear: 'yyyy-MM-dd hh:mm'
  }
  Vue.filter('timeDistance', function(value, { today = 'hh:mm', lastday = '昨天 hh:mm', week = 'W hh:mm', year = 'MM-dd hh:mm', lastyear = 'yyyy-MM-dd hh:mm' } = timeOption) {
    if(typeof value === 'string') {
      value = value.replace(/-/g, '/')
    }
    
    let date = new Date(value)
    let t = new Date(date.timeFormat('yyyy-MM-dd'))
    let n = new Date(new Date().timeFormat('yyyy-MM-dd'))

    if(n.getFullYear() === t.getFullYear()) {
      //同年
      if(n.getMonth() === t.getMonth() && n.getDate() === t.getDate()){
        //今天
        return date.timeFormat(today)
      }else if(n.getTime() - t.getTime() <= 1 * 24 * 60 * 60 * 1000) {
        //昨天
        return date.timeFormat(lastday)
      }else if(n.getTime() - t.getTime() <= 6 * 24 * 60 * 60 * 1000) {
        //7日内
        return date.timeFormat(week)
      }else{
        //同年
        return date.timeFormat(year)
      }
    }else{
      //不同年
      return date.timeFormat(lastyear)
    }
  })


  /*数字过滤器
  * number 保留小数 _ 默认配置 . 用前一个配置填充至最大长度
  */
 const numberFormat = function(num, fmt = '') {
    if(isNaN(num)) return num 
    num = Number(num)
    let fixed = [0,2,1,0,2,1,0]

    if(fmt.indexOf('.') > -1) {
      let a = fmt.indexOf('.')
      let b = a > 0 ? fmt.charAt(a - 1) : '_'
      fmt = fmt.replace(/\./g, '')
      fmt = fmt.substring(0, a) + ''.padEnd(fixed.length - fmt.length,b) + fmt.substring(a)
    }
    
    fmt = fmt.padEnd(7, '_').substring(0, 7).replace(/ /g, '_').split('').map((e, i) => {
      return e === '_' ? fixed[i] : Number(e)
    })

    if(num >= 10000000000) {
      num = (num / 100000000).toFixed(fmt[6]) + '亿'
    }else if(num >= 1000000000) {
      num = (num / 100000000).toFixed(fmt[5]) + '亿'
    }else if(num >= 100000000) {
      num = (num / 100000000).toFixed(fmt[4]) + '亿'
    }else if(num >= 1000000) {
      num = (num / 10000).toFixed(fmt[3]) + '万'
    }else if(num >= 100000) {
      num = (num / 10000).toFixed(fmt[2]) + '万'
    }else if(num >= 10000) {
      num = (num / 10000).toFixed(fmt[1]) + '万'
    }else{
      num = num.toFixed(fmt[0])
    }
    return num
  }
    Vue.filter('numberFormat', numberFormat)
  Vue.directive('number', function(el, binding) {
    let value = binding.value ?? '--'
    if(isNaN(value)) {
      el.innerText = el.dataset.numberDefault || value
      el.style.color = ''
      return
    }
    
    let n1 = Number(value)
    let number = el.dataset.numberFormat ? numberFormat(n1, el.dataset.numberFormat) : n1.toFixed(Number(el.dataset.numberPrecision || 2))
    let __numberValue__ = (binding.modifiers.nosign ? number : (n1 > 0 ? `+${number}` : number)) + (binding.modifiers.percent ? '%' : '')
    let baseNumber = Number(el.dataset.numberBase || 0)
    let __numberColor__ = n1 > baseNumber ? '#E11414' : (number < baseNumber ? '#1CC900' : '')

    if(!binding.modifiers.nonumber) {
      el.innerText = __numberValue__ + (el.dataset.numberUnit || '')
    }
    
    if(__numberColor__ && !binding.modifiers.nocolor) {
      el.style.color = __numberColor__
    }else{
      el.style.color = ''
    }
  })
}

export default index
