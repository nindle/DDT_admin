<template>
  <el-dialog
    class="popover"
    :class="{ 'full-screen': full, 'max-height': maxHeight, 'init-over': initOver }"
    :visible.sync="show"
    :width="width"
    :top="top"
    :modal-append-to-body="false"
    :destroy-on-close="isActive"
    :close-on-click-modal="false"
    ref="popover"
    :style="{ 
      '--mask-height': `${height}px`, 
      '--popover-width': width, 
      '--popover-top': top, 
      '--popover-offset': 
      `${offset}px` 
    }"
  >
    <!--标题-->
    <template #title>
      <slot name="title" />
      <i 
        class="el-icon-full-screen"
        v-if="fullScreen"
        @click="toggleFull"
      ></i>
    </template>
    <!--内容-->
    <el-scrollbar-pro 
      class="content-box"
      v-if="!noScroll"
    >
      <div class="content-box-view">
        <slot />
      </div>
    </el-scrollbar-pro>
    <div
      class="content-box no-scroll-box"
      v-if="noScroll"
    >
      <div class="content-box-view">
        <slot />
      </div>
    </div>

    <!--右侧-->
    <div 
      class="right-box"
      v-if="$scopedSlots.right"
      ref="right"
    >
      <slot name="right" />
    </div>

    <!--左侧-->
    <div 
      class="left-box"
      v-if="$scopedSlots.left"
      ref="left"
    >
      <slot name="left" />
    </div>
    
    <!--底部按钮-->
    <template #footer>
      <slot name="footer" />
      <div></div>
    </template>
  </el-dialog>
</template>

<script>
export default {
  data() {
    return {
      isActive: true,
      show: true,
      full: this.defaultFull || this.defaultFrameFull,
      height: 0,
      offset: 0,
      initOver: false
    }
  },
  props: {
    defaultFull: Boolean,
    fullScreen: Boolean,
    frameFullScreen: Boolean,
    defaultFrameFull: Boolean,
    maxHeight: Boolean,
    width: {
      type: String,
      default: '520px'
    },
    top: {
      type: String,
      default: '10vh'
    },
    noScroll: Boolean
  },
  inject: {
    setFullScreen: {
      default: () => {}
    }
  },
  methods: {
    async calcOffset() {
      let offset = 0

      if(this.$refs.right) {
        offset -= this.$refs.right.getBoundingClientRect().width / 2
      }

      if(this.$refs.left) {
        offset += this.$refs.left.getBoundingClientRect().width / 2
      }

      this.offset = offset

      await this.$nextTick()
      this.initOver = true
    },
    //切换全屏
    async toggleFull() {
      this.full = !this.full
      if(this.frameFullScreen) {
        this.setFullScreen?.(this.full)
      }
      this.$emit('full-screen', this.full)
      await this.$nextTick()
      this.height = this.$el.getBoundingClientRect().height
    }
  },
  watch: {
    async show() {
      if(this.isActive && !this.show) {
        this.$emit('close')
        this.setFullScreen?.(false)
        await this.$nextTick()
        this.height = this.$el.getBoundingClientRect().height
      }
    }
  },
  async mounted() {
    this.setFullScreen?.(this.defaultFrameFull)
    await this.$nextTick()
    this.height = this.$el.getBoundingClientRect().height
    this.calcOffset()
  },
  updated() {
    this.calcOffset()
  },
  beforeDestroy() {
    this.setFullScreen?.(false)
  },
  deactivated() {
    this.isActive = false
    this.show = false
  },
  activated() {
    this.isActive = true
    this.show = true
  },
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.popover {
  position: absolute;
  --popover-height: calc(var(--mask-height) - var(--popover-top) * 2);
  .el-icon-full-screen {
    position: absolute;
    right: 44px;
    top: 20px;
    cursor: pointer;
    color: #909399;
    &:hover { color: $--color-main;}
  }
  .content-box {
    max-height: calc(var(--popover-height) - 135px);
    .content-box-view { padding: 10px 20px 0;}
    &.no-scroll-box {
      height: calc(var(--popover-height) - 135px);
      .content-box-view { 
        width: 100%;
        height: 100%;
        box-sizing: border-box;
      }
    }
  }
  &.init-over {
    /deep/ {
      .el-dialog { transition: left .3s; }
    }
  }
  /deep/ {
    .el-dialog { 
      border-radius: 0;
      margin-bottom: 0;
      left: var(--popover-offset);
    }
    .el-dialog__header {
      padding: 16px !important;
      border-bottom: 1px solid #E9E9E9;
    }
    .el-dialog__title { font-size: 16px;}
    .el-dialog__headerbtn { top: 16px; }
    .el-dialog__body { padding: 10px 0 20px;}
    .el-dialog__footer { 
      padding-top: 0;
      height: 52px;
    }
  }
  &.max-height {
    .content-box {
      height: calc(var(--popover-height) - 135px);
    }
  }
  &.full-screen {
    --popover-height: calc(var(--mask-height) - 48px);
    .content-box {
      height: calc(var(--popover-height) - 135px);
    }
    /deep/ {
      .el-dialog {
        width: calc(100% - 48px + var(--popover-offset) * 2) !important;
        height: calc(100% - 48px) !important;
        margin: 24px !important;
        left: 0;
      }
    }
  }
  .right-box {
    position: absolute;
    right: 0;
    transform: translateX(100%);
    top: 0;
    background: #FFF;
    border-left: 1px solid #EEE;
    height: 100%;
  }
  .left-box {
    position: absolute;
    left: 0;
    transform: translateX(-100%);
    top: 0;
    background: #FFF;
    border-right: 1px solid #EEE;
    height: 100%;
  }
}

</style>