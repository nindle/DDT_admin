<template>
  <div style="display: flex">
    <el-input v-show="false" v-model="model[k]" disabled @change="$emit('change')"></el-input>
    <el-image
      class="input-image"
      :class="`size-${item.size || 'large'}`"
      :style="{ background: item.background || '' }"
      :src="model[k]"
      fit="cover"
      v-imageview="model[k]"
    >
      <template #error>
        <div class="el-image__error" v-if="item.size !== 'small'">{{ item.placeholder || `请上传${item.label}` }}</div>
        <div v-else></div>
      </template>
    </el-image>
    <div class="uploadButton" style="display: inline-flex; flex-direction: column">
      <el-button v-if="!item.hideButton" style="margin-left: 8px" @click="uploadFile" :loading="item.uploading" :disabled="item.disabled">{{
        item.uploading ? '上传中' : '浏览...'
      }}</el-button>
      <el-button
        v-if="model[k] && !item.hideButton"
        style="margin-left: 8px; margin-top: auto; padding: 4px 0; width: 24px;color: #C0C4CC"
        @click="deleteImg"
        type="text"
        icon="el-icon-delete"
      ></el-button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      inputEl: null
    }
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  methods: {
    //上传文件
    uploadFile() {
      const input = document.createElement('input')
      input.style.position = 'absolute'
      input.style.left = '-9999px'
      input.type = 'file'
      input.accept = 'image/*'

      input.onchange = async e => {
        document.body.removeChild(input)
        this.inputEl = null
        if (!e.target.files[0]) return

        let file = e.target.files[0]

        let allowSize = this.item.size || 1024
        let fileSize = file.size / 1024

        let allowSizeText = `${allowSize}KB`
        if (allowSize > 1024) {
          allowSizeText = Number((allowSize / 1024).toFixed(2)) + 'MB'
        }

        if (fileSize > allowSize * 1.2) {
          this.$message.error(`${this.item.label}图片大小不得超过${allowSizeText}`)
          return
        }

        if (fileSize > allowSize) {
          this.$message.warning(`${this.item.label}图片大小建议不超过${allowSizeText}`)
        }

        this.item.uploading = true

        let { result } = await this.$http({
          mode: 'form',
          url: '%CRM%/api/upload_file.sdcrm',
          data: {
            token: true,
            uploadFile: file
          }
        })

        this.item.uploading = false

        if (typeof this.item.fileName === 'function') {
          this.item.fileName(file.name)
        }
        if (typeof this.item.fileSize === 'function') {
          this.item.fileSize(file.size)
        }

        this.model[this.k] = result.url
      }

      if (this.inputEl) {
        document.body.removeChild(this.inputEl)
      }

      document.body.appendChild(input)
      this.inputEl = input
      input.click()
    },
    deleteImg() {
      this.model[this.k] = ''

      this.$emit('change')

      if (typeof this.item.fileName === 'function') {
        this.item.fileName('')
      }
      if (typeof this.item.fileSize === 'function') {
        this.item.fileSize(0)
      }
    }
  },
  beforeDestroy() {
    if (this.inputEl) {
      document.body.removeChild(this.inputEl)
    }
  }
}
</script>
