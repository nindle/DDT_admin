<template>
  <el-date-picker
    v-model="model[k]"
    type="date"
    :placeholder="item.placeholder || `请选择${item.label}`"
    format="yyyy-MM-dd"
    :value-format="item.format || 'timestamp'"
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    :disabled="item.disabled"
    :pickerOptions="item.pickerOptions"
    @change="$emit('change')"
  ></el-date-picker>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>