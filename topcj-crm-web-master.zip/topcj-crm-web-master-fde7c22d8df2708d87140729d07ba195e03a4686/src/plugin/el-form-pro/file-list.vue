<template>
  <el-upload
    action=""
    :limit="item.limit"
    multiple
    :accept="item.accept"
    :file-list="model[k]"
    :http-request="uploadFileList"
    :on-remove="removeFileList"
    :disabled="item.disabled"
    :on-exceed="exceedFileList"
    :on-change="onChange"
  >
    <el-button 
      size="small" 
      type="primary"
      slot="trigger"
    >点击上传</el-button>
    <el-button
      v-if="item.template"
      type="primary" 
      plain
      size="small"
      icon="el-icon-download"
      v-open="item.template"
      style="margin-left: 12px"
    >下载模板</el-button>
  </el-upload>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  methods: {
    async uploadFileList({ file }) {
      let key = this.k
      let auto = this.item.autoUpload ?? true

      if(auto) {
        let { result } = await this.$http({
          mode: 'form',
          url: '%CRM%/api/upload_file.sdcrm',
          data: {
            token: true,
            uploadFile: file
          }
        })

        let l = result.url.split('/')
        this.model[key].push({
          name: l[l.length - 1],
          url: result.url,
          size: file.size
        })  
      }else{
        this.model[key].push({
          name: file.name,
          file,
          size: file.size
        })  
      }
    },
    onChange(e){
      this.$emit('change', e)
    },
    removeFileList(file) {
      this.model[this.k].splice(this.model[this.k].indexOf(file), 1)
    },
    async exceedFileList(files) {
      for(let i in files) {
        if(this.item.limit > this.model[this.k].length) {
          await this.uploadFileList({ file: files[i] })
        }else{
          return
        }
      }
    },
  }
}
</script>