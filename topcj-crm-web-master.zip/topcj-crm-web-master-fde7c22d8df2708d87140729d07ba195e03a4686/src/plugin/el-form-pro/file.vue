<template>
  <div>
    <el-input
      :placeholder="item.placeholder || `请上传${item.label}`"
      v-model="model[k]"
      :disabled="typeof item.disabled === 'boolean' ? item.disabled : true"
      @change="$emit('change')"
    ></el-input>
    <el-button style="margin-left: 8px" @click="uploadFile" :loading="item.uploading" :disabled="item.disabled">{{
      item.uploading ? '上传中' : '浏览...'
    }}</el-button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      inputEl: null
    }
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  methods: {
    //上传文件
    uploadFile() {
      const input = document.createElement('input')
      input.style.position = 'absolute'
      input.style.left = '-9999px'
      input.type = 'file'
      input.accept = this.item.accept
      input.onchange = async e => {
        document.body.removeChild(input)
        this.inputEl = null
        if (!e.target.files[0]) return

        let file = e.target.files[0]

        this.item.uploading = true

        let { result } = await this.$http({
          mode: 'form',
          url: '%CRM%/api/upload_file.sdcrm',
          data: {
            token: true,
            uploadFile: file
          }
        })

        this.item.uploading = false

        if (typeof this.item.fileName === 'function') {
          this.item.fileName(file.name)
        }
        if (typeof this.item.fileSize === 'function') {
          this.item.fileSize(file.size)
        }

        this.model[this.k] = result.url
      }
      if (this.inputEl) {
        document.body.removeChild(this.inputEl)
      }
      document.body.appendChild(input)
      this.inputEl = input
      input.click()
    }
  },
  beforeDestroy() {
    if (this.inputEl) {
      document.body.removeChild(this.inputEl)
    }
  }
}
</script>
