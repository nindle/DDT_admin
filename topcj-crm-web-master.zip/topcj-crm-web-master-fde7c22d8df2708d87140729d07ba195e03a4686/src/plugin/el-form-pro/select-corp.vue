<template>
  <el-select
    clearable
    v-model="model[k]"
    :placeholder="item.placeholder || '请选择分公司'"
    :disabled="item.disabled || item.corpLock && managerInfo.corpId !== 0"
    :multiple="item.multiple"
    @change="$emit('change')"
  >
    <el-option
      v-for="l in corpList"
      :key="l.id"
      :value="l.id"
      :label="l.corpName"
    ></el-option>
  </el-select>
</template>

<script>
export default {
  computed: {
    corpList() {
      return this.$store.state.baseData.corpList.filter(e => (typeof this.item.isCorp === 'boolean' ? this.item.isCorp : true) ? e.isCorp : true)
    },
    managerInfo() {
      return this.$store.state.managerInfo
    },
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  created() {
    if(this.managerInfo.corpId !== 0 && this.item.corpLock) {
      if(this.item.multiple) {
        this.model[this.k] = [this.managerInfo.corpId]
      }else{
        this.model[this.k] = this.managerInfo.corpId
      }
    }
  }
}
</script>