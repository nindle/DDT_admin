<template>
  <el-scrollbar-pro 
    ref="scroll"
    v-loading="uploading"
    :element-loading-text="`上传中...${videoProgress ? `${videoProgress}%` : ''}`"
    element-loading-background="rgba(255,255,255,.5)"
  >
    <quill-editor
      v-model="model[k]"
      :options="editorOption"
      @change="$emit('change')"
      ref="quillEditor"
      :class="{ preview }"
    />
  </el-scrollbar-pro>
</template>

<script>
import TcVod from 'vod-js-sdk-v6'
import { quillEditor } from 'vue-quill-editor'
import 'quill/dist/quill.snow.css'
import Quill from 'quill'
import AppVideo from './richtext-video'


const Bold = Quill.import('formats/bold')
Bold.tagName = 'B'
Quill.register(Bold, true)

const Align = Quill.import('attributors/style/align')
Align.whitelist = ['right', 'center', 'justify']
Quill.register(Align, true)


const Block = Quill.import('blots/block')
Block.tagName = ['P', 'DIV', 'BUTTON', 'TABLE','THEAD','TBODY','TFOOT','CODE','PRE', 'SECTION','ARTICLE', 'IFRAME']
Block.allowedChildren.push(Block, AppVideo)

Quill.register(Block, true)

const Tr = Quill.import('blots/block/embed')
Tr.blotName = Tr.tagName = 'TR'
Quill.register(Tr)

const Th = Quill.import('blots/block/embed')
Th.blotName = Th.tagName = 'TH'
Quill.register(Th)

const Td = Quill.import('blots/block/embed')
Td.blotName = Td.tagName = 'TD'
Quill.register(Td)

const Br = Quill.import('blots/block/embed')
Br.blotName = Br.tagName = 'BR'
Quill.register(Br)

class Applock extends Block {
  static create() {
    return super.create();
  }

  static formats() {
    return true;
  }

  optimize(context) {
    super.optimize(context);
    if (this.domNode.tagName !== this.statics.tagName) {
      this.replaceWith(this.statics.blotName);
    }
  }
}
Applock.blotName = 'applock';
Applock.tagName = 'APPLOCK'

Quill.register(Applock, true)

Quill.register(AppVideo, true)

// const Indent = Quill.import('attributors/style/indent')
// Indent.whitelist = ['1em', '2em', '3em', '4em', '5em', '6em', '7em', '8em', '9em']
// Quill.register(Indent, true)

export default {
  data() {
    let hideTool = this.item.hideTool ?? ['applock']
    let container = [
      ['bold', 'italic', 'underline', 'strike'],
      // [{'indent': '+1'}, {'indent': '-1'}],
      [{'list': 'ordered'}, {'list': 'bullet'}],
      [{'background': []}, {'color': []}],
      [{'align': []}],
      [{ 'header': [1, 2, 3, false] }],
      ['clean'],
      ['link', 'image', 'video'],
      ['preview', 'html']
    ].map(e => {
      return e.filter(e => {
        if(typeof e === 'object') {
          return !hideTool.includes(Object.keys(e)[0])
        }else{
          return !hideTool.includes(e)
        }
      })
    }).filter(e => e.length)
    let that = this
    return {
      editorOption: {
        placeholder: this.item.placeholder || `请输入${this.item.label}`,
        modules: {
          toolbar: {
            container,
            handlers: {
              image: this.uploadImage,
              video: this.uploadVideo,
              preview: () => {
                this.preview = !this.preview
              },
              shadeBox: null,
              html() {
                const container = this.container
                const firstChild = container.nextElementSibling.firstChild
                if (!this.shadeBox) {
                  let shadeBox = this.shadeBox = document.createElement('div')
                  shadeBox.className = 'ql-html-shade-box'
                  container.style.position = 'relative'
                  container.appendChild(shadeBox)
                  firstChild.innerText = firstChild.innerHTML.replace(/\n/g,'')
                  that.isHtml = true
                  
                  shadeBox.addEventListener('click', function () {
                    that.isHtml = false
                    this.style.display = 'none'
                    firstChild.innerHTML = firstChild.innerText.replace(/>(\s+?)</g, '><').replace(/&nbsp;/g, ' ').trim()
                  }, false)
                } else {
                  this.shadeBox.style.display = 'flex'
                  that.isHtml = true
                  firstChild.innerText = firstChild.innerHTML.replace(/\n/g,'')
                  
                }
              }
            }
          },
        }
      },
      preview: false,
      isHtml: false,

      uploading: false,
      videoProgress: 0
    }
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  components: {
    quillEditor
  },
  methods: {
    //上传文件
    uploadImage(value) {
      if(!value) return

      const input = document.createElement('input')
      input.style.position = 'absolute'
      input.style.left = '-9999px'
      input.type = 'file'
      input.accept = 'image/*'
      input.click()
      input.onchange = async e => {
        if(!e.target.files[0]) return

        this.uploading = true

        let { result } = await this.$http({
          mode: 'form',
          url: '%CRM%/api/upload_file.sdcrm',
          data: {
            token: true,
            uploadFile: e.target.files[0]
          }
        })

        this.uploading = false

        let quill = this.$refs.quillEditor.quill
        let length = quill.getSelection().index
        quill.insertEmbed(length, 'image', result.url)
        quill.setSelection(length + 1)
      }
    },
    //上传视频
    uploadVideo(value) {
      if(!value) return

      const input = document.createElement('input')
      input.style.position = 'absolute'
      input.style.left = '-9999px'
      input.type = 'file'
      input.accept = 'video/mp4'
      input.click()
      input.onchange = async e => {
        if(!e.target.files[0]) return

        let file = e.target.files[0]

        this.uploading = true

        let { result } = await this.$http({
          url: '%CRM%/product/get_vod_sign.sdcrm',
          data: {
            token: true
          }
        })

        const tcVod = new TcVod({
          getSignature() {
            return result
          }
        })

        const uploader = tcVod.upload({
          mediaFile: file
        })

        // 频上传进度
        uploader.on('media_progress', info => {
          this.videoProgress = Math.min(info.percent, .99) * 100
        })
        uploader.done().then(doneResult => {
          this.uploading = false
          this.videoProgress = 0

          let quill = this.$refs.quillEditor.quill
          let length = quill.getSelection().index
          quill.insertEmbed(length, 'appvideo', doneResult.video.url)
          quill.setSelection(length + 1)
        })
      }
    },
    setContent(html) {
      let quill = this.$refs.quillEditor.quill.container.firstChild
      quill.innerHTML = html.replace(/>(\s+?)</g, '><').trim()
    },
  },
  mounted() {
    this.setContent(this.model[this.k])
    let q = this.$refs.quillEditor.quill.container.firstChild
    q.addEventListener('paste', (e) => {
      if(this.isHtml) {
        return
      }
      e.stopPropagation()
      e.preventDefault()
      let quill = this.$refs.quillEditor.quill
      let pasteHTML = e.clipboardData.getData('text/html').replace(/\n/g,'').replace(/>(\s+?)</g, '><').trim()
      let pasteText = e.clipboardData.getData('text').replace(/\n/g,'')
      if(pasteHTML) {
        q.innerHTML += pasteHTML.replace(/\n/g,'').trim()
      } else {
        let length = quill.selection.savedRange.index
        quill.insertText(length,pasteText)
      }
    })
  },
}
</script>

<style scoped lang="scss">
.el-form-richtext {
  width: 100%;
  height: 100%;
}
.quill-editor {
  &.preview {
    /deep/ {
      .ql-editor {
        background: #333;
        color: #FFF;
      }
    }
  }
  /deep/ {
    .ql-html-shade-box {
      background: #FFF;
      display: flex;
      justify-content: center;
      align-items: center;
      position:absolute; 
      top:0; 
      left:0; 
      width:100%; 
      height:100%; 
      cursor: pointer;
      &::before {
        content: "退出源码模式";
      }
    }
    .ql-toolbar.ql-snow {
      position: sticky;
      top: 0;
      z-index: 1;
      background: #FFF;
    }
    .ql-toolbar {
      line-height: 24px;
      border-radius: 4px 4px 0 0;
      border-color: #D9D9D9;
      svg { display: block; }
      &::after { display: none;}
    }
    .ql-container { 
      border-radius: 0 0 4px 4px;
      border-color: #D9D9D9;
    }
    .ql-editor { 
      min-height: 200px;
      &::before { 
        color: #C0C4CC;
        font-style: normal;
      }
    }
    .ql-preview {
      &::before { 
        content: "预";
        font-weight: bold;
      }
    }
    .ql-applock {
      width: 66px;
      &::before { 
        content: "登录查看";
        width:56px;
        display:inline-block;
        font-weight: bold;
      }
    }
    .ql-html {
      width: 50px;
      &::before { 
        content: "HTML";
        width:40x;
        display:inline-block;
      }
    }
    iframe {
      width: 600px;
      height: 338px;
    }
    applock {
      position: relative;
      display: block;
      background: #F5F5F5;
      &::before {
        content: "登录查看";
        position: absolute;
        left: 100%;
        top: 0;
        width: 12px;
        font-size: 12px;
        color: #BBB;
      }
      + applock {
        &::before { display: none;}
      }
    }
  }
  
}
</style>