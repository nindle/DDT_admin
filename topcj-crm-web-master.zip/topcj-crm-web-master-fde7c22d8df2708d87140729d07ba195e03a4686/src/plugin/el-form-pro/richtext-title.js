import E from 'wangeditor'
const { BtnMenu, $ } = E

//登录查看
function createQuote($childElem) {
  const $targetElem = $(`<h2></h2>`)
  $childElem.forEach(node => {
    $targetElem.append(node.clone(true))
  })
  return $targetElem
}
function bindEvent(editor) {
  function loginlockEnter(e) {
    const $selectElem = editor.selection.getSelectionContainerElem()
    const $topSelectElem = editor.selection.getSelectionRangeTopNodes()[0]
    if ($topSelectElem?.getNodeName() === 'H2') {
      if ($selectElem.getNodeName() === 'H2') {
        const selectNode = $selectElem.childNodes()?.getNode()
        editor.selection.moveCursor(selectNode)
      }
      if ($selectElem.text() === '') {
        e.preventDefault()
        $selectElem.remove()
        const $newLine = $('<p data-we-empty-p=""><br></p>')
        $newLine.insertAfter($topSelectElem)
        // 将光标移动br前面
        editor.selection.moveCursor($newLine.getNode(), 0)
      }
      if ($topSelectElem.text() === '') {
        $topSelectElem.remove()
      }
    }
  }
  editor.txt.eventHooks.enterDownEvents.push(loginlockEnter)
}

class LoginLockMenu extends BtnMenu {
  constructor(editor) {
    const $elem = E.$(
      `<div class="w-e-menu w-e-menu-title" data-title="标题">
        <i class="w-e-icon-header"></i>
      </div>`
    )
    super($elem, editor)
    bindEvent(editor)
  }
  // 菜单点击事件
  clickHandler() {
    const editor = this.editor
    const isSelectEmpty = editor.selection.isSelectionEmpty()
    let topNodeElem = editor.selection.getSelectionRangeTopNodes()
    const $topNodeElem = topNodeElem[topNodeElem.length - 1]
    const nodeName = this.getTopNodeName()
    if (nodeName === 'H2') {
      const $targetELem = $($topNodeElem.childNodes())
      const len = $targetELem.length
      let $middle = $topNodeElem
      $targetELem.forEach(elem => {
        const $elem = $(elem)
        $elem.insertAfter($middle)
        $middle = $elem
      })
      $topNodeElem.remove()
      editor.selection.moveCursor($targetELem.elems[len - 1])
      // 即时更新btn状态
      this.tryChangeActive()
    } else {
      let $quote = createQuote(topNodeElem)
            //如果选择的元素时顶层元素，就将选区移动到正确的位置
      if (editor.$textElem.equal($topNodeElem)) {
        const containerElem = editor.selection.getSelectionContainerElem()?.elems[0]
        editor.selection.createRangeByElems(
          containerElem.children[0],
          containerElem.children[0]
        )

        topNodeElem = editor.selection.getSelectionRangeTopNodes()
        $quote = createQuote(topNodeElem)
        $topNodeElem.append($quote)
      } else {
        $quote.insertAfter($topNodeElem)
      }

      this.delSelectNode(topNodeElem)
      const moveNode = $quote.childNodes()?.last().getNode()
      if (moveNode == null) return
      moveNode.textContent
          ? editor.selection.moveCursor(moveNode)
          : editor.selection.moveCursor(moveNode, 0)
      // 即时更新btn状态
      this.tryChangeActive()
      // 防止最后一行无法跳出
      $('<p data-we-empty-p=""><br></p>').insertAfter($quote)
      return
    }
    if (isSelectEmpty) {
      // 需要将选区范围折叠起来
      editor.selection.collapseRange()
      editor.selection.restoreSelection()
    }
  }
  tryChangeActive() {
    const editor = this.editor
    const cmdValue = editor.selection.getSelectionRangeTopNodes()[0]?.getNodeName()
    if (cmdValue === 'H2') {
      this.active()
    } else {
      this.unActive()
    }
  }
  getTopNodeName() {
    const editor = this.editor
    const $topNodeElem = editor.selection.getSelectionRangeTopNodes()[0]
    const nodeName = $topNodeElem?.getNodeName()

    return nodeName
  }
  delSelectNode(selectElem) {
    selectElem.forEach(node => {
      node.remove()
    })
  }
}

export default LoginLockMenu