import mammoth from 'mammoth'
import { base2file } from '../../assets/js/tool'
import { http } from '../../assets/js/http'
import E from 'wangeditor'
const { BtnMenu } = E


//清除格式功能
class CleanMenu extends BtnMenu {
  constructor(editor) {
    const $elem = E.$(
      `<div class="w-e-menu" data-title="导入Word">
        <i class="el-icon-document" style="font-size:18px;"></i>
      </div>`
    )
    super($elem, editor)
  }
  // 菜单点击事件
  clickHandler() {
    const input = document.createElement('input')
    input.style.position = 'absolute'
    input.style.left = '-9999px'
    input.type = 'file'
    input.accept = '.docx'
    input.click()
    input.onchange = async e => {
      if(!e.target.files[0]) return

      let file = e.target.files[0]

      this.editor.vue.uploading = true

      mammoth
        .convertToHtml(
          { arrayBuffer: file },
          {
            ignoreEmptyParagraphs: false,
            convertImage: mammoth.images.imgElement(async image => {
              const imageBuffer = await image.read('base64')
              const base64 = "data:" + image.contentType + ";base64," + imageBuffer
              const fileName = 'image.' + image.contentType.split('/')[1]

              const file = base2file(base64, fileName)

              let { result } = await http({
                mode: 'form',
                url: '%CRM%/api/upload_file.sdcrm',
                data: {
                  token: true,
                  uploadFile: file
                }
              })

              return {
                src: result.url
              }
            })
          }
        )
        .then(result => {
          this.editor.vue.uploading = false
          this.editor.cmd.do('insertHTML', result.value)
        })
        .catch(() => {
          this.editor.vue.$message.error('导入失败')
          this.editor.vue.uploading = false
        })
    }
  }
  tryChangeActive() {}
}

export default CleanMenu