<template>
  <el-date-picker
    v-model="model[k]"
    :popper-class="item.hideNow ? 'hide-now' : ''"
    type="year"
    :placeholder="item.placeholder || `请选择${item.label}`"
    format="yyyy"
    :value-format="item.format || 'timestamp'"
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    :disabled="item.disabled"
    @change="$emit('change')"
  ></el-date-picker>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>