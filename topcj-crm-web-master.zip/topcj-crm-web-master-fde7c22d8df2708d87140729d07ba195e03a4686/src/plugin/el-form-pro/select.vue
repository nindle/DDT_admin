<template>
  <el-select
    clearable
    :filterable="item.filterable"
    :remote="!!item.remote"
    :remote-method="item.remote"
    v-model="model[k]"
    :placeholder="item.placeholder || `请选择${item.label}`"
    :disabled="item.disabled"
    :multiple="item.multiple"
    @change="$emit('change')"
  >
    <el-option
      v-for="l in listData"
      :key="l[item.valueKey || 'value']"
      :value="l[item.valueKey || 'value']"
      :label="l[item.labelKey || 'label']"
      :disabled="l.disabled"
    >

    </el-option>
  </el-select>
</template>

<script>

export default {
  computed: {
    listData () {
      if (!this.item.filter) return this.item.options
      let filterData
      if (typeof this.item.filter === 'function') {
        filterData = this.item.filter()
      } else {
        filterData = this.item.filter
      }
      return this.item.options.filter(e => {
        let c = 0
        let l = 0
        for (let i in filterData) {
          if (e[i] === filterData[i]) {
            c++
          }
          l++
        }
        return c === l
      })
    }
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>

<style lang="scss" scoped>
.el-select {
  /deep/ {
    .el-select__tags {
      top: 4px;
      transform: translateY(0);
      .el-tag {
        white-space: unset;
        height: auto;
        line-height: 16px;
        padding: 4px 8px;
      }
    }
  }
}
</style>
