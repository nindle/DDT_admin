<template>
  <el-cascader
    clearable
    v-model="model[k]"
    :options="item.options"
    :props="{
      expandTrigger: 'hover',
      emitPath: false,
      multiple: item.multiple,
      checkStrictly: item.checkStrictly,
      children: `${item.childrenKey || 'children'}`,
      label: `${item.labelKey || 'label'}`,
      value: `${item.valueKey || 'value'}`
    }"
    :placeholder="item.placeholder || `请选择${item.label}`"
    :disabled="item.disabled"
    :show-all-levels="item.showAllLevels"
    :filterable="item.filterable"
    @change="$emit('change')"
  ></el-cascader>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>