<template>
  <el-upload
    style="margin-bottom: -8px"
    action=""
    :limit="item.limit"
    multiple
    accept="image/*"
    list-type="picture-card"
    :file-list="model[k]"
    :disabled="item.disabled"
    :http-request="uploadFileList"
    :on-remove="removeFileList"
    :on-exceed="exceedFileList"
    :class="{ limit: item.limit && item.limit <= model[k].length }"
  >
    <i class="el-icon-plus"></i>

    <template #file="{ file }">
      <div class="mask">
        <el-image
          :src="file.url"
          fit="cover"
          v-imageview:[k]="file.url"
        ></el-image>
        <i 
          class="el-icon-close"
          @click="removeFileList(file)"
        ></i>
      </div>
    </template>
  </el-upload>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  methods: {
    async uploadFileList({ file }) {
      let key = this.k
      let auto = this.item.autoUpload ?? true

      if(auto) {
        let { result } = await this.$http({
          mode: 'form',
          url: '%CRM%/api/upload_file.sdcrm',
          data: {
            token: true,
            uploadFile: file
          }
        })

        let l = result.url.split('/')
        this.model[key].push({
          name: l[l.length - 1],
          url: result.url
        })  
      }else{
        this.model[key].push({
          name: file.name,
          file
        })  
      }
    },
    removeFileList(file) {
      this.model[this.k].splice(this.model[this.k].indexOf(file), 1)
    },
    async exceedFileList(files) {
      for(let i in files) {
        if(this.item.limit > this.model[this.k].length) {
          await this.uploadFileList({ file: files[i] })
        }else{
          return
        }
      }
    },
  }
}
</script>