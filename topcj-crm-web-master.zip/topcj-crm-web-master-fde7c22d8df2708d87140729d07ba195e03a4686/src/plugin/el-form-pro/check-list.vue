<template>
  <div>
    <el-checkbox 
      v-for="(l, i) in item.options"
      :key="`${i}-${model[k].length}`"
      :checked="model[k].includes(l[item.valueKey || 'value'])" 
      :disabled="l.disabled || item.disabled"
      @change="select($event, l[item.valueKey || 'value'])"
    >{{l[item.labelKey || 'label']}}</el-checkbox>
  </div>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  methods: {
    select(type, item) {
      if(type) {
        this.model[this.k].push(item)
      }else{
        this.model[this.k].splice(this.model[this.k].indexOf(item), 1)
      }

      this.$emit('change')
    }
  }
}
</script>