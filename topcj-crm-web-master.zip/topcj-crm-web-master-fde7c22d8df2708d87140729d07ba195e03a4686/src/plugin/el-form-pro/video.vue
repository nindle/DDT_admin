<template>
  <div>
    <el-input 
      v-if="!uploading"
      :placeholder="item.placeholder || `请上传${item.label}`"
      v-model="model[k]"
      :disabled="typeof item.disabled === 'boolean' ? item.disabled : true"
      @change="$emit('change')"
    ></el-input>
    <el-input 
      v-else
      :placeholder="`${fileName}`"
      v-model="value"
      disabled
      :title="`正在上传【${fileName}】`"
    ></el-input>
    <el-button
      style="margin-left: 8px"
      @click="uploadFile"
      :loading="uploading"
      :disabled="item.disabled"
    >{{ uploading ? `${Math.floor(progress * 100)}%` : '浏览...' }}</el-button>
  </div>
</template>

<script>
import TcVod from 'vod-js-sdk-v6'

export default {
  data() {
    return {
      value: '',
      fileName: '',
      uploading: false,
      progress: 0
    }
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  methods: {
    //上传文件
    uploadFile() {
      const input = document.createElement('input')
      input.style.position = 'absolute'
      input.style.left = '-9999px'
      input.type = 'file'
      input.accept = 'video/mp4'
      input.click()
      input.onchange = async e => {
        if(!e.target.files[0]) return

        let file = e.target.files[0]

        this.fileName = file.name

        this.uploading = true

        let { result } = await this.$http({
          url: '%CRM%/product/get_vod_sign.sdcrm',
          data: {
            token: true
          }
        })

        const tcVod = new TcVod({
          getSignature() {
            return result
          }
        })

        const uploader = tcVod.upload({
          mediaFile: file
        })

        let format = this.item.format ?? '{id},{url}'

        // 频上传进度
        uploader.on('media_progress', info => {
          this.progress = Math.min(info.percent, .99)
        })
        uploader.done().then(doneResult => {
          this.uploading = false
          this.fileName = ''
          this.progress = 0

          this.model[this.k] = format.replace(/\{id\}/g, doneResult.fileId).replace(/\{url\}/g, doneResult.video.url)
        })
      }
    }
  }
}
</script>