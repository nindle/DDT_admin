<template>
  <el-select
    clearable
    filterable
    v-model="model[k]"
    :placeholder="item.placeholder || '请选择部门'"
    :disabled="item.disabled"
    :multiple="item.multiple"
    @change="$emit('change')"
  >
    <el-option
      v-for="l in groupList"
      :key="l.id"
      :value="l.id"
      :label="l.name"
    ></el-option>
  </el-select>
</template>

<script>
export default {
  computed: {
    groupList() {
      return this.$store.state.baseData.groupList
    }
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>