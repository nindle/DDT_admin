<template>
  <el-select
    clearable
    :filterable="item.filterable"
    :filter-method="filterableFn"
    :remote="!!item.remote"
    :remote-method="item.remote"
    :placeholder="item.placeholder || `请选择${item.label}`"
    v-model="model[k]"
    :disabled="item.disabled"
    @clear="clearFn"
    @focus="selectFocus"
    @remove-tag="removetagFn"
    :multiple="item.multiple"
    @change="$emit('change')"
    ref="selectTree"
  >
    <el-option
      style="height: 0"
      v-for="l in selectList"
      :key="l[item.valueKey || 'value']"
      :value="l[item.valueKey || 'value']"
      :label="l[item.labelKey || 'label']"
    >
    </el-option>
    <el-option style="height: auto;padding: 0" value="49180DEFA4FA54478C7071B5A3592BBA">
      <el-tree
        :data="item.options"
        :default-expanded-keys="[item.options[0][defaultProps.value]]"
        :node-key="defaultProps.value"
        :expand-on-click-node="false"
        :filter-node-method="filterNode"
        @node-click="handleNodeClick"
        :props="defaultProps"
        ref="reftree"
      >
        <!-- 多选高亮处理 -->
        <span 
          v-if="item.multiple"
          class="custom-tree-node"
          :class="{ active: typeof model[k] === 'object' ? model[k].includes(data[defaultProps.value]) : false }"
          slot-scope="{ node, data }" 
        >
          <i
            v-if="data.prefixIcon"
            :class="data.prefixIcon"
          ></i>
          <span class="label">
            {{ node.label }}
          </span>
          <span 
            class="treeShow"
          >
            <i class="el-icon-check"></i>
          </span>
        </span>
        <!-- 单选高亮处理 -->
        <span 
          v-else
          class="custom-tree-node" 
          :class="{ active: model[k] === data[defaultProps.value] }"
          slot-scope="{ node, data }" 
        >
          <i
            v-if="data.prefixIcon"
            :class="data.prefixIcon"
          ></i>
          <span class="label">
            {{ node.label }}
          </span>
          <span class="treeShow">
            <i class="el-icon-check"></i>
          </span>
        </span>
      </el-tree>
    </el-option>
  </el-select>
</template>

<script>
export default {
  data() {
    return {
      selectList: [],
      defaultProps: {
        children: this.item.childrenKey || 'children',
        label: this.item.labelKey || 'label',
        value: this.item.valueKey || 'value',
      }
    }
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  computed: {
    valueKeys() {
      return this.model[this.k]
    }
  },
  watch: {
    valueKeys: {
      handler(newVal) {
        this.selectList = []
        if (typeof newVal == 'object') {
          newVal.forEach(item => {
            this.selectList.push(this.recursive(item, this.item.options) == undefined ? item : this.recursive(item, this.item.options))
          })
        } else {
          if (newVal !== '') {
            this.selectList.push(this.recursive(newVal, this.item.options) == undefined ? newVal : this.recursive(newVal, this.item.options))
          }
        }
      },
      immediate: true
    }
  },

  methods: {
    // tree 选中事件
    handleNodeClick(data) {
      // 多选
      if (this.item.multiple) {
        if (this.model[this.k].indexOf(data[this.defaultProps.value]) == -1) {
          this.selectList.push(data)
          this.model[this.k].push(data[this.defaultProps.value])
        } else {
          this.model[this.k].forEach((item, i) => {
            if (item == data[this.defaultProps.value]) {
              this.model[this.k].splice(i, 1)
            }
          })
          this.selectList.forEach((item, i) => {
            if (item[this.defaultProps.value] == data[this.defaultProps.value]) {
              this.selectList.splice(i, 1)
            }
          })
        }
      }
      // 单选
      else {
        this.selectList = []
        if (this.selectList.indexOf(data) == -1) {
          this.selectList.push(data)
        }
        this.model[this.k] = data[this.defaultProps.value]
        this.$refs.selectTree.blur()
      }
      this.$emit('change')
    },
    // 全部删除
    clearFn() {
      this.selectList = []
      this.$refs.reftree.filter('')
      if (this.item.multiple) {
        this.model[this.k] = []
      } else {
        this.model[this.k] = ''
        this.selectList = []
      }
    },
    // 多选单个删除
    removetagFn(e) {
      this.selectList.forEach((item, i) => {
        if (item.id == e) {
          this.selectList.splice(i, 1)
        }
      })
    },
    // tree 过滤
    filterNode(value, data) {
      if (!value) return true
      return data[this.defaultProps.label].indexOf(value) !== -1
    },
    // 递归
    recursive(id, data) {
      for (var i = 0; i < data.length; i++) {
        let item = data[i]
        if (id == item[this.defaultProps.value]) {
          return item
        } else {
          if (item[this.defaultProps.children]) {
            var value = this.recursive(id, item[this.defaultProps.children])
            if (value) {
              return value
            }
          }
        }
      }
    },
    // select 搜索方法
    filterableFn(val) {
      this.$refs.reftree.filter(val)
    },
    // 搜索获取焦点事件
    selectFocus(e) {
      if (e.srcElement.value == '') {
        this.$refs.reftree.filter('')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.el-select {
  /deep/ {
    .el-select__tags {
      top: 4px;
      transform: translateY(0);
      .el-tag {
        white-space: unset;
        height: auto;
        line-height: 16px;
        padding: 4px 8px;
      }
    }
  }
}
/deep/ .custom-tree-node {
  width: 100%;
  display: flex;
  align-items: center;
  .label {
    margin-right: 6px;
  }
  .treeShow {
    display: none;
    margin-left: auto;
    margin-right: 6px;
    color: #3089ff;
  }
  [class^="el-icon-"], [class*=" el-icon-"]  {
    margin-right: 6px;
  }
  &.active {
    color: #3089ff;
    .treeShow { display: block;}
  }
}
/deep/ .el-tree {
  font-weight: 400;
}
</style>
