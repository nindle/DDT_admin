<template>
  <el-divider 
    content-position="left"
  >{{ item.text }}</el-divider>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>

<style lang="scss" scoped>
.el-divider--horizontal {
  margin: 12px 0;
  background-color: #EEE;
  /deep/ {
    .el-divider__text {
      color: #BBB;
      line-height: 20px;
    }
  }
}
</style>