<template>
  <el-switch
    v-model="model[k]"
    :disabled="item.disabled"
    :active-text="item.activeText"
    :inactive-text="item.inactiveText"
    :active-value="item.activeValue"
    :inactive-value="item.inactiveValue"
    @change="$emit('change')"
  ></el-switch>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>