<template>
  <el-date-picker
    v-model="model[k]"
    type="datetimerange"
    range-separator="-"
    :value-format="item.format || 'timestamp'"
    format="yyyy-MM-dd HH:mm:ss"
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    :start-placeholder="item.placeholder ? item.placeholder[0] : '开始时间'"
    :end-placeholder="item.placeholder ? item.placeholder[1] : '结束时间'"
    :default-time="['00:00:00', '23:59:59']"
    :disabled="item.disabled"
    :pickerOptions="item.pickerOptions"
    @change="$emit('change')"
  ></el-date-picker>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>