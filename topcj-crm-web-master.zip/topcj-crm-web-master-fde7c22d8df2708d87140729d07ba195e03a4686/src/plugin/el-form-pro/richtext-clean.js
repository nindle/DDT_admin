import E from 'wangeditor'
const { BtnMenu } = E

//清除格式功能
class CleanMenu extends BtnMenu {
  constructor(editor) {
    const $elem = E.$(
      `<div class="w-e-menu" data-title="清除格式">
        <i class="el-icon-brush" style="font-size:18px;"></i>
      </div>`
    )
    super($elem, editor)
  }
  // 菜单点击事件
  clickHandler() {
    let editor = this.editor
    let isSeleEmpty = editor.selection.isSelectionEmpty()
    let selectionText = editor.selection.getSelectionText()
    if (!isSeleEmpty) {
      editor.cmd.do('insertHTML', selectionText)
    }
  }
  tryChangeActive() {}
}

export default CleanMenu