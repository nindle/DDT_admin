<template>
  <el-input 
    :placeholder="item.placeholder || `请输入${item.label}`"
    type="textarea"
    :autosize="{ minRows: item.rows || 3 }"
    resize="none"
    v-model="model[k]"
    :disabled="item.disabled"
    :maxlength="item.maxLength || item.wordLimit"
    :show-word-limit="!!item.wordLimit"
    @change="$emit('change')"
  ></el-input>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>