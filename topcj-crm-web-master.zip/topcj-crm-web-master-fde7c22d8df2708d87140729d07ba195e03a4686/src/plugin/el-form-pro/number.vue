<template>
  <el-input-number 
    :placeholder="item.placeholder || `请输入${item.label}`"
    v-model="model[k]" 
    controls-position="right" 
    :disabled="item.disabled"
    :min="item.min"
    :max="item.max"
    :precision="item.precision"
    @change="$emit('change')"
  ></el-input-number>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>