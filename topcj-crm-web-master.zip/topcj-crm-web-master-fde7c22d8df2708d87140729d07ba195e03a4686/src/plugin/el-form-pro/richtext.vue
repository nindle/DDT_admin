<template>
  <el-scrollbar-pro
    ref="scroll"
    v-loading="uploading"
    :element-loading-text="`上传中...${videoProgress ? `${videoProgress}%` : ''}`"
    element-loading-background="rgba(255,255,255,.5)"
  >
    <div
      class="el-form-richtext-toolbar"
      ref="toolbar"
      v-show="!showHTML"
    ></div>
    <div
      class="el-form-richtext-container"
      ref="container"
      :style="{ '--min-height': `${minHeight}px` }"
      v-show="!showHTML"
      @click="containerClick"
    ></div>

    <div
      v-if="showHTML"
      class="el-form-richtext-toolbar-return"
      @click="exitHTMLEditor"
    >退出源码模式</div>

    <el-input
      :style="{ '--min-height': `${minHeight}px` }"
      v-if="showHTML"
      class="el-form-richtext-container-textarea"
      placeholder="请输入源码"
      type="textarea"
      resize="none"
      autosize
      v-model="model[k]"
    ></el-input>
  </el-scrollbar-pro>
</template>

<script>
import TcVod from 'vod-js-sdk-v6'
import E, { Tooltip, $ } from 'wangeditor'
import HTMLMenu from './richtext-html'
import CleanMenu from './richtext-clean'
import LoginLockMenu from './richtext-loginlock'
import TitleMenu from './richtext-title'
import mammoth from 'mammoth'
import { base2file } from '../../assets/js/tool'
// import { md5 } from '../../assets/js/crypto'
const htmlparser2 = require('htmlparser2')

const htmlparser = (str) => {
  const html = str
    .replace(/mso-bidi-/g, '')
    .replace(/font-family:.*?(;|(?="[ |>]))/g, '')
    .replace(/<!.*?>/g, '')
    .replace(/>(\s+?)</g, '><')
    .trim()

  const dom = htmlparser2.parseDocument(html)

  const result = dom2html(dom)

  return result
}

const dom2html = dom => {
  let html = ''

  switch(dom.type) {
    case 'root': {
      dom.children.forEach(e => {
        html += dom2html(e)
      })
      break
    }
    case 'tag': {
      //换行
      if(dom.name === 'br') {
        html += '<br />'
        break
      }

      //图片
      if(dom.name === 'img') {
        
        if(dom.attribs.src.indexOf('file://') === 0) {
          html += ''
          // html += `<local-img d="${md5(dom.attribs.src)}"></local-img>`
        }else{
          html += `<img src="${dom.attribs.src}" />`
        }

        break
      }

      html += '<' + dom.name
      for(let key in dom.attribs) {
        let value = dom.attribs[key]
        if(key === 'style') {
          let style = {}
          value.split(';').forEach(e => {
            let list = e.split(':')
            if(!list[0] || !list[1]) return
            let key = list[0].trim()
            let value = list[1].trim()
            if(key.indexOf('mso-') === 0) return
            if(['position', 'font-family', 'font-size', 'line-height'].includes(key)) return
            style[key] = value
          })
          value = ''
          for(let key in style) {
            value += `${key}:${style[key]};`
          }
        }
        html += ` ${key}="${value}"`
      }
      html += '>'

      let childrenHtml = ''

      dom.children.forEach(e => {
        childrenHtml += dom2html(e)
      })

      if(!childrenHtml) {
        childrenHtml = '&nbsp;'
      }

      html += `${childrenHtml}</${dom.name}>`
      break
    }
    case 'text': {
      html += dom.data
      break
    }
  }
  return html
}
// import DocxMenu from './richtext-docx'

export default {
  data () {
    return {
      editor: null,
      showHTML: false,
      minHeight: 0,

      uploading: false,
      videoProgress: 0
    }
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  methods: {
    //初始化
    init () {
      let hideTool = this.item.hideTool ?? ['loginlock']
      let uploadImgMaxLength = this.item.uploadImgMaxLength ?? 1
      this.minHeight = Math.max(this.$refs.scroll.$el.getBoundingClientRect().height, 240)
      let editor = editor = new E(this.$refs.toolbar, this.$refs.container)
      editor.config.zIndex = 500
      editor.config.focus = false
      editor.config.menuTooltipPosition = 'down'
      editor.config.placeholder = this.item.placeholder || `请输入${this.item.label}`
      //自定义提醒
      editor.config.customAlert = (s, t) => {
        switch (t) {
          case 'success':
            this.$message.success(s)
            break
          case 'info':
            this.$message.info(s)
            break
          case 'warning':
            this.$message.warning(s)
            break
          case 'error':
            this.$message.error(s)
            break
          default:
            this.$message.info(s)
            break
        }
      }
      //菜单
      if (!hideTool.includes('html')) {
        editor.menus.extend('html', HTMLMenu)
      }
      if (!hideTool.includes('clean')) {
        editor.menus.extend('clean', CleanMenu)
      }
      if (!hideTool.includes('loginlock')) {
        editor.menus.extend('loginlock', LoginLockMenu)
      }
      if (!hideTool.includes('title')) {
        editor.menus.extend('title', TitleMenu)
      }
      // if (!hideTool.includes('docx')) {
      //   editor.menus.extend('docx', DocxMenu)
      // }
      editor.config.menus = [
        'bold',
        'italic',
        'underline',
        'strikeThrough',
        'indent',
        'foreColor',
        'backColor',
        'justify',
        // 'title',
        'quote',
        // 'fontSize',
        // 'lineHeight',
        'link',
        'clean',
        'image',
        'video',
        // 'docx',
        'undo',
        'redo',
        'html',
        'loginlock'
      ].filter(e => !hideTool.includes(e))
      //字体大小
      editor.config.fontSizes = {
        'x-small': { name: '12px', value: '1' },
        'small': { name: '14px', value: '2' },
        'normal': { name: '16px', value: '3' },
        'large': { name: '18px', value: '4' },
        'x-large': { name: '20px', value: '5' },
        'xx-large': { name: '22px', value: '6' },
        'xxx-large': { name: '24px', value: '7' },
      }
      //配置颜色
      editor.config.colors = [
        '#000000',
        '#ffffff',
        '#eeece0',
        '#1c487f',
        '#4d80bf',
        '#8baa4a',
        '#7b5ba1',
        '#46acc8',
        '#f9963b', 
        '#E7322B', 
        '#228AF9', 
      ]
      //粘贴保留样式
      editor.config.pasteFilterStyle = false
      //更新事件
      editor.config.onchange = newHtml => {
        this.model[this.k] = newHtml
      }
      //上传图片
      editor.config.customUploadImg = this.uploadImage
      editor.config.showLinkImgAlt = false
      editor.config.showLinkImgHref = true
      editor.config.uploadImgMaxLength = uploadImgMaxLength
      //上传视频
      editor.config.uploadVideoAccept = ['mp4', 'MP4']
      editor.config.customUploadVideo = this.uploadVideo
      //强行校验错误，自定义插入事件
      editor.config.onlineVideoCheck = function (video) {
        if (video) {

          document.querySelectorAll('.w-e-icon-close.w-e-panel-close').forEach(e => {
            e.click()
          })
          editor.cmd.do('insertHTML', `<video src="${video}" controls="controls"></video>` + '<p data-we-empty-p=""><br></p>')
        }

        return false
      }

      editor.config.pasteTextHandle = pasteStr => {
        return htmlparser(pasteStr)
      }

      editor.config.linkImgCallback = (src, alt, href) => {
        setTimeout(() => {
          editor.history.revoke()
          const altText = alt ? `alt="${alt}" ` : ''
          const imgText = `<img src="${src}" ${altText}style="max-width:100%;" contenteditable="false" />`
          const aText = href ? `<a href="${href}" target="_blank">${imgText}</a>` : imgText
          editor.cmd.do('insertHTML', aText)
        }, 100)
      }

      editor.vue = this

      editor.create()

      //自定义事件-视频
      editor.txt.eventHooks.menuClickEvents.push(() => {
        setTimeout(() => {
          document.querySelector('.w-e-up-video-container + div > input')?.setAttribute('placeholder', '视频地址')
          const input = document.createElement('input')
          input.type = 'text'
          input.className = 'block'
          input.placeholder = '跳转链接'

          document.querySelector('.w-e-up-img-container')?.appendChild(input)
        }, 100)
      })
      if(this.item.menuClick) {
        editor.txt.eventHooks.menuClickEvents.push(this.item.menuClick)
      }

      let videoTooltip = null
      const showVideoTooltip = function ($node) {
        const conf = [
          {
            $elem: $("<span class='w-e-icon-trash-o'></span>"),
            onClick: (editor, $node) => {
              $node.remove()
              return true
            },
          },
          {
            $elem: $('<span>宽屏</span>'),
            onClick: (editor, $node) => {
              $node.attr('longside', 'x')
              return true
            },
          },
          {
            $elem: $('<span>竖屏</span>'),
            onClick: (editor, $node) => {
              $node.attr('longside', 'y')
              return true
            },
          }
        ]

        let videoTooltip = new Tooltip(editor, $node, conf)
        videoTooltip.create()
      }
      const hideVideoTooltip = function () {
        if (videoTooltip) {
          videoTooltip.remove()
          videoTooltip = null
        }
      }

      editor.txt.eventHooks.videoClickEvents = [showVideoTooltip]
      editor.txt.eventHooks.clickEvents.push(hideVideoTooltip)
      editor.txt.eventHooks.keyupEvents.push(hideVideoTooltip)
      editor.txt.eventHooks.toolbarClickEvents.push(hideVideoTooltip)
      editor.txt.eventHooks.menuClickEvents.push(hideVideoTooltip)
      editor.txt.eventHooks.textScrollEvents.push(hideVideoTooltip)
      editor.txt.eventHooks.changeEvents.push(hideVideoTooltip)

      editor.txt.html(this.model[this.k])

      this.editor = editor
    },
    async uploadImage (resultFiles, insertImgFn) {
      this.uploading = true
      const link = document.querySelector('.w-e-up-img-container input.block')?.value || void 0
      resultFiles.forEach(async (file) => {
        let { result } = await this.$http({
          mode: 'form',
          url: '%CRM%/api/upload_file.sdcrm',
          data: {
            token: true,
            uploadFile: file
          }
        })
        insertImgFn(result.url, void 0, link)
      })
      this.uploading = false
    },
    async uploadVideo (resultFiles, insertVideoFn) {
      let file = resultFiles[0]

      this.uploading = true

      let { result } = await this.$http({
        url: '%CRM%/product/get_vod_sign.sdcrm',
        data: {
          token: true
        }
      })

      const tcVod = new TcVod({
        getSignature () {
          return result
        }
      })

      const uploader = tcVod.upload({
        mediaFile: file
      })

      // 频上传进度
      uploader.on('media_progress', info => {
        this.videoProgress = Math.min(info.percent, .99) * 100
      })
      uploader.done().then(doneResult => {
        this.uploading = false
        this.videoProgress = 0

        insertVideoFn(doneResult.video.url)
      })
    },
    containerClick(event) {
      if(event.target.nodeName === 'LOCAL-IMG') {
        this.pasteImage(event.target)
      }
    },
    //补充粘贴
    pasteImage(target) {
      if(!target) return

      const id = target.getAttribute('d')

      const input = document.createElement('input')
      input.style.position = 'absolute'
      input.style.left = '-9999px'
      input.type = 'file'
      input.accept = '.docx,image/*'
      input.click()
      input.onchange = async e => {
        if(!e.target.files[0]) return

        let file = e.target.files[0]

        this.editor.vue.uploading = true

        if(file.type.indexOf('image') === 0) {
          let { result } = await this.$http({
            mode: 'form',
            url: '%CRM%/api/upload_file.sdcrm',
            data: {
              token: true,
              uploadFile: file
            }
          })
          this.editor.vue.uploading = false

          const reg = new RegExp(`<local-img[^<>]*?d="${id}".*?>.*?</local-img>`)
          this.editor.txt.html(this.model[this.k].replace(reg, `<img src="${result.url}" />`))
        }else{
          mammoth.convertToHtml(
            { arrayBuffer: file },
            {
              ignoreEmptyParagraphs: false,
              convertImage: mammoth.images.imgElement(async image => {
                const imageBuffer = await image.read('base64')
                const base64 = "data:" + image.contentType + ";base64," + imageBuffer

                const fileName = 'image.' + image.contentType.split('/')[1]

                const file = base2file(base64, fileName)

                let { result } = await this.$http({
                  mode: 'form',
                  url: '%CRM%/api/upload_file.sdcrm',
                  data: {
                    token: true,
                    uploadFile: file
                  }
                })

                this.editor.txt.html(this.model[this.k].replace(/<local-img.*?>.*?<\/local-img>/, `<img src="${result.url}" />`))
                return {
                  src: result.url
                }
              })
            }
          ).then(() => {
            this.editor.vue.uploading = false
          })
        }
      }
    },
    //退出源码编辑
    exitHTMLEditor () {
      this.showHTML = false
      this.model[this.k] = this.model[this.k].replace(/&quot;/g, `'`).replace(/\n/g, '').replace(/&nbsp;/g, ' ')
      this.editor.txt.html(this.model[this.k])
    }
  },
  mounted () {
    this.init()
  },
  beforeDestroy () {
    this.editor.destroy()
    this.editor = null
  }
}
</script>

<style scoped lang="scss">
@import '../../assets/css/common.scss';

.scrollbar {
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  overflow: hidden;
}
.el-form-richtext-toolbar,
.el-form-richtext-toolbar-return {
  position: sticky;
  top: 0;
  border-bottom: 1px solid #d9d9d9;
  z-index: 2;
}
.el-form-richtext-toolbar-return {
  text-align: center;
  line-height: 40px;
  background: #fff;
  cursor: pointer;
}
.el-form-richtext-container-textarea {
  position: relative;
  z-index: 1;
  font-size: 14px;
  min-height: var(--min-height);
  width: 100% !important;
  display: block;
  /deep/ {
    .el-textarea__inner {
      border: none;
      min-height: var(--min-height) !important;
    }
  }
}
.el-form-richtext-container {
  position: relative;
  z-index: 1;
  min-height: var(--min-height);
  /deep/ {
    local-img {
      position: relative;
      width: 300px;
      height: 50px;
      display: inline-block;
      background: rgba(#3089FF, .24);
      border: 1px solid #3089FF;
      color: #3089FF;
      cursor: pointer;
      border-radius: 4px;
      text-align: center;
      font-size: 16px !important;
      &::before {
        content: "本地图片";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
      }
      &::after {
        content: "请点击上传图片或Word文档";
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
      }
    }
    .w-e-text-container,
    .w-e-text {
      min-height: var(--min-height);
    }
    .w-e-text p,
    .w-e-text h1,
    .w-e-text h2,
    .w-e-text h3,
    .w-e-text h4,
    .w-e-text h5,
    .w-e-text h6,
    .w-e-text table,
    .w-e-text pre {
      margin: 0;
    }
    .w-e-text * {
      font-size: 18px !important;
      line-height: 33px !important;
    }
    .w-e-text loginlock {
      display: block;
      @include image(tichtext-loginlock, 'top left, #F5F5F5');
      &:hover {
        box-shadow: 0 0 5px #333;
      }
    }
    .w-e-text-container .placeholder {
      top: 0;
    }
    .w-e-text a {
      // text-decoration: underline;
      color: #06c;
      cursor: pointer;
    }
    .w-e-text h2 {
      font-size: 20px !important;
      line-height: 38px !important;
    }
    .w-e-text blockquote,.w-e-text blockquote * {
      border-left: none;
      padding: 0;
      margin: 0;
      line-height: inherit;
      background: none;
      font-size: 11px !important;
      line-height: 15px !important;
      color: #999;
    }
    font[size='1'] {
      font-size: 12px;
    }
    font[size='2'] {
      font-size: 14px;
    }
    font[size='3'] {
      font-size: 16px;
    }
    font[size='4'] {
      font-size: 18px;
    }
    font[size='5'] {
      font-size: 20px;
    }
    font[size='6'] {
      font-size: 22px;
    }
    font[size='7'] {
      font-size: 24px;
    }
    img {
      max-width: 100%;
    }
    iframe,
    video {
      width: 600px;
      height: 338px;
      background: #333;
      &[longside='y'] {
        width: 300px;
        height: 600px;
      }
    }
    video {
      margin: 0 auto;
      display: block;
    }
  }
}
</style>