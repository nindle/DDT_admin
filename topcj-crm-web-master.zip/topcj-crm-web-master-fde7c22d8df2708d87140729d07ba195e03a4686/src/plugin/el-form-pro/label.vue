<template>
  <div class="label-text">{{model[k]}}</div>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>