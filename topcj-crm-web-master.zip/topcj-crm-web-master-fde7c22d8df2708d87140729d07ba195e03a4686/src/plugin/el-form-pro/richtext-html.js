import E from 'wangeditor'
const { BtnMenu } = E

//编辑源码功能
class HTMLMenu extends BtnMenu {
  constructor(editor) {
    const $elem = E.$(
      `<div class="w-e-menu" data-title="源码编辑">
        <i class="el-icon-edit-outline" style="font-size:18px;"></i>
      </div>`
    )
    super($elem, editor)
  }
  // 菜单点击事件
  clickHandler() {
    this.editor.vue.showHTML = true
  }
  tryChangeActive() {}
}


export default HTMLMenu