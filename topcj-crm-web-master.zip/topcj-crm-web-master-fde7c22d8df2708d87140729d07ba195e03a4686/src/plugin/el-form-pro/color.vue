<template>
  <el-color-picker
    v-model="model[k]"
    :disabled="item.disabled"
    :show-alpha="item.alpha"
    :predefine="item.predefine"
    @change="$emit('change')"
  ></el-color-picker>
</template>

<script>
export default {
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  }
}
</script>