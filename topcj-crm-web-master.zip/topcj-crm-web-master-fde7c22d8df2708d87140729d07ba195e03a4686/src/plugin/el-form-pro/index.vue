<!--
  form
    config
      key 键值
        label 标题
        placeholder 占位
        type 类型
        hide 隐藏
        disabled 禁用
        change 更改事件

        --select 选择框配置
        options 选项
        valueKey
        labelKey
        filterable
        multiple

        --select-manager 选择员工配置
        filter 过滤
        multiple

        --select-corp 选择分公司配置
        corpLock 分公司禁用，自动选择分公司
        multiple

        --date/date-time 时间框配置
        format 格式化

        --file 单文件配置
        uploading 上传状态
        accept 上传类型

        --file-list 多文件配置
        accept 上传类型

        --image 图片
-->

<template>
  <el-form :model="model" :rules="rules" label-width="auto" @submit.native.prevent ref="form" :validate-on-rule-change="false">
    <el-form-item v-for="e in authConfig" :key="e.key" :label="e.label" :prop="e.key" :class="`form-item-${e.key}`" >
      <slot :name="e.configKey" :index="e.modelKey" :model="e.model">
        <component :is="getType(e.type)" :item="e" :model="e.model" :k="e.modelKey" @change="inputChange(e)" />
        <slot :name="`${e.configKey}-unit`" :index="e.modelKey" :model="e.model">
          <span v-if="e.unit" class="unit-text">{{ e.unit }}</span>
        </slot>
      </slot>
    </el-form-item>
  </el-form>
</template>

<script>
import FormInput from './input'
import FormTextarea from './textarea'
import FormNumber from './number'
import FormLabel from './label'
import FormSplit from './split'
import FormSelect from './select'
import FormSelectManager from './select-manager'
import FormSelectCorp from './select-corp'
import FormSwitch from './switch'
import FormDate from './date'
import FormDateTime from './date-time'
import FormDateRange from './date-range'
import FormFile from './file'
import FormFileList from './file-list'
import FormImage from './image'
import FormImageList from './image-list'
import FormSelectPlate from './select-plate'
import FormSelectStockIndexPlate from './select-stock-index-plate'
import FormSelectStock from './select-stock'
import FormSelectQywx from './select-qywx'
import FormSelectGroup from './select-group'
import FormSelectTree from './select-tree'
import FormCheckList from './check-list'
import FormButton from './button'
import FormVideo from './video'
import FormColor from './color'
import FormImageNoupload from './image-noupload'
import FormDateYear from './date-year'
import FormCascader from './cascader'
import FormDateTimeRange from './date-time-range'

export default {
  data() {
    return {}
  },
  props: {
    model: Object,
    config: Object
  },
  computed: {
    authConfig() {
      let list = []
      Object.keys(this.config).forEach(k => {
        let e = this.config[k]
        if (typeof e.hide === 'function' ? e.hide(this.model) : e.hide) return
        if (e.each) {
          this.model[k].forEach((a, i) => {
            list.push({
              ...e,
              model: this.model[k],
              configKey: k,
              modelKey: i,
              key: `${k}-${i}`,
              label: typeof e.label === 'function' ? e.label(i) : e.label
            })
          })
          return
        }

        list.push({
          ...e,
          model: this.model,
          configKey: k,
          modelKey: k,
          key: k
        })
      })

      return list
    },
    rules() {
      let rules = {}
      this.authConfig.forEach(e => {
        if (e.rule) {
          rules[e.key] = e.rule.map(a => {
            let b = { ...a }
            if (b.required && !b.message) {
              let text = ''
              switch (e.type) {
                case 'select':
                case 'select-manager':
                case 'select-corp':
                case 'select-plate':
                case 'select-stock':
                case 'select-stock-index-plate':
                case 'select-group':
                case 'select-qywx':
                case 'select-tree':
                case 'date':
                case 'date-time':
                case 'date-range':
                case 'date-time-range':
                case 'date-year':
                case 'switch':
                case 'check-list':
                case 'color':
                case 'button':
                case 'cascader':
                  text = '请选择'
                  break
                case 'file':
                case 'file-list':
                case 'image':
                case 'image-noupload':
                case 'image-list':
                case 'video':
                  text = '请上传'
                  break
                case 'richtext':
                case 'richtext-next':
                case 'textarea':
                case 'number':
                case 'label':
                case 'input':
                default:
                  text = '请输入'
                  break
              }
              b.message = `${text}${e.label}`
            }
            return b
          })
        }
      })
      return rules
    }
  },
  components: {
    FormInput,
    FormTextarea,
    FormNumber,
    FormLabel,
    FormSelect,
    FormSelectManager,
    FormSelectCorp,
    FormSwitch,
    FormDate,
    FormDateTime,
    FormDateYear,
    FormDateRange,
    FormFile,
    FormFileList,
    FormImage,
    FormImageList,
    FormRichtext: () => import('./richtext'),
    FormRichtextNext: () => import('./richtext.next'),
    FormSelectPlate,
    FormSelectStock,
    FormSelectQywx,
    FormSelectGroup,
    FormSelectTree,
    FormCheckList,
    FormButton,
    FormVideo,
    FormColor,
    FormImageNoupload,
    FormCascader,
    FormSplit,
    FormDateTimeRange,
    FormSelectStockIndexPlate
  },
  methods: {
    //获取类型
    getType(type) {
      switch (type) {
        case 'textarea':
          return 'FormTextarea'
        case 'number':
          return 'FormNumber'
        case 'label':
          return 'FormLabel'
        case 'select':
          return 'FormSelect'
        case 'select-manager':
          return 'FormSelectManager'
        case 'select-corp':
          return 'FormSelectCorp'
        case 'select-plate':
          return 'FormSelectPlate'
        case 'select-stock':
          return 'FormSelectStock'
        case 'select-stock-index-plate':
          return 'FormSelectStockIndexPlate'
        case 'select-group':
          return 'FormSelectGroup'
        case 'select-tree':
          return 'FormSelectTree'
        case 'select-qywx':
          return 'FormSelectQywx'
        case 'switch':
          return 'FormSwitch'
        case 'date':
          return 'FormDate'
        case 'date-time':
          return 'FormDateTime'
        case 'date-time-range':
          return 'FormDateTimeRange'
        case 'date-year':
          return 'FormDateYear'
        case 'date-range':
          return 'FormDateRange'
        case 'file':
          return 'FormFile'
        case 'file-list':
          return 'FormFileList'
        case 'image':
          return 'FormImage'
        case 'image-list':
          return 'FormImageList'
        case 'richtext':
          return 'FormRichtext'
        case 'richtext-next':
          return 'FormRichtextNext'
        case 'check-list':
          return 'FormCheckList'
        case 'button':
          return 'FormButton'
        case 'video':
          return 'FormVideo'
        case 'color':
          return 'FormColor'
        case 'image-noupload':
          return 'FormImageNoupload'
        case 'cascader':
          return 'FormCascader'
        case 'split':
          return 'FormSplit'
        case 'input':
        default:
          return 'FormInput'
      }
    },
    //数值变更
    inputChange(item) {
      if (item.type === 'richtext') {
        this.validateField(item.key)
      }

      if (typeof item.change !== 'function') return

      item.change(this.model[item.key], this.model)
    },
    //检查
    check() {
      let dom = this.$refs.form
      return new Promise(function(resolve) {
        dom.validate(valid => {
          if (!valid) {
            dom.$el.querySelector('.is-error')?.scrollIntoView({ block: 'center' })
          }
          resolve(valid)
        })
      })
    },
    validateField(key) {
      this.$refs.form.validateField(key)
    },
    scrollIntoView(key) {
      let dom = this.$refs.form
      dom.$el.querySelector(`.form-item-${key}`)?.scrollIntoView(true)
    }
  }
}
</script>

<style scoped lang="scss">
@import '../../assets/css/common.scss';

.el-form {
  /deep/ {
    .el-color-picker {
      vertical-align: top;
    }
    .el-input-number {
      width: 256px;
      .el-input__inner {
        text-align: left !important;
      }
    }
    .label-text {
      line-height: 24px;
      padding: 8px 0;
    }
    .unit-text {
      line-height: 24px;
      padding: 8px;
    }
    .el-input {
      width: 256px;
      .el-input__count {
        position: relative;
        left: calc(100% + 8px);
      }
    }
    .el-select {
      width: 256px;
    }
    .el-textarea {
      width: 256px;
      .el-textarea__inner {
        overflow: hidden;
      }
      .el-input__count {
        position: absolute;
        left: calc(100% + 8px);
        line-height: 20px;
        width: fit-content;
      }
    }
    .el-date-editor--daterange.el-input__inner {
      width: 256px;
    }
    .input-image {
      width: 256px;
      height: 144px;
      vertical-align: top;
      border-radius: 4px;
      cursor: pointer;
      &.size-large {
        width: 256px;
        height: 144px;
      }
      &.size-medium {
        width: 167px;
        height: 94px;
      }
      &.size-small {
        width: 40px;
        height: 40px;
      }
    }
    .limit {
      .el-upload--picture-card {
        display: none;
      }
    }
    .el-upload-list--picture-card {
      display: inline-block;
      .el-upload-list__item {
        width: 60px;
        height: 60px;
        vertical-align: top;
        overflow: unset;
        .mask {
          position: relative;
          width: 100%;
          height: 100%;
          .el-image {
            width: 100%;
            height: 100%;
            cursor: pointer;
            border-radius: 4px;
          }
          .el-icon-close {
            display: block;
            position: absolute;
            right: -6px;
            top: -6px;
            background: #f56c6c;
            border-radius: 50%;
            color: #fff;
            font-size: 12px;
          }
        }
      }
    }
    .el-upload--picture-card {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      width: 60px;
      height: 60px;
      margin-bottom: 8px;
      i {
        font-size: 16px;
      }
    }
    .is-error {
      .ql-toolbar,
      .ql-container {
        border-color: #f56c6c;
      }
    }
  }
}

.stock-label {
  padding-left: 6px;
  /deep/ b {
    color: $--color-main;
  }
}
</style>
