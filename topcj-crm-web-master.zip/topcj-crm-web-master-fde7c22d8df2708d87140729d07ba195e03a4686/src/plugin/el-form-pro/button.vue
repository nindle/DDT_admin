<template>
  <el-button
    :type="item.buttonType"
    size="small"
    :icon="item.icon"
    :disabled="item.disabled"
    @click="item.click(model)"
    :plain="item.plain"
  >{{item.buttonLabel}}</el-button>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>