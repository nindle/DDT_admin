<template>
  <!-- layout="total, sizes, prev, pager, next, jumper" -->
  <el-pagination
    :total="total"
    :layout="layoutString"
    :page-sizes="pageSizes"
    :page-size="pageSize"
    :pager-count="7"
    :current-page="pageNum"
    :background="background"
    :small="small"
    @size-change="changeSize"
    @current-change="changeCurrent"
  >
    <button type="button" class="btn-prev" :disabled="pageNum === 1 || pageCount === 0" @click="changeCurrent(1)">
      <i class="el-icon el-icon-d-arrow-left"></i>
    </button>
    <button type="button" class="btn-next" :disabled="pageNum === pageCount || pageCount === 0" @click="changeCurrent(pageCount)">
      <i class="el-icon el-icon-d-arrow-right"></i>
    </button>
  </el-pagination>
</template>

<script>
export default {
  data() {
    return {
      pageSizes: [10, 50, 100, 300, 500, 1000]
    }
  },
  props: {
    total: Number,
    pageNum: Number,
    pageSize: Number,
    background: {
      type: Boolean,
      default: true
    },
    small: Boolean,
    layout: {
      type: String,
      default() {
        return this.$store.state.sysMode === 1 ? 'normal' : 'simple'
      }
    }
  },
  computed: {
    pageCount() {
      return Math.ceil(this.total / this.pageSize)
    },
    layoutString() {
      switch (this.layout) {
        case 'default':
          return 'sizes, prev, next'
        case 'simple':
          return 'sizes, prev, next'
        case 'normal':
          return 'total, sizes, prev, pager, next, jumper'
        default:
          return this.layout
      }
    }
  },
  methods: {
    changeSize(size) {
      this.$emit('update:page-size', size)
      if (this.pageNum > 1) {
        this.changeCurrent(1)
      } else {
        this.$emit('change')
      }
    },
    changeCurrent(num) {
      this.$emit('update:page-num', num)
      this.$emit('change')
    }
  }
}
</script>
