const deepCopy = function(item) {
  let result
  switch(Object.prototype.toString.apply(item).slice(8, -1).toLowerCase()) {
    case 'number':
    case 'string':
    case 'boolean':
    case 'symbol':
    case 'bigint':
    case 'promise':
      result = item
      break
    case 'null':
      result = null
      break
    case 'undefined':
      result = undefined
      break
    case 'function':
      result = function() { item.apply(this, arguments) }
      break
    case 'asyncfunction':
      result = async function() { await item.apply(this, arguments) }
      break
    case 'array':
      result = []
      for(let i in item) {
        result.push(deepCopy(item[i]))
      }
      break
    case 'object':
      result = {}
      for(let i in item) {
        result[i] = deepCopy(item[i])
      }
      break
    case 'date':
      result = new Date(item.valueOf())
      break
    case 'regexp':
      result = new RegExp(item)
      break
    case 'set':
      result = new Set([...item])
      break
    case 'map':
      result = new Map([...item])
      break
    default:
      result = item
      break
  }
  return result
}

export default deepCopy