<template>
  <div 
    class="ks-menu"
    :class="{
      'ks-animation--enter': animation.enter,
      'ks-animation--active': animation.active,
      'ks-animation--leave': animation.leave
    }"
    :style="{ left, top, height }"
    ref="menu"
  >
    <div
      class="ks-menu-group"
      v-for="(g, i) in menu.data"
      :key="i"
    >
      <div 
        class="ks-menu-item"
        :class="{'ks-menu-item--disabled': e.disabled, 'ks-menu-item--default': e.children}"
        v-for="e in g"
        :key="e.id"
        @click="select(e)"
        @mouseenter="mouseenter(e, $event)"
        ref="item"
      >
        <span 
          v-if="menu.iconShow"
          class="ks-menu-item__icon"
          :class="e.icon"
        >
        </span>
        <span class="ks-menu-item__title">{{ e.title }}</span>
        <span 
          v-if="menu.subShow || menu.moreShow"
          class="ks-menu-item__split"
        ></span>
        <span 
          v-if="menu.subShow"
          class="ks-menu-item__subtitle"
        >{{ e.subTitle }}</span>
        <span
          v-if="menu.moreShow"
          :class="{ 'ks-menu-item__more--children': e.children}"
          class="ks-menu-item__more"
        ></span>
      </div>
    </div>
  </div>
</template>

<script>
const $sleep = function(time) {
  return new Promise(function(resolve) {
    setTimeout(() => {
      resolve()
    }, time)
  })
}

export default {
  data() {
    return {
      //菜单列表
      menu: {
        //开启图标
        iconShow: false,
        subShow: false,
        moreShow: false,
        data: []
      },
      //定位
      left: '0',
      top: '0',
      height: 'auto',
      //动画
      animation: {
        enter: false,
        active: false,
        leave: false
      },
      //保存的子实例
      children: {
        id: 0,
        vue: null
      }
    }
  },
  created() {
    this.init(this.option)
  },
  methods: {
    //初始化
    async init({event, menu, box}) {
      this.menu = menu
      this.show = true
      
      await this.$nextTick()

      let item = this.$refs.menu.getBoundingClientRect()
      this.height = `${item.height}px`

      if(event) {
        //点击事件
        let clientX = event.clientX
        let clientY = event.clientY
        let width = item.width + 3
        let height = item.height + 3

        if(clientX + width > document.documentElement.clientWidth) {
          this.left = `${clientX - width}px`
        }else{
          this.left = `${clientX + 3}px`
        }

        if(clientY + height > document.documentElement.clientHeight) {
          this.top = `${clientY - height}px`
        }else{
          this.top = `${clientY + 3}px`
        }
      }else if(box) {
        //盒子
        let boxR = box.right
        let boxL = box.left
        let boxB = box.bottom
        let boxT = box.top
        let width = item.width
        let height = item.height - 6

        if(boxR + width > document.documentElement.clientWidth) {
          this.left = `${boxL - width}px`
        }else{
          this.left = `${boxR}px`
        }

        if(boxB + height > document.documentElement.clientHeight) {
          this.top = `${boxB - height}px`
        }else{
          this.top = `${boxT - 6}px`
        }
      }

      this.animation.enter = true
      this.animation.active = true

      await $sleep(20)
      
      this.animation.enter = false
    },
    //选择
    select(item) {
      if(item.disabled) return
      if(typeof item.handler !== 'function') return

      item.handler()

      let parent = this
      do{
        parent = parent.option.parent
      }while(parent && parent.option.parent)

      if(parent) {
        parent.hide()
      }else{
        this.hide()
      }
    },
    //隐藏
    async hide() {
      this.animation.leave = true

      if(this.children.vue) this.children.vue.hide()

      await $sleep(300)

      this.remove()
    },
    //选择
    mouseenter(item) {
      //非当前子集
      if(this.children.id !== 0 && item.id !== this.children.id) {
        this.children.vue.hide()
        this.children = {
          id: 0,
          vue: null
        }
      }
      //当前子集
      if(item.id === this.children.id) return

      if(!item.children || item.disabled) return
      
      this.children = {
        id: item.id,
        vue: this._$contextmenu({
          box: this.$refs.item[item.id - 1].getBoundingClientRect(),
          menu: item.children,
          parent: this,
        }, this.$refs.item[item.id - 1])
      }
    }
  }
}
</script>

<style scoped lang="scss">
.ks-menu {
  position: fixed;
  min-width: 100px;
  background: #FFF;
  border-radius: 2px;
  box-shadow: 0 2px 12px 0 rgba(#000, 0.1);
  z-index: 8888;
  left: calc(var(--left) * 1px);
  top: calc(var(--top) * 1px);
  height: calc(var(--height) * 1px);
  overflow: hidden;
  &.ks-animation--active { transition: height .3s;}
  &.ks-animation--enter,
  &.ks-animation--leave { height: 0 !important;}
  > .ks-menu-group {
    &::after {
      content: "";
      display: block;
      width: calc(100% - 24px);
      height: 1px;
      background: #F5F5F5;
      margin: 6px 12px;
    }
    &:first-child { margin-top: 6px;}
    &:last-child { 
      margin-bottom: 6px;
      &::after { display: none;}
    }
    > .ks-menu-item {
      font-size: 12px;
      line-height: 26px;
      height: 26px;
      padding: 0 12px;
      color: #333;
      display: flex;
      cursor: pointer;
      > span {
        &.ks-menu-item__icon { 
          width: 16px;
          height: 16px;
          margin: 5px 6px 5px 0;
          background-size: contain;
          background-position: center;
          background-repeat: no-repeat;
          filter: grayscale(1) brightness(0.5);
          display: flex;
          align-items: center;
        }
        &.ks-menu-item__split {
          width: 24px;
          margin-left: auto;
        }
        &.ks-menu-item__subtitle { color: #BBB;}
        &.ks-menu-item__more {
          position: relative;
          width: 12px;
          &.ks-menu-item__more--children::before {
            content: "";
            position: absolute;
            top: 10px;
            left: 6px;
            width: 6px;
            height: 6px;
            border-bottom: 1px solid #BBB;
            border-right: 1px solid #BBB;
            transform-origin: 3px 6px;
            transform: rotate(-45deg);
            transition: transform .3s;
          }
        }
      }
      &:hover {
        color: #409EFF;
        background: rgba(#409EFF, .1);
        > span {
          &.ks-menu-item__icon { filter: none;}
        }
      }
      &.ks-menu-item--disabled {
        color: #CCC;
        background: none;
        cursor: default;
        > span {
          &.ks-menu-item__icon { 
            filter: grayscale(1) opacity(.6);
          }
          &.ks-menu-item__subtitle { color: #CCC;}
          &.ks-menu-item__more.ks-menu-item__more--children::before { 
            border-bottom-color: #CCC;
            border-right-color: #CCC;
          }
        }
      }
      &.ks-menu-item--default { cursor: default;}
    }

  }
}
</style>
