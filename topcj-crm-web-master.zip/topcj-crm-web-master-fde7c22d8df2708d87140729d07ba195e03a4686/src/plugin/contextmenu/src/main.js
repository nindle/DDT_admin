import Vue from 'vue'
import Menu from './menu'
import $deepCopy from './utils/deep-copy'

let MenuConstructor = Vue.extend(Menu)

let options = []
let timer = null

const contextMenu = function(option) {
  //捕捉事件
  options.push($deepCopy(option))
  clearTimeout(timer)
  timer = setTimeout(() => {
    analyzeOption(options)
    options = []
  }, 20)
}

//解析菜单插槽
const analyzeOption = function(_options) {
  let option = _options[0]
  let options = _options.slice(1)
  let options_name = options.map(e => e.name)

  if(!options.length) {
    option.menu = analyzeMenu(option.menu, option.name)
    createParent(option)
    return
  }

  //插槽储存
  let handler = []
  //查找插槽
  const _find = function(_array) {
    for(let i in _array) {
      if(_array[i] instanceof Array) {
        _find(_array[i])
      }else if(_array[i].slot) {
        let index
        if(_array[i].slot === '*') index = 0
        else index = options_name.indexOf(_array[i].slot)
        if(index > -1) {
          handler.push([_array, _array[i], options[index].menu])
          options.splice(index, 1)
          options_name.splice(index, 1)
        }
      }else if(_array[i].children instanceof Array) {
        _find(_array[i])
      }
    }
  }

  _find(option.menu)

  if(handler.length) {
    handler.forEach(e => {
      let index = e[0].indexOf(e[1])
      if(index > -1) {
        e[2].unshift(index, 1)
        Array.prototype.splice.apply(e[0], e[2])
      }
    })
    if(options.length) {
      analyzeOption([
        option,
        ...options
      ])
    }else{
      option.menu = analyzeMenu(option.menu, option.name)
      createParent(option)
    }
  }else{
    option.menu = analyzeMenu(option.menu, option.name)
    createParent(option)
  }
}

//解析菜单数组
const analyzeMenu = function(_menu = [], _name) {
  let id = 0
  let menu = {
    iconShow: false,
    subShow: false,
    moreShow: false,
    data: [[]]
  }

  const _push = ({icon, title, subTitle, handler, disabled = false, enabled, hide = false, show, children, noHandler = 'disabled'}) => {
    if(!title) return
    //隐藏设置
    if(typeof hide === 'string') hide = [hide]
    if(typeof show === 'string') show = [show]
    let _hide
    if(typeof hide === 'boolean') _hide = hide
    if(typeof show === 'boolean') _hide = !show
    if(hide instanceof Array) _hide = hide.includes(_name)
    if(show instanceof Array) _hide = !show.includes(_name)
    if(_hide) return

    //解析子集
    if(children) children = analyzeMenu(children, _name)
    //判断子集
    children = children && children.data.length ? children : undefined
    //有子集取消事件
    if(children) handler = undefined
    //禁用设置
    if(!handler && !children) {
      if(noHandler === 'disabled') {
        disabled = true
      }else if(noHandler === 'hide'){
        return
      }
    }else {
      if(typeof disabled === 'string') disabled = [disabled]
      if(typeof enabled === 'string') enabled = [enabled]
      let _disabled
      if(typeof disabled === 'boolean') _disabled = disabled
      if(typeof enabled === 'boolean') _disabled = !enabled
      if(disabled instanceof Array) _disabled = disabled.includes(_name)
      if(enabled instanceof Array) _disabled = !enabled.includes(_name)
      disabled = _disabled
    }
    
    if(icon && !menu.iconShow) menu.iconShow = true
    if(subTitle && !menu.subShow) menu.subShow = true
    if(children && !menu.moreShow) menu.moreShow = true

    menu.data[menu.data.length - 1].push({
      id: ++id,
      icon,
      title,
      subTitle,
      handler,
      disabled,
      children
    })
  }

  _menu.forEach(item => {
    if(item instanceof Array) {
      //数组
      menu.data.push([])
      item.forEach(e => { 
        if(e instanceof Object) {
          _push(e)
        }
      })
      menu.data.push([])
    }else{
      _push(item)
    }
  })

  menu.data = menu.data.filter(e => e.length)

  return menu
}

let instanceList = []

//创建父组件
const createParent = function(option) {
  if(instanceList.length) {
    instanceList.forEach(e => {
      e.hide()
    })
    instanceList = []
  }

  let instance = new MenuConstructor({
    data: {
      option
    },
    methods: {
      remove() {
        if(instance._isDestroyed) return
        document.body.removeChild(instance.$el)
        document.removeEventListener('click', close)
        document.removeEventListener('contextmenu', close)
        if(!instance._isDestroyed) instance.$destroy()
      }
    }
  })
  instance.$mount()
  document.body.appendChild(instance.$el)

  let close = function(event) {
    if(!instance.$el.contains(event.target)) {
      instance.hide()
    }
  }

  instanceList.push(instance)

  setTimeout(() => {
    document.addEventListener('click', close)
    document.addEventListener('contextmenu', close)
  }, 20)
}

//创建子组件
const createChilldren = function(option, dom) {
  if(!(option.parent instanceof MenuConstructor)) return

  let instance = new MenuConstructor({
    data: {
      option
    },
    methods: {
      remove() {
        if(instance._isDestroyed) return
        dom.removeChild(instance.$el)
        if(!instance._isDestroyed) instance.$destroy()
      }
    }
  })
  instance.$mount()
  dom.appendChild(instance.$el)

  return instance
}


//指令形式
const contextmenuDirective = {
  bind(el, binding) {
    el.__contextmenuValue__ = binding.value
    el.__contextmenuEvent__ = binding.arg ?? 'contextmenu'
    el.__contexrmenuEventPrevent__ = binding.modifiers.prevent

    el.__contextmenuHandler__ = e => {
      contextMenu({
        event: e,
        name: el.getAttribute('contextmenu-name'),
        menu: el.__contextmenuValue__
      })

      if(el.__contexrmenuEventPrevent__) {
        e.preventDefault()
      }
    }

    el.addEventListener(el.__contextmenuEvent__, el.__contextmenuHandler__)
  },
  update(el, binding) {
    if((binding.arg ?? 'contextmenu') !== el.__contextmenuEvent__) {
      el.removeEventListener(el.__contextmenuEvent__, el.__contextmenuHandler__)
      el.__contextmenuEvent__ = binding.arg ?? 'contextmenu'
      el.addEventListener(el.__contextmenuEvent__, el.__contextmenuHandler__)
    }

    el.__contexrmenuEventPrevent__ = binding.modifiers.prevent
  },
  unbind(el) {
    el.removeEventListener(el.__contextmenuEvent__, el.__contextmenuHandler__)
    delete el.__contextmenuValue__
    delete el.__contextmenuEvent__
    delete el.__contextmenuHandler__
    delete el.__contexrmenuEventPrevent__
  }
}


export { contextMenu, createChilldren, contextmenuDirective }