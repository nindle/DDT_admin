import { contextMenu, createChilldren, contextmenuDirective } from './src/main'

let index = {}
index.install = function(Vue) {
  Vue.directive('contextmenu', contextmenuDirective)
  Vue.prototype.$contextmenu = contextMenu
  Vue.prototype._$contextmenu = createChilldren
}

export default index