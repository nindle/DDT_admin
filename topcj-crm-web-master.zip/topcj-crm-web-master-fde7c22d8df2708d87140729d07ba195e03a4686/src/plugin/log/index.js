import { http } from '../../assets/js/http'

const log = function(moduleId, operateId, operateType, navId, infoId, subId, infoName) {
  http({
    url: '%CRM%/api/qy_manager_log.sdcrm',
    data: {
      token: true,
      moduleId,
      operateId,
      operateType,
      navId,
      infoId,
      subId,
      infoName
    }
  })

  if(operateId === 10) {
    //搜索
    http({
      url: '%CRM%/user/message/compliance_mode_search.sdcrm',
      data: {
        token: true,
        keyword: infoName
      }
    })
  }  
}

export default log