<template>
  <div class="label">{{item.label}}</div>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>