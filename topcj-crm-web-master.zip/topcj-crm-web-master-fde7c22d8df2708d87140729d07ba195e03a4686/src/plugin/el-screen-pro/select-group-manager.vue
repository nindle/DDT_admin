<template>
  <el-select
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    filterable
    v-model="model[k]"
    :placeholder="item.placeholder || '组织架构'"
    :disabled="!managerInfo.isLeader"
    size="small"
    @change="$emit('change')"
  >
    <el-option
      v-for="l in groupList"
      :key="l.value"
      :value="l.value"
      :label="l.label"
    >
      <i 
        class="i"
        :class="l.type"
        :style="{ width: `${l.level * 14}px` }"
      ></i>
      {{l.label}}
    </el-option>
  </el-select>
</template>

<script>
export default {
  computed: {
    groupList() {
      let filterData
      if(typeof this.item.filter === 'function') {
        filterData = this.item.filter()
      }else{
        filterData = this.item.filter || {}
      }

      let options = []

      const search = function(list, level) {
        list.forEach(e => {
          options.push({
            label: e.groupName,
            value: `group/${e.id}`,
            type: 'group',
            id: e.id,
            level
          })
          e.managerList.filter(e => {
            let c = 0
            let l = 0
            for(let i in filterData) {
              if(e[i] === filterData[i]) {
                c ++
              }
              l ++
            }
            return c === l
          }).forEach(e => {
            options.push({
              label: e.realName,
              value: `manager/${e.id}`,
              type: 'manager',
              id: e.id,
              level
            })
          })
          if(e.groupChildren.length) {
            search(e.groupChildren, level + 1)
          }
        })
      } 

      search(this.$store.state.baseData.groupList.filter(e => e.id === this.managerInfo.dataGroupId), 0)

      return options
    },
    managerInfo() {
      return this.$store.state.managerInfo
    },
  },
  props: {
    model: Object,
    item: Object,
    k: String
  },
  created() {
    if(this.managerInfo.isLeader) {
      this.model[this.k] = `group/${this.managerInfo.dataGroupId}`
    }else{
      this.model[this.k] = `manager/${this.managerInfo.id}`
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.i {
  position: relative;
  display: inline-block;
  vertical-align: top;
  height: 34px;
  font-style: normal;
  &.group {
    &::before {
      content: "";
      position: absolute;
      top: calc(50% - 5px);
      right: 0;
      width: 10px;
      height: 10px;
      background: $--color-main;
      border-radius: 50%;
    }
  }
  &.manager {
    padding-right: 14px;
    &::before {
      content: "└";
      position: absolute;
      top: 0;
      right: 0;
    }
  }
}
</style>