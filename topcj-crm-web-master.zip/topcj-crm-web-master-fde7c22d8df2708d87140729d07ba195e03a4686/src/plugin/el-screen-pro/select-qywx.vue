<template>
  <el-select
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    filterable
    v-model="model[k]"
    :placeholder="item.placeholder || '企业微信'"
    :disabled="item.disabled"
    @change="$emit('change')"
    size="small"
  >
    <el-option
      v-for="l in qywxList"
      :key="l.qyWx"
      :value="l.qyWx"
      :label="l.wxName"
    ></el-option>
  </el-select>
</template>

<script>
export default {
  computed: {
    qywxList() {
      if(!this.item.filter) return this.$store.state.baseData.qywxList

      let filterData
      if(typeof this.item.filter === 'function') {
        filterData = this.item.filter()
      }else{
        filterData = this.item.filter
      }

      return this.$store.state.baseData.qywxList.filter(e => {
        let c = 0
        let l = 0
        for(let i in filterData) {
          if(e[i] === filterData[i]) {
            c ++
          }
          l ++
        }
        return c === l
      })
    }
  },
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>