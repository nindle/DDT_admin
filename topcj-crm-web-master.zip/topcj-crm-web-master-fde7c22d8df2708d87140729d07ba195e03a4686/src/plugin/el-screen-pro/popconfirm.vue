<template>
  <el-popconfirm
    :title="item.title"
    @confirm="item.click"
  >
    <template #reference>
      <el-button
        :type="item.buttonType"
        size="small"
        :icon="item.icon"
        :disabled="item.disabled"
        :plain="item.plain"
      >{{item.label}}</el-button>
    </template>
  </el-popconfirm>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>