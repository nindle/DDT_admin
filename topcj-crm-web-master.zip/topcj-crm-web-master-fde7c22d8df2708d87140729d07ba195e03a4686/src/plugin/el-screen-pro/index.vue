<!--
  placeholder 占位
  type 类型
  hide 隐藏
  disabled 禁用
  change 更改事件
-->

<template>
  <div class="screen">
    <div 
      v-for="(e, k) in config"
      :key="k"
      class="screen-item"
      :class="[`screen-item-${k}`, { split: e.type === 'split', br: e.type === 'br', hide: typeof e.hide === 'function' ? e.hide() : e.hide }]"
      :style="{ 'margin-right': e.placeholderInLabel ? '32px' : '8px' }"
    >
      <div 
        v-if="e.placeholderInLabel"
        class="screen-item-name"
      >{{e.placeholderInLabel}}：</div>
      <slot 
        v-if="typeof e.hide === 'function' ? !e.hide() : !e.hide"
        :name="k"
      >
        <component 
          :is="getType(e)"
          :item="e"
          :model="autoChange ? model : saveModel"
          :k="k"
          @change="screenChange(e, k)"
        />
      </slot>
    </div>
  </div>
</template>

<script>
import { deepcopy } from '../../assets/js/tool'
import ScreenLabel from './label'
import ScreenButton from './button'
import ScreenInput from './input'
import ScreenSelect from './select'
import ScreenSelectCorp from './select-corp'
import ScreenSelectManager from './select-manager'
import ScreenSelectQywx from './select-qywx'
import ScreenDateRange from './date-range'
import ScreenDateTime from './date-time'
import ScreenDateTimeRange from './date-time-range'
import ScreenDateMonth from './date-month'
import ScreenDate from './date'
import ScreenSelectGroup from './select-group'
import ScreenSelectGroupManager from './select-group-manager'
import ScreenSwitch from './switch'
import ScreenPopconfirm from './popconfirm'
import ScreenSelectPlate from './select-plate'
import ScreenSelectStock from './select-stock'
import ScreenNumber from './number'
import ScreenNumberRange from './number-range'


export default {
  data() {
    return {
      initModel: {},
      saveModel: {}
    }
  },
  props: {
    model: {
      type: Object,
      default() {
        return {}
      }
    },
    config: Object,
    cancelInitCallback: Boolean,
    autoChange: {
      type: Boolean,
      default: true
    }
  },
  components: {
    ScreenLabel,
    ScreenButton,
    ScreenInput,
    ScreenSelect,
    ScreenSelectCorp,
    ScreenSelectManager,
    ScreenSelectQywx,
    ScreenDateRange,
    ScreenDateTime,
    ScreenDateMonth,
    ScreenDate,
    ScreenSelectGroup,
    ScreenSelectGroupManager,
    ScreenSwitch,
    ScreenDateTimeRange,
    ScreenPopconfirm,
    ScreenSelectPlate,
    ScreenSelectStock,
    ScreenNumber,
    ScreenNumberRange
  },
  methods: {
    //获取类型
    getType(item) {
      switch(item.type) {
        case 'label': return 'ScreenLabel'
        case 'button': return 'ScreenButton'
        case 'input': return 'ScreenInput'
        case 'select': return 'ScreenSelect'
        case 'select-corp': return 'ScreenSelectCorp'
        case 'select-manager': return 'ScreenSelectManager'
        case 'select-qywx': return 'ScreenSelectQywx'
        case 'date-range': return 'ScreenDateRange'
        case 'date-time-range': return 'ScreenDateTimeRange'
        case 'date-time': return 'ScreenDateTime'
        case 'date-month': return 'ScreenDateMonth'
        case 'date': return 'ScreenDate'
        case 'select-group': return 'ScreenSelectGroup'
        case 'select-group-manager': return 'ScreenSelectGroupManager'
        case 'switch': return 'ScreenSwitch'
        case 'select-stock': return 'ScreenSelectStock'
        case 'select-plate': return 'ScreenSelectPlate'
        case 'popconfirm': return 'ScreenPopconfirm'
        case 'number': return 'ScreenNumber'
        case 'number-range': return 'ScreenNumberRange'
      }
    },
    //输入变化
    screenChange(e, key) {
      if(e.changeLog) {
        if(e.type === 'input' && this.model[key]) {
          this.$log(5, 10, 1, this.$store.state.nav.id, undefined, undefined, this.model[key])
        }
      }

      if(e && typeof e.change === 'function') {
        if(this.autoChange) {
          e.change(this.model[key], this.model)
        }else{
          e.change(this.saveModel[key], this.saveModel)
        }

        if(e.changeStop) return
      }
      if(this.autoChange) {
        this.$emit('change')
      }
    },
    resetModel(data = {}) {
      Object.assign(this.saveModel, {
        ...deepcopy(this.initModel),
        ...data
      })
    },
    emitModel(data = {}) {
      Object.assign(this.model, {
        ...deepcopy(this.saveModel),
        ...data
      })
    },
    cancelModel(data = {}) {
      Object.assign(this.saveModel, {
        ...deepcopy(this.model),
        ...data
      })
    }
  },
  async mounted() {
    await this.$nextTick()
    this.initModel = deepcopy(this.model)
    this.saveModel = deepcopy(this.model)
    if(!this.cancelInitCallback) {
      this.$emit('change')
    }
  }
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.screen {
  width: calc(100% + 8px);
  flex-shrink: 0;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  margin-top: -12px;
  .screen-item {
    margin-right: 8px;
    margin-top: 12px;
    display: flex;
    align-items: center;
    &.split {
      width: 1px;
      margin-left: auto;
      margin-right: 0;
    }
    &.br {
      margin-right: 0;
      margin-top: 0;
      width: 100%;
    }
    &.hide {
      display: none;
    }
    /deep/ {
      .screen-item-name {
        font-size: 14px;
        display: inline-block;
      }
      > .el-input { width: 240px; }
      .screen-item-number {  width: 120px;}
      .screen-item-number-range {
        width: 120px;
        &:first-child {
          .el-input__inner { 
            border-radius: 4px 0 0 4px;
            border-right: 0;
          }
          &::after {
            content: "-";
            position: absolute;
            left: 117px;
            line-height: 32px;
            color: #333;
            z-index: 1;
          }
        }
        &:last-child {
          .el-input__inner { 
            border-radius: 0 4px 4px 0;
            border-left: 0;
          }
        }
      }
      > .el-date-editor { width: 240px; }
      > .el-select { 
        width: 120px; 
        &.multiple { width: 200px;}
      }
      > .el-date-editor--month { width: 120px; }
      > .el-date-editor--datetime { width: 190px; }
      > .el-date-editor--datetimerange { width: 350px; }
      > .el-date-editor--date { width: 140px; }
      > .label {
        position: relative;
        font-size: 15px;
        line-height: 32px;
        padding-left: 8px;
        height: 32px;
        white-space: nowrap;
        &::before {
          content: "";
          position: absolute;
          left: 0;
          top: 8px;
          width: 2px;
          height: 16px;
          background: $--color-main;
        }
      }
    }
  }
}
</style>