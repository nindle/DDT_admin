<template>
  <el-input
    :prefix-icon="item.icon || 'el-icon-search'"
    v-model="model[k]"
    :placeholder="item.placeholder || '请输入'"
    size="small"
    clearable
    :disabled="item.disabled"
    @change="$emit('change')"
  ></el-input>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>