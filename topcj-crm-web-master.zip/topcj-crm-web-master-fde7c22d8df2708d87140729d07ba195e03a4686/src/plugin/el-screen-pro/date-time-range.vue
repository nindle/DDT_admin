<template>
  <el-date-picker
    v-model="model[k]"
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    type="datetimerange"
    range-separator="-"
    :value-format="item.format || 'timestamp'"
    :start-placeholder="item.placeholder ? item.placeholder[0] : '开始时间'"
    :end-placeholder="item.placeholder ? item.placeholder[1] : '结束时间'"
    :default-time="['00:00:00', '23:59:59']"
    size="small"
    format="yyyy-MM-dd HH:mm:ss"
    :disabled="item.disabled"
    :pickerOptions="item.pickerOptions"
    @change="$emit('change')"
  ></el-date-picker>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>