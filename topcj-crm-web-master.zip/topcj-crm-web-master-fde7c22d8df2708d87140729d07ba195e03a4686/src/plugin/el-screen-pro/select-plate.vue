<template>
  <el-select
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    v-model="model[k]"
    :placeholder="item.placeholder || '请选择板块'"
    :disabled="item.disabled"
    filterable
    @change="$emit('change')"
    size="small"
  >
    <el-option
      v-for="l in plateList"
      :key="l.bcode"
      :value="plateFormat(l)"
      :label="`${l.bcode} ${l.bname}`"
    ></el-option>
  </el-select>
</template>

<script>
export default {
  computed: {
    plateList() {
      return this.$store.state.baseData.plateList
    },
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  methods: {
    //板块格式化
    plateFormat({bcode, bname}) {
      let format = this.item.format ?? '{code}.{name}'
      return format.replace(/\{code\}/g, bcode).replace(/\{name\}/g, bname)
    },
  }
}
</script>