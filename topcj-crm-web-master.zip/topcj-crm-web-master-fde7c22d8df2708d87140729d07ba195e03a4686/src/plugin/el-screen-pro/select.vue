<template>
  <el-select
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    :filterable="item.filterable"
    v-model="model[k]"
    :placeholder="item.placeholder || '请选择'"
    @change="$emit('change')"
    :disabled="item.disabled"
    :multiple="item.multiple"
    :collapse-tags="item.multiple"
    size="small"
    :class="{ 'multiple': item.multiple }"
  >
    <el-option
      v-for="l in listData"
      :key="l[item.valueKey || 'value']"
      :value="l[item.valueKey || 'value']"
      :label="l[item.labelKey || 'label']"
      :disabled="l[item.disabledKey || 'disabled']"
    ></el-option>
  </el-select>
</template>

<script>
export default {
  computed: {
    listData() {
      if(!this.item.filter) return this.item.options

      let filterData
      if(typeof this.item.filter === 'function') {
        filterData = this.item.filter()
      }else{
        filterData = this.item.filter
      }

      return this.item.options.filter(e => {
        let c = 0
        let l = 0
        for(let i in filterData) {
          if(e[i] === filterData[i]) {
            c ++
          }
          l ++
        }
        return c === l
      })
    },
    // title() {
    //   return this.listData.find(e => e[this.item.valueKey || 'value'] === this.model[this.k])?.[this.item.labelKey || 'label'] ?? ''
    // }
  },
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>