<template>
  <el-select
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    v-model="model[k]"
    :placeholder="item.placeholder || '分公司'"
    @change="$emit('change')"
    :disabled="corpId !== 0"
    size="small"
  >
    <el-option
      v-for="l in corpList"
      :key="l.id"
      :value="l.id"
      :label="l.corpName"
    ></el-option>
  </el-select>
</template>

<script>
export default {
  computed: {
    corpList() {
      return this.$store.state.baseData.corpList.filter(e => (typeof this.item.isCorp === 'boolean' ? this.item.isCorp : true) ? e.isCorp : true)
    },
    managerInfo() {
      return this.$store.state.managerInfo
    },
    corpId() {
      return Number(this.$route.query.corpId || this.managerInfo.corpId)
    }
  },
  props: {
    model: Object,
    item: Object,
    k: String
  },
  created() {
    if(this.corpId !== 0) {
      this.model[this.k] = this.corpId
    }
  }
}
</script>