<template>
  <el-select
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    filterable
    v-model="model[k]"
    :placeholder="item.placeholder || '业务员'"
    @change="$emit('change')"
    :disabled="item.disabled"
    size="small"
  >
    <el-option
      v-for="l in managerList"
      :key="l.id"
      :value="l.id"
      :label="l.realName"
    ></el-option>
  </el-select>
</template>

<script>
export default {
  computed: {
    managerList() {
      if(!this.item.filter) return this.$store.state.baseData.managerList

      let filterData
      if(typeof this.item.filter === 'function') {
        filterData = this.item.filter()
      }else{
        filterData = this.item.filter
      }

      return this.$store.state.baseData.managerList.filter(e => {
        let c = 0
        let l = 0
        for(let i in filterData) {
          const filterDataItem = filterData[i]
          if(filterDataItem instanceof Array) {
            if(filterDataItem.includes(e[i])) {
              c ++
            }
          }else{
            if(e[i] === filterDataItem) {
              c ++
            }
          }
          
          l ++
        }
        return c === l
      })
    }
  },
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>