<template>
  <div>
    <el-input
      class="screen-item-number-range"
      v-model="model[k][0]"
      :placeholder="item.placeholder ? item.placeholder[0] : '请输入'"
      size="small"
      clearable
      :disabled="item.disabled"
      @input="input(0, $event)"
      @change="change"
    >
    </el-input>
    <el-input
      class="screen-item-number-range"
      v-model="model[k][1]"
      :placeholder="item.placeholder ? item.placeholder[1] : '请输入'"
      size="small"
      clearable
      :disabled="item.disabled"
      @input="input(1, $event)"
      @change="change"
    ></el-input>
  </div>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  },
  data() {
    return {
      oldValue: [...this.model[this.k]]
    }
  },
  methods: {
    input(index, value) {
      if(isNaN(value)) {
        this.model[this.k][index] = this.oldValue[index]
      }else{
        this.oldValue[index] = this.model[this.k][index]
      }
    },
    change() {
      if(typeof this.model[this.k][0] !== 'undefined' && this.model[this.k][0] !== '') {
        this.model[this.k][0] = Number(this.model[this.k][0])
      }
      if(typeof this.model[this.k][1] !== 'undefined' && this.model[this.k][1] !== '') {
        this.model[this.k][1] = Number(this.model[this.k][1])
      }
      if(typeof this.model[this.k][0] === 'number' && typeof this.model[this.k][1] === 'number' && this.model[this.k][1] < this.model[this.k][0]) {
        this.model[this.k] = [this.model[this.k][1], this.model[this.k][0]]
      }

      this.$emit('change')
    }
  }
}
</script>