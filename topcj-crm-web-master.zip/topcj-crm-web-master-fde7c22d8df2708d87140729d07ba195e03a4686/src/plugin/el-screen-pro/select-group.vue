<template>
  <el-select
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    filterable
    v-model="model[k]"
    :placeholder="item.placeholder || '部门'"
    :disabled="item.disabled"
    size="small"
    @change="$emit('change')"
  >
    <el-option
      v-for="l in groupList"
      :key="l.id"
      :value="l.id"
      :label="l.name"
    ></el-option>
  </el-select>
</template>

<script>
export default {
  computed: {
    groupList() {
      return this.$store.state.baseData.groupList
    }
  },
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>