<template>
  <el-date-picker
    v-model="model[k]"
    type="daterange"
    range-separator="-"
    :value-format="item.format || 'timestamp'"
    :start-placeholder="item.placeholder ? item.placeholder[0] : '开始日期'"
    :end-placeholder="item.placeholder ? item.placeholder[1] : '结束日期'"
    :default-time="['00:00:00', '23:59:59']"
    size="small"
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    format="yyyy-MM-dd"
    :disabled="item.disabled"
    :pickerOptions="item.pickerOptions"
    @change="$emit('change')"
  ></el-date-picker>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>