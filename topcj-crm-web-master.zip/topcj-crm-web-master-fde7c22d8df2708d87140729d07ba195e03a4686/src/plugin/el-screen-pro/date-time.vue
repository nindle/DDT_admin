<template>
  <el-date-picker
  
    v-model="model[k]"
    type="datetime"
    :popper-class="item.hideNow ? 'hide-now' : ''"
    :placeholder="item.placeholder || '时间'"
    format="yyyy-MM-dd HH:mm:ss"
    :value-format="item.format || 'timestamp'"
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    :disabled="item.disabled"
    size="small"
    :pickerOptions="item.pickerOptions"
    @change="$emit('change')"
  ></el-date-picker>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>