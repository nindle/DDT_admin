<template>
  <el-date-picker
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    v-model="model[k]"
    type="month"
    :placeholder="item.placeholder || '月份'"
    size="small"
    :disabled="item.disabled"
    format="yyyy/MM"
    :value-format="item.format || 'timestamp'"
    @change="$emit('change')"
  ></el-date-picker>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>