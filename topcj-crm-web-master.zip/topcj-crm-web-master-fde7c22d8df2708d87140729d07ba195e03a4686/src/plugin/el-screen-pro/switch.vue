<template>
  <el-switch
    v-model="model[k]"
    :active-text="item.activeText"
    :inactive-text="item.inactiveText"
    :active-value="item.activeValue"
    :inactive-value="item.inactiveValue"
    :active-color="item.activeColor === 'main' ? '#3089FF' : item.activeColor"
    :inactive-color="item.inactiveColor === 'main' ? '#3089FF' : item.inactiveColor"
    @change="$emit('change')"
  ></el-switch>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>