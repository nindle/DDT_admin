<template>
  <el-button
    :type="item.buttonType"
    size="small"
    :icon="item.icon"
    :disabled="item.disabled"
    @click="item.click"
    :plain="item.plain"
    :loading="item.loading"
  >{{item.label}}</el-button>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  }
}
</script>