<template>
  <el-select
    :clearable="typeof item.clearable === 'boolean' ? item.clearable : true"
    v-model="model[k]"
    :placeholder="item.placeholder || '股票'"
    @clear="filterStock('')"
    :disabled="item.disabled"
    filterable
    :filter-method="filterStock"
    @change="$emit('change')"
    @blur="blur"
    size="small"
  >
    <el-option
      v-for="l in stockList"
      :key="`${l.scode}.${l.markettype}`"
      :value="stockFormat(l)"
      :label="`${l.scode} ${l.scodename} ${l.la}`"
    >
      <el-tag size="mini">{{l.markettype === 1 ? 'SH' : 'SZ'}}</el-tag>
      <span
        class="stock-label"  
        v-html="l.labelHtml"
      ></span>
    </el-option>

    <template 
      #empty
      v-if="item.customer"
    >
      <div class="el-select-dropdown__empty select-empty">
        自定义添加请按以下格式<br><br>
        {{stockFormat({ scode: '股票代码', markettype: '市场代码', scodename: '股票名称' })}}<br><br>
        例：{{stockFormat({ scode: '600001', markettype: '1', scodename: '浦发银行' })}}<br><br>
        --- 市场代码 ---<br>
        1：上海<br>
        2：深圳<br>
        3：北京<br>
        4：港股<br>
        5：美股<br>
        9：板块
      </div>
    </template>
  </el-select>
</template>

<script>
import { debounce } from '../../assets/js/tool'

export default {
  data() {
    return {
      stockList: []
    }
  },
  computed: {
    stockListAll() {
      return this.$store.state.baseData.stockList
    },
  },
  props: {
    model: [Object, Array],
    item: Object,
    k: [String, Number]
  },
  methods: {
    //股票格式化
    stockFormat({scode, markettype, scodename}) {
      let format = this.item.format ?? '{code}.{type}'
      return format.replace(/\{code\}/g, scode).replace(/\{type\}/g, markettype).replace(/\{name\}/g, scodename)
    },
    //搜索股票
    filterStock: debounce(function(searchText) {
      let stockList = []
      let s = searchText.toUpperCase().replace(/ |，|\/|、|;|；|\|/g, ',').split(',').filter(e => e).map(e => e.trim())
      if (searchText !== '') {
        stockList = this.stockListAll.filter(e => {
          let f = 0
          for(let i in s) {
            if(e.scode.indexOf(s[i]) > -1 || e.scodename.replace(/\s/g,'').indexOf(s[i]) > -1 || e.la.indexOf(s[i]) > -1){
              f ++
            }
          }
          return f === s.length
        }).sort((a, b) => {
          let a_i = [], b_i = []
          for(let i in s) {
            a_i.push(Math.min(a.scode.indexOf(s[i]) > -1 ? a.scode.indexOf(s[i]) : 999, a.scodename.replace(/\s/g,'').indexOf(s[i]) > -1 ? a.scodename.replace(/\s/g,'').indexOf(s[i]) : 999, a.la.indexOf(s[i]) > -1 ? a.la.indexOf(s[i]) : 999))
            b_i.push(Math.min(b.scode.indexOf(s[i]) > -1 ? b.scode.indexOf(s[i]) : 999, b.scodename.replace(/\s/g,'').indexOf(s[i]) > -1 ? b.scodename.replace(/\s/g,'').indexOf(s[i]) : 999, b.la.indexOf(s[i]) > -1 ? b.la.indexOf(s[i]) : 999))
          }
          a_i = a_i.sort((a, b) => a - b)[0]
          b_i = b_i.sort((a, b) => a - b)[0]
          return a_i - b_i
        }).slice(0, 5)
      }else{
        stockList = this.stockListAll.slice(0, 5)
      }

      this.stockList = stockList.map(e => {
        let html = `${e.scode} ${e.scodename} ${e.la}`
        for(let i in s) {
          let reg = new RegExp(`(${s[i]})(?![^><]*>)`, 'g')
          html = html.replace(reg, '<b>$1</b>')
        }
        e.labelHtml = html
        return e
      })
    }, 300),
    blur(e) {
      if(this.item.customer) {
        let format = this.item.format ?? '{code}.{type}'

        let formatReg = format.replace(/\{code\}/g, '.+').replace(/\{type\}/g, '\\d+').replace(/\{name\}/g, '.+')
        formatReg = new RegExp(`^${formatReg}$`)
        let value = e.target.value

        if(formatReg.test(value)) {
          this.model[this.k] = value
          this.$emit('change')
        }else{
          let formatText = format
          value = value.split(/ |，|\/|、|;|；|\||#|\.|,/).filter(e => e)
          let a = [...format.matchAll(/\{.*?\}/g)]
          if(value.length >= a.length) {
            for(let i in a) {
              let e = a[i]
              if(e[0] === '{type}' && !/^\d+$/.test(value[i])) {
                return
              }
              formatText = formatText.replace(e[0], value[i])
            }
            this.model[this.k] = formatText
            this.$emit('change')
          }
        }
      }
    }
  },
  created() {
    this.filterStock('')
  }
}
</script>

<style scoped>
.el-select.el-select.el-select.el-select {
  width: 200px;
}
</style>