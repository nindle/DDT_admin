<template>
  <el-input
    class="screen-item-number"
    v-model="model[k]"
    :placeholder="item.placeholder || '请输入'"
    size="small"
    clearable
    :disabled="item.disabled"
    @input="input"
    @change="$emit('change')"
  ></el-input>
</template>

<script>
export default {
  props: {
    model: Object,
    item: Object,
    k: String
  },
  data() {
    return {
      oldValue: this.model[this.k]
    }
  },
  methods: {
    input(value) {
      if(isNaN(value)) {
        this.model[this.k] = this.oldValue
      }else{
        this.oldValue = this.model[this.k]
      }
    }
  }
}
</script>