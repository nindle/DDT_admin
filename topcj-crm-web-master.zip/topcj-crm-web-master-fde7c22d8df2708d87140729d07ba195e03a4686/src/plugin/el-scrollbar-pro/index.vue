<template>
  <div 
    class="scrollbar"
    :style="{ '--scroll-height': height ? `${height + 17}px` : 'auto' }"
    ref="scrollbar"
  >
    <el-scrollbar ref="scroll">
      <div ref="scrollTopFlag"></div>
      <div 
        class="scrollbar-view"
         ref="scrollbarView"
      >
        <slot />
      </div>
      <div ref="scrollBottomFlag"></div>
    </el-scrollbar>
  </div>
</template>

<script>
import { addResizeListener, removeResizeListener } from '../../assets/js/resize-event'

export default {
  data() {
    return {
      height: 0,
      io: new IntersectionObserver(this.scroll),
      //上次滚动位置
      preScroll: {
        scrollTop: 0,
        scrollBottom: 0,
        scrollLeft: 0,
        scrollRight: 0
      }
    }
  },
  methods: {
    async initHeight() {
      let scrollTop = this.$refs.scroll.$refs.wrap.scrollTop
      this.height = 0
      await this.$nextTick()
      this.height = this.$refs.scrollbar.getBoundingClientRect().height
      await this.$nextTick()
      this.$refs.scroll.$refs.wrap.scrollTop = scrollTop
    },
    scroll(e) {
      if(e[0].intersectionRatio === 1) {
        if(this.$refs.scroll.$refs.wrap.scrollTop) {
          this.$emit('scroll-bottom')
        }else{
          this.$emit('scroll-top')
        }
      }
    },
    scrollTop(e) {
      this.$refs.scroll.$refs.wrap.scrollTop = e
    },
    scrollBottom(e) {
      this.$refs.scroll.$refs.wrap.scrollTop = this.$refs.scrollbarView.getBoundingClientRect().height - this.height - e
    },
    scrollHandle(e) {
      let container = e.srcElement

      //滚动方向
      let scrollDirection

      const scroll = {
        scrollTop: container.scrollTop,
        scrollBottom: container.scrollHeight - container.clientHeight - container.scrollTop,
        scrollLeft: container.scrollLeft,
        scrollRight: container.scrollWidth - container.clientWidth - container.scrollLeft
      }
      if(scroll.scrollTop > this.preScroll.scrollTop) scrollDirection = 'bottom'
      if(scroll.scrollTop < this.preScroll.scrollTop) scrollDirection = 'top'
      if(scroll.scrollLeft > this.preScroll.scrollLeft) scrollDirection = 'right'
      if(scroll.scrollLeft < this.preScroll.scrollLeft) scrollDirection = 'left'

      if(!scrollDirection) return
      this.preScroll = scroll

      //滚动数据
      const scrollData = {
        ...scroll,
        scrollDirection,
        clientHeight: container.clientHeight,
        clientWidth: container.clientWidth,
        scrollHeight: container.scrollHeight,
        scrollWidth: container.scrollWidth
      }
      
      this.$emit('scroll', scrollData)
    }
  },
  mounted() {
    this.initHeight()
    addResizeListener(this.$refs.scrollbar, this.initHeight)
    addResizeListener(this.$refs.scrollbarView, this.initHeight)
    this.io.observe(this.$refs.scrollBottomFlag)
    this.io.observe(this.$refs.scrollTopFlag)
    this.$refs.scroll.$refs.wrap.addEventListener('scroll', this.scrollHandle)
  },
  beforeDestroy() {
    removeResizeListener(this.$refs.scrollbar, this.initHeight)
    removeResizeListener(this.$refs.scrollbarView, this.initHeight)
    this.io.unobserve(this.$refs.scrollBottomFlag)
    this.io.unobserve(this.$refs.scrollTopFlag)
    this.io.disconnect()
    this.$refs.scroll.$refs.wrap.removeEventListener('scroll', this.scrollHandle)
  }
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.scrollbar {
  width: 100%;
  height: 100%;
  /deep/ {
    .el-scrollbar__wrap {
      max-height: var(--scroll-height);
    }
  }
}

</style>