<!--
  table
    head {
      key: 键值
      label: 标题
      hide: 隐藏列
      width: 宽度
      minWidth: 最小宽度
      align: 对齐方式
      fixed: 浮动
      type: 类型
      default: 默认值
      tooltip: 鼠标悬停提示
      prop: 数据键值 默认为[key]
      format: 格式化
      copy: 拷贝
      click: 点击
      clickStop: 阻止冒泡
      children: 子集
    }
-->

<template>
  <el-table
    :data="data"
    :max-height="noscroll ? undefined : 600"
    ref="table"
    :stripe="stripe"
    :border="border"
    :highlight-current-row="highlightCurrentRow"
    :current-row-key="currentRowKey"
    :row-key="authRowKey"
    :cell-style="getCellStyle"
    :row-style="rowStyle"
    tooltip-effect="dark"
    :show-summary="summary"
    :summary-method="getSummaries"
    @row-click="
      (a, b, c) => {
        $emit('row-click', a, b, c)
      }
    "
    @row-contextmenu="
      (a, b, c) => {
        $emit('row-contextmenu', a, b, c)
      }
    "
    @header-contextmenu="headerContextmenu"
    @selection-change="$emit('selection-change', $event)"
    :style="{ '--table-other-height': tableOtherHeight }"
    :key="updateFlag"
  >
    <el-table-column-pro
      v-for="(e, i) in finalHead"
      :key="e.key"
      :head="finalHead"
      :item="e"
      :excel-mode="excelMode"
      :border="border"
      :index="i"
      :sort-key.sync="sortKey"
      :sort-type.sync="sortType"
      @sort="$emit('sort', { key: sortKey, type: sortType })"
    >
      <template v-for="(e, k) in $scopedSlots" #[k]="{ row, index, content }">
        <slot :name="k" :row="row" :index="index" :content="content" />
      </template>
    </el-table-column-pro>

    <template #empty>
      <div class="noresult" :style="{ width: `${tableWidth}px` }"></div>
    </template>
  </el-table>
</template>

<script>
import Vue from 'vue'
import elTableColumnPro from './column'
import CustomHead from './custom-header'
import { md5 } from '../../assets/js/crypto'
import { storage } from '../../assets/js/tool'
let CustomHeadConstructor = Vue.extend(CustomHead)

import tableList from './table'

export default {
  data() {
    return {
      excelMode: false,
      tableOtherHeight: 0,
      sortKey: this.defaultSortKey ?? '',
      sortType: this.defaultSortType ?? 'desc',
      tableWidth: 0,

      updateFlag: 0,
    }
  },
  props: {
    data: Array,
    head: Array,
    //是否显示斑马纹
    stripe: Boolean,
    //是否带有纵向边框
    border: Boolean,
    //是否高亮当前行
    highlightCurrentRow: Boolean,
    //当前行的Key
    currentRowKey: [String, Number],
    //行数据的Key
    rowKey: String,
    //取消滚动条
    noscroll: Boolean,
    //展示合计
    summary: Boolean,
    //默认排序键值
    defaultSortKey: String,
    //默认排序键值
    defaultSortType: String,
    //行样式
    rowStyle: [Function, Object],

    //自定义表头
    customHead: Boolean,
    //导出Excel
    exportExcel: String,
  },
  computed: {
    authHead() {
      return this.head.filter(e => !((typeof e.hide === 'function' ? e.hide() : e.hide) || (this.excelMode && e.excel === false)))
    },
    finalHead() {
      this.updateFlag
      const setData = storage.local(`table${this.headerKey}`)
      if (setData) {
        return setData
          .filter(e => e.s)
          .map(e => {
            return this.head.find(a => a.key === e.k)
          })
      }

      return this.authHead
    },
    authRowKey() {
      if (this.rowKey) return this.rowKey

      if (this.data.length) {
        if (this.data[0].id) {
          return 'id'
        }
      }

      return undefined
    },
    headerKey() {
      return this.$route.name + '-' + this.$store.state.managerInfo.id + '-' + md5(this.authHead.map(e => e.key).join('|'))
    },
  },
  components: {
    elTableColumnPro,
  },
  methods: {
    //初始化
    async init() {
      if (this.noscroll) return

      await this.$nextTick()

      let table = this.$refs.table
      let { height, width } = table.$refs.headerWrapper.getBoundingClientRect()
      this.tableOtherHeight = height + (this.summary ? 49 : 0)
      this.tableWidth = width

      table.$el.style.maxHeight = 'unset'

      if (table.$refs.footerWrapper) {
        table.$refs.footerWrapper.querySelectorAll('td').forEach(e => {
          e.onclick = () => {
            this.$copy(e.innerText)
          }
        })
      }
    },
    getCellStyle({ row, rowIndex, column }) {
      let style = this.getCellItem(column.property)?.style
      if (typeof style === 'function') {
        return style(row, rowIndex)
      }

      return style
    },
    getSummaries({ columns, data }) {
      let list = {
        $sum: key => {
          if (typeof key === 'function') {
            return data.reduce((pre, a) => pre + key(a), 0)
          } else {
            return data.reduce((pre, a) => pre + a[key], 0)
          }
        },
        $count: key => {
          if (typeof key === 'function') {
            return Array.from(new Set(data.map(e => key(e)))).length
          } else {
            return Array.from(new Set(data.map(e => e[key]))).length
          }
        },
      }

      let after = []

      let resultList = columns.map((e, i) => {
        let item = this.getCellItem(e.property)
        let result
        if (typeof item.summary === 'function') {
          after.push(function () {
            resultList[i] = item.summary(data, list)
          })
        } else if (typeof item.summary === 'undefined' || typeof item.summary === 'number') {
          let precision = 0
          result = data
            .reduce((pre, a) => {
              precision = Math.max(precision, `${a[e.property]}`.split('.')[1]?.length ?? 0)
              return pre + Number(a[e.property])
            }, 0)
            .toFixed(item.summary ?? precision)
        } else {
          result = item.summary
        }

        list[e.property] = result

        return result
      })

      after.forEach(e => e())

      return resultList
    },
    getCellItem(key, list) {
      list = list ?? this.head
      for (let i in list) {
        if (list[i].key === key) {
          return list[i]
        }
        if (list[i].children) {
          let s = this.getCellItem(key, list[i].children)
          if (s) return s
        }
      }
    },
    setSelection(list) {
      this.$refs.table.clearSelection()
      list.forEach(e => {
        this.$refs.table.toggleRowSelection(e, true)
      })
    },
    headerContextmenu(_column, event) {
      this.$contextmenu({
        event,
        menu: [
          {
            icon: 'el-icon-edit',
            title: '编辑表头',
            handler: () => {
              let instance = new CustomHeadConstructor({
                propsData: {
                  show: true,
                  data: this.authHead,
                  dataKey: this.headerKey,
                },
                methods: {
                  close: () => {
                    instance.$destroy()
                    instance.$el.remove()
                  },
                  update: () => {
                    this.updateFlag++
                  },
                },
              })
              instance.$mount(this.createPopoverBox(this))
            },
            hide: !this.customHead,
          },
          {
            icon: 'el-icon-document',
            title: '导出Excel',
            handler: () => {
              this.$copyExcel(this, this.exportExcel)
            },
            hide: !this.exportExcel,
          },
        ],
      })
    },
    //获取弹框容器
    createPopoverBox(vm) {
      if (vm.componentTagName === 'elLayoutPro') {
        const div = document.createElement('div')
        vm.$el.querySelector('.popover-box').appendChild(div)
        return div
      }
      if (vm.$parent) {
        return this.createPopoverBox(vm.$parent)
      }
      const div = document.createElement('div')
      document.body.appendChild(div)
      return div
    },
  },
  watch: {
    finalHead: {
      deep: true,
      handler() {
        this.init()
      },
    },
  },
  created() {
    tableList.push(this)
  },
  mounted() {
    this.init()
  },
  beforeDestroy() {
    let table = this.$refs.table
    if (table.$refs.footerWrapper) {
      table.$refs.footerWrapper.querySelectorAll('td').forEach(e => {
        e.onclick = null
      })
    }
    tableList.splice(tableList.indexOf(this), 1)
  },
}
</script>

<style scoped lang="scss">
@import '../../assets/css/common.scss';

.el-table {
  width: 100%;
  height: 100%;
  &.select-mode {
    cursor: pointer;
    &:hover {
      outline: 2px dashed $--color-main;
      &::after {
        content: '导出Excel';
        background: rgba($--color-main, 0.1);
      }
    }
    &::after {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      right: 0;
      color: $--color-main;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 99;
    }
  }
  &.el-table--scrollable-y {
    /deep/ {
      .el-table__fixed-right {
        bottom: 0 !important;
        right: 6px !important;
      }
    }
  }
  /deep/ {
    .el-table__empty-block {
      display: block;
    }
    .el-tooltip.el-icon-question.headtip {
      position: absolute;
      right: -16px;
      top: calc(50% - 7px);
      color: $--color-main;
      cursor: pointer;
    }
    .has-click {
      color: $--color-main;
      cursor: pointer;
    }
    .has-tooltip {
      @include ellipsis;
    }
    .el-table__body-wrapper {
      max-height: calc(100% - var(--table-other-height) * 1px) !important;
      // overflow: scroll;
    }
    .el-table__fixed-body-wrapper {
      max-height: calc(100% - var(--table-other-height) * 1px - 6px) !important;
    }
    .el-table__body-wrapper::-webkit-scrollbar {
      width: 6px;
      height: 6px;
    }
    .el-table__body-wrapper::-webkit-scrollbar-thumb {
      border-radius: 4px;
      background: rgba(144, 147, 153, 0.3);
    }
    .el-table__body-wrapper::-webkit-scrollbar-track {
      background: #fff;
    }
    .el-table__fixed {
      bottom: 0 !important;
    }
    .el-table__fixed-right {
      bottom: 0 !important;
      // right: 6px !important;
    }
    .el-table__footer-wrapper tbody td {
      background: #fafafa !important;
    }
    thead {
      color: #333;
      th {
        background: #fafafa !important;
        font-weight: normal;
        &:first-child .cell {
          padding-left: 24px !important;
        }
        &:nth-last-child(2) .cell {
          padding-right: 24px !important;
        }
      }
    }
    td {
      &:first-child .cell {
        padding-left: 24px !important;
      }
      &:last-child .cell {
        padding-right: 24px !important;
      }
    }
    .cell {
      padding: 0 16px 0 8px !important;
    }
  }
  &.el-table--border {
    /deep/ {
      .el-tooltip.el-icon-question {
        position: relative;
        right: 0;
        top: 0;
        color: $--color-main;
        cursor: pointer;
      }
      thead th,
      tbody td {
        .cell {
          padding: 0 12px !important;
        }
      }
    }
  }
  .noresult {
    position: sticky;
    left: 0;
    width: 100%;
    height: 200px;
    @include image(noresult, center no-repeat);
    text-align: center;
    &::before {
      content: '无记录';
      color: #bbb;
      line-height: 340px;
      padding-left: 16px;
    }
  }
}
</style>