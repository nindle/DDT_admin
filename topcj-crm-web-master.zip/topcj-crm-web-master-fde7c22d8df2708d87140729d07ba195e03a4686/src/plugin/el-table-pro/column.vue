<template>
  <el-table-column
    :type="item.type"
    :width="getWidth(item.width, index, item)"
    :min-width="getWidth(item.minWidth, index, item)"
    :align="item.align || (border ? 'center' : 'left')"
    :fixed="item.fixed"
    :selectable="item.selectable"
    :show-overflow-tooltip="item.tooltip"
    :resizable="false"
    :property="item.key"
  >
    <template #header>
      <slot 
        :name="`head-${item.key}`"
        :label="item.label"
      >
        <div 
          style="position: relative"
          :style="{ cursor: item.sort ? 'pointer' : '' }"
          @click="headSort(item)"
        >
          {{item.label}}
          <div 
            class="sort"
            v-if="item.sort"
            :class="sortKey === (typeof item.sort === 'string' ? item.sort : (item.prop || item.key)) ? sortType : ''"
          ></div>
          <el-tooltip 
            class="headtip"
            v-if="item.headtip && !excelMode"
            effect="dark" 
            :content="item.headtip" 
            placement="right"
          >
            <span class="el-icon-question"></span>
          </el-tooltip>
        </div>
      </slot>
    </template>

    <template #default="{ row, $index }" v-if="!item.type">
      <div 
        v-if="!(typeof item.edit === 'function' ? item.edit(row) : item.edit) || excelMode"
        @click="clickCell(item, row, $event)"
        :class="{ 'has-click': item.click, 'has-tooltip': item.tooltip }"
        style="display: inline-block"
      >
        <slot 
          :name="`body-${item.key}${excelMode ? '--' : ''}`" 
          :row="row"
          :index="$index"
          :content="getBody(item, row, excelMode ? 'excel' : 'format')"
        >
          <template v-if="item.button && !excelMode">
            <template v-if="item.button.popconfirm">
              <el-popconfirm
                :title="item.button.popconfirm"
                @confirm="item.button.click(row)"
              >
                <template #reference>
                  <el-button
                    :type="item.button.type"
                    :size="item.button.size || 'small'"
                    :icon="item.button.icon"
                    :disabled="typeof item.button.disabled === 'function' ? item.button.disabled(row) : item.button.disabled"
                  >{{item.button.label || getBody(item, row, excelMode ? 'excel' : 'format')}}</el-button>
                </template>
              </el-popconfirm>
            </template>
            <template v-else>
              <el-button
                :type="item.button.type"
                :size="item.button.size || 'small'"
                :icon="item.button.icon"
                :disabled="typeof item.button.disabled === 'function' ? item.button.disabled(row) : item.button.disabled"
                @click="item.button.click(row, $event)"
              >{{item.button.label || getBody(item, row, excelMode ? 'excel' : 'format')}}</el-button>
            </template>
          </template>
          <template v-else>
            <i 
              class="cell-state"
              :class="`cell-state-${getBody(item, row, 'state')}`"
              v-if="item.state"
            ></i>
             <template v-if="item.tag">
              <el-tag
                v-if="getBody(item, row, 'tag')"
                :type="getBody(item, row, 'tag')"
                size="small"
              >{{getBody(item, row, excelMode ? 'excel' : 'format')}}</el-tag>
            </template>
            <template v-else>
              {{getBody(item, row, excelMode ? 'excel' : 'format')}}
            </template>
          </template>
        </slot>
      </div>
      <component 
        class="edit-cell"
        v-if="(typeof item.edit === 'function' ? item.edit(row) : item.edit) && initFlag && !excelMode"
        :is="getType(item, row)"
        :item="typeof item.editItem === 'function' ? item.editItem(row) : (item.editItem || item)"
        :model="row"
        :k="item.prop || item.key"
        @change="inputChange(item, row)"
      />
    </template>

    <el-table-column-pro
      v-for="e in authHead"
      :key="e.key"
      :head="head"
      :item="e"
      :excel-mode="excelMode"
      :index="index"
      :border="border"
    >
      <template
        v-for="(e, k) in $scopedSlots"
        #[k]="{ row, index, content }"
      >
        <slot 
          :name="k" 
          :row="row"
          :index="index"
          :content="content"
        />
      </template>
    </el-table-column-pro>
  </el-table-column>
</template>

<script>
export default {
  data() {
    return {
      initFlag: false
    }
  },
  name: 'elTableColumnPro',
  props: {
    item: Object,
    excelMode: Boolean,
    index: Number,
    head: Array,
    border: Boolean,
    sortKey: String,
    sortType: String
  },
  computed: {
    authHead() {
      return this.item.children?.filter(e => !((typeof e.hide === 'function' ? e.hide() : e.hide) || (this.excelMode && e.excel === false))) ?? []
    }
  },
  components: {
    FormInput: () => import('../el-form-pro/input'),
    FormTextarea: () => import('../el-form-pro/textarea'),
    FormNumber: () => import('../el-form-pro/number'),
    FormSelect: () => import('../el-form-pro/select'),
    FormSelectManager: () => import('../el-form-pro/select-manager'),
    FormSelectCorp: () => import('../el-form-pro/select-corp'),
    FormSwitch: () => import('../el-form-pro/switch'),
    FormDate: () => import('../el-form-pro/date'),
    FormDateTime: () => import('../el-form-pro/date-time'),
    FormDateRange: () => import('../el-form-pro/date-range'),
    FormSelectPlate: () => import('../el-form-pro/select-plate'),
    FormSelectStock: () => import('../el-form-pro/select-stock'),
  },
  methods: {
    //获取类型
    getType(item, row) {
      switch((typeof item.edit === 'function' ? item.edit(row) : item.edit)) {
        case 'textarea': return 'FormTextarea'
        case 'number': return 'FormNumber'
        case 'select': return 'FormSelect'
        case 'select-manager': return 'FormSelectManager'
        case 'select-corp': return 'FormSelectCorp'
        case 'select-plate': return 'FormSelectPlate'
        case 'select-stock': return 'FormSelectStock'
        case 'switch': return 'FormSwitch'
        case 'date': return 'FormDate'
        case 'date-time': return 'FormDateTime'
        case 'date-range': return 'FormDateRange'
        case 'input':
        default: return 'FormInput'
      }
    },
    //数值变更
    inputChange(item, row) {
      if(typeof item.change !== 'function') return

      item.change(row)
    },
    getWidth(width, index, item) {
      if(typeof width !== 'number') return

      if(this.border) return width + 25 + (item.headtip ? 20 : 0)

      if(index === 0) {
        return width + 40
      }else if(index === this.head.length - 1) {
        return width + 32
      }else{
        return width + 24
      }
    },
    getBody(e, row, key = 'format') {
      let prop = e.prop || e.key
      if(!prop) return ''

      let format = e[key] ?? e.format

      if(typeof format === 'function') {
        //函数
        return format(...prop.split(',').map(k => k === 'this' ? row : row[k]))
      }else if(typeof format === 'string') {
        //字符串
        return prop.split(',').reduce((pre, k) => pre.replace(new RegExp('{' + k + '}', 'g'), this.getData(row[k], e.default)), format)
      }else if(typeof format === 'object') {
        let r = prop.split(',').map(k => this.getData(row[k])).join(',')
        //对象
        if(format.list instanceof Array) {
          //数组匹配
          let { list, key = 'key', value = 'value' } = format
          
          for(let k in list) {
            let a = list[k]
            if(a[key] == r) {
              return a[value]
            }
          }
          return e.default ?? r
        }else{
          //对象匹配
          return format[r] ?? e.default ?? r
        }

      }else{
        return prop.split(',').map(k => this.getData(row[k], e.default)).join(',')
      }
    },
    getData(data, def) {
      if(data === '' || data === undefined || data === null) {
        return def ?? ''
      }else{
        return data
      }
    },
    clickCell(e, row, event) {
      if(typeof e.click === 'function') {
        e.click(row)
      }

      if(e.copy) {
        if(typeof e.copy === 'boolean') {
          this.$copy(this.getBody(e, row))
        }else{
          this.$copy(this.getBody(e, row, 'copy'))
        }
      }

      if(e.clickStop) {
        event.stopPropagation()
      }
    },
    headSort(item) {
      if(!item.sort) return

      let key = typeof item.sort === 'string' ? item.sort : (item.prop || item.key)
      
      if(key === this.sortKey) {
        let type = this.sortType === 'desc' ? 'asc' : 'desc'
        this.$emit('update:sort-type', type)
      } else {
        this.$emit('update:sort-key', key)
        this.$emit('update:sort-type', 'desc')
      }

      this.$emit('sort')
    }
  },
  async mounted() {
    await this.$nextTick()
    this.initFlag = true
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.cell-state {
  position: absolute;
  left: -2px;
  top: calc(50% - 3px);
  width: 6px;
  height: 6px;
  border-radius: 50%;
  &.cell-state-primary { background: #3089FF;}
  &.cell-state-success { background: #67C23A;}
  &.cell-state-warning { background: #E6A23C;}
  &.cell-state-error { background: #F56C6C;}
  &.cell-state-info { background: #909399;}
}

.sort {
  display: inline-block;
  &::after {
    content: "";
    width: 0;
    height: 0;
    position: relative;
    top: -15px;
    left: -5px;
    border-bottom: 5px solid #BBB;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
  }
  &::before {
    content: "";
    width: 0;
    height: 0;
    position: relative;
    top: 15px;
    left: 5px;
    border-top: 5px solid #BBB;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
  }
  &.asc {
    &::after { border-bottom-color: $--color-main;}
  }
  &.desc {
    &::before { border-top-color: $--color-main;}
  }
}
.edit-cell {
  width: 100%;
  /deep/ {
    .el-input__inner {
      line-height: 32px;
      height: 32px;
      border-color: transparent !important;
      padding: 0 !important;
      background: transparent;
      text-align: left !important;
    }
    .el-input-number__decrease, .el-input-number__increase {
      border: 1px solid #D9D9D9;
      box-sizing: border-box;
      height: 19px;
    }
    .el-textarea__inner {
      border-color: transparent !important;
      padding: 0 !important;
      overflow: hidden;
      background: transparent;
    }
    .el-input__prefix { display: none;}
    .el-input__suffix { display: none;}
  }
}
</style>