<template>
  <el-dialog-pro @close="close">
    <template #title>
      编辑表头(仅本地)
    </template>

    <el-tree
      :data="headData"
      node-key="key"
      draggable
      :allow-drag="e => e.data.customHeadMove"
      :allow-drop="(a, b, type) => type !== 'inner' && b.data.customHeadMove"
    >
      <template #default="{ data }">
        <div 
          class="header"
          :class="{ 'no-move': !data.customHeadMove }"
        >
          <el-checkbox
            v-model="data.customHeadShowValue"
            :disabled="!data.customHeadHide"
          ></el-checkbox>
          <span class="label">{{data.label}}</span>
        </div>
      </template>
    </el-tree>

    <template #footer> 
      <el-button 
        size="small" 
        @click="reset"
      >重 置</el-button>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { storage } from '../../assets/js/tool'

export default {
  data(){
    let headData = []
    const setData = storage.local(`table${this.dataKey}`)
    if(setData) {
      headData = setData.map(e => {
        const item = this.data.find(a => a.key === e.k)
        const customHead = typeof item.customHead === 'undefined' ? true : item.customHead
        return {
          key: item.key,
          label: item.label || item.editLabel,
          customHeadMove: typeof customHead === 'object' ? customHead.includes('move') : customHead,
          customHeadHide: typeof customHead === 'object' ? customHead.includes('hide') : customHead,
          customHeadShowValue: e.s
        }
      })
    }else{
      headData = this.data.map(e => {
        const customHead = typeof e.customHead === 'undefined' ? true : e.customHead
        return {
          key: e.key,
          label: e.label || e.editLabel,
          customHeadMove: typeof customHead === 'object' ? customHead.includes('move') : customHead,
          customHeadHide: typeof customHead === 'object' ? customHead.includes('hide') : customHead,
          customHeadShowValue: true
        }
      })
    }

    return {
      headData
    }
  },
  props: {
    show: Boolean,
    data: Array,
    dataKey: String
  },
  methods:{
    submit() {
      storage.local(`table${this.dataKey}`, this.headData.map(e => {
        return {
          k: e.key,
          s: e.customHeadShowValue
        }
      }))

      this.$message.success('修改成功')
      this.update()
      this.close()
    },
    reset() {
      this.headData = this.data.map(e => {
        const customHead = typeof e.customHead === 'undefined' ? true : e.customHead
        return {
          key: e.key,
          label: e.label || e.editLabel,
          customHeadMove: typeof customHead === 'object' ? customHead.includes('move') : customHead,
          customHeadHide: typeof customHead === 'object' ? customHead.includes('hide') : customHead,
          customHeadShowValue: true
        }
      })
    },
    close(){
      this.$emit('update:show', false)
    },
    update() {
      this.$emit('update-head')
    }
  }
}
</script>

<style lang="scss" scoped>
.header {
  .label {
    margin-left: 10px;
  }
  &.no-move {
    .label {
      opacity: .3;
    }
  }
}
</style>