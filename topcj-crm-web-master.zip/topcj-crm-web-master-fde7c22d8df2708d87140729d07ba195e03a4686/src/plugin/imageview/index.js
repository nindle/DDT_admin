import { createImageview, imageviewDirective } from './src/main'

let index = {}
index.install = function(Vue) {
  Vue.directive('imageview', imageviewDirective)
  Vue.prototype.$imageview = createImageview
}

export default index