import Vue from 'vue'
import Imageview from './image-viewer'

const ImageviewConstructor = Vue.extend(Imageview)
let instance = null

const createImageview = function(option) {
  if(instance === null) {
    const list = []
    const rotate = []

    option.list.forEach(e => {
      if(typeof e === 'string') {
        list.push(e)
        rotate.push(0)
      }else{
        list.push(e.url)
        rotate.push(e.rotate ?? 0)
      }
    })

    instance = new ImageviewConstructor({
      data: {
        transform: {
          scale: 1,
          deg: rotate[option.index ?? 0],
          offsetX: 0,
          offsetY: 0,
          enableTransition: false
        }
      },
      propsData: {
        urlList: list,
        onClose: () => {
          if(option.onClose) {
            option.onClose()
          }
          document.querySelector('#app > .frame').removeChild(instance.$el)
          instance.$destroy()
          instance = null
        },
        onSwitch: (index) => {
          instance.transform.deg = rotate[index]
        },
        initialIndex: option.index ?? 0,
        zIndex: 9999
      },
      watch: {
        'transform.deg'() {
          if(option.onRotate) {
            option.onRotate(instance.index, instance.transform.deg)
          }
          rotate[instance.index] = instance.transform.deg
        }
      }
    })
    instance.$mount()
    document.querySelector('#app > .frame').appendChild(instance.$el)
  }else{
    instance.init(option)
  }
}

createImageview.close = function() {
  if(instance?.onClose) {
    instance.onClose()
  }
}

const saveImageList = {}

const imageviewDirective = {
  bind(el, binding) {
    el.__imageviewValue__ = binding.value ?? el.src
    el.__imageviewGroup__ = binding.arg ?? `${el.__imageviewValue__}${parseInt(Math.random() * 99999999 + 1)}`
    if(!saveImageList[el.__imageviewGroup__]) saveImageList[el.__imageviewGroup__] = []
    saveImageList[el.__imageviewGroup__].push(el.__imageviewValue__)
    
    el.__imageviewHandler__ = () => {
      if(!el.__imageviewValue__) return
      let list = saveImageList[el.__imageviewGroup__].filter(e => e)
      createImageview({
        list,
        index: list.indexOf(el.__imageviewValue__)
      })
    }

    el.addEventListener('click', el.__imageviewHandler__)
  },
  update(el, binding) {
    let oldIndex = saveImageList[el.__imageviewGroup__].indexOf(el.__imageviewValue__)
    el.__imageviewValue__ = binding.value ?? el.src
    let newGroup = binding.arg ?? el.__imageviewValue__
    if(el.__imageviewGroup__ === newGroup) {
      saveImageList[el.__imageviewGroup__][oldIndex] = el.__imageviewValue__
    }else{
      saveImageList[el.__imageviewGroup__].splice(oldIndex, 1)
      el.__imageviewGroup__ = newGroup
      if(!saveImageList[el.__imageviewGroup__]) saveImageList[el.__imageviewGroup__] = []
      saveImageList[el.__imageviewGroup__].push(el.__imageviewValue__)
    }
  },
  unbind(el) {
    let index = saveImageList[el.__imageviewGroup__].indexOf(el.__imageviewValue__)
    saveImageList[el.__imageviewGroup__].splice(index, 1)
    el.removeEventListener('click', el.__imageviewHandler__)
    delete el.__imageviewGroup__
    delete el.__imageviewValue__
    delete el.__imageviewHandler__
  }
}

export { createImageview, imageviewDirective }