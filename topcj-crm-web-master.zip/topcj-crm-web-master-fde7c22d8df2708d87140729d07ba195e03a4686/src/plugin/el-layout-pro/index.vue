<template>
  <div
    class="layout"
    :style="{ '--layout-height': layoutHeight}"
    v-loading="loading"
    element-loading-text="拼命加载中"
    element-loading-background="rgba(255,255,255,.5)"
  >
    <div
      class="layout-box"
      ref="resize"
      @click="$emit('layout-click')"
    >
      <div
        class="screen-box screen-box-top"
        ref="screenTop"
        v-if="$scopedSlots['screen-top']"
      >
        <slot name="screen-top" />
      </div>

      <div
        class="screen-box"
        ref="screen"
        v-if="$scopedSlots.screen"
      >
        <slot name="screen" />
      </div>

      <div
        class="table-box"
        :style="{ height: tableHeight }"
        ref="table"
        v-if="$scopedSlots.table"
      >
        <slot name="table" />
      </div>

      <div
        class="scroll-box"
        :style="{ height: tableHeight, '--scroll-height': scrollHeight, '--scroll-bar-index': scrollBarIndex }"
        ref="scroll"
        v-if="$scopedSlots.scroll"
      >
        <el-scrollbar-pro
          @scroll-bottom="emitEvent('scroll-bottom')"
          @scroll-top="emitEvent('scroll-top')"
        >
          <slot name="scroll" />
        </el-scrollbar-pro>
      </div>

      <div
        class="page-box"
        :class="`page-algin-${ pageAlgin }`"
        ref="page"
        v-if="typeof total === 'number'"
      >
        <el-page-pro
          :total="total"
          :page-num.sync="pageNum_s"
          :page-size.sync="pageSize_s"
          :layout="pageLayout"
          :small="pageSmall"
          @change="pageChange"
        ></el-page-pro>
      </div>
    </div>

    <div class="popover-box">
      <slot name="popover" />
    </div>
  </div>
</template>

<script>
import { addResizeListener, removeResizeListener } from '../../assets/js/resize-event'

export default {
  data () {
    return {
      componentTagName: 'elLayoutPro',
      layoutHeight: 'auto',
      tableHeight: 'auto',
      scrollHeight: 'auto',
      pageNum_s: this.pageNum,
      pageSize_s: this.pageSize
    }
  },
  props: {
    loading: Boolean,
    total: Number,
    pageNum: Number,
    pageSize: Number,
    pageLayout: String,
    pageSmall: Boolean,
    pageAlgin: {
      type: String,
      default: 'center'
    },
    scrollBarIndex: {
      type: [Number, String],
      default: 1
    }
  },
  methods: {
    pageChange () {
      setTimeout(() => {
        this.$emit('page-change')
      })
    },
    initHeight () {
      let screenTopHeight = this.$refs.screenTop?.getBoundingClientRect().height ?? 0
      let screenHeight = this.$refs.screen?.getBoundingClientRect().height ?? 0
      let pageHeight = this.$refs.page?.getBoundingClientRect().height ?? 0

      this.layoutHeight = this.$el.getBoundingClientRect().height + 'px'

      this.tableHeight = `calc(100% - ${pageHeight + screenHeight + screenTopHeight}px)`

      this.scrollHeight = `calc(100vh - ${document.body.offsetHeight - this.$el.getBoundingClientRect().height + pageHeight + screenHeight + screenTopHeight}px)`
    },
    emitEvent (event) {
      this.$emit(event)
    }
  },
  watch: {
    pageNum () {
      this.pageNum_s = this.pageNum
    },
    pageNum_s () {
      this.$emit('update:page-num', this.pageNum_s)
    },
    pageSize_s () {
      this.$emit('update:page-size', this.pageSize_s)
    }
  },
  mounted () {
    this.initHeight()

    addResizeListener(this.$refs.resize, this.initHeight)
  },
  beforeDestroy () {
    removeResizeListener(this.$refs.resize, this.initHeight)
  }
}
</script>

<style scoped lang="scss">
@import '../../assets/css/common.scss';

.layout {
  .layout-box {
    height: 100%;
    width: 100%;
  }
  .screen-box {
    padding: 24px 24px 0;
    display: flex;
    .el-date-editor {
      width: 240px;
    }
    .el-input {
      width: 240px;
    }
    .el-select {
      width: 120px;
    }
    .label {
      position: relative;
      font-size: 15px;
      line-height: 32px;
      padding-left: 8px;
      white-space: nowrap;
      &::before {
        content: '';
        position: absolute;
        left: 0;
        top: 8px;
        width: 2px;
        height: 16px;
        background: $--color-main;
      }
    }
    > * {
      margin-right: 8px;
      &:last-child {
        margin-right: 0;
      }
    }
    .split {
      margin-left: auto;
    }
    &.screen-box-top {
      background: #F0F2F5;
      padding: 0 24px 24px;
    }
  }
  .table-box {
    padding: 24px;
    box-sizing: border-box;
  }
  .scroll-box {
    max-height: var(--scroll-height);
    /deep/ {
      .el-scrollbar__bar {
        z-index: var(--scroll-bar-index);
      }
    }
  }
  .page-box {
    display: flex;
    padding: 0 24px 24px;
    &.page-algin-center {
      justify-content: center;
    }
    &.page-algin-left {
      justify-content: flex-start;
    }
    &.page-algin-right {
      justify-content: flex-end;
    }
  }
}
</style>