<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  data() {
    return {
      hasTips: false,
      version: ''
    }
  },
  methods: {
    checkVersion() {
      setTimeout(() => {
        this.$http({
          mode: 'get',
          url: `${this.SYS.URL}/index.html?v=${Date.now()}`
        }).then(e => {
          let m = e.match(/<noscript>(.+)<\/noscript>/)
          let text = m[1].split(';')
          let version = text[0]
          if(version === this.version) {
            this.checkVersion()
          }else{
            switch(text[1]) {
              case 'normal':
                //普通升级:继续检查
                this.checkVersion()
                break
              case 'tips':
                //提醒升级
                if(!this.hasTips) {
                  this.hasTips = true
                  this.$notify.info({
                    title: '更新提醒',
                    message: '顶点通升级啦，点击更新！',
                    showClose: true,
                    duration: 0,
                    position: 'bottom-right',
                    onClick: () => {
                      window.location.reload()
                    },
                    onClose: () => {
                      setTimeout(() => {
                        this.hasTips = false
                      }, 10 * 60 * 1000)
                    }
                  })
                }
                this.checkVersion()
                break
              case 'reload':
                //自动刷新
                window.location.reload()
                break
              case 'focus':
                //强制下线并刷新
                this.$store.commit('setToken', null)
                window.location.reload()
                break
              default:
                this.checkVersion()
                break
            }
          }
        })
      }, 60 * 1000)
    }
  },
  created() {
    this.version = document.querySelector('noscript').innerText.split(';')[0]
    this.checkVersion()
  }
}
</script>

<style lang="scss">
* {
  margin: 0;
  padding: 0;
  outline: unset;
}

ul, ol { list-style: none;}
a, a:active {
  color: inherit;
  text-decoration: none;
}
h1, h2, h3, h4, h5, h6 { font-weight: normal;}
html, body, #app {
  width: 100%;
  height: 100%;
  min-height: 100%;
  overflow: hidden;
  user-select: none;
  font-family: "微软雅黑";
  text-size-adjust: none;
  -webkit-tap-highlight-color: transparent;
}
input, button, img, textarea { 
  outline: none; 
  font-family: "微软雅黑";
}
iframe {
  width: 100%;
  height: 100%;
  border: none;
}

input::-ms-clear,
input::-ms-reveal { display: none;}
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button { -webkit-appearance: none;}
input[type="number"] { -moz-appearance: textfield;}
</style>
