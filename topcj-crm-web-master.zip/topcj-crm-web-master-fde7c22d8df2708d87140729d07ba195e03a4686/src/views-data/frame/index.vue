<template>
  <div 
    class="gm-frame"
    :class="{ 'hide-nav': !showNav && hideNav}"
  >
    <navigation @nav="selectNav"/>
    <div 
      class="show-nav"
      @mousemove="mousemove"
    >
      <i 
        class="el-icon-arrow-right"
        :style="{ '--top': navHoverTop }"
        @click="showNav = true"
      ></i>
    </div>

    <div class="right-box">
      <top-info :navLabel="nav.title" />
      <div class="content">
        <keep-alive :include="keepNavList">
          <router-view 
            v-if="nav.title"
            class="content-view"
            :auth="actionType"
            :nav="nav"
            :tag="tagList"
            :key="$route.path"
          />
          <div 
            v-else
            class="content-view content-block"
          ></div>
        </keep-alive>
      </div>
    </div>
  </div>
</template>

<script>
import navigation from './navigation'
import TopInfo from './topInfo'

export default {
  data() {
    return {
      nav: {},
      tagList: {},
      actionType: [],
      navHoverTop: 0,
      showNav: false
    }
  },
  components: {
    navigation,
    TopInfo
  },
  computed: {
    keepNavList() {
      return this.$store.state.topNav.filter(e => !e.disabled && !e.dev).map(e => e.name)
    },
    hideNav() {
      return this.$route.meta?.hideNav
    }
  },
  methods: {
    selectNav(nav) {
      //权限
      this.actionType = nav.actionType?.split(',').map(e => Number(e)) ?? []

      //标签
      let group = this.$store.state.baseData.tagTreeList.filter(e => !e.navId || e.navId === nav.id)
      let tagList = {}
      let sysModeFlag = this.$store.state.sysMode === 2
      group.forEach(e => {
        e.labels.forEach(e => {
          tagList[`t${e.id}`] = e.values.map(e => {
            tagList[`v${e.id}`] ={
              ...e,
              visible: sysModeFlag ? e.visible : 1
            }
            return {
              ...e,
              visible: sysModeFlag ? e.visible : 1
            }
          })
        })
      })
      this.tagList = tagList

      //导航
      this.nav = nav
      this.showNav = false

      if(nav.linkUrl) {
        this.$store.commit('setTopNav', {
          path: nav.linkUrl,
          name: this.$route.name,
          title: nav.title,
          add: true
        })
      }
    },
    mousemove(e) {
      this.navHoverTop = e.clientY
    }
  },
  created() {
    this.$store.commit('initTopNav', this.$route.name.split('-')[0])
  },
  watch :{
    $route() {
      this.nav = {}
    }
  }
}
</script>

<style scoped lang="scss">

.gm-frame {
  position: relative;
  width: 100%;
  height: 100%;
  &.hide-nav {
    .navigation { left: -256px;}
    .right-box { width: 100%;}
    .show-nav { display: block;}
  }
  .navigation {
    position: absolute;
    left: 0;
    transition: left .3s;
  }
  .right-box {
    position: absolute;
    right: 0;
    top: 0;
    height: 100%;
    width: calc(100% - 256px);
    display: flex;
    flex-direction: column;
    .content {
      position: relative;
      width: 100%;
      height: calc(100% - 65px);
      .content-view { 
        position: relative;
        background: #F0F2F5;
      }
      .content-block {
        width: 100%;
        height: 100%;
        background: #F0F2F5;
      }
    }
  }
  .show-nav {
    display: none;
    position: absolute;
    left: 0;
    top: 0;
    width: 10px;
    height: 100%;
    z-index: 9;
    i {
      position: absolute;
      left: -50px;
      top: calc(var(--top) * 1px - 50px);
      width: 50px;
      height: 100px;
      border-radius: 50%;
      background: #001229;
      color: #FFF;
      font-size: 20px;
      line-height: 100px;
      text-indent: 30px;
      cursor: pointer;
      transition: left .3s;
    }
    &:hover i { left: -30px;}
  }
}
</style>
