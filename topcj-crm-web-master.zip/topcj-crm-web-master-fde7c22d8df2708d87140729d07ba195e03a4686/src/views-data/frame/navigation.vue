<template>
  <div class="navigation">
    <div class="search-box">
      <el-input 
        placeholder="输入应用、快速定位"
        size="small"
        prefix-icon="el-icon-search"
        clearable
        v-model="searchStr"
        @input="search"
      />
    </div>
    <el-scrollbar-pro>
      <el-menu
        :default-active="routePath"
        background-color="#001229"
        text-color="#FFF"
        active-text-color="#FFF"
        router
        :default-openeds="openList"
      >
        <el-submenu
          v-for="e in gmNav"
          :key="e.name"
          :index="e.name"
        >
          <template #title>
            <i 
              class="icon"
              :style="{ backgroundImage: `url(${e.iconUrl})` }"
            ></i>
            <span>{{e.title}}</span>
          </template>
          <el-menu-item 
            v-for="e in e.children"
            :key="e.name"
            :index="e.path"
          >
            <span>{{e.title}}</span>
          </el-menu-item>
        </el-submenu>
      </el-menu>
    </el-scrollbar-pro>
  </div>
</template>

<script>
import { deepcopy, debounce } from '../../assets/js/tool'
import chinese2pinyin from '../../assets/js/chinese2pinyin'

export default {
  data() {
    return {
      saveGmNav: [],
      gmNav: [],
      searchStr: '',
      openList: []
    }
  },
  computed: {
    navigationTree() {
      return this.$store.state.baseData.navigationTree
    },
    navigationList() {
      return this.$store.state.baseData.navigationList
    },
    managerNavigationName() {
      return this.$store.state.baseData.managerNavigation.map(e => e.name)
    },
    managerNavigation() {
      return this.$store.state.baseData.managerNavigation
    },
    routePath() {
      return this.$route.path
    }
  },
  methods: {
    //获取导航
    getGmNav() {
      if(!this.navigationTree.length) return

      let gmNav = deepcopy(this.navigationTree.filter(e => e.name === 'dc')[0].children).filter(e => {
        e.path = e.linkUrl
        if(e.children && e.children.length) {
          e.children = e.children.filter(a => {
            a.path = a.linkUrl
            let py = chinese2pinyin(a.title)
            a.py = py[0]
            a.jp = py[1]
            return this.managerNavigationName.includes(a.name)
          })
          return e.children.length
        }else{
          let py = chinese2pinyin(e.title)
          e.py = py[0]
          e.jp = py[1]
          return this.managerNavigationName.includes(e.name)
        }
      })

      this.gmNav = gmNav

      this.saveGmNav = deepcopy(gmNav)

      this.select(this.routePath)
    },
    select(path) {
      console.log(`%cROUTE%c ${path}`, 'background: rgb(204, 153, 102); color: #FFF; padding: 0 4px;', 'color: #000')

      this.$emit('nav', this.navigationList.find(e => e.linkUrl === path) && this.managerNavigation.find(e => e.linkUrl === path) || {})
    },
    //搜索
    search: debounce(function() {
      if(!this.searchStr) {
        this.gmNav = deepcopy(this.saveGmNav)
        this.openList = []
        return
      }

      let searchStr = this.searchStr.toLowerCase().split('|').filter(e => e)

      const search = function(text) {
        for(let i in searchStr) {
          let k = searchStr[i]
          if(text.toLowerCase().indexOf(k) > -1) {
            return true
          }
        }
        return false
      }

      this.gmNav = deepcopy(this.saveGmNav).filter(e => {
        if(e.children && e.children.length) {
          e.children = e.children.filter(a => {
            return search(a.title) || search(a.py) || search(a.jp) || search(a.path) || !searchStr.length
          })
          return e.children.length
        }else{
          return search(e.title) || search(e.py) || search(e.jp) || search(e.path) || !searchStr.length
        }
      })

      this.openList = this.gmNav.map(e => e.name)
    }, 300)
  },
  watch: {
    navigationTree: {
      immediate: true,
      handler() {
        this.getGmNav()
      }
    },
    $route() {
      this.select(this.$route.path)
    }
  }
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.navigation {
  position: relative;
  width: 256px;
  height: 100%;
  z-index: 2;
  background: #001229;
  box-shadow: 2px 0 6px 0 rgba(#001529, .35);
  .search-box {
    width: 100%;
    height: 64px;
    background: #001C40;
    display: flex;
    justify-content: center;
    align-items: center;
    .el-input {
      width: 206px;
      /deep/ {
        .el-input__inner { 
          background: rgba(#FFF, .08);
          border-color: transparent;
          &:focus {
            background: #FFF;
          }
        }
      }
    }
  }
  .el-menu { border-right: none; }
  .scrollbar { max-height: calc(100vh - 64px);}
  /deep/ {
    .el-submenu {
      &.is-active {
        .el-submenu__title { opacity: 1;}
      }
      .el-submenu__title {
        opacity: .65;
        color: #FFF !important;
        .icon {
          display: inline-block;
          width: 16px;
          height: 16px;
          margin-right: 12px;
          @include cover;
        }
      }
      .el-menu-item {
        position: relative;
        height: 38px;
        line-height: 38px;
        padding: 0 48px !important;
        background: #000A17 !important;
        @include ellipsis;
        span { opacity: .65;}
        &::before {
          content: "";
          position: absolute;
          left: 0;
          top: 0;
          width: 60px;
          height: 100%;
          border-left: 4px solid transparent;
          transition: .3s;
        }
        &:hover::before { border-left-color: #FFF;}
        &.is-active {
          span { opacity: 1;}
          &::before {
            border-left-color: $--color-main;
            background: linear-gradient(270deg,rgba(71,150,254,0) 0%,rgba(48,137,255,.4) 100%);
          }
        }
      }
    }
  }
}
</style>
