<template>
  <div class="top-info">
    <div class="logo"></div>
    
    <TopNav base="/dc" />

    <div class="user">
      <el-dropdown @command="command">
        <span class="el-dropdown-link">
          <div 
            class="headimg"
            :style="{backgroundImage: `url(${managerInfo.avatarPath || managerHead})`}"
          ></div>
          {{managerInfo.realName}}
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="logout">退出登录</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    
    </div>
    
  </div>
</template>

<script>
import managerHead from '../../assets/images/headimg_manager.png'
import TopNav from '../../views-gm/frame/topNav'

export default {
  data() {
    return {
      managerHead
    }
  },
  props: {
    navLabel: String
  },
  computed: {
    managerInfo() {
      return this.$store.state.managerInfo
    },
  },
  methods: {
    command(type) {
      switch(type) {
        case 'logout': 
          this.$store.commit('setToken', null)
          break
      }
    }
  },
  components: {
    TopNav
  },
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.top-info {
  width: 100%;
  height: 64px;
  border-bottom: 1px solid #E9E9E9;
  color: #333;
  background: #FFF;
  display: flex;
  align-items: center;
  .logo {
    margin-left: 24px;
    padding-left: 54px;
    height: 28px;
    font-size: 20px;
    line-height: 28px;
    @include image(gm_logo, left center/42px no-repeat);
  }
  .nav-label {
    font-size: 14px;
    color: #333;
    margin-left: 24px;
    .icon {
      margin-right: 10px;
    }
  }
  .user {
    margin-left: auto;
    margin-right: 24px;
    line-height: 24px;
    .el-dropdown-link {
      display: flex;
      cursor: pointer;
    }
    .headimg {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      margin-right: 12px;
      @include cover;
    }
  }
}
</style>
