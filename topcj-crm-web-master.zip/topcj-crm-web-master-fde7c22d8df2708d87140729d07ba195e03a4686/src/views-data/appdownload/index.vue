<template>
  <div  class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >

      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data :data="tableData"/>
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'

export default {
  name: 'dc-appdownload',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
        time: [
          new Date(new Date(Date.now() - (7 * 24 * 60 * 60 * 1000)).timeFormat('yyyy-MM-dd 00:00:00')).getTime(),
          new Date(new Date().timeFormat('yyyy-MM-dd 23:59:59')).getTime()
        ],
        corpId: '',
        channelId: ''
      },
      config: {
        time: {
          type: 'date-range'
        },
        corpId: {
          type: 'select-corp'
        },
        channelId: {
          type: 'select',
          placeholder: '渠道',
          options: this.$store.state.baseData.resChannelList,
          valueKey: 'id',
          labelKey: 'channelName',
        },
        split: { type: 'split' },
        excel:{
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        }
      }
    }
  },
  props: {
    nav: Object,
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }
      
      let { result } = await this.$http({
        url: '%CRM%/product/download_app.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          stime: this.screen.time?.[0] ?? undefined,
          etime: this.screen.time?.[1] ?? undefined,
          corp: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          channelId: typeof this.screen.channelId === 'number' ? this.screen.channelId : undefined
        }
      })
      
      this.total = result.total
      this.tableData = result.contents

      this.loading = false
    })
  },
  components: {
    TableData
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>