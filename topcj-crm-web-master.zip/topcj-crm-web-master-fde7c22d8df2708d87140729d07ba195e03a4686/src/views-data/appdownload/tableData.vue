<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  >
  </el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'ctime',
          label: '日期',
          minWidth: 80,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd') : '--'
        },
        {
          key: 'dealToday',
          label: '当日成交用户数',
          minWidth: 98
        },
        {
          key: 'addToday',
          label: '当日新增账户',
          minWidth: 84,
        },
        {
          key: 'keepTomorrow',
          label: '次日留存率',
          minWidth: 70,
          format: e => (e * 100).toFixed(2) + '%',
          excel: e => `'${(e * 100).toFixed(2)}%`
        }
      ]
    }
  }, 
  props:{
    data:Array
  }
}
</script>