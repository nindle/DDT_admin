<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >
      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData()"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data :data="tableData"/>
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
export default {
  name:'dc-qylogcount',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
        
      },
      config: {
        split: { type: 'split' },
        update:{
          buttonType: 'primary',
          type: 'button',
          label: '刷新数据',
          click: () => { this.getTableData()}
        }
      },
      timer: null
    }
  },
  props: {
    nav: Object,
  },
  methods: {
    update() {
      clearTimeout(this.timer)
      this.timer = setTimeout(() => {
        this.getTableData()
      }, 60000)
    },
    getTableData: throttle(async function() {
      clearTimeout(this.timer)
      this.loading = true

      let { result } = await this.$http({
        url: '%CRM%/report/get_qy_log_info_report.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      })
      
      this.total = result.total
      this.tableData = result.records

      this.loading = false

      this.update()
    })
  },
  components: {
    TableData
  },
  activated() {
    this.getTableData()
  },
  deactivated() {
    clearTimeout(this.timer)
  },
  beforeDestroy() {
    clearTimeout(this.timer)
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>