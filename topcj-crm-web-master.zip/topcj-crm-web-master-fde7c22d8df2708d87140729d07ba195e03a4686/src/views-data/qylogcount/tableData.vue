<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'cdate',
          label: '日期',
          minWidth: 80,
          format: e => new Date(e).timeFormat('yyyy-MM-dd')
        },
        {
          key: 'info',
          label: '账号',
          minWidth: 56
        },
        {
          key: 'total',
          label: '总操作次数',
          minWidth: 70
        },
        {
          key: 'searchTotal',
          label: '搜索次数',
          minWidth: 56
        },
        {
          key: 'copyTotal',
          label: '复制次数',
          minWidth: 56
        },
        {
          key: 'showTotal',
          label: '查看号码次数',
          minWidth: 84
        },
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>