<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'ctime',
          label: '日期',
          minWidth: 80,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd') : '--'
        },
        {
          key: 'serviceDay',
          label: '服务期内用户',
          minWidth: 84
        },
        {
          key: 'addToday',
          label: '新增用户数',
          minWidth: 70
        },
        {
          key: 'keepPerson',
          label: `${this.day}日留存`,
          minWidth: 64,
          format: e => (e * 100).toFixed(2)  + '%',
          excel: e => `'${(e * 100).toFixed(2)}%`
        },
      ]
    }
  },
  props: {
    data: Array,
    day: Number
  },
  watch: {
    day: {
      handler() {
        this.head.find(e => e.key === 'keepPerson').label = `${this.day}日留存`
      },
      immediate: true
    }
  }
}
</script>