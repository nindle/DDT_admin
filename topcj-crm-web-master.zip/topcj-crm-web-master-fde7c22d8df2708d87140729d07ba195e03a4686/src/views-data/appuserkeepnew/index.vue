<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >

      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data
          :data="tableData"
          :day.sync="screen.day"
        />
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
export default {
  name: 'dc-appuserkeepnew',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
        time: [
          new Date(new Date(Date.now() - (7 * 24 * 60 * 60 * 1000)).timeFormat('yyyy-MM-dd 00:00:00')).getTime(),
          new Date(new Date().timeFormat('yyyy-MM-dd 23:59:59')).getTime()
        ],
        type: '',
        day: 1,
        product: 1
      },
      config: {
        time: {
          type: 'date-range'
        },
        type: {
          type: 'select',
          placeholder: '类型',
          options: [
            {value: 1 , label: '首单'},
            {value: 2 , label: '续费'},
          ]
        },
        day: {
          type: 'select',
          placeholder: '留存',
          options: [
            {value: 1 , label: '1日后留存'},
            {value: 2 , label: '2日后留存'},
            {value: 3 , label: '3日后留存'},
            {value: 7 , label: '7日后留存'},
            {value: 14 , label: '14日后留存'},
            {value: 30 , label: '30日后留存'},
          ],
          clearable: false
        },
        product: {
          type: 'select',
          placeholder: '产品',
          options: [
            {value: 1, label: '新产品'},
            {value: 2, label: '老产品'}
          ],
          clearable: false
        },
        split: { type: 'split' },
        excel:{
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        }
      }
    }
  },
  props: {
    nav: Object,
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/product/new_preserve.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          stime: this.screen.time?.[0] ?? new Date(new Date(Date.now() - (7 * 24 * 60 * 60 * 1000)).timeFormat('yyyy-MM-dd 00:00:00')).getTime(),
          etime: this.screen.time?.[1] ?? new Date(new Date().timeFormat('yyyy-MM-dd 23:59:59')).getTime(),
          type: typeof this.screen.type === 'number' ? this.screen.type : undefined,
          day: this.screen.day,
          product: this.screen.product
        }
      })
      
      this.total = result.total
      this.tableData = result.contents

      this.loading = false
    })
  },
  components: {
    TableData
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>