<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'ctime',
          label: '日期',
          minWidth: 80,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd') : '--'
        },
        {
          key: 'dealNum',
          label: '总成交用户',
          minWidth: 70
        },
        {
          key: 'serviceDay',
          label: '服务期内用户',
          minWidth: 84
        },
        {
          key: 'optionalPerson',
          label: '加自选股人数',
          minWidth: 84
        },
        {
          key: 'optionalNum',
          label: '加自选股个数',
          minWidth: 84
        },
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>