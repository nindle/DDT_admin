<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >

      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <!-- <div 
          class="canvas" 
          ref="canvas"
        ></div> -->
        <table-data :data="tableData"/>
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import echarts from 'echarts'
import TableData from './tableData'
export default {
  name: 'dc-salesperformance',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
        month: '',
        corpId: '',
        channelId: '',
      },
      config: {
        month: {
          type: 'date-month'
        },
        corpId: {
          type: 'select-corp'
        },
        channelId: {
          type: 'select',
          placeholder: '渠道',
          options: this.$store.state.baseData.resChannelList,
          valueKey: 'id',
          labelKey: 'channelName',
        },
        split: { type: 'split' },
        excel:{
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        }
      },
      options: {}
    }
  },
  props: {
    nav: Object,
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/sale/sales_performance.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          month: this.screen.month,
          corpId:typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          channelId: typeof this.screen.channelId === 'number' ? this.screen.channelId : undefined,
        }
      })
      
      this.total = result.total
      this.tableData = result.contents
      // this.getChart(result.contents)
      this.loading = false
    }),
    getChart(data) {

      let x = data.map(e => {
        return e.ctime
      })

      let dds = data.map(e => {
        return e.scount
      })

      let yj = data.map(e => {
        return e.total
      })

      let yh = data.map(e => {
        return e.person
      })

      let leftMax = 0
      let rightMax = 0
      data.forEach(e => {
        if(leftMax < e.scount) {
          leftMax = e.scount
        } 

        if(leftMax < e.person) {
          leftMax = e.person
        }

        if(rightMax < e.total) {
          rightMax = e.total
        }
      })
      
      this.options = {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
              type: 'cross',
              crossStyle: {
                  color: '#999'
              }
          }
        },
        toolbox: {
            feature: {
                dataView: {show: true, readOnly: false},
                magicType: {show: true, type: ['line', 'bar']},
                restore: {show: true},
                saveAsImage: {show: true}
            }
        },
        legend: {
            data: ['订单数', '业绩', '用户数']
        },
        xAxis: [
            {
                type: 'category',
                data: x,
                axisPointer: {
                    type: 'shadow'
                }
            }
        ],
        yAxis: [
            {
                type: 'value',
                name: '订单数',
                min: 0,
                max: leftMax,
                interval: leftMax / 5,
                axisLabel: {
                    formatter: '{value}'
                }
            },
            {
                type: 'value',
                name: '业绩',
                min: 0,
                max: rightMax,
                interval: rightMax / 5,
                axisLabel: {
                    formatter: '{value}'
                }
            }
        ],
        series: [
            {
                name: '用户数',
                type: 'bar',
                data: yh
            },
            {
                name: '订单数',
                type: 'line',
                data: dds
            },
            {
                name: '业绩',
                type: 'line',
                yAxisIndex: 1,
                data: yj
            }
        ]
      }
      let chart = echarts.init(this.$refs.canvas)

      chart.setOption(this.options)
    }
  },
  components: {
    TableData
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
    // .canvas {
    //   height: 400px;
    // }
    // /deep/ {
    //   .el-table {
    //     height: calc(100% - 400px);
    //   }
    // }
  }
}
</style>