<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'ctime',
          label: '月份',
          minWidth: 80,
          format: e => new Date(e).timeFormat('yyyy-MM')
        },
        {
          key: 'salesman',
          label: '在职业务人数',
          minWidth: 84,
        },
        {
          key: 'person',
          label: '成交用户数',
          minWidth: 70
        },
        {
          key: 'scount',
          label: '订单总数',
          minWidth: 56,
        },
        {
          key: 'total',
          label: '总业绩',
          minWidth: 42,
          format: e => e.toFixed(2)
        },
        {
          key: 'arpa',
          label: '客单价',
          minWidth: 42,
          format: e => e.toFixed(2)
        },
        {
          key: 'upt',
          label: '客单量',
          minWidth: 42,
          format: e => e.toFixed(2)
        },
        {
          key: 'avgCount',
          label: '人均单数',
          minWidth: 56,
          format: e => e.toFixed(2)
        },
        {
          key: 'avgFee',
          label: '人均金额',
          minWidth: 56,
          format: e => e.toFixed(2)
        },
        
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>