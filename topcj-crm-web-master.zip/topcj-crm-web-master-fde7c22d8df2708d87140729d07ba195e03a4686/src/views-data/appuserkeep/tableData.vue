<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'ctime',
          label: '日期',
          minWidth: 80,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd') : '--'
        },
        {
          key: 'dealToday',
          label: 'AI产品成交用户数',
          minWidth: 122
        },
        {
          key: 'serviceDay',
          label: '服务期内用户',
          minWidth: 84
        },
        {
          key: 'loginCount',
          label: '留存用户',
          minWidth: 56
        },
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>