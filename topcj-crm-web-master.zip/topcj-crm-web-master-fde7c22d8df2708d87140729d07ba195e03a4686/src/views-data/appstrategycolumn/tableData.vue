<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'ctime',
          label: '日期',
          minWidth: 80,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd') : '--'
        },
        {
          key: 'strategy',
          label: '已上线策略数',
          minWidth: 84
        },
        {
          key: 'stare',
          label: '当日盯盘票个数',
          minWidth: 98
        },
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>