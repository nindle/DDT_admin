<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'ctime',
          label: '日期',
          minWidth: 80,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd') : '--'
        },
        {
          key: 'population',
          label: '人数',
          minWidth: 28,
          default: 0
        },
        {
          key: 'countNum',
          label: '次数',
          minWidth: 28,
          default: 0
        },
        {
          key: 'duration',
          label: '停留时长（秒）',
          minWidth: 70,
          format: `{duration}秒`,
          default: 0,
          hide: this.type === 'button'
        },
      ]
    }
  },
  props: {
    data: Array,
    type: String
  },
  watch: {
    type: {
      handler() {
        this.head.find(e => e.key === 'duration').hide = this.type === 'button' ? true : false
      }, 
      immediate: true
    }
  }
}
</script>