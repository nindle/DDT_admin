<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'corpId',
          label: '分公司',
          minWidth: 80,
          format: {
            list: this.$store.state.baseData.corpList,
            key: 'id',
            value: 'corpName'
          }
        },
        {
          key: 'sellCount',
          label: '在岗销售人数',
          minWidth: 84,
        },
        {
          key: 'sellQualificationCount',
          label: '在岗销售有资质人数',
          minWidth: 126
        },
        {
          key: 'afterCount',
          label: '在岗售后人数',
          minWidth: 84,
        },
        {
          key: 'afterQualificationCount',
          label: '在岗售后有资质人数',
          minWidth: 126,
        },
        {
          key: 'complianceCount',
          label: '在岗合规人数',
          minWidth: 84,
        },
        {
          key: 'complianceQualificationCount',
          label: '在岗合规有资质人数',
          minWidth: 126,
        },
        {
          key: 'analyseCount',
          label: '投顾人数',
          minWidth: 56,
        },
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>