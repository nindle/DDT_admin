<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
    >

      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData()"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data :data="tableData"/>
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
export default {
  name: 'dc-qualification',
  data() {
    return {
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
        month: '',
        corpId: '',
      },
      config: {
        month: {
          type: 'date-month'
        },
        corpId: {
          type: 'select-corp'
        },
        split: { type: 'split' },
        excel:{
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        }
      },
    }
  },
  props: {
    nav: Object,
  },
  methods: {
    getTableData: throttle(async function() {
      this.loading = true

      let { result } = await this.$http({
        url: '%CRM%/compliance/qualification.sdcrm',
        data: {
          token: true,
          month: this.screen.month,
          corp:typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
        }
      })

      this.total = result.length
      this.tableData = result
      this.loading = false
    }),
  },
  components: {
    TableData
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
    // .canvas {
    //   height: 400px;
    // }
    // /deep/ {
    //   .el-table {
    //     height: calc(100% - 400px);
    //   }
    // }
  }
}
</style>