<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'resChannelId',
          label: '渠道',
          minWidth: 28,
          format: {
            list: this.$store.state.baseData.resChannelList,
            key: 'id',
            value: 'channelName',
          }
        },
        {
          key: 'resources',
          label: '资源数',
          minWidth: 42
        },
        {
          key: 'person',
          label: '成交人数',
          minWidth: 56
        },
        {
          key: 'scount',
          label: '购买总单数',
          minWidth: 56,
        },
        {
          key: 'total',
          label: '总业绩',
          minWidth: 42
        },
        {
          key: 'arpa',
          label: '客单价',
          minWidth: 42
        },
        {
          key: 'upt',
          label: '客单量',
          minWidth: 42
        },
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>