<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >

      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <!-- <div 
          class="canvas" 
          ref="canvas"
        ></div> -->
        <table-data :data="tableData"/>
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import echarts from 'echarts'
import TableData from './tableData'
export default {
  name: 'dc-saleschannel',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
         time: [
          new Date(new Date(Date.now() - (7 * 24 * 60 * 60 * 1000)).timeFormat('yyyy-MM-dd 00:00:00')).getTime(),
          new Date(new Date().timeFormat('yyyy-MM-dd 23:59:59')).getTime()
        ],
        corpId: '',
      },
      config: {
        time: {
          type: 'date-range'
        },
        corpId: {
          type: 'select-corp'
        },
        split: { type: 'split' },
        excel:{
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        }
      },
      options: {}
    }
  },
  props: {
    nav: Object,
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }
      
      let { result } = await this.$http({
        url: '%CRM%/sale/sales_channel.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          stime: this.screen.time?.[0] ?? undefined,
          etime: this.screen.time?.[1] ?? undefined,
          corpId:typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
        }
      })
      
      this.total = result.total
      this.tableData = result.contents
      // this.getChart(result.contents)
      this.loading = false
    }),
    getChart() {
      let y = ['总计']
      let scount = []
      let total = []
      let resources = []
      let allScount = 0,allTotal = 0, allResources = 0
      this.tableData.forEach(e => {
        y.push(this.$store.state.baseData.resChannelList.filter(item => e.resChannelId === item.id)?.channelName ?? e.resChannelId) 
        scount.push(e.scount)
        allScount += e.scount
        total.push(e.total)
        allTotal += e.total
        resources.push(e.resources)
        allResources += e.resources
      })

      scount.unshift(allScount)
      total.unshift(allTotal)
      resources.unshift(allResources)


      this.options = {
          title: {
            text: '渠道分析情况',
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'shadow'
            }
          },
          legend: {
            data: ['成交量', '成交额', '资源数']
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'value',
            boundaryGap: [0, 0.01]
          },
          yAxis: {
            type: 'category',
            data: y.reverse()
          },
          series: [
            {
                name: '成交量',
                type: 'bar',
                data: scount.reverse()
            },
            {
                name: '成交额',
                type: 'bar',
                data: total.reverse()
            },
            {
                name: '资源数',
                type: 'bar',
                data: resources.reverse()
            }
          ]
      };
      let chart = echarts.init(this.$refs.canvas)

      chart.setOption(this.options)
    }
  },
  components: {
    TableData
  },
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
    // .canvas {
    //   height: 400px;
    // }
    // /deep/ {
    //   .el-table {
    //     height: calc(100% - 400px);
    //   }
    // }
  }
}
</style>