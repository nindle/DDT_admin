<template>
  <div  class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >

      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :column="screen.column"
        />
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'

export default {
  name: 'dc-appcolumn',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
        time: [
          new Date(new Date(Date.now() - (7 * 24 * 60 * 60 * 1000)).timeFormat('yyyy-MM-dd 00:00:00')).getTime(),
          new Date(new Date().timeFormat('yyyy-MM-dd 23:59:59')).getTime()
        ],
        type: '',
        column: 1
      },
      config: {
        time: {
          type: 'date-range'
        },
        type: {
          type: 'select',
          placeholder: '类型',
          options: [
            { value: 1, label: '首单' },
            { value: 2, label: '续费' },
          ]
        },
        column: {
          type: 'select',
          placeholder: '栏目',
          options: [
            { value: 1, label: '个人速递-VIP专享文件' },
            { value: 2, label: '个人速递-复盘汇总' },
            { value: 3, label: '个人速递-机构内参' },
            { value: 4, label: '个人速递-每日策略' },
            { value: 5, label: '个人速递-热点精选' },
            { value: 6, label: '个人速递-玩转ETF' },
            { value: 7, label: '个人速递-盘中宝' },
            { value: 8, label: '个人速递-财经情报站' },
            { value: 9, label: '个人速递-主题投资' },
            { value: 10, label: '个人速递-顶点周刊' },
            { value: 11, label: '策略训练营-策略判大势' },
            { value: 12, label: '策略训练营-策略挖热点' },
            { value: 13, label: '策略训练营-策略教学票' },
            { value: 14, label: '策略训练营-策略直播课' },
            { value: 15, label: '策略训练营-策略私教课' },
            { value: 16, label: '策略选股-我的盯盘' },
            { value: 17, label: '策略选股-我的策略' },
            { value: 18, label: '策略选股-广场策略' },
            { value: 19, label: '策略选股-配置策略' },
            { value: 20, label: '策略选股-盯盘推送', disabled: true },
            { value: 21, label: '行情自选-加自选' },
            { value: 22, label: '行情自选-VIP问股' },
            { value: 23, label: '在线咨询：问老师' },
            { value: 24, label: '问客服：当日问客服' },
            { value: 25, label: '点击拨打客户电话' },
          ],
          clearable: false
        },
        split: { type: 'split' },
        excel:{
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        }
      }
    }
  },
  props: {
    nav: Object,
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }
      
      let { result } = await this.$http({
        url: '%CRM%/product/product_column.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          stime: this.screen.time?.[0] ?? undefined,
          etime: this.screen.time?.[1] ?? undefined,
          type: this.screen.type || undefined,
          column: this.screen.column || undefined
        }
      })
      
      this.total = result.total
      this.tableData = result.contents

      this.loading = false
    })
  },
  components: {
    TableData
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>