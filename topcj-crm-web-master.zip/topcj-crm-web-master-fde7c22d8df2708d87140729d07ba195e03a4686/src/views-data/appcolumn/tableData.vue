<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  >
  </el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'corp',
          label: '公司',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.corpList,
            value: 'corpName',
            key: 'id'
          }
        },
        {
          key: 'population',
          label: '访问人数',
          minWidth: 56,
          default: 0,
          hide: () => ![1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18].includes(this.column)
        },
        {
          key: 'countNum',
          label: '访问次数',
          minWidth: 56,
          default: 0,
          hide: () => ![1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18].includes(this.column)
        },
        {
          key: 'duration',
          label: '停留时长',
          minWidth: 56,
          format: e => this.$options.filters.secondFormat(e, '(h小时 )(m分 )s秒'),
          hide: () => ![1,2,3,4,5,6,7,8,9,10,13,18].includes(this.column)
        },
        {
          key: 'duration',
          label: '观看时长',
          minWidth: 56,
          format: e => this.$options.filters.secondFormat(e, '(h小时 )(m分 )s秒'),
          hide: () => ![14,15].includes(this.column)
        },
        {
          key: 'otherPopulation',
          label: '投票人数',
          minWidth: 56,
          default: 0,
          hide: () => ![11,12].includes(this.column)
        },
        {
          key: 'otherPopulation',
          label: '加自选人数',
          minWidth: 70,
          default: 0,
          hide: () => ![16,18].includes(this.column)
        },
        {
          key: 'otherPopulation',
          label: '操作人数',
          minWidth: 56,
          default: 0,
          hide: () => ![17].includes(this.column)
        },
        {
          key: 'otherPopulation',
          label: '配置人数',
          minWidth: 56,
          default: 0,
          hide: () => ![19].includes(this.column)
        },
        {
          key: 'otherPopulation',
          label: '人数',
          minWidth: 56,
          default: 0,
          hide: () => ![21,22,23,24,25].includes(this.column)
        },
        {
          key: 'detailsNum',
          label: '查看详情人数',
          minWidth: 84,
          default: 0,
          hide: () => ![18].includes(this.column)
        },
        {
          key: 'otherCountNum',
          label: '配置次数',
          minWidth: 56,
          default: 0,
          hide: () => ![19].includes(this.column)
        },
        {
          key: 'otherCountNum',
          label: '次数',
          minWidth: 56,
          default: 0,
          hide: () => ![21,22,23,24,25].includes(this.column)
        },
      ]
    }
  }, 
  props:{
    data: Array,
    column: Number
  }
}
</script>