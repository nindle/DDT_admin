<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'ageRange',
          label:'年龄',
          hide: () => this.type === 2,
          minWidth: 28,
          format: {
            '1' : '18-25',
            '2' : '26-35',
            '3' : '36-45',
            '4' : '46-55',
            '5' : '56以上',
          }
        },
        {
          key: 'gender',
          label:'性别',
          hide: () => this.type === 1,
          minWidth: 28,
          format: {
            '1' : '男',
            '2' : '女',
          }
        },
        {
          key: 'person',
          label: '成交用户数',
          minWidth: 70
        },
        {
          key: 'scount',
          label: '订单总数',
          minWidth: 56,
        },
        {
          key: 'total',
          label: '总业绩',
          minWidth: 42,
          format: e => e.toFixed(2)
        },
        {
          key: 'arpa',
          label: '客单价',
          minWidth: 42,
          format: e => e.toFixed(2)
        },
        {
          key: 'upt',
          label: '客单量',
          minWidth: 42,
          format: e => e.toFixed(2)
        },
      ]
    }
  },
  props: {
    data: Array,
    type: Number
  },
}
</script>