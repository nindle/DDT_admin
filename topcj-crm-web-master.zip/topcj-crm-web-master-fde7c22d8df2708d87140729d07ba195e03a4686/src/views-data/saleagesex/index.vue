<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >

      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :type="screen.type"
        />
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
export default {
  name: 'dc-saleagesex',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
        type: 1,
        corpId: '',
        channelId: '',
        age: '',
        sex: ''
      },
      config: {
        type: {
          type: 'select',
          options: [
            {value: 1,label: '年龄'},
            {value: 2,label: '性别'},
          ],
          clearable: false
        },
        corpId: {
          type: 'select-corp'
        },
        channelId: {
          type: 'select',
          placeholder: '渠道',
          options: this.$store.state.baseData.resChannelList,
          valueKey: 'id',
          labelKey: 'channelName',
        },
        age: {
          type: 'select',
          placeholder: '年龄',
          options: [
            {value: 1,label: '18-25'},
            {value: 2,label: '26-35'},
            {value: 3,label: '36-45'},
            {value: 4,label: '46-55'},
            {value: 5,label: '56以上'},
          ],
          hide: () => this.screen.type === 2
        },
        sex: {
          type: 'select',
          hide: () => this.screen.type === 1,
          placeholder: '性别',
          options: [
            {value: 1,label: '男'},
            {value: 2,label: '女'},
          ],
          
        },
        split: { type: 'split' },
        excel:{
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        }
      },
    }
  },
  props: {
    nav: Object,
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/sale/age_sex.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          type: this.screen.type ? this.screen.type : undefined,
          corpId:typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined, 
          channelId: typeof this.screen.channelId === 'number' ? this.screen.channelId : undefined,
          age: this.screen.type === 1 ? (this.screen.age ? this.screen.age : undefined) : undefined,
          sex: this.screen.type === 2 ? (this.screen.sex ? this.screen.sex : undefined) : undefined,
        }
      })
      
      this.total = result.length
      this.tableData = result
      this.loading = false
    }),
  },
  components: {
    TableData
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>