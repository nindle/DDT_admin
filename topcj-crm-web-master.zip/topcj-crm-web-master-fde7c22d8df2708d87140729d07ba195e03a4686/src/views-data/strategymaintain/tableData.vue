<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'strategyName',
          label: '策略名称',
          minWidth: 56
        },
        {
          key: 'ctime',
          label: '日期',
          minWidth: 80,
          format: e => new Date(e).timeFormat('yyyy-MM-dd')
        },
        {
          key: 'scodeName',
          label: '股票名称',
          minWidth: 56
        },
        {
          key: 'scode',
          label: '股票代码',
          minWidth: 56,
          excel: `'{scode}`
        },
        {
          key: 'inprice',
          label: '买入价',
          minWidth: 42
        },
        {
          key: 'sellTime',
          label: '卖出日期',
          minWidth: 80,
          default: '--',
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd') : '--'
        },
        {
          key: 'sellPrice',
          label: '卖出价',
          minWidth: 42
        },
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>