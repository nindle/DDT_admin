<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'name',
          label: '套餐',
          minWidth: 28
        },
        {
          key: 'money',
          label: '价格',
          minWidth: 56
        },
        {
          key: 'person',
          label: '购买总人数',
          minWidth: 70
        },
        {
          key: 'scount',
          label: '购买总单数',
          minWidth: 56,
        },
        {
          key: 'total',
          label: '总业绩',
          minWidth: 42,
          format: e => e.toFixed(2)
        },
        {
          key: 'arpa',
          label: '客单价',
          minWidth: 42
        },
        {
          key: 'upt',
          label: '客单量',
          minWidth: 42
        },
        
        
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>