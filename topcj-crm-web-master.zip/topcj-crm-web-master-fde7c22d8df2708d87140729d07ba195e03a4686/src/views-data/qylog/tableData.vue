<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
    @row-contextmenu="contextmenu"
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: '记录ID',
          minWidth: 56,
          copy: true
        },
        {
          key: 'ctime',
          label: '创建时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat(),
          copy: true
        },
        {
          key: 'userName',
          label: '账号',
          minWidth: 56,
          copy: true
        },
        {
          key: 'moduleName',
          label: '模块名称',
          minWidth: 56,
          copy: true
        },
        {
          key: 'operateName',
          label: '操作',
          minWidth: 56,
          copy: true
        },
        {
          key: 'operateType',
          label: '操作类型',
          minWidth: 56,
          format: {
            '1': '成功',
            '2': '失败'
          },
          copy: true
        },
        {
          key: 'navId',
          label: '菜单',
          minWidth: 112,
          format: {
            list: this.$store.state.baseData.navigationList,
            key: 'id',
            value: 'title'
          },
          copy: true
        },
        {
          key: 'infoId',
          label: '信息ID',
          minWidth: 56,
          copy: true
        },
        {
          key: 'subId',
          label: '其他信息ID',
          minWidth: 84,
          copy: true
        },
        {
          key: 'infoName',
          label: '信息名称',
          minWidth: 240,
          copy: true
        },
        {
          key: 'ip',
          label: 'IP地址',
          minWidth: 100,
          copy: true
        },
      ]
    }
  },
  props: {
    data: Array
  },
  methods: {
    contextmenu(row, config, event) {
      if(!['infoId', 'subId', 'infoName'].includes(config.property)) return

      let value = `${row[config.property]}`
      if(!/^\d+$/.test(value) && !/^http.+$/.test(value)) return

      let orderOption = {
        icon: 'el-icon-chat-line-square',
        hide: !/^\d+$/.test(value),
        title: '根据订单ID复制详情',
        subTitle: '一般为6位数字及以下',
        handler: () => {
          this.getData({ orderId: value }, row)
        }
      }

      let userOption = {
        icon: 'el-icon-chat-line-square',
        hide: !/^\d+$/.test(value),
        title: '根据用户ID复制详情',
        subTitle: '一般为8位数字',
        handler: () => {
          this.getData({ userId: value }, row)
        }
      }

      let telOption = {
        icon: 'el-icon-chat-line-square',
        hide: !/^\d+$/.test(value),
        title: '根据手机号复制详情',
        subTitle: '一般为11位数字',
        handler: () => {
          this.getData({ tel: value }, row)
        },
        disabled: true
      }

      let snOption = {
        icon: 'el-icon-chat-line-square',
        hide: !(/^\d+$/.test(value) || /sn=(\d+?)[&|$]/.test(value)),
        title: '根据订单号复制详情',
        subTitle: '一般为18位数字',
        handler: () => {
          let sn = value
          if(/sn=(\d+?)[&|$]/.test(value)) {
            sn = value.match(/sn=(\d+?)[&|$]/)[1]
          }

          this.getData({ sn }, row)
        }
      }

      let group1 = [], group2 = []

      if(/^\d+$/.test(value)) {
        if(value.length === 18) {
          group1.push(snOption)
          group2.push(orderOption, userOption, telOption)
        }
        if(value.length === 11) {
          group1.push(telOption)
          group2.push(orderOption, userOption, snOption)
        }
        if(value.length === 8) {
          group1.push(userOption)
          group2.push(orderOption, telOption, snOption)
        }
        if(value.length <= 6) {
          group1.push(orderOption)
          group2.push(userOption, telOption, snOption)
        }
      }else if(/sn=(\d+?)[&|$]/.test(value)){
        group1.push(snOption)
        group2.push(orderOption, userOption, telOption)
      }else{
        group2.push(orderOption, userOption, telOption, snOption)
      }

      this.$contextmenu({
        event,
        menu: [
          group1,
          group2,
          [
            {
              icon: 'el-icon-link',
              hide: !(/^http.+$/.test(value) && row.operateId !== 15),
              title: '打开链接',
              handler: () => {
                this.$open(value)
              }
            },
            {
              icon: 'el-icon-picture-outline',
              hide: !(/^http.+$/.test(value) && row.operateId === 15),
              title: '预览图片',
              handler: () => {
                this.$imageview({
                  list: [value]
                })
              }
            }
          ]
        ]
      })
    },
    async getData(data, row) {
      let { result, code, msg, errmsg } = await this.$http({
        url: '%CRM%/report/get_user_info.sdcrm',
        data: {
          token: true,
          ...data
        }
      }) 

      if(code !== 8200 || !result) {
        this.$message.error(`复制失败：${errmsg || msg}`)
        return
      }

      let archivesText = ''
      switch(result.archivesStatus) {
        case 0: 
          archivesText = '待上传'
          break
        case 1:
          archivesText = '待审核'
          break
        case 2:
          archivesText = '已通过'
          break
        case 4:
          archivesText = '待补充'
          break
      }

      this.$copy(`操作时间：${new Date(row.ctime).timeFormat('hh:MM')}
操作菜单：${this.$store.state.baseData.navigationList.find(e => e.id === row.navId)?.title ?? ''}
信息ID：${result.userId}
成交日期：${new Date(result.dealTime).timeFormat('yyyy.MM.dd')}
成交金额：${result.totalCost}
档案状态：${archivesText}
资质归属：
用户姓名：${result.realname}
服务有效期：${new Date(result.serviceDate).timeFormat('yyyy.MM.dd')}
特别说明：
操作账号：${row.userName}`)
    }
  }
}
</script>