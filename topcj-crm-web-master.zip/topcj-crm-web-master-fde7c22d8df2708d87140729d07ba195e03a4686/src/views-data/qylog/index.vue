<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >
      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data :data="tableData"/>
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
export default {
  name:'dc-qylog',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
        userName: ['15267437609','888888','00001','1906','19957270883','15505889206','cjgly','19642','17704','17703'],
        time: [],
        // moduleId: '',
        operateId: ''
      },
      config: {
        userName: {
          placeholder: '账号',
          type: 'select',
          options: ['15267437609','888888','00001','1906','19957270883','15505889206','cjgly','18004','19642','17704','17703'].map(e => {
            return {
              value: e
            }
          }),
          labelKey: 'value',
          multiple: true
        },
        time: {
          type: 'date-range'
        },
        operateId: {
          placeholder: '操作',
          type: 'select',
          options: [
            { value: 1, label: '显示' },
            { value: 10, label: '搜索' },
            { value: 13, label: '复制' },
            { value: 12, label: '查看用户详情' },
            { value: 15, label: '图片预览' },
            { value: 17, label: '查看隐蔽内容' },
            { value: 11, label: '显示号码' },
            { value: 16, label: '点击' },
            { value: 18, label: '重置密码' },
          ]
        },
        split: { type: 'split' },
        update:{
          buttonType: 'primary',
          type: 'button',
          label: '刷新数据',
          click: () => { this.getTableData(true)}
        }
      },
      timer: null
    }
  },
  props: {
    nav: Object,
  },
  methods: {
    update() {
      clearTimeout(this.timer)
      this.timer = setTimeout(() => {
        this.getTableData()
      }, 60000)
    },
    getTableData: throttle(async function(toFirst) {
      clearTimeout(this.timer)
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/report/get_qy_log_list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
          operateId: this.screen.operateId || undefined,
          userNames: this.screen.userName.length ? this.screen.userName : ['15267437609','888888','00001','1906','19957270883','15505889206','cjgly','18004','19642','17704','17703']
        }
      })
      
      this.total = result.total
      this.tableData = result.records

      this.loading = false

      this.update()
    })
  },
  components: {
    TableData
  },
  activated() {
    this.getTableData()
  },
  deactivated() {
    clearTimeout(this.timer)
  },
  beforeDestroy() {
    clearTimeout(this.timer)
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>