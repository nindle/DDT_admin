import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import './assets/css/element.scss'
import { http, SYS } from './assets/js/http'
import Plugin from './plugin/index'
import Copy from './plugin/copy'
import Contextmenu from './plugin/contextmenu'
import Imageview from './plugin/imageview'

Copy.default({
  afterCopy() {
    resetMessage.success('已复制至剪贴板')
  }
})

global.oncontextmenu = function(e) {
  e.preventDefault()
}

//重置消息提醒
const resetMessage = (options) => {
  return ElementUI.Message({
    showClose: true,
    ...options
  })
}
['success', 'warning', 'info', 'error'].forEach((type) => {
  resetMessage[type] = (options) => {
    if (typeof options === 'string') {
      options = {
        message: options
      }
    }
    options.type = type
    return resetMessage(options)
  }
})

Vue.use(ElementUI)
Vue.use(Plugin)
Vue.use(Copy)
Vue.use(Contextmenu)
Vue.use(Imageview)

Vue.config.productionTip = false

Vue.prototype.$http = http
Vue.prototype.$message = resetMessage
Vue.prototype.SYS = SYS


new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
