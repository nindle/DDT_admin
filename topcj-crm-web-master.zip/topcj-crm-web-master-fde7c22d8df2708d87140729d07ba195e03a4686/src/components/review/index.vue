<template>
  <el-dialog-pro 
    @close="close"
    width="296px"
    v-if="!hide"
  >
    <!--标题-->
    <template #title>
      不通过原因
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
      >确 认</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle, deepcopy } from '../../assets/js/tool'

export default {
  data() {
    return {
      hide: true,
      reviewType: 1,
      form: {
        reason: [],
        content: ''
      },
      config: {
        reason: {
          type: 'select',
          placeholder: '请选择不通过理由',
          options: [],
          valueKey: 'id',
          labelKey: 'remark',
          multiple: true,
          rule: this.customReason ? [
            { 
              validator: (rule, value, callback) => {
                if(!value.length && !this.form.content) {
                  callback(new Error('请至少填写一个理由'))
                }else{
                  if(!this.form.content) {
                    this.$refs.form.validateField('content')
                  }
                  callback()
                }
              }
            }
          ] : [ { required: true, message: '请选择不通过理由', type: 'array' } ]
        },
        content: {
          hide: !this.customReason,
          type: 'textarea',
          placeholder: '请填写不通过理由',
          rule: [
            { 
              validator: (rule, value, callback) => {
                if(!this.form.reason.length && !value) {
                  callback(new Error('请至少填写一个理由'))
                }else{
                  if(!this.form.reason.length) {
                    this.$refs.form.validateField('reason')
                  }
                  callback()
                }
              }
            }
          ]
        }
      }
    }
  },
  props: {
    show: Boolean,
    //理由的typeId
    reasonType: Number,
    /*
    *审核请求列表
    * [{
    *   url: 审核接口
    *   data: 审核请求数据 
    *   meta: 额外的数据
    * }]
    */
    reviewList: Array,
    //是否需要选择理由
    reason: Boolean,
    //是否扣分
    deduct: Boolean,
    //扣分表名（每个页面有个定值，不传会改为扣用户分）
    source: String,
    //审核状态键值
    reviewKey: {
      type: String,
      default: 'status'
    },
    reviewOnlineState: {
      type: [Number, String],
      default: 1
    },
    //审核不通过文案要填充的key值，仅填充在data中
    reasonKey: {
      type: String,
      default: 'reason'
    },
    //扣分项id的key值，默认在data中查询；传meta.id会在meta中查询
    idKey: {
      type: String,
      default: 'id'
    },
    //用户id的key值，默认在data中查询；传meta.userId会在meta中查询
    userKey: {
      type: String,
      default: 'userId'
    },
    //分公司id的key值，默认在data中查询；传meta.corpId会在meta中查询
    corpKey: {
      type: String,
      default: 'corpId'
    },
    //订单id的key值，默认在data中查询；传meta.orderId会在meta中查询
    orderKey: {
      type: String,
      default: 'orderId'
    },
    //打开自定义输入框
    customReason: Boolean
  },
  methods: {
    //初始化
    init() {
      if(!this.reviewList.length) {
        this.$message.error('请选择需要审核的数据')
        this.close()
        return
      }

      //判断当前审核类型
      if(this.reviewOnlineState == this.reviewList[0].data[this.reviewKey]) {
        //审核通过
        this.reviewType = 1
        this.submitReview()
      }else{
        //审核不通过
        this.reviewType = 0
        if(this.reason) {
          //需要理由
          this.getReason()
        }else{
          //不需要理由
          this.submitReview()
        }
      }
    },
    //获取理由
    async getReason() {
      let { result } = await this.$http({
        url: '%CRM%/conformance/get_conformance_search.sdcrm',
        data: {
          token: true,
          callType: 0,
          status: 1,
          typeId: this.reasonType,
          isPage: 0
        }
      })

      this.hide = false

      this.config.reason.options = result
    },
    async submit() {
      if(!await this.$refs.form.check()) return

      this.submitReview()
    },
    //提交审核
    submitReview: throttle(async function() {
      this.hide = true

      let allData = deepcopy(this.reviewList)

      if(this.reviewType === 0 && this.reason) {
        let reason = this.config.reason.options.filter(e => this.form.reason.includes(e.id)).map(e => e.remark)
        if(this.form.content) {
          reason.push(this.form.content)
        }

        allData = allData.map(e => {
          e.data[this.reasonKey] = reason.join('；')
          return e
        })
      }

      let data = await this.$http({
        mode: 'relay',
        all: allData,
        interval: 20
      })

      let successCount = 0
      let errorCount = 0
      let successList = []
      let dataList = []

      data.map((result, i) => {
        if(result.code === 8200) {
          successCount++
          successList.push(allData[i])
        }else{
          errorCount++
          dataList.push(`ID：${allData[i].data[this.idKey]}，错误信息：${result.errmsg || result.msg}`)
        }
      })

      if(data.length === 1) {
        //只有一条数据
        if(successCount === 1) {
          this.$message.success(`审核成功`)
        }else{
          this.$message.error(data[0].errmsg || data[0].msg)
        }
      }else{
        if(dataList.length){
          this.$copy(dataList.join('\n'), () => {
            this.$message.success(`审核成功${successCount}条，失败${errorCount}条；失败信息已复制`)
          }, false)
        }else{
          this.$message.success(`审核成功${successCount}条，失败${errorCount}条`)
        }
      }

      if(this.reviewType === 0 && successList.length) {
        this.submitDeduct(successList)
      }

      this.$emit('success')
      this.close()
    }),
    //扣分
    async submitDeduct(list) {
      let allData = []
      
      list.forEach(e => {
        this.form.reason.forEach(a => {
          let item = {}
          if(this.source) {
            item.sourceId = (this.idKey.indexOf('.') > -1 ? this.idKey.split('.') : ['data', this.idKey]).reduce((pre, e) => pre[e], e)
            item.source = this.source
            item.corpId = (this.corpKey.indexOf('.') > -1 ? this.corpKey.split('.') : ['data', this.corpKey]).reduce((pre, e) => pre[e], e)
          }else{
            item.userId = (this.userKey.indexOf('.') > -1 ? this.userKey.split('.') : ['data', this.userKey]).reduce((pre, e) => pre[e], e)
          }
          item.orderId = (this.orderKey.indexOf('.') > -1 ? this.orderKey.split('.') : ['data', this.orderKey]).reduce((pre, e) => pre[e], e)

          allData.push({
            url: '%CRM%/conformance/add_conformance_record.sdcrm',
            data: {
              token: true,
              conformanceId: a,
              remark: this.config.reason.options.filter(e => a === e.id)[0].remark,
              ...item
            }
          })
        })
      })

      this.$http({
        mode: 'relay',
        all: allData
      })
    },
    close() {
      this.$emit('update:show', false)
    }
  },
  created() {
    this.init()
  }
}
</script>
