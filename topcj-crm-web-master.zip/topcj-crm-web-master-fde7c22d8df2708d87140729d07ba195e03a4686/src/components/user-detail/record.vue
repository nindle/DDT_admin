<template>
  <div class="record-box">
    <el-tabs v-model="activeName">
      <el-tab-pane 
        label="销售工单" 
        name="memo"
        lazy
      >
        <record-memo :saved='saved' :userid='userId'/>
      </el-tab-pane>
      <el-tab-pane 
        v-if="!userDetailConfig.orderTab"
        label="订单情况" 
        name="order"
        lazy
      >
        <record-order :userId="userId"/>
      </el-tab-pane>
    </el-tabs>
    <!-- <work-order/> -->
  </div>
</template>

<script>
// import workOrder from './workOrder'
import RecordOrder from './recordOrder'
import RecordMemo from './recordMemo'

export default {
  data() {
    return {
      activeName: 'memo'
    }
  },
  components: {
    RecordOrder,
    RecordMemo,
    // workOrder
  },
  computed: {
    
  },
  props: {
    userId: Number,
    saved:Boolean,
    userDetailConfig:{
      type:Object,
      default(){
        return {}
      }
    }
  },
  methods: {
    
  },
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.record-box {
  position: relative;
  background: #FFF;
  margin: 12px;
  padding: 0 12px 12px;
  /deep/ {
    .el-tabs__header {
      position: sticky;
      top: 0;
      background: #FFF;
      z-index: 2;
    }
    .el-tabs__nav { width: 100%;}
    .el-tabs__item {
      width: 50%;
      text-align: center;
    }
  }
}
</style>