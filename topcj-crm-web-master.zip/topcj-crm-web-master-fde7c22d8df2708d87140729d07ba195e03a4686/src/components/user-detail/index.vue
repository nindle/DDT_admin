<template>
  <div class="user-detail">
    <detail 
      v-if="userDetail"
      :user-detail="userDetail"
      :userDetailConfig='userDetailConfig'
      :customTag='customTag'
      :show-delete='showDelete'
      @delete="$emit('delete')"
    />
    <record 
      :user-id="userId"
      :saved='saved'
      :userDetailConfig='userDetailConfig'
    />
    <div v-if="!drawer" class="fixbtn">
      <div @click="getUserDetail()"><i></i>工单管理</div>
    </div>
    <div v-if="drawer" @click.stop="drawer = false" v-show="drawer" class="shadowBox">
    </div>
    <Workorder
      v-if="drawer"
      :userId="userId"
      :userDetail="userDetail"
      :ready='ready'
      :customTag='customTag'
      @getInfo='getInfo'
    />
  </div>
</template>

<script>
import Detail from './detail'
import Record from './record'
import Workorder from './workOrder'
import Bus from '../../assets/js/bus'

export default {
  data() {
    return {
      isActive: true,
      userDetail: null,
      ready:false,
      saved:false,
      drawer:false,
    }
  },
  created() {
    this.getUserDetail(1)
    Bus.$on('openDrawer', this.openDrawer)
    this.$log(5, 12, 1, this.$store.state.nav.id, this.userId)
  },
  beforeDestroy () { 
    Bus.$off('openDrawer', this.openDrawer)
  },
  activated() {
    this.isActive = true
  },
  deactivated() {
    this.isActive = false
  },
  props: {
    userId: Number,
    corpId: Number,
    showDelete: Boolean,
    userDetailConfig:Object,
    customTag: Object,
  },
  components: {
    Detail,
    Record,
    Workorder
  },
  methods: {
    async getUserDetail(e) {
      if(this.userDetailConfig?.name === 'gm-corp_source'){
        // this.userDetail = await this.getUserDetailSource(this.userId,this.corpId)
        let user = {
          userId:this.userId,
          path:'%CRM%/res/get_res_profile.sdcrm',
          corpId:this.corpId
        }
        this.userDetail = await this.$store.dispatch('getUserDetail', user)
        this.userDetail.corpId = this.corpId
      }else{
        this.userDetail = await this.$store.dispatch('getUserDetail', this.userId)
      }
      this.ready = true
      if(e)return;
      this.drawer = true
    },
    async getUserDetailSource(userId,corpId){
      let { result } =  await this.$http({
        url: '%CRM%/res/get_res_profile.sdcrm',
        data:{
          token:true,
          userId,
          corpId
        }
      })
      return result ?? {}
    },
    openDrawer() {
      if(!this.isActive) return
      
      this.getUserDetail()
    },
    getInfo(){
      this.saved = true
    },
  },
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";
.user-detail {
  width: 100%;
  height: 100%;
  // overflow: hidden;
  position: relative;
  .shadowBox{
    z-index: 5000;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    background: rgba(#000,.4);
    .content .list .select .addTag{
      width: 20px;
      height: 20px;
      @include image(im-moreTag);
      padding: 0;
      cursor: pointer;
      margin-top: 11px;
    }
  }
  .fixbtn {
    position: sticky;
    bottom: 0;
    line-height: 21px;
    font-size: 16px;
    text-align: center;
    width: 100%;
    box-sizing: border-box;
    padding: 8px 0 11px 0;
    border-width: 1px;
    border-style: solid;
    &:hover {
      cursor: pointer;
      border-width: 1px;
      border-style: solid;
    }
    div {
      display: inline-block;
      height: 21px;
      i {
        float: left;
        width: 18px;
        height: 18px;
        @include image(tool-detail-gener);
        background-size: cover;
        background-size: contain;
        background-size: 100% 100%;
        margin-top: 3px;
        margin-right: 13px;
      }
    }
    color: #333;
    border-color: transparent;
    box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.16);
    background-color: #fff;
    &:hover {
      border-color: rgba(71, 150, 254, 1);
    }
  }
}
</style>
