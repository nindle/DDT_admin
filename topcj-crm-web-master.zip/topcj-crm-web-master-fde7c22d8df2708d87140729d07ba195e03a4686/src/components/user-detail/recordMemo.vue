<template>
  <div>
    <div id="select">
      <div class="selectBox">
        <el-select size="mini" v-model="value" placeholder="全部类型">
          <el-option
            v-for="item in baseDataType"
            :key="item.id"
            :label="item.description"
            :value="item.id"
          ></el-option>
        </el-select>
      </div>

      <div class="selectBox">
        <el-select size="mini" v-model="recording" placeholder="拨通记录">
          <el-option
            v-for="item in recordingList"
            :key="item.value"
            :label="item.description"
            :value="item.id"
          ></el-option>
        </el-select>
      </div>
    </div>
    <div v-show="!infoArr.length" class="ncont">暂无内容</div>
    <div class="flexBox">
      <div
        class="infoList"
        v-for="(item,index) in infoArr"
        :key="index"
        :class="{color:item.memoColor}"
        :style="{order:-item.memoColorOrder}"
        @mouseenter="hoverIndex=index"
        @mouseleave="hoverIndex='-1'"
      >
        <div v-if="index==hoverIndex&&item.memoColor" class="listmask">
            <span class="cancelRed" @click="changeType(item.id,index)">取消标红</span>
        </div>
        <div class="tip">
          <span :class="{type:true}">{{nameType[item.memoType]}}</span>
          <span 
            class="auth"
            v-if="$store.state.sysMode !== 2"
          >添加人：{{item.realName || item.userName}}</span>
          <span class="time">{{new Date(item.ctime)|timeFormat}}</span>
        </div>
        <div class="cont">
          <div 
            v-if="item.memoType!==0"
          >{{item.memo }}</div>
          <div class="aduio" v-if="item.memoType===0">
            <Audio :audio='item.memo'/>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Audio from "../message/msg-audio"
export default {
  props: ["userid",'saved'],
  components: {
    Audio
  },
  data() {
    return {
      recordingList: [],
      optionsEnable: [
        { description: "拨通记录", id: 1 },
        { description: "所有记录", id: 0 }
      ], //recording 延伸选项
      value: 0,
      recording: "",
      infoArr: [],
      pageNum: 1,
      pageSize: 30,
      load: true, //控制加载频率
      flag: false, //控制接口请求
      optionLength: 0, //控制option当前label
      isHold: -1, //拨通记录
      nameType: {
        "0": "录音",
        "1": "销售工单",
        "2": "服务工单",
        "3": "意向工单",
        "4": "特殊工单",
        "5": "内诉工单",
        "6": "外诉工单",
        "90": "直播间"
      },
      newInfoArr: {},
      option: { title: "取消标红", cont: "你确认要取消标红的状态吗?" }, //弹窗文案
      ifshow: false, //是否显示弹框
      changeId: "", //当前取消标红的id
      changeIndex: "", //当前取消标红的index
      hoverIndex: "-1", //当前鼠标移入list 的 index
      memotype:[],
    };
  },
  methods: {
    formatTooltip(val) {
      return this.totime(val);
    },
    //监听弹窗返回操作
    changeIf() {
        this.changeMemoType();
        this.infoArr[this.changeIndex].memoColor = 0;
        this.infoArr[this.changeIndex].memoColorOrder = 0;
        this.ifshow = false;
    },
    //aduio改变value
    changeAudioTime(time, i) {
      let audio = this.$refs["aduio" + i][0];
      setTimeout(() => (audio.currentTime = time), 30);
    },

    //获取工单内容
    async getInfo() {
      if(!this.userid) {
        return
      }
      let momo = this.value;
      this.infoArr = [];
      if (this.value == this.optionLength - 2) return; //录音
      switch (this.value) {
        case 0: //全部类型
          momo = -1;
          break;
        case this.optionLength - 1: //直播间
          momo = 90;
          break;
        // case this.optionLength - 1: //微工作台
        //   momo = 91;
        //   break;
      }
      let { result } = await this.$http({
        url: "%CRM%/memo/get_user_memo.sdcrm",
        data: {
          token: true,
          userId: this.userid, //this.userid, //70000728,//
          pageNum: 1,
          pageSize: this.pageSize,
          memoType: momo,
          isHold: this.isHold
        },
      })
      this.infoArr = result.records.map(v => {
        if(v.memoType!==0) {
          v.memo = v.memo.replace(/topmsg/g, "置顶").replace(/&quot;/g, '"')
        }else{
          v.memo = v.memo.replace('http://192.168.3.10/', 'https://rec.topxlc.com/')
        }
        return {
          ...v,
          playStatus: false,
          startime: "0:00",
          endtime: v.hold,
          modeltime: 0,
          maxtime: 0
        };
      });
    },
    //加载当前工单内容
    async getInfos() {
      if(!this.userid) {
        return
      }
      if (this.flag) return;
      this.load = false;
      this.pageNum++;
      let momo = this.value;
      switch (this.value) {
        case 0: //全部类型
          momo = -1;
          break;
        case this.optionLength - 1: //直播间
          momo = 90;
          break;
        // case this.optionLength - 1: //微工作台
        //   momo = 91;
        //   break;
      }
      let { result } = await this.$http({
        url: "%CRM%/memo/get_user_memo.sdcrm",
        data: {
          token: true,
          userId: this.userid,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          memoType: momo
        }
      })
      if (result.records.length === 0) {
        this.flag = true; //不再请求数据
        return;
      }
      else {
        setTimeout(() => (this.load = true), 20);
        let newarr = result.records.map(v => {
          if(v.memoType!==0) {
            v.memo = v.memo.replace(/topmsg/g, "置顶").replace(/&quot;/g, '"')
          }else{
            v.memo = v.memo.replace('http://192.168.3.10/', 'https://rec.topxlc.com/')
          }
          return {
            ...v,
            playStatus: false,
            startime: "0:00",
            endtime: v.hold,
            modeltime: 0,
            maxtime: 0
          };
        });
        this.infoArr = this.infoArr.concat(newarr);
      }
    },
    //获取录音工单内容
    async getvoice() {
      if(!this.userid) {
        return
      }
      let { result } = await this.$http({
        url: "%CRM%/memo/get_user_memo.sdcrm",
        data: {
          token: true,
          userId: this.userid, //70000728,//
          pageNum: 1,
          pageSize: this.pageSize,
          memoType: 0,
          isHold: this.isHold
        },
      });
      this.infoArr = result.records.map(v => {
        if(v.memoType!==0) {
          v.memo = v.memo.replace(/topmsg/g, "置顶").replace(/&quot;/g, '"')
        }else{
          v.memo = v.memo.replace('http://192.168.3.10/', 'https://rec.topxlc.com/')
        }
        return {
          ...v,
          playStatus: false,
          startime: "0:00",
          endtime: v.hold,
          modeltime: 0,
          maxtime: 0
        };
      });
    },

    //滑动加载录音工单内容
    async getvoices() {
      if(!this.userid) {
        return
      }
      if (this.flag) return;
      this.load = false;
      this.pageNum++;
      let { result } = await this.$http({
        url: "%CRM%/memo/get_user_memo.sdcrm",
        data: {
          token: true,
          userId: this.userid, //70000728,//
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          memoType:0,
          isHold: this.isHold
        },
      });
      if (result.records.length === 0) {
        this.flag = true; //不再请求数据
        return;
      } 
      else {
        setTimeout(() => (this.load = true), 20);
        let newarr = result.records.map(v => {
          if(v.memoType!==0) {
            v.memo = v.memo.replace(/topmsg/g, "置顶").replace(/&quot;/g, '"')
          }else{
            v.memo = v.memo.replace('http://192.168.3.10/', 'https://rec.topxlc.com/')
          }
          return {
            ...v,
            playStatus: false,
            startime: "0:00",
            endtime: v.hold,
            modeltime: 0,
            maxtime: 0
          };
        });
        this.infoArr = this.infoArr.concat(newarr);
      }
    },
    //修改工单红单的id跟index
    changeType(id, i) {
      this.$confirm('确定取消标红?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
        }).then(() => {
          this.changeId = id;
          this.changeIndex = i;
          this.changeIf()
          // this.$message({
          //   type: 'success',
          //   message: '成功!'
          // });
        }).catch(() => {
          // this.$message({
          //   type: 'info',
          //   message: '已取消删除'
          // });
      });
      // this.ifshow = true;
    },
    //修改红单操作
    async changeMemoType() {
      let { code } = await this.$http({
        url: "%CRM%/memo/update_memo_color.sdcrm",
        data: {
          token: true,
          id: Number(this.changeId),
          memoColor: 0
        },
      });
      if (code == 8200) {
        //静态修改
        this.$message({
          message: "修改成功",
          type: "success"
        });
      } 
      else {
        this.$message({
          message: "修改失败",
          type: "error"
        });
      }
    },
    totime(time) {
      time = parseInt(time);
      var m = parseInt(time / 60);
      var s = time - m * 60;
      return (
        (m == 0 ? "0" : m < 10 ? "0" + m : "" + m) +
        ":" +
        (s == 0 ? "00" : s < 10 ? "0" + s : "" + s)
      );
    },
    async getmemoType(){
      let { result,code } = await this.$http({
        mode: 'get',
        url: '%CRM%/memo/get_memo_types.sdcrm',
        data: {
          token: true
        },
      })
      if(code === 8200) {
        let dataArr=[{description:'全部类型',id:0}].concat(result).concat({description:'录音',id:result.length+1},{description:'直播间',id:result.length+2})
        this.memotype = dataArr
        this.optionLength = this.memotype.length;
        this.getInfo(this.memotype);
      }
    }
  },

  filters: {
    //录音时间格式化
    totime(time) {
      time = parseInt(time);
      var m = parseInt(time / 60);
      var s = time - m * 60;
      return (
        (m == 0 ? "0" : m < 10 ? "0" + m : "" + m) +
        ":" +
        (s == 0 ? "00" : s < 10 ? "0" + s : "" + s)
      );
    },
    regs(str) {
      return str.replace(/topmsg/g, "置顶").replace(/&quot;/g, '"')
    }
  },

  computed: {
    baseDataType() {
      return this.memotype;
    }
  },
  created() {
    this.getmemoType()
    this.flag = false; //滚动条加载初始化  可以继续加载
    //如果添加工单 相同id  重新加载
    // Bus.$on("addmemo", b => {
    //   if (b == this.value || this.value == 0) {
    //     this.getInfo();
    //   }
    // });
    // Bus.$on("scroll", d => {
    //   if (d.scrollHeight - (d.clientHeight + d.scrollTop) <= 80) {
    //     if (this.load && this.value !== this.optionLength - 3) {
    //       this.getInfos();
    //     } else {
    //       if (this.load) {
    //         this.getvoices();
    //       }
    //     }
    //   }
    // });
  },
  watch: {
    value(n) {
      //清空第二选项
      this.recordingList = [];
      this.recording = "";
      this.getInfo();
      //录音工单获取
      if (n === this.optionLength - 2) {
        this.recordingList = this.optionsEnable;
        this.recording = 0; //默认所有记录
      }
    },
    userid() {
      if(this.userid) {
        this.getInfo();
      }
    },
    recording(n) {
      if(n === '') return
      this.isHold = Number(n);
      this.getvoice();
    },
    saved(){
      this.getInfo()
    }
  }
};
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";
// @import "./theme.scss";

#select {
  &::after {
    content: "";
    display: table;
    clear: both;
  }
  margin-bottom: 15px;
  .selectBox {
    display: inline-block;
    float: left;
    margin-left: 10px;
    // margin-top: 15px;
  }
  & /deep/ .el-input__inner {
    padding: 0;
    box-sizing: border-box;
    width: 87px;
    font-size: 12px;
    color: #747474;
    height: 26px;
    line-height: 26px;
    padding-left: 12px;
  }
  & /deep/ .el-input__icon {
    line-height: 26px;
  }
}

.infoList {
  margin-bottom: 10px;
  width: 100%;
  box-sizing: border-box;
  padding: 15px 12px;
  position: relative;
  .tip {
    width: 282px;
    line-height: 19px;
    display: flex;
    white-space: nowrap;
    span {
      font-size: 12px;
      color: #AEAEAE;
    }
    .type {
      font-size: 14px;
      margin-right: 5px;
      color: #4796FE;
    }
    .time { margin-left: auto;}
  }

  .cont {
    width: 282px;
    font-size: 12px;
    line-height: 18px;
    margin-top: 10px;
    word-break: break-all;
    user-select: text;
    >>> a {
      cursor: pointer;
      color: #4796FE;
    }
  }
  background-color: #F7F7F7;
  .cont {
    color: #333;
  }
}
.color {
  background: rgba(#F15C5C,0.2);
  .type{
    color: #333!important;
  }
  .cont{
    color: #FF3B30!important;
  }
}

div.ncont {
  text-align: center;
  height: 40px;
  line-height: 40px;
  font-size: 14px;
  color: rgba(102, 102, 102, 1);
  border-color:rgba(223, 223, 223, 1);
}
//录音内容
.aduio {
  width: 100%;
  // height: 44px;
  // background: #fff;
  position: relative;
  .btn {
    width: 20px;
    height: 20px;
    position: absolute;
    left: 10px;
    top: 14px;
    cursor: pointer;
  }
  .play {
    @include image(tool-detail-play);
  }
  .pause {
    @include image(tool-detail-pause);
  }
  .line {
    position: absolute;
    width: 173px;
    height: 4px;
    border-radius: 80px;
    background-color: #dfdfdf;
    top: 22px;
    left: 38px;
    span {
      position: absolute;
      left: 0;
      top: 0;
      height: 100%;
      width: calc(var(--pc) * 100%);
      border-radius: 80px;
      background: #4796fe;
      &::after {
        content: "";
        position: absolute;
        width: 31px;
        height: 31px;
        @include image(tool-detail-posses);
        right: -15px;
        top: -12px;
      }
    }
  }
  .time {
    position: absolute;
    font-size: 12px;
    line-height: 16px;
    color: #666;
    right: 10px;
    top: 16px;
  }
}

.flexBox {
  display: flex;
  flex-direction: column;
}
.listmask {
  position: absolute;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  background: rgba(0,0,0,0.5);
  .cancelRed{
    background: #4796FE;
    color: #fff;
  }
  .cancelRed {
    position: absolute;
    width: 76px;
    height: 30px;
    line-height: 30px;
    text-align: center;
    font-size: 14px;
    border-radius: 4px;
    top: calc(50% - 15px);
    left: 115px;
    cursor: pointer;
  }
}

#lineBox {
  position: absolute;
  width: 173px;
  left: 38px;
  top: 22px;
  >>> .el-slider__runway {
    height: 4px;
    border-radius: 80px;
    margin: 0;
  }
  >>> .el-slider__button-wrapper {
    height: 12px;
    width: 12px;
    position: relative;
    top: -8px;
    z-index:10
  }
  >>> .el-slider__button {
    height: 12px;
    width: 12px;
    @include image(tool-detail-posses);
    border-radius: 0;
    border: none;
    &:hover {
      transform: scale(1);
    }
  }
  >>> .el-slider__bar {
    height: 4px;
    background: #4796fe;
    border-radius: 80px;
  }
}
</style>
