<template>
  <div class="record-order">
    <div class="order-time">
      <div 
        class="item"
        v-for="e in orderListExpTime"
        :key="e.id"
        :class="{ over: new Date(e.expTime).getTime() < Date.now() }"
      >
        <span :title="e.className">{{e.className}}</span>
        <span>到期时间：{{e.expTime | timeFormat('yyyy-MM-dd')}}</span>
      </div>
    </div>
    <el-table-pro
      :head="head"
      :data="tableData"
      noscroll
    >
      <template #body-ctime="{ row }">
        {{row.sn}}<br>{{row.dealTime |timeFormat('yyyy-MM-dd')}}
      </template>
      <template #body-packageName="{ row }">
        {{row.packageName}}<br>{{row.serviceDay}}天
      </template>
    </el-table-pro>
  </div>
</template>

<script>
import { md5 } from '../../assets/js/crypto'

export default {
  data() {
    return {
      orderListExpTime: [],
      head: [
        {
          key: 'ctime',
          label: '编号/消费时间',
          minWidth: 50,
        },
        {
          key: 'refund',
          label: '退费',
          minWidth: 12,
          format: e => e ? '是' : '否' 
        },
        {
          key: 'packageName',
          label: '名称/服务期',
          minWidth: 54,
        },
        {
          key: 'realName',
          label: '归属',
          minWidth: 30
        },
        // {
        //   key: 'sn',
        //   label: '合同',
        //   minWidth: 12,
        //   format: '查看',
        //   click: this.openAgreement
        // }
      ],
      tableData: []
    }
  },
  computed: {
    
  },
  props: {
    userId: Number
  },
  methods: {
    async getOrderListExpTime() {
      let { result } = await this.$http({
        url: '%CRM%/user/get_user_class.sdcrm',
        data: {
          token: true,
          userId: this.userId,
        }
      })

      this.orderListExpTime = result
    },
    async getOrderList() {
      let { result } = await this.$http({
        url: '%CRM%/user/get_order_list.sdcrm',
        data: {
          token: true,
          userId: this.userId,
          pageNum: 1,
          pageSize: 99
        }
      })

      this.tableData = result.records
    },
    openAgreement({ sn }) {
      let time = Date.now()
      let token = this.$store.state.token
      let sign = md5(`7685ab5265c568c41024cca4b396efa1${token}${sn}${time}`)
      
      let url = `${this.SYS.WEBURL}/ns/#/agreement/12?gm=${token}&sn=${sn}&time=${time}&sign=${sign}&size=16`

      this.$open(url)
    }
  },
  created() {
    this.getOrderListExpTime()
    this.getOrderList()
  }
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.record-order {
  .order-time {
    .item {
      width: 100%;
      height: 26px;
      margin-top: 10px;
      padding: 0 12px;
      font-size: 14px;
      line-height: 26px;
      display: flex;
      box-sizing: border-box;
      justify-content: space-between;
      color: $--color-main;
      background: rgba($--color-main, .15);
      span:first-child { 
        font-weight: bold;
        max-width: 40%;
        @include ellipsis;
      }
      &.over {
        color: #999;
        background:#F5F5F5;
      }
    }
  }
  .el-table {
    margin-top: 12px;
    font-size: 12px;
    /deep/ {
      th, td { padding: 6px 0;}
      td:last-child .cell,
      thead th:nth-last-child(2) .cell { padding-right: 6px !important;}
      td:first-child .cell,
      thead th:first-child .cell { padding-left: 6px !important;}
      .cell { 
        padding: 0 6px !important;
        line-height: 18px;
      }
    }
  }
}
</style>