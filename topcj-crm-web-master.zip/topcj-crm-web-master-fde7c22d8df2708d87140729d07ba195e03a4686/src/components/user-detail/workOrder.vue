<template>
  <div class="maskBox">
    <div class="cont">
      <div  class="showBox">
        <div class="filt">
          <el-select style="width:100px;" v-model="usermemo" size="mini" placeholder="全部类型">
            <el-option
              v-for="item in usermemotype"
              :key="item.id"
              :label="item.description"
              :value="item.id">
            </el-option>
          </el-select>
          <div>
            <span>是否标红：</span>
            <el-switch
              v-model="markRed"
              active-text=""
              inactive-text="">
            </el-switch>
          </div>
        </div>
        <div class="tip">
          <div class="input">
            <textarea v-model="content" ></textarea>
          </div>
          <div class="tips">
            <span :class="{active:tipIndex === i}" @click="tipIndex = i;content = e" v-for="(e,i) in tipList" :key="i">{{e}}</span>
            <div class="submit" @click="submitTop()">添加</div>
          </div>
        </div>
        <div class="line"></div>
        <div class="label">
          <el-scrollbar>
            <div class="content">
              <div
                class="list"
                :class="e.tagGroupType ? 'radio' : 'check'"
                v-for="(e, i) in finTag"
                :key="e.tagGroupId"
                v-show="e.tags.length"
              >
                <div class="lab">{{e.tagGroupName}}</div>
                <div class="select">
                  <span
                    :class="{ active: a.active }"
                    v-for="(a, j) in e.tags"
                    :key="a.id"
                    @click="select(i, j)"
                  >{{a.tagTitle}}</span>
                  <!-- <span class="addTag" v-if="i==0" @click="addTag">

                  </span> -->
                </div>
              </div>
            </div>
          </el-scrollbar>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  props:{
    userId:Number,
    userDetail:Object,
    ready:Boolean,
    customTag: Object
  },
  data(){
    return{
      usermemo:1,
      usermemotype:[],
      markRed:true,
      tipList:["无人接听","拒绝接听","提示空号","不炒股票"],
      tipIndex:null,
      content:'',
      info:null,
      tag:[],
    }
  },
  created (){
    if(this.ready){
      this.setTags()
    }
    this.getmemoType()
  },
  watch:{
    content(v){
      this.tipList.forEach((e,i)=>{
        if(e === v){
          this.info = i
          this.tipIndex = i
        }
      })
    },
    ready(v){
      if(v){
        this.setTags()
      }
    }
  },
  computed:{
    finTag() {
      if(this.customTag?.tagList) {
        return this.customTag.tagList
      }
      return this.tag
    }
  },
  methods:{
    addTag(){
      this.iftag=true
    },
    async getmemoType(){
      let { result,code } = await this.$http({
        mode: 'get',
        url: '%CRM%/memo/get_memo_types.sdcrm',
        data: {
          token: true
        }
      })
      if(code !== 8200){
        return
      }
      this.usermemotype = result
    },
    async submitTop(){
      if(!this.content){
        this.$message.error('请输入内容')
        return
      }
      let { code,msg } = await this.$http({
        url: "%CRM%/memo/add_memo.sdcrm",
        data: {
          token: true,
          userId: this.userId,
          memoType: typeof(this.usermemo) === 'number' ? this.usermemo : undefined,
          memoColor: this.markRed ? 1 :0,
          //索引
          memo: this.content
        },
      });
      if(code!==8200){
        this.$message({
          message: msg,
          type: "error"
        });
        return
      }
      this.info = "";
      this.$message({
        message: "添加成功",
        type: "success"
      });
      this.markRed = false;
      this.content = '';
      this.tipIndex = -1;
      this.$emit('getInfo')
    },
    //整理标签
    setTags() {
      let data = this.userDetail.tagsList
      let tag = this.$store.state.baseData.tagList.filter(e => {
        return e.isEdit;
      });
      for (let i in tag) {
        for (let j in tag[i].tags) {
          let e = tag[i].tags[j];
          for (let m in data) {
            if (e.id === data[m].id) {
              e.active = true;
            }
          }
        }
      }
      this.tag = tag;
    },
    //选择标签
    select(index1, index2) {
      let tag = this.finTag

      if (tag[index1].tagGroupType) {
        //单选
        if (tag[index1].tags[index2].active) {
          //已选
          tag[index1].tags[index2].active = false;
        } else {
          //未选
          for (let i in tag[index1].tags) {
            if (Number(i) === index2) {
              tag[index1].tags[i].active = true;
            } else {
              tag[index1].tags[i].active = false;
            }
          }
        }
      } else {
        //多选
        tag[index1].tags[index2].active = !tag[index1].tags[index2].active;
      }

      if(this.customTag?.tagChange) {
        this.customTag.tagChange(tag[index1].tags[index2])
      }else{
        this.submit();
      }
      // this.tag = tag;
    },

    submit: throttle(async function() {
      let s = [];
      for (let i in this.tag) {
        for (let j in this.tag[i].tags) {
          let e = this.tag[i].tags[j];
          if (e.active) {
            s.push({ ...e, share: this.tag[i].share });
          }
        }
      }
      let userid = this.userId
      let { code } = await this.$http({
        url: "%CRM%/tags/set_user_tag.sdcrm",
        data: {
          token: true,
          tagIds: s
            .map(e => {
              return e.id;
            })
            .join(","),
          userId: userid,
          managerId: this.$store.state.managerInfo.id
        },
      });
      if(code!==8200){
        return
      }
      let { result } = await this.$http({
        url: '%CRM%/tags/get_user_tag.sdcrm',
        data: {
          token: true,
          managerId: this.$store.state.managerInfo.id,
          userId: userid
        }
      })
      this.userDetail.tagsList = result.tagIds
      this.$store.commit('setUserDetail',{
        userid,
        data:this.userDetail
      })
      this.setTags()
    }),
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";
.maskBox{
  position: sticky;
  width: 100%;
  height: 100%;
  // top: 0;
  bottom: 0;
  z-index:5500;
  .cont{
    height: 100%;
    width: 100%;
    // top: 0;
  }
  
  .showBox{
    position: sticky;
    bottom: 0;
    box-sizing: border-box;
    padding: 0 12px 20px;
    width: 100%;
    height: 507px;
    background: #fff;
    >div{
      font-size: 14px;
      line-height: 28px;
      margin-top: 14px;
    }
    .filt{
      padding-top: 14px;
      display: flex;
      justify-content: left;
      >div>span{
        margin-left: 18px;
        display: inline-block;
        line-height: 20px;
      }
    }
    .tip{
      display: flex;
      justify-content: space-between;
      .input{
        background: #F5F5F5;
        width: 257px;
        height: 105px;
        padding: 8px;
        box-sizing: border-box;
        >textarea{
          width: 100%;
          height: 100%;
          resize:none;
          outline:none;
          border: none;
          background: #F5F5F5;
        }
      }
      .tips{
        color: #666666;
        width: 56px;
        line-height: 21px;
        font-size: 12px;
        >span{
          cursor: pointer;
        }
        .active{
          color: #4796FE;
        }
        >div{
          cursor: pointer;
          margin-top: 2px;
          background: #4796FE;
          color: #Fff;
          text-align: center;
          line-height: 18px;
        }
      }
    }
    .line{
      height: 1px;
      width: 100%;
      background: #dfdfdf;
    }
    .label{
      height: calc( 100% -  176px);
      /deep/.el-scrollbar{
        height: 100%;
      }
      .content {
        padding: 20px 7px 0;
        .list{
          .lab{ color: #666;}
          .select {
            span {
              border-color: #DFDFDF;
              color: #999;
              &.active {
                border-color: #4796FE;
                color: #4796FE;
                background: rgba(#4796FE, .15);
              }
            }
          }
        }
        .list {
          padding-bottom: 20px;
          .lab {
            font-size: 12px;
            line-height: 16px;
            padding-left: 5px;
          }
          &.radio .lab::after {
            content: " (单选)：";
          }
          &.check .lab::after {
            content: " (多选)：";
          }
          .select {
            display: flex;
            flex-wrap: wrap;
            span {
              font-size: 12px;
              line-height: 22px;
              height: 22px;
              padding: 0 8px;
              margin: 10px 5px 0;
              border-radius: 4px;
              text-align: center;
              border-width: 1px;
              border-style: solid;
              cursor: pointer;
            }
          }
        }
      }
    }
  }
}

</style>