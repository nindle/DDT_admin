<template>
  <div class="detail-box">
    <div class="nick-name">
      <span>客户名称：</span>
      <span  
        class="name"
        v-copy
        v-if="!isEditNickName"
      >{{userDetail.remarkName || userDetail.nickname}}</span>
      <i 
        class="el-icon-edit"
        v-if="!isEditNickName"
        @click="openEditNickName"
      ></i>
      <el-input
        size="mini"
        v-model="nickName"
        v-if="isEditNickName"
        autofocus
        @change="editNickName"
      ></el-input>
    </div>

    <div class="status">{{userDetail.status | filterStatus}}</div>

    <div class="info">
      <span 
        v-copy="userDetail.nickname"
        class="gender"
        :class="`gender${userDetail.gender}`"
      >昵称：{{userDetail.nickname}}<i class="el-icon-user-solid"></i></span>

      <span 
        v-if="userDetail.status !== 1"
        class="risk"
        :class="{ on: userDetail.riskScore }"
        title="风险测评"
      >{{userDetail.riskScore | filterRisk(userDetail.riskType)}}
        <i 
          class="el-icon-s-order"
          v-if="!userDetail.riskScore"
        ></i>
      </span>

      <span 
        class="idnum"
        :class="{on: userDetail.idNum}"
        v-if="userDetail.status !== 1"
        title="实名认证"
      ><i class="el-icon-s-custom"></i></span>

      <span class="split"></span>

      <span v-copy="userDetail.userId">顶点ID：{{userDetail.userId}}</span>

      <span 
        class="mobileauth"
        v-if="mobileauth && authShowUserPhone"
        v-copy
      >{{mobileauth}}</span>
      <el-button 
        class="mobile"
        type="text"
        size="small"
        icon="el-icon-search"
        @click="findMobile"
        v-if="!mobileauth && userDetail.mobile && authShowUserPhone"
      >查询手机</el-button>

      <span class="split"></span>

      <template v-if="userDetail.idNum">
        <span>姓名：
          <scratch
            class="realname"
            :data="userDetail.realname"
            mode="name"
            :log="userDetail.userId"
            copy
          />
        </span>
        <span>年龄：{{ userDetail.birthday | filterAge }}岁</span>
        <span>生日：{{ userDetail.birthday | timeFormat('MM月dd日') }}</span>
      </template>
    </div>

    <div 
      class="step"
      :class="{s1: userDetail.tagIdsList.includes(801), s2: userDetail.tagIdsList.includes(802), s3: userDetail.tagIdsList.includes(803)}"
      :data-text-1="userTagRename.filter(e => e.id === 800)[0].tagTitle"
      :data-text-2="userTagRename.filter(e => e.id === 801)[0].tagTitle"
      :data-text-3="userTagRename.filter(e => e.id === 802)[0].tagTitle"
      :data-text-4="userTagRename.filter(e => e.id === 803)[0].tagTitle"
    >
      <span></span>
      <span></span>
      <span></span>
    </div>
    <div class="tag-password">
      <div class="tag">
        <el-tag
          v-for="(e, i) in tagsList"
          :key="i"
          :type="productTag.includes(e.id) ? 'danger' : (e.share === 1 ? 'info' : '')"
          size="small"
        >{{e.tagTitle}}</el-tag>
      </div>
      <el-button
        type="text"
        size="small"
        icon="el-icon-refresh"
        @click="resetPassword"
        v-if="authShowPassWord"
      >重置密码</el-button>
    </div>
    
    <div class="attach">
      <slot name="" :userDetail="userDetail" :resName="resName" :attachInfo="attachInfo">
        <span>注册时间：{{ userDetail.regTime | timeFormat }}</span>
        <span class="split"></span>
        <span v-if="false">来源：{{resName}}</span>
        <span>关键词：{{userDetail.keyword}}</span>
        <span class="split"></span>
        <template v-if="$store.state.sysMode !== 2">
          <span v-if="!userDetailConfig.gsName" v-copy="attachInfo.gsName">业务：{{attachInfo.gsName}}</span>
          <span v-if="!userDetailConfig.jcName" v-copy="attachInfo.jcName">监察：{{attachInfo.jcName}}</span>
          <span v-if="!userDetailConfig.shName" v-copy="attachInfo.shName">售后：{{attachInfo.shName}}</span>
        </template>
        <!-- 默认打开 -->
        <!-- 默认关闭 -->
        <span v-if="userDetailConfig.corp" v-copy="attachInfo.corp">归属公司：{{attachInfo.corp}}</span>
        <span v-if="userDetailConfig.getTime">分配时间：{{ userDetail.getTime | timeFormat }}</span>
        <span v-if="userDetailConfig.lastActivationTime">激活时间：{{ userDetail.lastActivationTime | timeFormat }}</span>
      </slot>

      <el-popconfirm
        v-if="showDelete"
        class="delete"
        title="确定丢弃该资源？"
        iconColor="#3089FF"
        @confirm="$emit('delete')"
      >
        <el-button
          slot="reference"
          size="mini"
          type="text"
          icon="el-icon-delete"
        >丢弃</el-button>
      </el-popconfirm>
    </div>
  </div>
</template>

<script>
import { md5 } from '../../assets/js/crypto'
import Scratch from '../other/scratch'

export default {
  data() {
    let managerNavigationActionType = this.$store.state.baseData.managerNavigation.find(e => e.name === 'view_user_phone')?.actionType.split(',').map(e => Number(e)) ?? []
    let resetPassWordActionType = this.$store.state.baseData.managerNavigation.find(e => e.name === 'reset_password')?.actionType.split(',').map(e => Number(e)) ?? []
    return {
      mobileauth: '',
      isEditNickName: false,
      nickName: '',
      userTagRename: this.$store.state.baseData.tagList.filter(e => e.tagGroupId === 39)[0].tags,
      authShowUserPhone: (managerNavigationActionType.includes(1) || !managerNavigationActionType.includes(4)) && this.$store.state.sysMode === 1,
      authShowPassWord: resetPassWordActionType.includes(1)
    }
  },
  components: {
    Scratch
  },
  computed: {
    tagsList() {
      if(this.customTag?.userTag) {
        return this.customTag.userTag
      }
      return this.userDetail.tagsList.filter(e => {
        for(let i in this.showTagIdsList) {
          let a = this.showTagIdsList[i]
          if(a.id === e.id) {
            e.tagTitle = a.tagTitle
            return true
          }
        }
        return false
      })
    },
    showTagIdsList() {
      return this.$store.state.baseData.tagList
        .filter(e => [39,40,14,21,41,1,43].includes(e.tagGroupId))
        .reduce((pre, e) => [...pre, ...e.tags], [])
    },
    productTag() {
      return this.$store.state.baseData.tagList.filter(e => e.tagGroupId === 14)[0].tags.map(e => e.id)
    },
    attachInfo() {
      let result = {}

      this.userDetail.attachList.forEach(e => {
        if(e.attachType === 2) {
          result.gsName = e.realName
        }else if(e.attachType === 1) {
          result.shName = e.realName
        }else if(e.attachType === 4) {
          result.jcName = e.realName
        }
        result.ctime = e.ctime
      })

      return result
    },
    resName() {
      return this.$store.state.baseData.secTypeList.filter(e => e.id === this.userDetail.resType)[0]?.resName ?? ''
    }
  },
  props: {
    showDelete: Boolean,
    userDetail: Object,
    customTag: Object,
    //控制隐藏项
    userDetailConfig:{
      type:Object,
      default(){
        return {
          corp:false
        }
      }
    }
  },
  methods: {
    openEditNickName() {
      this.isEditNickName = true
      this.nickName = this.userDetail.remarkName || this.userDetail.nickname
    },
    async editNickName() {
      await this.$http({
        url: this.userDetailConfig?.name === 'gm-corp_source' && '%CRM%/res/set_res_remark_name.sdcrm' || '%CRM%/user/set_user_name.sdcrm',
        // url: '%CRM%/user/set_res_remark_name.sdcrm',
        data: {
          token: true,
          remarkName: this.nickName,
          userId: this.userDetail.userId,
          corpId:this.userDetail.corpId ?? undefined
        }
      })

      this.userDetail.remarkName = this.nickName
      this.isEditNickName = false
      this.nickName = ''
    },
    async findMobile() {
      let mobileauth = this.userDetail.mobileauth
      if(!mobileauth) {
        let deadline = Date.now()
        let loginId = this.userDetail.loginId

        let { code, result, errmsg, msg } = await this.$http({
          url: '%CRM%/call/find_mobile_by_login_id.sdcrm',
          data: {
            token: true,
            loginId,
            deadline,
            sign: md5(`${loginId}f097f902d77743fcb27d74e6cdb9f8f6${deadline}`)
          }
        })

        if(code !== 8200) {
          this.$message.error(errmsg || msg)
          return
        }

        mobileauth = result || '--'
        this.userDetail.mobileauth = mobileauth
      }
      
      this.mobileauth = mobileauth
      this.$log(5, 11, 1, this.$store.state.nav.id, this.userDetail.userId)
    },
    async deleteUser() {
      await this.$http({
        url: this.userDetailConfig?.name === 'gm-corp_source' && '%CRM%/user/user_discard.sdcrm' || '%CRM%/res/res_discard.sdcrm',
        data: {
          token: true,
          userId: this.userDetail.userId
        }
      })
    },
    async resetPassword() {
      let deadline = Date.now()
      let loginId = this.userDetail.loginId

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/user/reset_user_password.sdcrm',
        data: {
          token: true,
          loginId,
          deadline,
          sign: md5(`${loginId}f097f902d77743fcb27d74e6cdb9f8f6${deadline}`)
        }
      })

      if(code !== 8200) {
        this.$message.error(errmsg || msg)
        return
      }
      this.$message.success('重置成功')
      this.$log(5, 18, 1, this.$store.state.nav.id, this.userDetail.userId)
    }
  },
  filters: {
    filterStatus(type) {
      switch(type) {
        case 4:
        case 0: return '已激活'
        case 1: return '未激活'
        case 2: return '冻结'
        case 3: return '被合并'
        default: return ''
      }
    },
    filterRisk(score, num) {
      switch(num){
        case 0: return score + '(保守型)'
        case 1: return score + '(相对保守型)'
        case 2: return score + '(稳健型)'
        case 3: return score + '(相对积极型)'
        case 4: return score + '(积极型)'
        default: return ''
      }
    },
    filterAge(date) {
      return Math.floor((new Date().getTime() - new Date(date).getTime()) / (365 * 24 * 60 * 60 * 1000))
    }
  }
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.detail-box {
  position: relative;
  background: #FFF;
  margin: 12px;
  padding: 12px;
  .nick-name {
    font-size: 14px;
    line-height: 28px;
    color: #333;
    .el-input { width: 120px;}
    .name {
      display: inline-block;
      max-width: 150px;
      @include ellipsis;
      vertical-align: top;
    }
    .el-icon-edit {
      color: $--color-main;
      cursor: pointer;
      margin-left: 6px;
    }
  }
  .status {
    position: absolute;
    right: 12px;
    top: 12px;
    font-size: 12px;
    line-height: 28px;
    color: #999;
  }
  .info {
    display: flex;
    flex-wrap: wrap;
    font-size: 12px;
    line-height: 22px;
    color: #999;
    justify-content: space-between;
    i { font-size: 14px;}
    .gender {
      i { margin-left: 6px;}
      &.gender1 i { color: $--color-main;}
      &.gender2 i { color: rgb(241, 94, 94);}
    }
    .risk { 
      margin-left: auto;
      &.on { color: $--color-main;}
    }
    .idnum { 
      &.on { color: $--color-main;}
      margin-left: 6px;
    }
    .split { width: 100%;}
    .mobileauth { margin-left: auto;}
    .mobile {
      margin-left: auto;
      padding: 0;
    }
    .realname {
      display: inline-block;
      /deep/ {
        .el-button { padding: 0;}
      }
    }
  }
  .step {
    width: 100%;
    display: flex;
    align-items: center;
    padding-top: 10px;
    span {
      position: relative;
      flex-grow: 1;
      height: 4px;
      border-radius: 2px;
      background: #DFDFDF;
      margin-right: 3px;
      &::before {
        content: "";
        position: absolute;
        left: calc(50% - 6px);
        top: -4px;
        width: 8px;
        height: 8px;
        background: #AEAEAE;
        border-radius: 50%;
        border: 2px solid #FFF;
      }
    }
    &::after {
      content: attr(data-text-1);
      font-size: 12px;
      color: #999;
      margin-left: 9px;
    }
    &.s1 {
      span:nth-child(1) {
        background: $--color-main;
        &::before { background: $--color-main;}
      }
      &::after { content: attr(data-text-2);}
    }
    &.s2 {
      span:nth-child(2) {
        background: $--color-main;
        &::before { background: $--color-main;}
      }
      &::after { content: attr(data-text-3);}
    }
    &.s3 {
      span:nth-child(3) {
        background: $--color-main;
        &::before { background: $--color-main;}
      }
      &::after { content: attr(data-text-4);}
    }
  }
  .tag-password {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
    .tag {
      .el-tag { margin: 0 8px 8px 0;}
    }

    /deep/ {
      .el-button {
        height: 24px;
        padding:  0;
      }
    }
  }
  
  
  .attach {
    position: relative;
    background: #F5F5F5;
    margin-top: 10px;
    padding: 8px;
    font-size: 12px;
    line-height: 22px;
    color: #999;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    .split { width: 100%;}
    .delete {
      position: absolute;
      right: 8px;
      top: 4px;
    }
  }
}
</style>