<template>
  <div 
    class="msg-text"
    v-html="html"
    @click="click"
    :data-label="label"
  ></div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  computed: {
    html() {
      let html = this.text

      if(!html) return ''

      html = html.replace(/&/g, '&amp;')

      if(this.face) {
        html = html.replace(/\/::~/g, '[撇嘴]')
          .replace(/\/::B/g, '[色]')
          .replace(/\/::\|/g, '[发呆]')
          .replace(/\/:8-\)/g, '[得意]')
          .replace(/\/::</g, '[流泪]')
          .replace(/\/::\$/g, '[害羞]')
          .replace(/\/::X/g, '[闭嘴]')
          .replace(/\/::Z/g, '[睡]')
          .replace(/\/::'\(/g, '[大哭]')
          .replace(/\/::-\|/g, '[尴尬]')
          .replace(/\/::@/g, '[发怒]')
          .replace(/\/::P/g, '[调皮]')
          .replace(/\/::D/g, '[呲牙]')
          .replace(/\/::O/g, '[惊讶]')
          .replace(/\/::\(/g, '[难过]')
          .replace(/\/::Q/g, '[抓狂]')
          .replace(/\/::T/g, '[吐]')
          .replace(/\/:,@P/g, '[偷笑]')
          .replace(/\/:,@-D/g, '[可爱]')
          .replace(/\/::d/g, '[白眼]')
          .replace(/\/:,@o/g, '[傲慢]')
          .replace(/\/:\|-\)/g, '[困]')
          .replace(/\/::!/g, '[惊恐]')
          .replace(/\/::L/g, '[流汗]')
          .replace(/\/::>/g, '[憨笑]')
          .replace(/\/:,@f/g, '[奋斗]')
          .replace(/\/::-S/g, '[咒骂]')
          .replace(/\/:\?/g, '[疑问]')
          .replace(/\/:,@x/g, '[嘘]')
          .replace(/\/:,@@/g, '[晕]')
          .replace(/\/:,@!/g, '[衰]')
          .replace(/\/:!!!/g, '[骷髅]')
          .replace(/\/:xx/g, '[敲打]')
          .replace(/\/:bye/g, '[再见]')
          .replace(/\/:wipe/g, '[擦汗]')
          .replace(/\/:dig/g, '[抠鼻]')
          .replace(/\/:handclap/g, '[鼓掌]')
          .replace(/\/:B-\)/g, '[坏笑]')
          .replace(/\/:<@/g, '[左哼哼]')
          .replace(/\/:@>/g, '[右哼哼]')
          .replace(/\/::-O/g, '[哈欠]')
          .replace(/\/:>-\|/g, '[鄙视]')
          .replace(/\/:P-\(/g, '[委屈]')
          .replace(/\/::'\|/g, '[快哭了]')
          .replace(/\/:X-\)/g, '[阴险]')
          .replace(/\/::\*/g, '[亲亲]')
          .replace(/\/:8\*/g, '[可怜]')
          .replace(/\/:pd/g, '[菜刀]')
          .replace(/\/:<W>/g, '[西瓜]')
          .replace(/\/:beer/g, '[啤酒]')
          .replace(/\/:coffee/g, '[咖啡]')
          .replace(/\/:pig/g, '[猪头]')
          .replace(/\/:rose/g, '[玫瑰]')
          .replace(/\/:fade/g, '[凋谢]')
          .replace(/\/:showlove/g, '[嘴唇]')
          .replace(/\/:heart/g, '[爱心]')
          .replace(/\/:break/g, '[心碎]')
          .replace(/\/:cake/g, '[蛋糕]')
          .replace(/\/:bome/g, '[炸弹]')
          .replace(/\/:shit/g, '[便便]')
          .replace(/\/:moon/g, '[月亮]')
          .replace(/\/:sun/g, '[太阳]')
          .replace(/\/:hug/g, '[拥抱]')
          .replace(/\/:strong/g, '[强]')
          .replace(/\/:weak/g, '[弱]')
          .replace(/\/:share/g, '[握手]')
          .replace(/\/:v/g, '[胜利]')
          .replace(/\/:@\)/g, '[抱拳]')
          .replace(/\/:jj/g, '[勾引]')
          .replace(/\/:@@/g, '[拳头]')
          .replace(/\/:ok/g, '[OK]')
          .replace(/\/:jump/g, '[跳跳]')
          .replace(/\/:shake/g, '[发抖]')
          .replace(/\/:<O>/g, '[怄火]')
          .replace(/\/:circle/g, '[转圈]')
          .replace(/\[Hey\]/g, '[嘿哈]')
          .replace(/\[Facepalm\]/g, '[捂脸]')
          .replace(/\[Smirk\]/g, '[奸笑]')
          .replace(/\[Smart\]/g, '[机智]')
          .replace(/\[Concerned\]/g, '[皱眉]')
          .replace(/\[Yeah!\]/g, '[耶]')
          .replace(/\[Packet\]/g, '[红包]')

        let reg = new RegExp(/\[(微笑|撇嘴|色|发呆|得意|流泪|害羞|闭嘴|睡|大哭|尴尬|发怒|调皮|呲牙|惊讶|难过|酷|囧|抓狂|吐|偷笑|可爱|白眼|傲慢|饥饿|困|惊恐|流汗|憨笑|大兵|奋斗|咒骂|疑问|嘘|晕|折磨|衰|骷髅|敲打|再见|擦汗|抠鼻|鼓掌|糗大了|坏笑|左哼哼|右哼哼|哈欠|鄙视|委屈|快哭了|阴险|亲亲|吓|可怜|菜刀|西瓜|啤酒|篮球|乒乓|咖啡|饭|猪头|玫瑰|凋谢|嘴唇|爱心|心碎|蛋糕|闪电|炸弹|刀|足球|瓢虫|便便|月亮|太阳|礼物|拥抱|强|弱|握手|胜利|抱拳|勾引|拳头|差劲|爱你|NO|OK|爱情|飞吻|跳跳|发抖|怄火|转圈|嘿哈|捂脸|奸笑|机智|皱眉|耶|茶|红包|蜡烛)\]/, 'g')
        html = html.replace(reg, `<img class="face-${this.faceTheme}" face="$1" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAGElEQVRIie3BAQEAAACAkP6v7ggKAICqAQkYAAHO7iU+AAAAAElFTkSuQmCC" />`)
      }

      if(this.br) {
        html = html.replace(/\n/g, '<br>')
      }

      if(this.divbr) {
        html = html.replace(/[\f|\r]/g, '')
          .replace(/$/, '\f')
          .replace(/\n([^\n|\f]+)/g, '<div>$1</div>')
          .replace(/\n/g, '<div><br></div>')
          .replace(/[\f|\n|\r]/g, '')
          .replace(/( )(?![^><]*>)/g, '&nbsp;')
      }

      if(this.link) {
        html = html.replace(/\b(([\w-]+:\/\/?|www[.])[^\s()<>]+(?:[\w\d]+|([^[:punct:]\s]|\/)))/g, '<a link="$&">$&</a>')
      }

      if(this.safehtml) {
        html = html.replace(/</g, '&lt;').replace(/>/g, '&gt;')
      }

      if(typeof this.keyword === 'string') {
        let reg = new RegExp(`(${this.keyword})(?![^><]*>)`, 'g')
        html = html.replace(reg, '<b>$1</b>')
      }else if(this.keyword){
        this.keyword.forEach(e => {
          let reg = new RegExp(`(${e})(?![^><]*>)`, 'g')
          html = html.replace(reg, '<b>$1</b>')
        })
      }

      return html
    }
  },
  props: {
    label: String,
    text: String,
    face: Boolean,
    faceTheme: {
      type: String,
      default: 'default'
    },
    br: Boolean,
    divbr: Boolean,
    link: Boolean,
    safehtml: Boolean,
    keyword: [String, Array]
  },
  methods: {
    click(e) {
      if(e.target.nodeName !== 'A') return

      this.$open(e.target.getAttribute('link'))
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

//表情
@mixin face($name) {
  background: url(../../assets/images/face/#{$name}.png) center/100% no-repeat;
}

@mixin face-new($name) {
  background: url(../../assets/images/face_2/#{$name}.png) center/100% no-repeat;
}

.msg-text {
  word-break: break-word;
  &::before {
    content: attr(data-label);
    color: $--color-main;
  }
  /deep/ {
    .face-default {
      &[face] {
        display: inline-block;
        width: 1.2em;
        height: 1.2em;
        vertical-align: sub;
      }
      &[face="微笑"] { @include face(qq_001);}
      &[face="撇嘴"] { @include face(qq_002);}
      &[face="色"] { @include face(qq_003);}
      &[face="发呆"] { @include face(qq_004);}
      &[face="得意"] { @include face(qq_005);}
      &[face="流泪"] { @include face(qq_006);}
      &[face="害羞"] { @include face(qq_007);}
      &[face="闭嘴"] { @include face(qq_008);}
      &[face="睡"] { @include face(qq_009);}
      &[face="大哭"] { @include face(qq_010);}
      &[face="尴尬"] { @include face(qq_011);}
      &[face="发怒"] { @include face(qq_012);}
      &[face="调皮"] { @include face(qq_013);}
      &[face="呲牙"] { @include face(qq_014);}
      &[face="惊讶"] { @include face(qq_015);}
      &[face="难过"] { @include face(qq_016);}
      &[face="酷"] { @include face(qq_017);}
      &[face="囧"] { @include face(qq_018);}
      &[face="抓狂"] { @include face(qq_019);}
      &[face="吐"] { @include face(qq_020);}
      &[face="偷笑"] { @include face(qq_021);}
      &[face="可爱"] { @include face(qq_022);}
      &[face="白眼"] { @include face(qq_023);}
      &[face="傲慢"] { @include face(qq_024);}
      &[face="饥饿"] { @include face(qq_025);}
      &[face="困"] { @include face(qq_026);}
      &[face="惊恐"] { @include face(qq_027);}
      &[face="流汗"] { @include face(qq_028);}
      &[face="憨笑"] { @include face(qq_029);}
      &[face="大兵"] { @include face(qq_030);}
      &[face="奋斗"] { @include face(qq_031);}
      &[face="咒骂"] { @include face(qq_032);}
      &[face="疑问"] { @include face(qq_033);}
      &[face="嘘"] { @include face(qq_034);}
      &[face="晕"] { @include face(qq_035);}
      &[face="折磨"] { @include face(qq_036);}
      &[face="衰"] { @include face(qq_037);}
      &[face="骷髅"] { @include face(qq_038);}
      &[face="敲打"] { @include face(qq_039);}
      &[face="再见"] { @include face(qq_040);}
      &[face="擦汗"] { @include face(qq_041);}
      &[face="抠鼻"] { @include face(qq_042);}
      &[face="鼓掌"] { @include face(qq_043);}
      &[face="糗大了"] { @include face(qq_044);}
      &[face="坏笑"] { @include face(qq_045);}
      &[face="左哼哼"] { @include face(qq_046);}
      &[face="右哼哼"] { @include face(qq_047);}
      &[face="哈欠"] { @include face(qq_048);}
      &[face="鄙视"] { @include face(qq_049);}
      &[face="委屈"] { @include face(qq_050);}
      &[face="快哭了"] { @include face(qq_051);}
      &[face="阴险"] { @include face(qq_052);}
      &[face="亲亲"] { @include face(qq_053);}
      &[face="吓"] { @include face(qq_054);}
      &[face="可怜"] { @include face(qq_055);}
      &[face="菜刀"] { @include face(qq_056);}
      &[face="西瓜"] { @include face(qq_057);}
      &[face="啤酒"] { @include face(qq_058);}
      &[face="篮球"] { @include face(qq_059);}
      &[face="乒乓"] { @include face(qq_060);}
      &[face="咖啡"] { @include face(qq_061);}
      &[face="饭"] { @include face(qq_062);}
      &[face="猪头"] { @include face(qq_063);}
      &[face="玫瑰"] { @include face(qq_064);}
      &[face="凋谢"] { @include face(qq_065);}
      &[face="嘴唇"] { @include face(qq_066);}
      &[face="爱心"] { @include face(qq_067);}
      &[face="心碎"] { @include face(qq_068);}
      &[face="蛋糕"] { @include face(qq_069);}
      &[face="闪电"] { @include face(qq_070);}
      &[face="炸弹"] { @include face(qq_071);}
      &[face="刀"] { @include face(qq_072);}
      &[face="足球"] { @include face(qq_073);}
      &[face="瓢虫"] { @include face(qq_074);}
      &[face="便便"] { @include face(qq_075);}
      &[face="月亮"] { @include face(qq_076);}
      &[face="太阳"] { @include face(qq_077);}
      &[face="礼物"] { @include face(qq_078);}
      &[face="拥抱"] { @include face(qq_079);}
      &[face="强"] { @include face(qq_080);}
      &[face="弱"] { @include face(qq_081);}
      &[face="握手"] { @include face(qq_082);}
      &[face="胜利"] { @include face(qq_083);}
      &[face="抱拳"] { @include face(qq_084);}
      &[face="勾引"] { @include face(qq_085);}
      &[face="拳头"] { @include face(qq_086);}
      &[face="差劲"] { @include face(qq_087);}
      &[face="爱你"] { @include face(qq_088);}
      &[face="NO"] { @include face(qq_089);}
      &[face="OK"] { @include face(qq_090);}
      &[face="爱情"] { @include face(qq_091);}
      &[face="飞吻"] { @include face(qq_092);}
      &[face="跳跳"] { @include face(qq_093);}
      &[face="发抖"] { @include face(qq_094);}
      &[face="怄火"] { @include face(qq_095);}
      &[face="转圈"] { @include face(qq_096);}
      &[face="嘿哈"] { @include face(qq_097);}
      &[face="捂脸"] { @include face(qq_098);}
      &[face="奸笑"] { @include face(qq_099);}
      &[face="机智"] { @include face(qq_100);}
      &[face="皱眉"] { @include face(qq_101);}
      &[face="耶"] { @include face(qq_102);}
      &[face="茶"] { @include face(qq_103);}
      &[face="红包"] { @include face(qq_104);}
      &[face="蜡烛"] { @include face(qq_105);}
    }
    .face-new {
      &[face] {
        display: inline-block;
        width: 1.2em;
        height: 1.2em;
        vertical-align: sub;
      }
      &[face="微笑"] { @include face-new(qq_001);}
      &[face="撇嘴"] { @include face-new(qq_002);}
      &[face="色"] { @include face-new(qq_003);}
      &[face="发呆"] { @include face-new(qq_004);}
      &[face="得意"] { @include face-new(qq_005);}
      &[face="流泪"] { @include face-new(qq_006);}
      &[face="害羞"] { @include face-new(qq_007);}
      &[face="闭嘴"] { @include face-new(qq_008);}
      &[face="睡"] { @include face-new(qq_009);}
      &[face="大哭"] { @include face-new(qq_010);}
      &[face="尴尬"] { @include face-new(qq_011);}
      &[face="发怒"] { @include face-new(qq_012);}
      &[face="调皮"] { @include face-new(qq_013);}
      &[face="呲牙"] { @include face-new(qq_014);}
      &[face="惊讶"] { @include face-new(qq_015);}
      &[face="难过"] { @include face-new(qq_016);}
      &[face="酷"] { @include face-new(qq_017);}
      &[face="囧"] { @include face-new(qq_018);}
      &[face="抓狂"] { @include face-new(qq_019);}
      &[face="吐"] { @include face-new(qq_020);}
      &[face="偷笑"] { @include face-new(qq_021);}
      &[face="可爱"] { @include face-new(qq_022);}
      &[face="白眼"] { @include face-new(qq_023);}
      &[face="傲慢"] { @include face-new(qq_024);}
      &[face="饥饿"] { @include face-new(qq_025);}
      &[face="困"] { @include face-new(qq_026);}
      &[face="惊恐"] { @include face-new(qq_027);}
      &[face="流汗"] { @include face-new(qq_028);}
      &[face="憨笑"] { @include face-new(qq_029);}
      &[face="大兵"] { @include face-new(qq_030);}
      &[face="奋斗"] { @include face-new(qq_031);}
      &[face="咒骂"] { @include face-new(qq_032);}
      &[face="疑问"] { @include face-new(qq_033);}
      &[face="嘘"] { @include face-new(qq_034);}
      &[face="晕"] { @include face-new(qq_035);}
      &[face="折磨"] { @include face-new(qq_036);}
      &[face="衰"] { @include face-new(qq_037);}
      &[face="骷髅"] { @include face-new(qq_038);}
      &[face="敲打"] { @include face-new(qq_039);}
      &[face="再见"] { @include face-new(qq_040);}
      &[face="擦汗"] { @include face-new(qq_041);}
      &[face="抠鼻"] { @include face-new(qq_042);}
      &[face="鼓掌"] { @include face-new(qq_043);}
      &[face="糗大了"] { @include face-new(qq_044);}
      &[face="坏笑"] { @include face-new(qq_045);}
      &[face="左哼哼"] { @include face-new(qq_046);}
      &[face="右哼哼"] { @include face-new(qq_047);}
      &[face="哈欠"] { @include face-new(qq_048);}
      &[face="鄙视"] { @include face-new(qq_049);}
      &[face="委屈"] { @include face-new(qq_050);}
      &[face="快哭了"] { @include face-new(qq_051);}
      &[face="阴险"] { @include face-new(qq_052);}
      &[face="亲亲"] { @include face-new(qq_053);}
      &[face="吓"] { @include face-new(qq_054);}
      &[face="可怜"] { @include face-new(qq_055);}
    }
    a {
      color: $--color-main;
      cursor: pointer;
    }
    b {
      background: #F56C6C;
      color: #FFF;
      padding: 0 3px;
      border-radius: 3px;
    }
  }
}

</style>
