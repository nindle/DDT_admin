<template>
  <div class="message-box">
    <div 
      class="message-item"
      v-for="e in data"
      :key="e.id"
      @contextmenu.prevent="$emit('contextmenu', $event, e)"
      :style="typeof messageStyle === 'function' ? messageStyle(e) : messageStyle"
      :ref="`message-${e.id}`"
      :class="[{ find: findId === e.id }, typeof messageClass === 'function' ? messageClass(e) : messageStyle]"
    >
      <div class="msg-head">
        <el-checkbox 
          :key="Date.now()"
          @change="checkMsg($event, e)"
          :checked="selectList.includes(e)"
          v-if="select"
        ></el-checkbox>

        <span :class="e.type === 1 ? 'user' : 'manager'">{{e.type === 1 ? '用户' : (e.managerTitle || '业务')}}{{e.type === 1 ? (e.nickname ? `: ${e.nickname}` : '') : (e.managerName ? `: ${e.managerName}` : '')}}</span>
        <i
          class="icon"
          :class="`appType${e.appType}`"
        ></i>
        <span class="time">
          <slot 
            name="message-time"
            :item="e"
          >{{e.lastTime | timeFormat}}</slot>
        </span>
      </div>
      <div class="msg-body">
        <!--文字消息-->
        <msg-text 
          v-if="e.msgType === 'text'"
          :text="e.content"
          face
          br
          link
          :keyword="textKeyword ? textKeyword(e) : undefined"
        />

        <!--图片消息-->
        <msg-text 
          v-if="(e.msgType === 'image' || e.msgType === 'qy_app_image') && e.content && translate"
          :text="e.content"
          label="图片识别："
        />
        <msg-image 
          v-if="e.msgType === 'image' || e.msgType === 'qy_app_image'"
          :image="e.imageUrl"
          :lock-height="lockImageHeight"
          :download="downloadImage"
        />

        <!--语音消息-->
        <msg-text 
          v-if="(e.msgType === 'track' || e.msgType === 'voice') && e.content && translate"
          :text="e.content"
          label="语音识别："
        />
        <msg-audio
          v-if="e.msgType === 'track' || e.msgType === 'voice'"
          :audio="e.imageUrl"
        /> 

        <!--图文消息-->
        <msg-news 
          v-if="e.msgType === 'news' || e.msgType === 'mpnews' || e.msgType === 'link'"
          :title="e.title"
          :image="e.imageUrl"
          :description="(e.msgType === 'news' || e.msgType === 'link') ? e.description : e.digest"
          :url="e.url"
          :source="e.sourceId"
          :type="e.msgType"
        />

        <!--视频消息-->
        <msg-video 
          v-if="e.msgType === 'video'"
          :video="e.imageUrl"
        />

        <!--文件消息-->
        <msg-file
          v-if="e.msgType === 'file'"
          :url="e.imageUrl"
        />

        <!--事件消息-->
        <msg-text 
          class="msg-event"
          v-if="e.msgType === 'event'"
          :text="e.content"
          br
        />
      </div>
      <slot 
        name="bottom" 
        :item="e"
      />
    </div>

    <div 
      class="noresult"
      v-if="!data.length"
    ></div>

  </div>
</template>

<script>
import MsgAudio from './msg-audio'
import MsgText from './msg-text'
import MsgImage from './msg-image'
import MsgNews from './msg-news'
import MsgFile from './msg-file'
import MsgVideo from './msg-video'
import bus from '../../assets/js/bus'

export default {
  data() {
    return {
      findId: -1,
      timer: null,
      isActive: true
    }
  },
  props: {
    data: Array,
    translate: Boolean,
    select: Boolean,
    selectList: {
      type: Array,
      default() {
        return []
      }
    },
    textKeyword: Function,
    lockImageHeight: Boolean,
    downloadImage: Boolean,
    messageStyle: [Object, Function],
    messageClass: [Object, Function],
  },
  components: {
    MsgText,
    MsgImage,
    MsgNews,
    MsgFile,
    MsgAudio,
    MsgVideo
  },
  methods: {
    checkMsg(type, item) {
      if(type && !this.selectList.includes(item)) {
        this.selectList.push(item)
      }else if(!type){
        this.selectList.splice(this.selectList.indexOf(item), 1)
      }
    },
    messageScrollIntoView(id) {
      if(!this.isActive) return

      if(this.$refs[`message-${id}`]) {
        this.$refs[`message-${id}`][0].scrollIntoView({ block: 'center' })
        this.findId = id
        clearTimeout(this.timer)
        this.timer = setTimeout(() => {
          this.findId = -1
        }, 600)
      }
    }
  },
  created() {
    bus.$on('messageScrollIntoView', this.messageScrollIntoView)
  },
  beforeDestroy() {
    bus.$off('messageScrollIntoView', this.messageScrollIntoView)
    clearTimeout(this.timer)
  },
  activated() {
    this.isActive = true
  },
  deactivated() {
    this.isActive = false
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.message-box {
  font-size: 14px;
  .message-item {
    &.find {
      background: rgba($--color-main, .1);
    }
    transition: background .3s;
    padding: 4px 0;
    .msg-head {
      display: flex;
      align-items: center;
      .el-checkbox { margin-right: 6px;}
      .manager { color: $--color-main;}
      .user { color: #999;}
      .time {
        margin-left: auto;
        color: #999;
        font-size: 12px;
      }
      .icon {
        width: 14px;
        height: 14px;
        margin-left: 6px;
        &.appType1 { @include image(pass_icon_wgzt_2, center/100%);}
        &.appType2 { @include image(pass_icon_wx_2, center/100%);}
        &.appType3 { @include image(pass_icon_tel_2, center/100%);}
        &.appType4 { @include image(pass_icon_wxwork_2, center/100%);}
        &.appType7 { @include image(pass_icon_sms_2, center/100%);}
      }
    }
    .msg-body {
      padding: 8px 0;
    }
  }
  .noresult {
    width: 100%;
    height: 200px;
    @include image(noresult, center no-repeat);
    text-align: center;
    &::before {
      content: "无记录";
      color: #BBB;
      line-height: 340px;
      padding-left: 16px;
    }
  }
}
</style>
