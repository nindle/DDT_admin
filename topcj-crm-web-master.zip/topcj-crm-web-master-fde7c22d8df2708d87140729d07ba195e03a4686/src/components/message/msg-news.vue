<template>
  <div 
    :class="`msg-${type}`"
    @click="click"
  >
    <div 
      class="image" 
      :style="{backgroundImage: `url(${image})`}"
    ></div>
    <div class="title">{{title}}</div>
    <div class="description">{{description}}</div>
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  props: {
    url: String,
    title: String,
    image: String,
    description: String,
    source: Number,
    type: {
      type: String,
      default: 'news'
    }
  },
  methods: {
    click() {
      if(this.type === 'news' || this.type === 'link') {
        this.$open(this.url)
      }else{
        this.$open(`${this.SYS.URL}/news?id=${this.source}`)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.msg-mpnews,
.msg-news {
  width: 318px;
  border-radius: 4px;
  overflow: hidden;
  cursor: pointer;
  border: 1px solid #DDD;
  background: #FFF;
  .image {
    width: 100%;
    height: 137px;
    @include cover;
  }
  .title {
    white-space: pre;
    font-size: 14px;
    line-height: 30px;
    margin: 0 15px;
    color: #333;
    @include ellipsis;
  }
  .description {
    white-space: pre-wrap;
    font-size: 12px;
    line-height: 16px;
    max-height: 32px;
    @include ellipsis(2);
    margin: 0 15px 7px;
    word-break: break-all;
    color: #999;
  }
}

.msg-link {
  position: relative;
  width: 218px;
  border-radius: 4px;
  overflow: hidden;
  cursor: pointer;
  background: #FFF;
  border: 1px solid #DDD;
  background: #FFF;
  .image {
    position: absolute;
    top: 30px;
    right: 9px;
    width: 42px;
    height: 42px;
    border-radius: 2px;
    @include cover;
  }
  .title {
    white-space: pre;
    font-size: 14px;
    line-height: 30px;
    margin: 0 15px;
    color: #000;
    @include ellipsis;
  }
  .description {
    white-space: pre-wrap;
    font-size: 12px;
    line-height: 16px;
    height: 48px;
    overflow: hidden;
    margin: 0 60px 5px 15px;
    word-break: break-all;
    color: #999;
    @include ellipsis(2);
  }
}

</style>
