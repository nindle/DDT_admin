<template>
  <div 
    class="msg-file"
    v-open="url"
  >
    <div class="title">{{title}}</div>
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  computed:{
    title() {
      return this.name || this.url.substring(this.url.lastIndexOf('/') + 1)
    }
  },
  props: {
    url: String,
    name: String
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.msg-file {
  width: 242px;
  height: 76px;
  overflow: hidden;
  border: 1px solid #DDD;
  border-radius: 4px;
  @include image(sendmsg_file, 18px 18px/35px no-repeat);
  cursor: pointer;
  .title {
    white-space: pre-wrap;
    font-size: 14px;
    line-height: 18px;
    margin: 18px 18px 18px 70px;
    word-break: break-all;
    max-height: 36px;
    @include ellipsis(2);
  }
}

</style>
