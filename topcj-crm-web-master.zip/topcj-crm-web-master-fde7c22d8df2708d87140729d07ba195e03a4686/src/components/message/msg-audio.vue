<template>
  <div class="msg-audio">
    <audio 
      :src="audio"
      ref="audio"
      @loadeddata="loadeddata"
      @timeupdate="timeupdate"
    ></audio>
    <el-button 
      class="button"
      type="primary" 
      :icon="loading ? 'el-icon-loading' : 'el-icon-phone'"
      size="mini"
      circle
      @click="play"
    ></el-button>
    <el-slider 
      v-model="time"
      @change="changeTime"
      :max="duration"
      :format-tooltip="t => $options.filters.secondFormat(t, '+m:+s')"
    ></el-slider>
    <span class="text">{{time | secondFormat('+m:+s')}}/{{duration | secondFormat('+m:+s')}}</span>
  </div>
</template>

<script>
export default {
  data() {
    return {
      loading: true,
      time: 0,
      duration: 0
    }
  },
  props: {
    audio: String
  },
  methods: {
    //数据加载完毕
    loadeddata() {
      this.loading = false
      this.duration = this.$refs.audio.duration
    },
    //时间更新
    timeupdate() {
      this.time = this.$refs.audio.currentTime
    },
    //跳转播放
    changeTime(t) {
      if(this.loading) {
        this.time = 0
        return
      }

      this.$refs.audio.currentTime = t
    },
    //切换播放状态
    play() {
      if(this.loading) return

      if(this.$refs.audio.paused) {
        this.$refs.audio.play()
      }else{
        this.$refs.audio.pause()
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.msg-audio {
  width: 256px;
  height: 40px;
  background: rgba($--color-main, .12);
  border-radius: 4px;
  display: flex;
  align-items: center;
  padding: 0 12px;
  .button {
    width: 16px;
    height: 16px;
    padding: 0;
  }
  .el-slider {
    width: 136px;
    margin-left: 12px;
    /deep/ {
      .el-slider__button {
        width: 8px;
        height: 8px;
      }
      .el-slider__runway { background: rgba(#000, .04); }
    }
  }
  .text {
    margin-left: auto;
    font-size: 12px;
  }
}
</style>
