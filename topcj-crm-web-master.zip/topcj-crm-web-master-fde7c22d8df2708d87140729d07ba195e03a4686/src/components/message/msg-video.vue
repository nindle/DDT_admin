<template>
  <div class="msg-video">
    <video :src="video" controls></video>
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  props: {
    video: String
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";


.msg-video {
  max-width: 233px;
  border-radius: 4px;
  video {
    display: block;
    max-width: 100%;
    border-radius: 4px;
  }
}

</style>
