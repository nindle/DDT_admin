<template>
  <div class="msg-image">
    <img 
      v-if="!lockHeight"
      v-imageview 
      :src="image"
    />
    <div 
      v-else
      class="image"
      :style="{ backgroundImage: `url(${image})` }"
      v-imageview="image"
    ></div>
    <el-button
      type="text"
      size="small"
      v-if="download"
      icon="el-icon-download"
      @click="$open(image)"
    >下载原图</el-button>
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
  props: {
    image: String,
    lockHeight: Boolean,
    download: Boolean
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";


.msg-image {
  display: flex;
  align-items: flex-end;
  width: fit-content;
  img {
    border-radius: 4px;
    max-width: 233px;
    display: block;
    cursor: pointer;
  }
  .image {
    width: 233px;
    height: 233px;
    border-radius: 4px;
    cursor: pointer;
    @include cover;
  }
  .el-button {
    margin-left: 12px;
  }
}
</style>
