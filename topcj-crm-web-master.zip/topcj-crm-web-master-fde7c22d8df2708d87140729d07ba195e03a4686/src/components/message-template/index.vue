<!-- defaultCorpId -1不展示框 其他数字 默认展示可选-->
<template>
  <div class="parent">
    <div v-if="defaultCorpId !== -1" class="corpBox">
       <el-select style="width:120px;" size="small" :disabled='isCorp' clearable v-model="corpId" placeholder="请选择公司">
          <el-option
            v-for="item in corpIdList"
            :key="item.id"
            :label="item.corpName"
            :value="item.id">
          </el-option>
        </el-select>
    </div>
    <div class="bbox">
      <div class="topSelect">
        <div class="table">
          <span :class="{active:e.key === tableIndex}" @click="tableIndex = e.key;listIndex = i" v-show="e.label" v-for="(e,i) in tableList" :key='i'>{{e.label}}</span>
        </div>
        <div v-if="[0,1,2,3,4].includes(tableIndex)" class="seach">
          <div class="inpBox">
            <input placeholder="请输入关键字"  v-model="searchTxt" />
            <div class="close" v-if="searchTxt" @click="searchTxt = ''">+</div>
          </div>
          <div v-if="![4,7].includes(tableIndex)" @click="addthing()" class="addthing">
            {{`+${tableList[tableIndex].label}`}}
          </div>
          <div v-show="![4,7].includes(tableIndex)" class="sort" @mouseenter="optionIndex=true" @mouseleave="optionIndex=false">
            <div class="option" v-show="optionIndex">
              <div class="list">
                <div class="value1">
                </div>
                <div class="value" @click="sortIndex=0" :class="{active:sortIndex===0}">使用次数降序</div>
                <div class="value" @click="sortIndex=1" :class="{active:sortIndex===1}">使用次数升序</div>
                <div class="value" @click="sortIndex=2" :class="{active:sortIndex===2}">更新时间倒序</div>
                <div class="value" @click="sortIndex=3" :class="{active:sortIndex===3}">更新时间升序</div>
              </div>
            </div>
          </div>
        </div>
        <div v-if="tableIndex === 7" class="seven">
          <el-date-picker
            style="width:240px;"
            v-model="timeSeven"
            size="small"
            type="daterange"
            range-separator="-"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="yyyy/MM/dd"
            format="yyyy-MM-dd"
            >
          </el-date-picker>
          <el-button type="primary" @click="timeSeven_c = timeSeven" size="small">提 交</el-button>
        </div>
      </div>
      <div 
        class="showMain"
        :class="{ slotMain: ![0,1,2,3,4, 7].includes(tableIndex)}"
      >
        <el-scrollbar-pro>
          <Font v-if="tableIndex === 0" :dataList='dataList'/>
          <Fontimg v-if="tableIndex === 1" :dataList='dataList'/>
          <Link v-if="tableIndex === 2" :dataList='dataList'/>
          <Images v-if="tableIndex === 3" :dataList='dataList'/>
          <Info v-if="tableIndex === 4" :pageData='pageNum' :keyword='searchTxt' :corpId='corpId' @getTotal='setTotal'/>
          <Sourece v-if="tableIndex === 7" :pageData='pageNum' :keyword='searchTxt' :timer='timeSeven_c' :corpId='corpId' @getTotal='setTotal' @clearTime='clearTime' />
          <slot v-if="tableIndex == tableList[listIndex].key" :name='tableList[listIndex].key'/>
        </el-scrollbar-pro>
      </div>
      <div v-if="tableIndex === 7 || tableIndex < 5" class="pageBox">
        <el-pagination
          class="pages"
          small
          layout="prev, pager, next"
          :current-page='pageNum'
          @current-change='getList'
          :total="total">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import Font from './font'
import Fontimg from './font-image'
import Link from './link'
import Images from './image'
import Info from './info'
import Sourece from './source'
// import Sends from './sends'
// import Page from './page'
// import Ipt from './seach-input'
// import { deepcopy } from '../../assets/js/tool'
export default {
  props:{
    defaultCorpId:Number,
    config:Array,
    tableLists:{
      type:Array,
      default(){
        return [
        ]
      },
    },
    mode: {
      type: String,
      default: 'ai'
    }
  },
  data(){
    return{
      tableList:[
        {label:'文字',key:0},
        {label:'图文',key:1},
        {label:'外链',key:2},
        {label:'图片',key:3},
        {label:'资讯',key:4},
        // {label:'群发',key:6},
        {label:'话术库',key:7},
      ],
      // tableList:["文字","图文","外链","图片","资讯","群发"],
      //点击的当前索引
      listIndex:1,
      tableIndex:null,
      searchTxt:'',
      pageNum:1,
      pageSize:10,
      dataList:[],
      optionIndex: false, 
      sort:0,
      sortType:0,
      sortIndex:null,
      corpId:null,
      isCorp:false,
      total:null,
      timeSeven:[],
      timeSeven_c:[],
    }
  },
  computed:{
    corpIdList(){
      return this.$store.state.baseData.corpList
    }
  },
  created(){
    if(this.config){
      this.tableList = [...this.tableList,...this.config]
    }
    this.tableIndex = 0
    if(this.defaultCorpId!==-1){
      this.corpId = this.defaultCorpId
    }
    if(this.$store.state.managerInfo.corpId){
      this.isCorp = true
      this.corpId = this.$store.state.managerInfo.corpId
    }
    //自定义列
    if(this.tableLists.length){
      this.tableList = this.tableLists
    }

    this.getList()
  },
  components:{
    // Ipt,
    Font,
    Fontimg,
    Link,
    Images,
    Info,
    Sourece,

    // Sends,
    // Page,
  },
  watch:{
    tableIndex(v){
      switch(v){
        case 0:
          this.msgType = 'text'
        break
        case 1:
          this.msgType = 'mpnews'
        break
        case 2:
          this.msgType = 'news'
        break
        case 3:
          this.msgType = 'image'
        break
        case 4:
          this.msgType = 'info'
        break
      }
      
      this.getList()
    },
    sortIndex(v){
      switch(v){
        case 0:
          this.sort=0
          this.sortType=0
        break
        case 1:
          this.sort=1 
          this.sortType=0
        break
        case 2:
          this.sort=0
          this.sortType=1
        break
        case 3:
          this.sort=1 
          this.sortType=1
        break
      }
      this.pageNum = 1
      this.getList()
    },
    searchTxt(){
      this.pageNum = 1
      this.getList()
    },
    corpId(){
      this.getList()
    },
  },
  methods:{
    clearTime(){
      this.timeSeven = []
    },
    setTotal(v){
      this.total = v
    },
    addthing(){
      if(this.tableIndex === 4){
        return
      }

      if(this.mode === 'ai') {
        this.$router.push({name:'ai-assets_store',query:{type:this.msgType}})
      }else if(this.mode === 'gm') {
        this.$router.push({name:'gm-assets_depot_next',query:{
          type:this.msgType,
          corpId: this.$store.state.managerInfo.corpId
        }})
      }

      
    },
    async getList(a){
      if(this.tableIndex === 4 || this.tableIndex === 7){
        this.pageNum = a
        return
      }

      let ajax = {}

      if(this.mode === 'ai') {
        ajax = {
          url: "%CRM%/source/search_source_ai.sdcrm",
          data:{
            token:true,
            corpId: typeof(this.corpId) === 'number' ? this.corpId : undefined,
            searchTxt:this.searchTxt ? this.searchTxt : undefined,
            msgType:this.msgType,
            pageNum:a,
            share:2,
            pageSize:this.pageSize,
            sort:this.sort ? this.sort :0,
            sortType:this.sortType ? this.sortType : 0,
          }
        }
      }else if(this.mode === 'gm') {
        ajax = {
          url: this.searchTxt ? '%CRM%/source/search_source.sdcrm' : '%CRM%/source/get_source.sdcrm',
          data: {
            token: true,
            managerId: this.$store.state.managerInfo.id,
            pageNum: a,
            pageSize: this.pageSize,
            searchTxt:this.searchTxt ? this.searchTxt : undefined,
            isauth: 1,
            share:2,
            msgType:this.msgType,
            sort:this.sort ? this.sort :0,
            sortType:this.sortType ? this.sortType : 0,
          }
        }
      }

      let { result, code } = await this.$http(ajax)

      if(code !== 8200){
        return
      }
      // this.dataList.contents = result.records
      this.dataList = result.records || result.contents
      this.total = result.total
    }
  },
}
</script>
<style lang="scss" scoped>
@import '../../assets/css/common.scss';
.parent{
  width: 100%;
  height: 100%;
  position: relative;
  .corpBox{
    position: absolute;
    top: -40px;
    right: 20px;
  }
}
.bbox{
  height: 100%;
  width: 350px;
  // background: #e9e9e9;
  .topSelect{
    width: 100%;
    box-sizing: border-box;
    padding: 0 20px;
    .table{
      width: 100%;
      display: flex;
      justify-content: space-around;
      box-sizing: border-box;
      padding: 15px 0;
      font-size: 12px;
      >span{
        // margin: 0 10px;
        line-height: 22px;
        cursor: pointer;
        height: 22px;
        padding: 0 5px;
        text-align: center;
      }
      .active{
        box-shadow: 0px 3px 4px rgba(0,47,109,0.18);
        display: block;
        background: #4796FE;
        border-radius: 11px;
        color: #Fff;
      }
    }
    .seach{
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #E4E4E4;
      .inpBox {
        width: 226px;
        height: 30px;
        box-sizing: border-box;
        line-height: 30px;
        margin-bottom: 20px;
        border: 1px solid transparent;
        background:  #ECE9E7;
        color:#000;
        border-radius: 4px;
        display: inline-block;
        position: relative;
        &::before {
          content: "";
          position: absolute;
          width: 13px;
          height: 13px;
          @include image(fangdajing);
          background-size: 100% 100%;
          left: 6px;
          top: 8px;
        }
        input {
          outline: none;
          border: none;
          font-size: 12px;
          height: 30px;
          position: relative;
          top: -2px;
          background: transparent;
          width: 160px;
          margin-left: 30px;
          line-height: 28px;
        }
        input::-webkit-input-placeholder {
          color:#999
        }
        .close {
          position: absolute;
          right: 5px;
          top: 6px;
          width: 17px;
          height: 17px;
          font-size: 18px;
          text-align: center;
          line-height: 15px;
          border-radius: 50%;
          cursor: pointer;
          transform: rotate(45deg);
          background: #DBD9D8;
          color: #999;
        }
      }
      .notAll{
        cursor:not-allowed;
        background: #999;
      }
      .addthing{
        font-size: 14px;
        cursor: pointer;
        background: rgba(71,150,254,0.15);
        color: #4796FE;
        line-height: 30px;
        height: 30px;
        text-align: center;
        border-radius: 4px;
        padding: 0 8px;
      }
      .sort {
        float: right;
        width: 20px;
        height: 33px;
        position: relative;
        cursor: pointer;
        .option{
          background: #fff;
          .list{
            color: #999;
            .value1{
              border-bottom-color: #ECE9E7;
              span{
                border-color: #999;
              }
              .active{
                border-color: #4796FE;
              }
              .active::after{
                background:#4796FE ;
              }
            }
            .value.active{
              color: #4796FE;
            }
          }
        }
        .option {
          position: absolute;
          width: 120px;
          height: 180px;
          top: 32px;
          right: 0px;
          z-index: 9;
          box-shadow: 0px 0px 6px rgba(0, 0, 0, 0.1);
          cursor: auto;
          .list {
            width: 110px;
            margin: 0 auto;
            font-size: 12px;
            text-align: center;
            .value1 {
              box-sizing: border-box;
              height: 36px;
              width: 110px;
              border-bottom-style: solid;
              border-bottom-width: 1px;
              cursor: pointer;
              span {
                position: absolute;
                width: 15px;
                height: 15px;
                box-sizing: border-box;
                border-style: solid;
                border-width: 1px;
                border-radius: 50%;
                top: 12px;
                left: 17px;
              }
              .active::after {
                content: "";
                width: 7px;
                height: 7px;
                border-radius: 50%;
                top: 3px;
                left: 3px;
                position: absolute;
              }
              div{
                position: absolute;
                top: 11px;
                left: 38px;
                line-height: 16px;
                width: 60px;
                text-align: left
              }
            }
            .value{
              line-height: 16px;
              cursor: pointer;
              position: absolute;
              text-align: center;
              left: 17px;
            }
            .value:nth-of-type(2){
              top: 51px;
            }
            .value:nth-of-type(3){
              top: 83px;
            }
            .value:nth-of-type(4){
              top: 115px;
            }
            .value:nth-of-type(5){
              top: 147px;
            }
          }
        }
      }
      .sort::after {
        content: "";
        position: absolute;
        width: 19px;
        height: 19px;
        top: 5px;
        @include image(im-assets-sort);
        background-size: 100% 100%;
      }
    }
    .seven{
      padding-bottom: 20px;
      width: 100%;
      display: flex;
      justify-content: space-between;
    }
  }
  .showMain{
    box-sizing: border-box;
    padding: 20px 0;
    height: calc(100% - 140px);
    &.slotMain {
      padding: 0;
      height: calc(100% - 52px);
    }
  }
  .pageBox{
    display:flex;
    justify-content: center;
  }
}
</style>