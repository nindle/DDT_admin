<template>
  <div>
    <div class="contBox">
      <div class="list">
        <div
          v-for="(item,index) in textArr"
          :key="index"
          :class="{'list-div':true}"
          @mouseover="show(index)"
          @mouseout="out"
          @click="send(item)"
        >
          <div class="imgbox" :style="{backgroundImage:`url(${item.picUrl})`}"></div>
          <span class="count">{{item.count}}次</span>
          <Msgtest class="cont" :text='item.sourceTitle' face br/>
          <!-- <div class="cont" :title="item.sourceTitle" v-html="htmlFormat(item.sourceTitle, `${regs}`)"></div> -->
          <div style="display:none;" :class="{mask:index==hoverIndex}">
            <!-- <span class="watch" :class="{hover:watchSee}"></span> -->
            <i class="el-icon-link" v-imageview='item.picUrl' @click.stop></i>
            <!-- <img
              :src="item.picUrl"
              alt
              :preview="index"
              class="show"
              @click.stop
              @mouseenter="hover"
              @mouseleave="hoverOut"
              v-show="index==hoverIndex"
            /> -->
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Bus from '../../assets/js/bus'
import Msgtest from '../message/msg-text'
export default {
  props:{
    dataList:[Array,Object],
  },
  data() {
    return {
      hoverIndex: -1,
      watchSee: false //img图标显示 hover的时候显示img小图
    };
  },
  components:{
    Msgtest
  },
  created() {
  },
  computed: {
    textArr(){
      return this.dataList
    }
  },
  methods: {
    //查看图片
    hover() {
      // this.$previewRefresh();
      this.watchSee = true;
    },
    hoverOut() {
      this.watchSee = false;
    },
    show(index) {
      this.hoverIndex = index;
    },
    out() {
      this.hoverIndex = -1;
    },
    //关键字加载
    //发送图片
    send(item) {
      Bus.$emit('inputMessage', {
        type: "image",
        imageUrl: item.picUrl
      })
    }
  },

  watch: {

  }
};
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";
.contBox {
  width: 100%;
  .list {
    width: 330px;
    margin: 0 auto;
    box-sizing: border-box;
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
    .list-div {
      border-radius: 6px;
      width: 100px;
      height: 127px;
      box-sizing: border-box;
      position: relative;
      margin-right: 15px;
      &:nth-child(3n){
        margin-right:0
      }
      background-color:#fff;
      margin-bottom: 15px;
      .times {
        left: 7px;
      }
      .count {
        right: 5px;
      }
      div.imgbox {
        position: absolute;
        top: 0;
        width: 100%;
        height: 100px;
        background-size: cover;
        background-position: center;
        left: 0;
        border-top-right-radius: 4px;
        border-top-left-radius: 4px;
      }
      .cont {
        height: 27px;
        line-height: 27px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        position: absolute;
        bottom: 0;
        font-size: 12px;
        width: 80px;
        left: 5px;
        white-space: pre;
        color: #333;
      }
      .mask {
        display: block!important;
        position: absolute;
        width: 100%;
        height: 50px;
        background:linear-gradient(180deg,rgba(0,0,0,1) 0%,rgba(0,0,0,0) 100%);
        opacity:0.59;
        border-top-right-radius: 4px;
        border-top-left-radius: 4px;
        i{
          cursor: pointer;
          position: absolute;
          right: 10px;
          font-size: 22px;
          color: #fff;
          top: 10px;
          width: 20px;
          height: 20px;
        }
        i:hover{
          color: #409EFF;
        }
        img.show {
          position: absolute;
          width: 24px;
          height: 24px;
          right: 6px;
          top: 6px;
          opacity: 0;
          cursor: pointer;
        }
      }
    }
  }
}
.count{
  position: absolute;
  width: 36px;
  height: 16px;
  line-height: 16px;
  text-align: center;
  font-size: 12px;
  border-radius:10px;
  color: #fff;
  background: rgba(0,0,0,0.6);
  left:5px;
  top: 79px;

}
</style>

