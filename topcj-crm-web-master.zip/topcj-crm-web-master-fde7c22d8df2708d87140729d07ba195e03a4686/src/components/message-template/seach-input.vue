<template>
  <div :style="{ '--height': _height}" class="seachBox">
    <input :placeholder="placeholder" v-model="value2" type="text">
  </div>
</template>
<script>
export default {
  props:{
    value:[String,Number],
    size:{
      default:'medium'
    },
    placeholder:{
      default:'请输入..'
    }
  },
  data(){
    return{
      value2:'',
    }
  },
  created(){
    this.init()
    this.value2 = this.value
  },
  watch:{
    size(){
      this.init()
    },
    value(v){
      this.value2 = v
    },
    value2(v){
      this.value = v
      this.$emit('input',v)
    }
  },
  methods:{
    init(){
      switch(this.size){
        case 'medium': this._height = 30; break
        case 'small': this._height = 24; break
        case 'mini': this._height = 18; break
      }
    }
  },
}
</script>
<style lang="scss" scoped>
@import '../../assets/css/common.scss';
.seachBox{
  width: 100%;
  height: calc(var(--height));
  >input{
    width: 100%;
    height: 100%;
    line-height: 100%;
    background: #ECE9E7;
    color: #000;
    border-radius: 4px;
    display: inline-block;
    border: 1px solid transparent;
    position: relative;
  }
  >input::before{
    display: block;
    content: '';
    @include image(fangdajing);
    width: 13px;
    height: 13px;
    background-size: 100% 100%;
    position: absolute;
    line-height: calc(var(--height));
    left: 5px;
  }
  >input:focus{
    background: #fff;
  }
  >input:focus::after{
    content: "+";
    display: block;
    width: 17px;
    height: 17px;
    font-size: 18px;
    transform: translate(45deg);
    position: absolute;
    right: 5px;
    line-height: calc(var(--height));
  }
}
</style>