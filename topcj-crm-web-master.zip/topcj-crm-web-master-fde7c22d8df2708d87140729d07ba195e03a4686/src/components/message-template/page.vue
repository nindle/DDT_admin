<template>
  <div class="pageBox">
    <el-page-pro
      :total="total"
      :page-num.sync="pageNum_s"
      :page-size.sync="pageSize_s"
      @change="pageChange"
    ></el-page-pro>
  </div>
</template>
<script>
export default {
  data(){
    return{

    }
  }
}
</script>
<style lang="scss" scoped>
.pageBox{
  width: 100%;
  
}
</style>