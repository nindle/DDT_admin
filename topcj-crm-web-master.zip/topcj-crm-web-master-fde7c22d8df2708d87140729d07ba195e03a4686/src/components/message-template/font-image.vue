<template>
  <div>
    <div class="contBox">
      <div class="list">
        <div
          v-for="(item,index) in textArr"
          :key="index"
          :class="{'list-div':true}"
          @mouseover="show(index)"
          @mouseout="out"
          @click="send(item,item.id,index)"
        >
          <span class="times">{{item.updateTime | timeFormat('yyyy-MM-dd')}}</span>
          <span class="count">{{item.count}}次</span>
          <div class="imgbox" :style="{backgroundImage:`url(${item.picUrl})`}"></div>
          <Msgtest class="cont" :text='item.title' face br/>
          <div style="display:none;" :class="{mask:index==hoverIndex}">
            <i class="el-icon-link" @click.stop="open(item.id)"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Bus from '../../assets/js/bus'

import Msgtest from '../message/msg-text'
export default {
  props:{
    dataList:[Array,Object],
  },
  data() {
    return {
      hoverIndex: -1,
    };
  },
  components:{
    Msgtest,
  },
  computed: {
    textArr(){
      return this.dataList
    }
  },
  created() {

  },
  methods: {
    show(index) {
      this.hoverIndex = index;
    },
    out() {
      this.hoverIndex = -1;
    },
    //查看图文
    open(id) {
      // openMpnews(id);
      this.$open(`${this.SYS.URL}/news?id=${id}`)
    },
    //发送图文
    send(item) {
      // alert('发送图文')
      Bus.$emit('inputMessage', {
        type: "mpnews",
        imageUrl: item.picUrl,
        content: item.content,
        title: item.title,
        source: item.id,
        description: item.digest
      })
    }
  },
  watch: {

  }
};
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";
.contBox {
  width: 100%;
  .list {
    width: 330px;
    margin: 0 auto;
    box-sizing: border-box;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    .list-div {
      border-radius: 6px;
      width: 158px;
      height: 138px;
      position: relative;
      background-color:#fff;
      margin-bottom: 15px;
      span {
        color:#666;
        font-size: 12px;
        position: absolute;
        top: 6px;
        line-height: 14px;
      }
      .times {
        left: 7px;
      }
      .count {
        right: 5px;
      }
      div.imgbox {
        position: absolute;
        top: 26px;
        width: 100%;
        height: 67px;
        background-size: cover;
        background-position: center;
        left: 0;
      }
      div {
        position: absolute;
        width: 144px;
        font-size: 12px;
        color:#333;

        line-height: 16px;
      }
      .cont {
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
        height: 32px;
        left: 7px;
        bottom: 6px;
        white-space: pre-wrap;
      }
      .mask {
        display: block!important;
        position: relative;
        width: 100%;
        height: 67px;
        top: 26px;
        background: linear-gradient(180deg, rgba(#333, .8),  rgba(#333, 0));
        i{
          cursor: pointer;
          position: absolute;
          right: 10px;
          font-size: 22px;
          color: #fff;
          top: 10px;
          width: 20px;
          height: 20px;
        }
        i:hover{
          color: #409EFF;
        }
      }
    }
  }
}
</style>
