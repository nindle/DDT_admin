<template>
  <div>
    <div class="list-box">
      <div
        v-for="(item,index) in textArr"
        :key="index"
        class="list-t"
        @click="change(item)"
        @mouseover="over(index)"
        @mouseout="out"
      >
        <span>{{item.ctime | timeFormat('yy/MM/dd')}}</span>
        <!-- <span>{{item.count}}次</span> -->
        <div>
          <Msgtest :class="{fade:true,nfade:textIndex==index}" :text='item.title' face br/>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Bus from '../../assets/js/bus'
import Msgtest from '../message/msg-text'
export default {
  props:{
    pageData:[Array,Object,Number],
    keyword:String,
    corpId:[Number,String],
  },
  data() {
    return {
      textIndex: "-1", //初始化索引
      time: null,
      textArr:[],
      pageNum:1,
      pageSize:10,
    };
  },
  components:{
    Msgtest
  },
  computed:{
    // textArr(){
    //   return this.dataList.contents
    // }
  },
  watch:{
    keyword(){
      this.pageNum = 1
      this.getList()
    },
    pageData(v){
      v
      this.pageNum = this.pageData
      this.getList()
    },
    corpId(){
      this.getList()
    }
  },
  created() {
    this.pageNum = this.pageData
    this.getList()
  },
  methods: {
    async getList(){
      let { result} = await this.$http({
        url:"%CRM%/info/get_info_search.sdcrm",
        data:{
          token:true,
          pageNum:this.pageNum,
          pageSize:this.pageSize,
          keyword:this.keyword ? this.keyword : undefined,
          corpId:typeof(this.corpId) === 'number' ? this.corpId : undefined
        }
      })
      this.textArr = result.contents
      this.$emit('getTotal',result.total)
    },
    //mouse  hover切换
    over(index) {
      this.textIndex = index;
    },
    out() {
      this.textIndex = -1;
    },
    //选择内容发送
    change(item) {
      let copylink =`${this.SYS.WEBURL}/wx/topnewsinfo?sn=${item.sn}&id=${item.id}`
      Bus.$emit('inputMessage', {
        type: "text",
        content: `${item.title} ${copylink}`
      })
    },
  },
};
</script>

<style scoped lang="scss">
.bar-el {
  width: 100%;
  height: 452px;
}
.list-box {
  width: 330px;
  margin: 0 auto;
  box-sizing: border-box;
  .list-t {
    width: 100%;
    color:#333;
    font-size: 12px;
    border-radius: 6px;
    background: #fff;
    box-sizing: border-box;
    position: relative;
    padding: 10px 0 10px 15px;
    margin-bottom: 15px;
    min-height: 57px;
    display: table;
    text-align: left;
    div {
      width: 238px;
      line-height: 20px;
      position: relative;
      display: table-cell;
      vertical-align: middle;
      right: 35px;
      div.fade {
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
        white-space: pre-wrap
      }
      div.nfade {
        display: block;
      }
    }
    &:hover {
      background:rgba(255,255,255,1);
      box-shadow:0px 3px 8px rgba(0,0,0,0.16);
      cursor: pointer;
    }
    span {
      position: absolute;
      right: 10px;
      color:#AEAEAE;
      font-size: 12px;
      line-height: 20px;
    }
    span:nth-child(1) {
      top: 10px;
    }
    span:nth-child(2) {
      top: 30px;
    }
  }
}
</style>
