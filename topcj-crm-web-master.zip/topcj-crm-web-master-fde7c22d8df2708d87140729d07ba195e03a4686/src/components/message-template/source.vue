<template>
  <div>
    <div class="list-box">
      <div
        v-for="(item,index) in textArr"
        :key="index"
        class="list-t"
        @click="change(item)"
      >
        <span>{{item.ctime | timeFormat('yy/MM/dd')}}</span>
        <!-- <span>{{item.count}}次</span> -->
        <div>
          <Msgtest :class="{fade:true,nfade:textIndex==index}" :text='item.title' face br/>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Msgtest from '../message/msg-text'
import Bus from '../../assets/js/bus'
export default {
  data(){
    return{
      textIndex: "-1", //初始化索引
      time: null,
      textArr:[],
      pageNum:1,
      pageSize:10,
    }
  },
  components:{
    Msgtest
  },
  props:{
    pageData:[Array,Object,Number],
    keyword:String,
    corpId:[Number,String],
    timer:Array
  },
  watch:{
    keyword(){
      this.pageNum = 1
      this.getList()
    },
    pageData(){
      this.pageNum = this.pageData
      this.getList()
    },
    corpId(){
      this.getList()
    },
    timer(){
      this.getListTime()
    }
  },
  created() {
    this.pageNum = this.pageData
    this.getList()
  },
  methods:{
    async getListTime(){
      let { result} = await this.$http({
        url:"%CRM%/message_source/get_message_source_title.sdcrm",
        data:{
          token:true,
          pageNum:1,
          pageSize:99,
          corpId:typeof(this.corpId) === 'number' ? this.corpId : undefined,
          isLock:undefined,
          stime:this.timer?.[0],
          etime:this.timer?.[1]
        }
      })
      if(!result.records.length){
        this.$message('当前查询范围未找到符合条件')
        return
      }
      Bus.$emit('addMessageSource', result.records.map(e=>e.id))
      this.$emit('clearTime')
    },
    async getList(){
      let { result} = await this.$http({
        url:"%CRM%/message_source/get_message_source_title.sdcrm",
        data:{
          token:true,
          pageNum:this.pageNum,
          pageSize:this.pageSize,
          keyWord:this.keyword ? this.keyword : undefined,
          corpId:typeof(this.corpId) === 'number' ? this.corpId : undefined,
          isLock:undefined
        }
      })
      this.textArr = result.records
      this.$emit('getTotal',result.total)
    },
    //选择内容发送
    change(item) {
      // let copylink =`${this.SYS.WEBURL}/wx/topnewsinfo?sn=${item.sn}&id=${item.id}`
      Bus.$emit('addMessageSource', item.id)
    },
  }
}
</script>

<style scoped lang="scss">
.bar-el {
  width: 100%;
  height: 452px;
}
.list-box {
  width: 330px;
  margin: 0 auto;
  box-sizing: border-box;
  .list-t {
    width: 100%;
    color:#333;
    font-size: 12px;
    border-radius: 6px;
    background: #fff;
    box-sizing: border-box;
    position: relative;
    padding: 10px 0 10px 15px;
    margin-bottom: 15px;
    min-height: 57px;
    display: table;
    text-align: left;
    div {
      width: 238px;
      line-height: 20px;
      position: relative;
      display: table-cell;
      vertical-align: middle;
      right: 35px;
      div.fade {
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
        white-space: pre-wrap
      }
      div.nfade {
        display: block;
      }
    }
    &:hover {
      background:rgba(255,255,255,1);
      box-shadow:0px 3px 8px rgba(0,0,0,0.16);
      cursor: pointer;
    }
    span {
      position: absolute;
      right: 10px;
      color:#AEAEAE;
      font-size: 12px;
      line-height: 20px;
    }
    span:nth-child(1) {
      top: 10px;
    }
    span:nth-child(2) {
      top: 30px;
    }
  }
}
</style>
