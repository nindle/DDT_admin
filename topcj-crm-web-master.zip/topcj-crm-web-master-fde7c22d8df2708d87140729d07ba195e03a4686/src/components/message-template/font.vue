<template>
  <div>
    <div class="list-box">
      <div
        v-for="(item,index) in textArr"
        :key="index"
        class="list-t"
        @click="change(item.text,item.id,index)"
        @mouseover="over(index)"
        @mouseout="out"
      >
        <span>{{item.updateTime | timeFormat('yy/MM/dd')}}</span>
        <span>{{item.count}}次</span>
        <div>
          <Msgtest :class="{fade:true,nfade:textIndex==index}" :text='item.text' face br/>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Bus from '../../assets/js/bus'
import Msgtest from '../message/msg-text'
export default {
  props:{
    dataList:[Array,Object],
  },
  data() {
    return {
      textIndex: "-1", //初始化索引
      time: null
    };
  },
  components:{
    Msgtest
  },
  computed:{
    textArr(){
      return this.dataList
    }
  },
  created() {
  },
  methods: {
    //mouse  hover切换
    over(index) {
      this.textIndex = index;
    },
    out() {
      this.textIndex = -1;
    },
    //选择内容发送
    change(cont) {
      Bus.$emit('inputMessage', {
        type: "text",
        content: cont
      })
    },
  },
  watch: {

  }
};
</script>

<style scoped lang="scss">
.bar-el {
  width: 100%;
  height: 452px;
}
.list-box {
  width: 330px;
  margin: 0 auto;
  box-sizing: border-box;
  .list-t {
    width: 100%;
    color:#333;
    font-size: 12px;
    border-radius: 6px;
    background: #fff;
    box-sizing: border-box;
    position: relative;
    padding: 10px 0 10px 15px;
    margin-bottom: 15px;
    min-height: 57px;
    display: table;
    text-align: left;
    div {
      width: 238px;
      line-height: 20px;
      position: relative;
      display: table-cell;
      vertical-align: middle;
      right: 35px;
      div.fade {
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
        white-space: pre-wrap
      }
      div.nfade {
        display: block;
      }
    }
    &:hover {
      background:rgba(255,255,255,1);
      box-shadow:0px 3px 8px rgba(0,0,0,0.16);
      cursor: pointer;
    }
    span {
      position: absolute;
      right: 10px;
      color:#AEAEAE;
      font-size: 12px;
      line-height: 20px;
    }
    span:nth-child(1) {
      top: 10px;
    }
    span:nth-child(2) {
      top: 30px;
    }
  }
}
</style>
