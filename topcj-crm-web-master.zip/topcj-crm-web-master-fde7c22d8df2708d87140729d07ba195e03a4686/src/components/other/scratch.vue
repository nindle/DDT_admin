<template>
  <div>
    <!--无数据-->
    <template v-if="!data">
      <span>{{ noData }}</span>
    </template>

    <!--未展示-->
    <template v-else-if="!isShow">
      <el-button type="text" size="small" icon="el-icon-search" v-if="showButtonCompute" @click="show">{{ buttonText }}</el-button>
      <span v-if="mode === 'name'" style="margin-left: 8px">{{ data | getName }}</span>
    </template>

    <!--未展示-->
    <template v-else>
      <span @click="copyData">{{ data }}</span>
    </template>
  </div>
</template>

<script>
const isShowExample = {}

export default {
  data() {
    return {
      isShow: false,
    }
  },
  props: {
    data: [Number, String],
    mode: {
      type: String,
      default: 'userId',
    },
    log: [Number, String],
    copy: Boolean,
    noData: {
      type: String,
      default: '--',
    },
    showButton: Boolean,
  },
  computed: {
    showButtonCompute() {
      return this.showButton || this.$store.state.sysMode !== 2 || !['name', 'tel'].includes(this.mode)
    },
    buttonText() {
      switch (this.mode) {
        case 'userId':
          return '查询ID'
        case 'tel':
          return '查询手机'
        case 'name':
          return '查询'
        case 'money':
          return '查询'
        default:
          return '查询'
      }
    },
  },
  methods: {
    async show() {
      if (this.log) {
        if (this.mode === 'tel') {
          this.$log(5, 11, 1, this.$store.state.nav.id, this.log)
        }
        if (this.mode === 'name') {
          this.$log(5, 17, 1, this.$store.state.nav.id, undefined, this.log, '实名')
        }
      }
      this.isShow = true
      if (isShowExample[this.mode]) {
        isShowExample[this.mode].isShow = false
      }
      isShowExample[this.mode] = this
    },
    copyData() {
      if (!this.copy) return

      this.$copy(this.data)
    },
  },
  filters: {
    getName(text) {
      if (!text) return ''
      return text.charAt(0) + ''.padStart(text.length - 1, '*')
    },
  },
  beforeDestroy() {
    if (isShowExample[this.mode] === this) {
      isShowExample[this.mode] = null
    }
  },
}
</script>
