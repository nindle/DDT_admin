<template>
  <i 
    class="el-icon-phone"
    @click="call"
  ></i>
</template>

<script>
import { md5 } from '../../assets/js/crypto'
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      
    }
  },
  props: {
    userId: Number,
  },
  methods: {
    call(event) {
      if(this.$store.state.managerInfo.agentNumber && this.$store.state.managerInfo.agentNumberSec) {
        //有两个分机号
        this.$contextmenu({
          event,
          menu: [
            {
              title: '主卡',
              handler: () => {
                this.callPhone(this.$store.state.managerInfo.agentNumber)
              }
            },
            {
              title: '副卡',
              handler: () => {
                this.callPhone(this.$store.state.managerInfo.agentNumberSec)
              }
            }
          ]
        })
      }else{
        this.callPhone(this.$store.state.managerInfo.agentNumber || this.$store.state.managerInfo.agentNumberSec)
      }
    },
    callPhone: throttle(async function(caller) {
      this.$emit('call', this.userId)

      let time = `${Date.now()}`
      let sign = md5(`6d03b88781ef216f8678c8f45050b999${time}`)

      let { code, msg, errmsg } = await this.$http({
        url: '%CC%/callcenter/makecall2',
        data: {
          caller,
          user_id: this.userId,
          deadline: time,
          sign
        }
      })

      if(code !== 8200) {
        this.$message.error(msg || errmsg)
        return
      }

      this.$http({
        url: '%CRM%/call/update_user_dial_time.sdcrm',
        data: {
          token: true,
          userId: this.userId
        }
      })
    }),
  }
}
</script>
<style lang="scss" scoped>
@import "../../assets/css/common.scss";
.el-icon-phone {
  color: $--color-main;
  padding: 3px;
  background: rgba($--color-main, .2);
  border-radius: 4px;
  cursor: pointer;
}
</style>