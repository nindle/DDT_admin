<template>
  <div class="message-input">
    <div class="tool-box">
      <slot
        v-for="e in tool"
        :name="`tool-${e}`"
      >
        <!--表情-->
        <el-popover
          placement="top"
          width="390"
          trigger="click"
          v-if="['face', 'face-55'].includes(e)"
          :key="`face-${e}`"
        >
          <select-face
            @select="inputHtml"
            :length="Number(e.split('-')[1] || 0)"
          />
          <div
            slot="reference"
            class="icon-face"
          ></div>
        </el-popover>

        <!--文件-->
        <div
          v-if="e === 'file'"
          :key="`file-${e}`"
          class="icon-file"
          @click="uploadFile()"
        ></div>

        <!--图片-->
        <div
          v-if="e === 'image'"
          :key="`image-${e}`"
          class="icon-file"
          @click="uploadFile('image/*')"
        ></div>

        <!--语音-->
        <msg-audio
          v-if="e === 'voice'"
          :key="`voice-${e}`"
          class="el-icon-microphone"
          @success="inputMessage({ type: 'voice', url: $event })"
        />
      </slot>
    </div>
    <div
      class="input-box"
      ref="inputbox"
      :style="{ '--height': `${inputHeight}px` }"
      @drop.prevent="dragFile"
      :data-placeholder="showPlaceHolder ? placeholder : ''"
    >
      <el-scrollbar-pro>
        <msg-text
          class="message"
          contenteditable
          ref="message"
          @keydown.native="textKeydown"
          @keyup.native="textKeyup"
        ></msg-text>
      </el-scrollbar-pro>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import MsgText from '../message/msg-text'
import SelectFace from './selectFace'
import MsgAudio from './audio'

import Bus from '../../assets/js/bus'

import sendmsgFile from '../../assets/images/sendmsg_file.png'
import sendmsgVideo from '../../assets/images/sendmsg_video.png'
import { loadfile } from '../../assets/js/tool'

const MsgTextConstructor = Vue.extend(MsgText)

export default {
  data () {
    return {
      isActive: true,
      inputHeight: 0,
      showPlaceHolder: true,
      mpnewsSaveList: [],
    }
  },
  props: {
    tool: {
      type: Array,
      default () {
        return ['face', 'file']
      }
    },
    placeholder: {
      type: String,
      default: '请输入'
    },
    enterEvent: String,
    //上传的图片已base64保存
    imageBase64: Boolean
  },
  components: {
    MsgText,
    SelectFace,
    MsgAudio
  },
  methods: {
    //拖拽文件
    dragFile (e) {
      if (!(this.tool.includes('file') || this.tool.includes('image'))) return

      let type = this.tool.includes('file') ? 'file' : 'image'

      if (e.dataTransfer.files) {
        e.dataTransfer.files.forEach(e => {
          if (type === 'image' ? e.type.indexOf('image/') === 0 : e.type) {
            this.inputFile(e)
          }
        })
      }
    },
    //上传文件
    uploadFile (accept = '*') {
      const input = document.createElement('input')
      input.style.position = 'absolute'
      input.style.left = '-9999px'
      input.type = 'file'
      input.accept = accept
      input.click()
      input.onchange = async e => {
        if (!e.srcElement.files[0]) return

        this.inputFile(e.srcElement.files[0])
      }
    },
    //输入框中添加文件
    async inputFile (file) {
      if (!file) return

      let { name, type, size } = file

      if (type.indexOf('image/') === 0) {
        if (size > 2 * 1024 * 1024) {
          this.$message.error('图片不能超过2MB')
          return
        }
        type = 'image'
      } else if (type.indexOf('video/') === 0) {
        if (size > 20 * 1024 * 1024) {
          this.$message.error('视频不能超过20MB')
          return
        }
        type = 'video'
      } else if (type.indexOf('audio/') === 0) {
        if (size > 20 * 1024 * 1024) {
          this.$message.error('语音不能超过20MB')
          return
        }
        type = 'voice'
      } else {
        if (size > 20 * 1024 * 1024) {
          this.$message.error('文件不能超过20MB')
          return
        }
        type = 'file'
      }

      if (type === 'image' && this.imageBase64) {
        //上传的图片已base64保存
        let { result } = await loadfile(file)
        await this.inputHtml(`<img msgtype="image-base64" src="${result}" filename="${this.encodeText(name)}">`)
        return
      }

      let { result, code } = await this.$http({
        url: '%CRM%/source/upload_file.sdcrm',
        mode: 'form',
        data: {
          token: true,
          type,
          uploadFile: file
        }
      })

      if (code !== 8200) return

      if (type === 'image') {
        await this.inputHtml(`<img msgtype="image" src="${result.url}">`)
      } else if (type === 'voice') {
        let canvas = document.createElement('canvas')
        canvas.width = 110
        canvas.height = 40
        let ctx = canvas.getContext('2d')
        ctx.fillStyle = '#FFF'
        ctx.fillRect(0, 0, 110, 40)

        ctx.fillStyle = '#000'
        ctx.textBaseline = 'top'
        ctx.font = '13px 微软雅黑'

        let t = '语音消息'
        ctx.fillText(t, 40, 15)

        await this.inputHtml(`<img 
          msgtype="voice" 
          imageurl="${result.url}"
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAGElEQVRIie3BAQEAAACAkP6v7ggKAICqAQkYAAHO7iU+AAAAAElFTkSuQmCC"
          style="background: url(${sendmsgVideo}) 10px center/auto 20px no-repeat, url(${canvas.toDataURL('image/png')}) left center no-repeat"
        >`.replace(/(\s+?)/g, ' '))
      } else {
        let canvas = document.createElement('canvas')
        canvas.width = 240
        canvas.height = 60
        let ctx = canvas.getContext('2d')
        ctx.fillStyle = '#FFF'
        ctx.fillRect(0, 0, 240, 60)

        ctx.fillStyle = '#000'
        ctx.textBaseline = 'top'
        ctx.font = '14px 微软雅黑'
        ctx.fillText(this.cutString(name, 12), 55, 15)

        ctx.fillStyle = '#999'
        ctx.font = '12px 微软雅黑'
        ctx.fillText(this.sizeFormat(size), 55, 38)

        await this.inputHtml(`<img 
          msgtype="${type}" 
          imageurl="${result.url}"
          filename="${this.encodeText(name.slice(0, name.lastIndexOf('.')))}"
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAGElEQVRIie3BAQEAAACAkP6v7ggKAICqAQkYAAHO7iU+AAAAAElFTkSuQmCC"
          style="background: url(${type === 'file' ? sendmsgFile : sendmsgVideo}) 10px center/auto 40px no-repeat, url(${canvas.toDataURL('image/png')}) left center no-repeat"
        >`.replace(/(\s+?)/g, ' '))
      }
    },
    //输入框中添加外部类型
    inputMessage (data) {
      if (!this.isActive) return

      let text = ''

      if (data.type === 'text') {
        //文本
        text += data.content
      } else if (data.type === 'image') {
        //图片
        text += `<img msgtype="image" src="${data.imageUrl}">`
      } else if (data.type === 'news') {
        //图文链接型
        let canvas = document.createElement('canvas')
        canvas.width = 318
        canvas.height = 53
        let ctx = canvas.getContext('2d')
        ctx.fillStyle = '#FFF'
        ctx.fillRect(0, 0, 318, 53)

        ctx.fillStyle = '#000'
        ctx.textBaseline = 'top'
        ctx.font = '14px 微软雅黑'
        ctx.fillText(this.cutString(data.title, 19), 15, 8)

        ctx.fillStyle = '#999'
        ctx.font = '12px 微软雅黑'
        ctx.fillText(this.cutString(data.description, 23), 15, 34)

        let html = `<img
            msgtype="news"
            contenteditable="false" 
            data-title="${this.encodeText(data.title)}" 
            data-description="${this.encodeText(data.description)}"
            data-url="${data.url}"
            data-background="${data.imageUrl}"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAGElEQVRIie3BAQEAAACAkP6v7ggKAICqAQkYAAHO7iU+AAAAAElFTkSuQmCC"
            style="background: url(${canvas.toDataURL('image/png')}) bottom center/100% no-repeat, url(${data.imageUrl}) top center/100% no-repeat"
          />`

        text += html.replace(/(\s+?)/g, ' ')
      } else if (data.type === 'mpnews') {
        //图文文章型
        let canvas = document.createElement('canvas')
        canvas.width = 318
        canvas.height = 53
        let ctx = canvas.getContext('2d')
        ctx.fillStyle = '#FFF'
        ctx.fillRect(0, 0, 318, 53)

        ctx.fillStyle = '#000'
        ctx.textBaseline = 'top'
        ctx.font = '14px 微软雅黑'
        ctx.fillText(this.cutString(data.title, 19), 15, 8)

        ctx.fillStyle = '#999'
        ctx.font = '12px 微软雅黑'
        ctx.fillText(this.cutString(data.description, 23), 15, 34)

        this.mpnewsSaveList.push(data.content)

        let html = `<img
            msgtype="mpnews"
            contenteditable="false" 
            data-title="${this.encodeText(data.title)}" 
            data-digest="${this.encodeText(data.description)}"
            data-index="${this.mpnewsSaveList.length - 1}"
            data-background="${data.imageUrl}"
            data-source="${data.source}"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAGElEQVRIie3BAQEAAACAkP6v7ggKAICqAQkYAAHO7iU+AAAAAElFTkSuQmCC"
            style="background: url(${canvas.toDataURL('image/png')}) bottom center/100% no-repeat, url(${data.imageUrl}) top center/100% no-repeat"
          />`

        text += html.replace(/(\s+?)/g, ' ')
      } else if (data.type === 'voice') {
        //语音型
        let canvas = document.createElement('canvas')
        canvas.width = 110
        canvas.height = 40
        let ctx = canvas.getContext('2d')
        ctx.fillStyle = '#FFF'
        ctx.fillRect(0, 0, 110, 40)

        ctx.fillStyle = '#000'
        ctx.textBaseline = 'top'
        ctx.font = '13px 微软雅黑'

        let t = '语音消息'
        ctx.fillText(t, 40, 15)

        let html = `<img 
          msgtype="voice" 
          imageurl="${data.url}"
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAGElEQVRIie3BAQEAAACAkP6v7ggKAICqAQkYAAHO7iU+AAAAAElFTkSuQmCC"
          style="background: url(${sendmsgVideo}) 10px center/auto 20px no-repeat, url(${canvas.toDataURL('image/png')}) left center no-repeat"
        >`

        text += html.replace(/(\s+?)/g, ' ')
      } else if (data.type === 'video' || data.type === 'file') {
        //视频
        let canvas = document.createElement('canvas')
        canvas.width = 240
        canvas.height = 60
        let ctx = canvas.getContext('2d')
        ctx.fillStyle = '#FFF'
        ctx.fillRect(0, 0, 240, 60)

        const fileName = data.title ? (data.title + data.imageUrl.slice(data.imageUrl.lastIndexOf('.'))) : this.getFileName(data.imageUrl)

        ctx.fillStyle = '#000'
        ctx.textBaseline = 'top'
        ctx.font = '14px 微软雅黑'
        ctx.fillText(this.cutString(fileName, 12), 55, 15)

        let html = `<img 
          msgtype="${data.type}" 
          imageurl="${data.imageUrl}"
          filename="${this.encodeText(fileName)}"
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAGElEQVRIie3BAQEAAACAkP6v7ggKAICqAQkYAAHO7iU+AAAAAElFTkSuQmCC"
          style="background: url(${data.type === 'file' ? sendmsgFile : sendmsgVideo}) 10px center/auto 40px no-repeat, url(${canvas.toDataURL('image/png')}) left center no-repeat"
        >`

        text += html.replace(/(\s+?)/g, ' ')
      }

      this.inputHtml(text)
    },
    //输入框中添加html
    async inputHtml (text) {
      let instance = new MsgTextConstructor({
        propsData: {
          text,
          face: true,
          divbr: true
        }
      })
      instance.$mount()

      let message = this.$refs.message.$el

      message.focus()

      let sel = global.getSelection(), range

      if (sel.getRangeAt && sel.rangeCount) {
        range = sel.getRangeAt(0)
        range.deleteContents()
        let el = instance.$el
        let frag = document.createDocumentFragment(), node, lastNode
        while ((node = el.firstChild)) {
          lastNode = frag.appendChild(node)
        }
        range.insertNode(frag)
        if (lastNode) {
          range = range.cloneRange()
          range.setStartAfter(lastNode)
          range.collapse(true)
          sel.removeAllRanges()
          sel.addRange(range)
        }
      }

      this.showPlaceHolder = false
    },
    //回车换行
    textKeydown (e) {
      if (e.key === 'Enter') {
        if (!this.enterEvent || e.shiftKey || e.ctrlKey) {
          this.inputHtml('<div><br></div>')
        } else {
          this.$emit('event', this.enterEvent)
        }
        e.preventDefault()
      }
    },
    textKeyup () {
      if (this.$refs.message.$el.innerHTML) {
        this.showPlaceHolder = false
      } else {
        this.showPlaceHolder = true
      }
    },
    //截取字符串
    cutString (str, num) {
      if (str.length > num) {
        return str.substring(0, num) + '...'
      } else {
        return str
      }
    },
    //文件大小格式化
    sizeFormat (num) {
      if (num > 1024 * 1024) {
        return (num / (1024 * 1024)).toFixed(2) + 'MB'
      } else if (num > 1024) {
        return (num / 1024).toFixed(2) + 'KB'
      } else {
        return Math.floor(num) + 'B'
      }
    },
    //初始化粘贴消息
    initPaste () {
      this.$refs.message.$el.addEventListener('paste', async e => {
        e.stopPropagation()
        e.preventDefault()
        let event = (e.originalEvent || e)

        let files = Array.from(event.clipboardData.files)

        let text = event.clipboardData.getData('text/html') || event.clipboardData.getData('text')

        if (text) {
          if (text.indexOf('<html') > -1) {
            //html格式
            if (text.indexOf('<!--StartFragment-->') > -1) {
              text = text.split('<!--StartFragment-->')[1].split('<!--EndFragment-->')[0]
            }

            text = text.replace(/[\f|\n|\r]/g, '')
          }

          text = text.replace(/<img.*?face="(.+?)".*?>/g, '[$1]')
          if (!this.tool.includes('file')) {
            text = text.replace(/<img.*?src="(.+?)".*?>/g, '')
          } else {
            text = text.replace(/<img.*?src="(.+?)".*?>/g, '%CUT_FLAG%[image]$1[/image]%CUT_FLAG%')
          }
          text = text.replace(/<br.*?>/g, '\n')
          text = text.replace(/<\/?[^>]*>/g, '')

          text = text.split('%CUT_FLAG%')

          for (let i in text) {
            let e = text[i]
            if (!e) continue

            if (/^\[image\](.+?)\[\/image\]$/.test(e)) {
              if (e.indexOf('[image]http') !== 0) {
                //不是网络图片
                await this.inputFile(files.shift())
              } else {
                //网络图片
                await this.inputHtml(e.replace(/\[image\](.+?)\[\/image\]/g, '<img src="$1" msgtype="image">'))
              }
            } else {
              await this.inputHtml(e)
            }
          }
        }
      })
    },
    //获取消息
    getMessage () {
      let text = this.$refs.message.$el.innerHTML

      text = text.replace(/<div>/g, '\n').replace(/<\/div>/g, '').replace(/<br.*?>/g, '').replace(/<img.*?>/g, '%,%$&%,%').split('%,%')

      let messageList = []

      let saveText = ''
      text.forEach((e, i) => {
        if (e) {
          if (/^<img/.test(e)) {
            if (/face=".*?"/.test(e)) {
              //表情
              saveText += e.replace(/<.*?face="(.+?)".*?>/, '[$1]')
            } else {
              if (saveText) {
                messageList.push({
                  msgType: 'text',
                  content: this.decodeText(saveText)
                })
                saveText = ''
              }
              if (/msgtype="image-base64"/.test(e)) {
                //图片base64
                messageList.push({
                  msgType: 'image-base64',
                  imageBase64: e.replace(/<.*?src="(.*?)".*?>/, '$1'),
                  fileName: this.decodeText(e.replace(/<.*?filename="(.*?)".*?>/, '$1')),
                })
              }

              if (/msgtype="image"/.test(e)) {
                //图片
                messageList.push({
                  msgType: 'image',
                  imageUrl: e.replace(/<.*?src="(.*?)".*?>/, '$1')
                })
              }
              if (/msgtype="news"/.test(e)) {
                //图文
                messageList.push({
                  msgType: 'news',
                  imageUrl: e.replace(/<.*?data-background="(.*?)".*?>/, '$1'),
                  picurl: e.replace(/<.*?data-background="(.*?)".*?>/, '$1'),
                  url: this.decodeText(e.replace(/<.*?data-url="(.*?)".*?>/, '$1')),
                  title: this.decodeText(e.replace(/<.*?data-title="(.*?)".*?>/, '$1')),
                  description: this.decodeText(e.replace(/<.*?data-description="(.*?)".*?>/, '$1')),
                })
              }
              if (/msgtype="file"/.test(e)) {
                //文件
                messageList.push({
                  msgType: 'file',
                  imageUrl: e.replace(/<.*?imageurl="(.*?)".*?>/, '$1'),
                  title: this.decodeText(e.replace(/<.*?filename="(.*?)".*?>/, '$1')),
                })
              }
              if (/msgtype="video"/.test(e)) {
                //视频
                messageList.push({
                  msgType: 'video',
                  imageUrl: e.replace(/<.*?imageurl="(.*?)".*?>/, '$1')
                })
              }
              if (/msgtype="voice"/.test(e)) {
                //语音
                messageList.push({
                  msgType: 'voice',
                  imageUrl: e.replace(/<.*?imageurl="(.*?)".*?>/, '$1')
                })
              }
              if (/msgtype="mpnews"/.test(e)) {
                //图文
                messageList.push({
                  msgType: 'mpnews',
                  imageUrl: e.replace(/<.*?data-background="(.*?)".*?>/, '$1'),
                  picurl: e.replace(/<.*?data-background="(.*?)".*?>/, '$1'),
                  content: this.mpnewsSaveList[e.replace(/<.*?data-index="(.*?)".*?>/, '$1')],
                  title: this.decodeText(e.replace(/<.*?data-title="(.*?)".*?>/, '$1')),
                  digest: this.decodeText(e.replace(/<.*?data-digest="(.*?)".*?>/, '$1')),
                  sourceId: Number(e.replace(/<.*?data-source="(.*?)".*?>/, '$1'))
                })
              }
            }
          } else {
            saveText += e
          }
        }
        if (i === text.length - 1 && saveText) {
          messageList.push({
            msgType: 'text',
            content: this.decodeText(saveText)
          })
        }
      })

      return messageList.filter(e => {
        if (e.msgType !== 'text') return true
        return e.content.replace(/\s/g, '').length
      })
    },
    //清空消息
    clearMessage () {
      this.$refs.message.$el.innerHTML = ''
    },
    //转码
    encodeText (text) {
      return text
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
    },
    decodeText (text) {
      return text
        .replace(/&amp(;)?/g, '&')
        .replace(/&#38(;)?/g, '&')
        .replace(/&lt(;)?/g, '<')
        .replace(/&#60(;)?/g, '<')
        .replace(/&gt(;)?/g, '>')
        .replace(/&#62(;)?/g, '>')
        .replace(/&nbsp(;)?/g, ' ')
        .replace(/&#160(;)?/g, ' ')
        .replace(/&#39(;)?/g, '\'')
        .replace(/&quot(;)?/g, '"')
        .replace(/&#34(;)?/g, '"')
    },
    getFileName (url) {
      return url.slice(url.lastIndexOf('/') + 1)
    }
  },
  async mounted () {
    await this.$nextTick()
    this.inputHeight = this.$refs.inputbox.getBoundingClientRect().height
    this.initPaste()
  },
  created () {
    Bus.$on('inputMessage', this.inputMessage)
  },
  beforeDestroy () {
    Bus.$off('inputMessage', this.inputMessage)
  },
  activated () {
    this.isActive = true
  },
  deactivated () {
    this.isActive = false
  }
}
</script>

<style lang="scss" scoped>
@import '../../assets/css/common.scss';

.message-input {
  width: 100%;
  height: 100%;
  text-align: left;
  .tool-box {
    width: 100%;
    height: 38px;
    padding: 0 20px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    > * {
      margin-right: 16px;
    }
    .icon-face {
      width: 18px;
      height: 18px;
      @include image(message_face, center/100% no-repeat);
      cursor: pointer;
    }
    .icon-file {
      width: 18px;
      height: 18px;
      @include image(message_file, center/100% no-repeat);
      cursor: pointer;
    }
    .el-icon-microphone {
      font-size: 20px;
      cursor: pointer;
      color: #555;
      /deep/ span {
        font-size: 14px;
      }
    }
  }
  .input-box {
    position: relative;
    height: calc(100% - 38px);
    font-size: 14px;
    line-height: 20px;
    color: #333;
    &::before {
      content: attr(data-placeholder);
      position: absolute;
      left: 20px;
      top: 0;
      color: #999;
    }
    .message {
      min-height: var(--height);
      padding: 0 20px;
      word-break: break-all;
      /deep/ {
        [msgtype*='image'] {
          max-width: 120px;
        }
        [msgtype*='news'] {
          width: 318px;
          height: 190px;
          border-radius: 6px;
          display: inline-block;
          border: 1px solid;
          overflow: hidden;
          border: 1px solid #bbb;
        }
        [msgtype*='file'],
        [msgtype*='video'] {
          width: 240px;
          height: 60px;
          border-radius: 6px;
          display: inline-block;
          border: 1px solid;
          overflow: hidden;
          border: 1px solid #bbb;
        }
        [msgtype*='voice'] {
          width: 110px;
          height: 40px;
          border-radius: 6px;
          display: inline-block;
          border: 1px solid;
          overflow: hidden;
          border: 1px solid #bbb;
        }
      }
    }
  }
}
</style>