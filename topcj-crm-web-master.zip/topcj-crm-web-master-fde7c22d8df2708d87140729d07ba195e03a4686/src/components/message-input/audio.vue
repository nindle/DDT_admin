<template>
  <div
    @mousedown="mouseStart"
    @mouseleave="mouseLeave"
    @mouseenter="mouseenter"
  ><span>{{ text }}</span></div>
</template>

<script>
import ZRecorder from './recorder'

export default {
  data () {
    return {
      timer: null,
      recoder: null,
      text: '按住说话',
      error: false,
      flag: false
    }
  },
  props: ['title'],
  created() {
    document.addEventListener('mouseup', this.bodyMouseup)
    this.init()
  },
  beforeDestroy () {
    document.removeEventListener('mouseup', this.bodyMouseup)
    clearTimeout(this.timer)
  },
  methods: {
    init() {
      clearTimeout(this.timer)
      this.text = this.title || '按住说话'
    },
    //按钮按下
    mouseStart() {
      this.flag = true
      clearTimeout(this.timer)

      ZRecorder
        .get()
        .then(e => {
          this.recoder = e
          this.recoder.start()
          this.text = '松开结束'
          this.timer = setTimeout(() => {
            //强制结束
            this.mouseEnd()
          }, 60 * 1000)
        })
        .catch(() => {
          this.flag = false
          this.$message.error('请检查你的录音设备')
        })
    },
    //松开时上传语音
    mouseEnd () {
      this.flag = false
      clearTimeout(this.timer)

      this.recoder.stop()

      const {blob, durationMs} = this.recoder.getVoice()
      // 当语音时间小于1000时，不发送
      if (durationMs < 1000) {
        this.$message.error('语音时间小于1s')
        this.init()
        return
      }

      const files = new File([blob], new Date().getTime() + '.wav', {lastModified: Date.now()});

      this.$http({
        mode: 'form',
        url: '%CRM%/source/upload_file.sdcrm',
        data: {
          token: true,
          type: 'voice',
          uploadFile: files
        }
      }).then(({ result }) => {
        this.$emit('success', result.url)
      })

      this.init()
    },
    mouseLeave() {
      if(this.flag) {
        this.text = '松开取消'
      }
    },
    mouseenter() {
      if(this.flag) {
        this.text = '松开结束'
      }
    },
    bodyMouseup() {
      if(this.flag) {
        if(this.text === '松开结束') {
          this.mouseEnd()
        }else{
          this.flag = false
          clearTimeout(this.timer)
          this.recoder.stop()
          this.init()
        }
      }
    }
  }
}
</script>
