<template>
  <el-dialog-pro 
    @close="close" 
    max-height
    top="24px"
  >
    <!-- 标题 -->
    <template #title>
      <el-tabs v-model="activeName">
        <el-tab-pane 
          v-for="e in tabList.filter(e => e.show)"
          :key="e.name"
          :label="e.label" 
          :name="e.name"
        ></el-tab-pane>
      </el-tabs>
    </template>

    <!-- 内容 -->
    <component 
      v-if="selectOrder.sn"
      :is="activeName" 
      :sn="selectOrder.sn"
      :order-id="selectOrder.id"
      :user-id="data.userId"
      :key="selectOrder.sn"
      :type="type"
      ref="content"
    />

    <!-- 左边用户详情 -->
    <template #left>
      <user-detail 
        :data="data"
        :active-sn="selectOrder.sn"
        :type="type"
        @select="setSelectOrder"
        ref="userDetail"
      />
    </template>

  </el-dialog-pro>
</template>
<script>
import Disclosure from './s-disclosure'
import Risk from './s-risk'
import Agreement from './s-agreement'
import Refund from './s-refund'
import Message from './s-message'
import UserDetail from './userDetail'

export default {
  data() {
    return {
      //切换
      activeName: 'Message',
      tabList: [
        { name: 'Message', label: this.type === 1 ? '营销记录' : '服务记录', show: true},
        { name: 'Disclosure', label: '风险揭示书', show: true},
        { name: 'Risk', label: '风险测评', show: true},
        { name: 'Agreement', label: '合同协议', show: true},
        { name: 'Refund', label: '退费材料', show: false},
      ],
      //当前订单号
      selectOrder: {}
    }
  },
  props:{
    show: Boolean,
    data: Object,
    type: Number
  },
  inject: ['auth'],
  components: {
    Disclosure,
    UserDetail,
    Risk,
    Agreement,
    Refund,
    Message
  },
  methods:{
    //获取退费情况
    async getRefund() {
      if(this.type === 1) return 

      let { result } = await this.$http({
        url: '%CRM%/refund/get_refund_search.sdcrm',
        data: {
          token: true,
          managerId: this.$store.state.managerInfo.id,
          pageNum: 1,
          pageSize: 1,
          searchTxt: `${this.selectOrder.sn}`
        }
      })

      this.tabList.filter(e => e.name === 'Refund')[0].show = !!result.contents.length
    },
    //选择订单
    setSelectOrder(e) {
      this.selectOrder = e
      this.getRefund()
    },
    close(){
      this.$emit('update:show', false)
    }
  }
}
</script>

<style lang="scss" scoped>
.popover {
  /deep/ {
    .el-dialog__header { padding-bottom: 0 !important;}
  }
  .el-tabs {
    /deep/ {
      .el-tabs__header { margin: 0; }
      .el-tabs__item { 
        font-size: 15px;
        line-height: 21px;
        height: 37px;
        padding: 0 12px;
      }
      .el-tabs__nav-wrap::after { display: none;}
      .el-tabs__item.is-top:nth-child(2), .el-tabs--top .el-tabs__item.is-bottom:nth-child(2), .el-tabs--bottom .el-tabs__item.is-top:nth-child(2), .el-tabs--bottom .el-tabs__item.is-bottom:nth-child(2) { padding-left: 0;}
      .el-tabs__item.is-top:last-child, .el-tabs--top .el-tabs__item.is-bottom:last-child, .el-tabs--bottom .el-tabs__item.is-top:last-child, .el-tabs--bottom .el-tabs__item.is-bottom:last-child { padding-right: 0;}
    }
  }
}
</style>