<template>
  <div 
    class="user-detail"
    :style="{ '--other-height': `${48 + 164 + 62 + 56 + 0}px` }"
  >
    <!--基本信息-->
    <div class="info">
      <div class="r"></div>
      <div class="text">
        <div>用户：{{data.userId}}</div>
        <div>
          <span>入档时间：</span>
          <span>{{data.archivesTime | timeFormat('yyyy-MM-dd')}}</span>
        </div>
        <div>
          <span>实名：</span>
          <span>{{data.realname | filterRealName}}</span>
        </div>
        <div>
          <span>风测：</span>
          <span>{{data.score}}分</span>
        </div>
        <div>
          <span>户口所在地：</span>
          <span>{{data.areaZone}}</span>
        </div>
      </div>
    </div>

    <!--审核情况-->
    <div 
      class="review" 
      v-if="false"
    >
      <div class="title">审核情况</div>
      <div class="linetext">
        <span>过滤人：</span>
        <span>分公司合规</span>
      </div>
      <div class="linetext">
        <span>初审人：</span>
        <span>分公司合规</span>
      </div>
      <div class="linetext">
        <span>复审人：</span>
        <span>集团审核人</span>
      </div>
    </div>

    <!--成交情况-->
    <div class="deal">
      <div class="title">成交情况</div>

      <el-scrollbar-pro>
        <div 
          class="order"
          v-for="(e, i) in orderList"
          :key="e.sn"
          :class="{ active: activeSn === e.sn }"
          :style="{ marginTop: i === 0 ? '0' : '' }"
          @click="$emit('select', e)"
        >
          <div class="linetext">
            <span>订单编号：</span>
            <span>{{e.sn}}</span>
          </div>
          <div class="linetext">
            <span>购买套餐：</span>
            <span>{{e.packageName}}</span>
          </div>
          <div class="linetext">
            <span>开通时间：</span>
            <span>{{e.ctime | timeFormat('yyyy-MM-dd hh:mm')}}</span>
          </div>
          <div class="linetext">
            <span>到期时间：</span>
            <span>{{e.expTime | timeFormat('yyyy-MM-dd hh:mm')}}</span>
          </div>
          <el-divider></el-divider>
          <div 
            class="linetext"
            v-if="type === 2"
          >
            <span>售后归属：</span>
            <span>
              <template v-if="auth.includes('editname')">
                <el-input
                  v-model="e.sub_serviceName"
                  size="mini"
                  @change="editName(e)"
                ></el-input>
              </template>
              <template v-else>{{e.sub_serviceName}}</template>
            </span>
          </div>
          <div 
            class="linetext"
            v-if="type === 1"
          >
            <span>业务归属：</span>
            <span>
              <template v-if="auth.includes('editname')">
                <el-input
                  v-model="e.sub_managerName"
                  size="mini"
                  @change="editName(e)"
                ></el-input>
              </template>
              <template v-else>{{e.sub_managerName}}</template>
            </span>
          </div>
          <div 
            class="linetext"
            v-if="type === 1"
          >
            <span>过滤人：</span>
            <span>
              <template v-if="auth.includes('editname')">
                <el-input
                  v-model="e.sub_passManagerName"
                  size="mini"
                  @change="editName(e)"
                ></el-input>
              </template>
              <template v-else>{{e.sub_passManagerName}}</template>
            </span>
          </div>
          <div 
            class="linetext"
            v-if="type === 1"
          >
            <span>初审人：</span>
            <span>
              <template v-if="auth.includes('editname')">
                <el-input
                  v-model="e.sub_archivistsName"
                  size="mini"
                  @change="editName(e)"
                ></el-input>
              </template>
              <template v-else>{{e.sub_archivistsName}}</template>
            </span>
          </div>
          <div 
            class="linetext"
            v-if="type === 1"
          >
            <span>复审人：</span>
            <span>
              <template v-if="auth.includes('editname')">
                <el-input
                  v-model="e.sub_reviewerName"
                  size="mini"
                  @change="editName(e)"
                ></el-input>
              </template>
              <template v-else>{{e.sub_reviewerName}}</template>
            </span>
          </div>
        </div>
      </el-scrollbar-pro>
    </div>

    <!--签署链接-->
    <el-button
      class="agreement"
      type="primary"
      plain
      size="small"
      @click="copyLink"
    >合同签署链接</el-button>

  </div>
</template>
<script>
export default {
  data() {
    return {
      orderList: []
    }
  },
  inject: ['auth'],
  props:{
    data: Object,
    activeSn: String,
    type: Number
  },
  methods:{
    //获取订单列表
    async getOrderList() {
      let { result } = await this.$http({
        url: '%CRM%/buy/order/get_user_archives_order.sdcrm',
        data: {
          token: true,
          userId: this.data.userId
        }
      })

      this.orderList = result.map(e => {
        e.sub_managerName = e.aiManagerName
        e.sub_passManagerName = e.aiPassManagerName
        e.sub_archivistsName = e.aiArchivistsName
        e.sub_reviewerName = e.aiReviewerName
        e.sub_serviceName = e.aiServiceName
        e.showEdit = false
        return e
      })

      if(this.orderList.length) {
        this.$emit('select', this.orderList[0])
      }
    },
    //复制签署链接
    copyLink() {
      if(!this.activeSn) return

      let text = `合同签署链接:${this.SYS.WEBURL}/ns/#/signcontract?sn=${this.activeSn}&time=${Date.now()}`
      this.$copy(text)
    },
    //修改名称
    async editName(e) {
      await this.$http({
        url: '%CRM%/buy/order/set_order_auditor.sdcrm',
        data: {
          token: true,
          orderId: e.id,
          aiManagerName: e.sub_managerName,
          aiPassManagerName: e.sub_passManagerName,
          aiArchivistsName: e.sub_archivistsName,
          aiReviewerName: e.sub_reviewerName,
          aiServiceName: e.sub_serviceName
        }
      })

      e.aiManagerName = e.sub_managerName
      e.aiPassManagerName = e.sub_passManagerName
      e.aiArchivistsName = e.sub_archivistsName
      e.aiReviewerName = e.sub_reviewerName
      e.aiServiceName = e.sub_serviceName

      e.showEdit = false
    }
  },
  filters: {
    filterRealName(text) {
      if(!text) return ''
      return text.charAt(0) + ''.padStart(text.length-1, '*')
    }
  },
  created() {
    this.getOrderList()
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.user-detail {
  width: 340px;
  height: 100%;
  padding: 24px 0;
  box-sizing: border-box;
  .info {
    position: relative;
    width: 292px;
    height: 164px;
    border-radius: 8px;
    background: #0B69FF;
    overflow: hidden;
    box-shadow: 0 5px 15px 0 rgba(#0B69FF, .24), 0 15px 10px 0 rgba(#0B69FF, .06);
    margin: 0 24px;
    .r {
      position: absolute;
      right: -107px;
      top: -60px;
      border-radius: 50%;
      background: #AFDDFF;
      width: 160px;
      height: 160px;
      overflow: hidden;
      &::before {
        content: "";
        position: absolute;
        right: -19px;
        top: 98px;
        border-radius: 50%;
        background: #61D3FF;
        width: 240px;
        height: 240px;
      }
    }
    &::before {
      content: "";
      position: absolute;
      right: -126px;
      top: 38px;
      border-radius: 50%;
      background: #003CE5;
      width: 240px;
      height: 240px;
    }
    .text {
      position: relative;
      padding: 16px;
      > div {
        color: #FFF;
        font-size: 14px;
        line-height: 22px;
        padding-bottom: 4px;
        display: flex;
        justify-content: space-between;
        &:first-child { 
          font-size: 16px;
          line-height: 24px;
          padding-bottom: 8px;
        }
        > span:first-child { opacity: .65;}
      }
    }
  }

  .title {
    color: #333;
    font-size: 14px;
    line-height: 22px;
    font-weight: bold;
    padding-bottom: 12px;
    padding-top: 24px;
  }
  .linetext {
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    color: #333;
    padding-bottom: 8px;
    > span:first-child { color: #999;}
    > span:last-child {
      max-width: 180px;
    }
  }
  .review {
    padding-bottom: 16px;
    border-bottom: 1px solid #EEE;
    margin: 0 24px;
  }
  .deal {
    .title { 
      margin: 0 24px;
      padding-bottom: 16px;
    }
    .order {
      margin: 16px 24px 0;
      background: #FAFAFA;
      padding: 16px 16px 8px;
      cursor: pointer;
      &.active { 
        background: rgba($--color-main, .2);
        .linetext {
          color: $--color-main;
          > span:first-child { color: #333;}
          .el-input {
            /deep/ {
              .el-input__inner { color: $--color-main;}
            }
          }
        }
      }
      .el-input {
        /deep/ {
          .el-input__inner {
            height: 19px;
            line-height: 19px;
            border-color: transparent;
            background: none;
            font-size: 14px;
            text-align: right;
            padding: 0;
            color: #333;
            &:focus {
              padding: 0 10px;
              border-bottom-color: $--color-main;
            }
          }
        }
      }
      .el-divider--horizontal {
        margin: 12px 0;
      }
    }
    .scrollbar { max-height: calc(var(--popover-height) - var(--other-height))}
  }
  .agreement {
    display: block;
    margin: 24px auto 0;
  }
}
</style>