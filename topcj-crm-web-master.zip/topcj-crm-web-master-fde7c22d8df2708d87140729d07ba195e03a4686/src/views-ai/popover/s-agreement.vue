<template>
  <iframe
    :src="src"
  ></iframe>
</template>
<script>
import { md5 } from '../../assets/js/crypto'

export default {
  data() {
    return {
      src: ''
    }
  },
  computed: {
    
  },
  props:{
    sn: String
  },
  methods:{
    init() {
      if(!this.sn) return

      let sn = this.sn
      let time = Date.now()
      let token = this.$store.state.token
      let sign = md5(`7685ab5265c568c41024cca4b396efa1${token}${sn}${time}`)

      this.src = `${this.SYS.WEBURL}/ns/#/agreementfullimage?gm=${token}&sn=${sn}&time=${time}&sign=${sign}&noresult=${encodeURIComponent(`/agreement/12?gm=${token}&sn=${sn}&time=${time}&sign=${sign}&size=16`)}`
    }
  },
  created() {
    this.init()
  }
}
</script>

<style lang="scss" scoped>
iframe {
  width: 100%;
  border: none;
  display: block;
  height: calc(var(--popover-height) - 145px);
}
</style>