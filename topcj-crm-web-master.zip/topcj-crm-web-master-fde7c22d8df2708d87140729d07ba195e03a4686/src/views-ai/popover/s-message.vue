<template>
  <div>
    <el-screen-pro
      :model="screen"
      :config="config"
      @change="getMessageList"
    ></el-screen-pro>
    <!-- 聊天信息 -->
    <message 
      :data="messageList"
      translate
    ></message>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import Message from '../../components/message'

export default {
  data() {
    return {
      //消息列表
      messageList: [],
      //筛选数据
      screen: {
        msgType: '',
        appType: '',
        corpId: 1
      },
      config: {
        msgType: {
          placeholder: '消息类型',
          type: 'select',
          options: [
            { value: 'text', label: '文字' },
            { value: 'image', label: '图片' },
            { value: 'track', label: '录音' },
            { value: 'voice', label: '语音' },
            { value: 'news', label: '外链' },
            { value: 'mpnews', label: '图文' },
            { value: 'link', label: '链接' },
            { value: 'video', label: '视频' },
            { value: 'file', label: '文件' },
          ]
        },
        appType: {
          placeholder: '聊天通道',
          type: 'select',
          options: [
            { value: 1, label: '工作台' },
            { value: 2, label: '微信' },
            { value: 3, label: '电话' },
            { value: 4, label: '外部联系人' },
            { value: 7, label: '短信' }
          ]
        }
      }
    }
  },
  props:{
    orderId: Number,
    userId: Number,
    type: Number
  },
  inject: ['auth'],
  components: {
    Message
  },
  methods:{
    //获取消息记录
    async getMessageList() {
      if(this.type === 1) {
        await this.getMessageType1()
      }else{
        await this.getMessageType2()
      }
    },
    //获取营销记录
    getMessageType1: throttle(async function() {
      let data = await this.$http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/user/message/order/:userId/:orderId.sdcrm',
            mode: 'get',
            data: {
              token: true,
              userId: this.userId,
              orderId: this.orderId,
              msgType: this.screen.msgType || undefined,
              appType: this.screen.appType || undefined
            }
          },
          {
            url: '%CRM%/user/message/call/:userId/:orderId.sdcrm',
            mode: 'get',
            data: {
              token: true,
              userId: this.userId,
              orderId: this.orderId
            }
          }
        ]
      })

      this.messageList = [
        ...(data[0].result.map(e => {
          e.managerTitle = '业务'
          return e
        }) || []), 
        ...(data[1].result.filter(e => {
          return (this.screen.msgType ? this.screen.msgType === e.msgType : true) && (this.screen.appType ? this.screen.appType === e.appType : true)
        }).map(e => {
          e.managerTitle = '合规电话'
          return e
        }) || [])
      ].map(e => {
        if(e.reason) {
          e.remark = JSON.parse(e.reason)
        }else{
          e.remark = []
        }
        return e
      })
    }),
     //获取售后记录
    getMessageType2: throttle(async function() {
      let { result } = await this.$http({
        url: '%CRM%/user/message/service.sdcrm',
        data: {
          token: true,
          userId: this.userId,
          selected: null,
          msgType: this.screen.msgType || undefined,
          appType: this.screen.appType || undefined
        }
      })

      this.messageList = result.map(e => {
        e.managerTitle = '售后'
        if(e.reason) {
          e.remark = JSON.parse(e.reason)
        }else{
          e.remark = []
        }
        return e
      })
    })
  }
}
</script>

<style lang="scss" scoped>
.screen {
  position: sticky;
  top: 0;
  padding-bottom: 24px;
  background: #FFF;
  z-index: 99;
}
</style>