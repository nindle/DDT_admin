<template>
  <div>
    <template v-for="e in list">
      <el-button
        type="text"
        icon="el-icon-download"
        v-open="e.picUrl1"
        :key="e.picUrl1"
        v-if="e.picUrl1"
      >{{e.picUrl1 | getName}}</el-button>
      <el-button
        type="text"
        icon="el-icon-download"
        v-open="e.picUrl2"
        :key="e.picUrl2"
        v-if="e.picUrl2"
      >{{e.picUrl2 | getName}}</el-button>
      <el-button
        type="text"
        icon="el-icon-download"
        v-open="e.fileUrl"
        :key="e.fileUrl"
        v-if="e.fileUrl"
      >{{e.fileUrl | getName}}</el-button>
    </template>
  </div>
</template>
<script>
export default {
  data() {
    return {
      list: []
    }
  },
  props:{
    sn: String
  },
  methods:{
    async init() {
      if(!this.sn) return

      let { result } = await this.$http({
        url: '%CRM%/refund/get_refund_search.sdcrm',
        data: {
          token: true,
          managerId: this.$store.state.managerInfo.id,
          pageNum: 1,
          pageSize: 1,
          searchTxt: `${this.sn}`
        }
      })

      this.list = result.contents
    }
  },
  filters: {
    getName(text) {
      let a = text.split('/')
      return a[a.length - 1]
    }
  },
  created() {
    this.init()
  }
}
</script>

<style lang="scss" scoped>
.el-button {
  display: block;
  margin: 0;
}
</style>