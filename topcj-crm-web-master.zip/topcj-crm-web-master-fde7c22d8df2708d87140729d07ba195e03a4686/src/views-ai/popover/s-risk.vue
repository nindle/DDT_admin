<template>
  <iframe
    :src="src"
  ></iframe>
</template>
<script>
import { md5 } from '../../assets/js/crypto'

export default {
  data() {
    return {
      src: ''
    }
  },
  computed: {
    
  },
  props:{
    sn: String,
    userId: Number
  },
  methods:{
    async init() {
      if(!this.sn) return

      let { result } = await this.$http({
        url: '%CRM%/user/get_user_risk.sdcrm',
        data: {
          token: true,
          userId: this.userId
        },
      })

      if(!result) {
        this.src = `https://www.topxlc.com/m/graduation?srisk=${encodeURIComponent(JSON.stringify({}))}`
        return
      }

      //有风测结果
      let sn = this.sn
      let time = Date.now()
      let token = this.$store.state.token
      let sign = md5(`7685ab5265c568c41024cca4b396efa1${token}${sn}${time}`)
      let noresult = `https://www.topxlc.com/m/graduation?srisk=${encodeURIComponent(JSON.stringify(result))}`

      this.src = `${this.SYS.WEBURL}/ns/#/risktest?gm=${token}&sn=${sn}&time=${time}&sign=${sign}&noresult=${encodeURIComponent(noresult)}`
    }
  },
  created() {
    this.init()
  }
}
</script>

<style lang="scss" scoped>
iframe {
  width: 100%;
  border: none;
  display: block;
  height: calc(var(--popover-height) - 145px);
}
</style>