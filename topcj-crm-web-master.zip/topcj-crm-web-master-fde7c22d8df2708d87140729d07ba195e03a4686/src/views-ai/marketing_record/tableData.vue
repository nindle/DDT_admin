<template>
  <div class="scroll-box">
    <div class="card-box">
      <el-card 
        v-for="e in data" 
        :key="e.userId"
        @click.native="$emit('open', e)"
      >
        <template #header>
          <el-checkbox
            v-if="auth.includes('distribution')"
            :key="Date.now()"
            @change="checkItem($event, e)"
            :checked="selectList.includes(e)"
            @click.native.stop
          >用户编号：{{e.userId}}</el-checkbox>
        </template>

        <div class="item">
          <span>入档时间：</span>
          {{e.archivesTime | timeFormat('yyyy-MM-dd hh:mm')}}
        </div>
        <div class="item">
          <span>最近成交：</span>
          {{e.lastCostTime | timeFormat('yyyy-MM-dd hh:mm')}}
        </div>
        <div class="item">
          <span>实名认证：</span>
          {{e.realname | filterRealName}}
        </div>
        <div class="item">
          <span>风险测评：</span>
          {{e.score}}分
        </div>
        <div class="item c">
          <span>点击查看：</span>
          协议、聊天记录
        </div>
      </el-card>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      
    }
  },
  props: {
    data: Array,
    selectList: {
      type: Array,
      default() {
        return []
      }
    }
  },
  inject: ['auth'],
  methods: {
    checkItem(type, item) {
      if(type && !this.selectList.includes(item)) {
        this.selectList.push(item)
      }else if(!type){
        this.selectList.splice(this.selectList.indexOf(item), 1)
      }
    }
  },
  filters: {
    filterRealName(text) {
      if(!text) return ''
      return text.charAt(0) + ''.padStart(text.length-1, '*')
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.scroll-box {
  width: 100%;
  overflow-x: hidden;
  .card-box {
    width: calc(100% + 24px);
    display: flex;
    flex-wrap: wrap;
    .el-card {
      width: 304px;
      box-sizing: border-box;
      margin-right: 24px;
      margin-bottom: 24px;
      cursor: pointer;
      /deep/ {
        .el-card__header { 
          background: #FAFAFA;
          padding: 0;
          .el-checkbox {
            width: 100%;
            display: flex;
            align-items: center;
            flex-direction: row-reverse;
            justify-content: space-between;
            padding: 18px 20px 18px 10px;
            box-sizing: border-box;
            .el-checkbox__label {
              color: #606266 !important;
            }
          }
        }
      }
      .item {
        font-size: 14px;
        color: #333;
        margin-bottom: 16px;
        &.c { color: $--color-main;}
        span { color: #999;}
        &:last-child { margin-bottom: 0;}
      }
    }
  }
}
</style>
