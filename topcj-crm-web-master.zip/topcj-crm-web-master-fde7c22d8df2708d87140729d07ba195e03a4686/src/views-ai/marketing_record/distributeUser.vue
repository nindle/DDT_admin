
<template>
  <el-dialog-pro 
    @close="close"
    width="296px"
  >
    <!--标题-->
    <template #title>
      分配资源<span class="tip">(共{{data.length}}个)</span>
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        managerId: ''
      },
      config: {
        managerId: {
          placeholder: '请输入员工姓名/工号',
          type: 'select-manager',
          filter: {
            managerType: 4,
            corpId: 0,
            isLock: 0
          },
          rule: [
            { required: true, message: '请选择员工' }
          ]
        }
      },
      loading: false
    }
  },
  props: {
    data: Array
  },
  methods: {
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/user/user_batch_distribute.sdcrm',
        data: {
          token: true,
          managerId: this.form.managerId,
          attachType: 4,
          userIds: this.data.map(e => e.userId)
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`分配失败：${errmsg || msg}`)
        return
      }

      this.$message.success('分配成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>

<style lang="scss" scoped>
.tip {
  font-size: 12px;
  color: #999;
  margin-left: 6px;
}
</style>
