<template>
  <div class="view">
    <top-data>
      <el-button
        type="primary"
        size="small"
        @click="$router.push({ name: 'ai-marketing_review', params: { status: 1 } })"
        v-if="auth.includes('approval')"
      >进入审批工作台</el-button>
      <el-button
        type="primary"
        size="small"
        @click="$router.push({ name: 'ai-marketing_review', params: { status: 2 } })"
        v-if="auth.includes('inspect')"
      >进入稽查工作台</el-button>
    </top-data>
    <el-layout-pro 
      class="box"
      @scroll-bottom="getTableData()"
    >
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        >
          <template #selectAll>
            <el-checkbox
              :key="Date.now()"
              @change="selectUserAll"
              :checked="selectUser.length === tableData.length && selectUser.length > 0"
              :indeterminate="selectUser.length !== tableData.length && selectUser.length > 0"
            >全选</el-checkbox>
          </template>
        </el-screen-pro>
      </template>

      <template #scroll>
        <table-data 
          :data="tableData"
          @open="openPopover"
          :select-list="selectUser"
        />
      </template>

      <template #popover>
        <popover 
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          :type="1"
        />

        <distribute-user 
          v-if="showDistribute"
          :show.sync="showDistribute"
          :data="selectUser"
          @change="getTableData(true)"
        />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'

import TopData from './topData'
import TableData from './tableData'
import Popover from '../popover/index'
import DistributeUser from './distributeUser'

export default {
  data() {
    return {
      showPopover: false,
      rowData: null,
      //筛选
      screen: {
        corpId: '',
        serviceStatus: '',
        buyStatus: '',
        archivesStatus: 1,
        time: [],
        superviseId: '',
        search: '',
        superviseTime: [],
        reviewer: this.$store.state.managerInfo.isLeader ? '' : this.$store.state.managerInfo.id
      },
      config: {
        corpId: {
          type: 'select-corp'
        },
        reviewer: {
          type: 'select-manager',
          placeholder: '审核人',
          filter: {
            isLock: 0,
            managerType: 4,
            corpId: 0
          },
          disabled: !this.$store.state.managerInfo.isLeader
        },
        serviceStatus: {
          type: 'select',
          placeholder: '服务状态',
          options: [
            { label: '服务期内', value: 1 },
            { label: '已到期', value: 2 }
          ]
        },
        buyStatus: {
          type: 'select',
          placeholder: '退费状态',
          options: [
            { label: '已退费', value: 3 },
            { label: '未退费', value: 1 }
          ]
        },
        archivesStatus: {
          type: 'select',
          placeholder: '审核状态',
          options: [
            { label: '待审核', value: 1 },
            { label: '已通过', value: 2 }
          ]
        },
        time: {
          type: 'date-range',
          placeholder: ['成交日期', '结束日期']
        },
        search: {
          type: 'input',
          placeholder: '输入编号/昵称/名称/手机号'
        },
        br: { type: 'br' },
        split: { type: 'split' },
        superviseId: {
          type: 'select-manager',
          placeholder: '集团合规归属人',
          filter: {
            managerType: 4,
            corpId: 0,
            isLock: 0
          }
        },
        superviseTime: {
          type: 'date-range',
          placeholder: ['分配日期', '结束日期']
        },
        selectAll: {
          hide: !this.auth.includes('distribution')
        },
        distribute: {
          hide: !this.auth.includes('distribution'),
          type: 'button',
          buttonType: 'primary',
          label: '分配',
          click: this.openDistributeUser
        }
      },
      //表格数据
      tableData: [],
      //选择用户
      selectUser: [],
      //显示分配弹框
      showDistribute: false
    }
  },
  props: {
    auth: Array
  },
  provide() {
    return {
      auth: this.auth
    }
  },
  components: {
    TopData,
    TableData,
    Popover,
    DistributeUser
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      let from = toFirst ? 1 : (Math.ceil(this.tableData.length / 30) + 1)

      this.selectUser = []

      let { result } = await this.$http({
        url: '%CRM%/buy/order/user_archives_list.sdcrm',
        data: {
          token: true,
          size: 30,
          from,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
          keyword: this.screen.search ? this.screen.search : undefined,
          serviceStatus: this.screen.serviceStatus ? this.screen.serviceStatus : undefined,
          buyStatus: this.screen.buyStatus ? this.screen.buyStatus : undefined,
          pageType: 1,
          archivesStatus: this.screen.archivesStatus ? this.screen.archivesStatus : undefined,
          superviseId: this.screen.superviseId ? this.screen.superviseId : undefined,
          reviewer: this.screen.reviewer ? this.screen.reviewer : undefined,
          superviseStime: this.screen.superviseTime?.[0],
          superviseEtime: this.screen.superviseTime?.[1]
        }
      })

      if(from === 1) {
        this.tableData = result.records
      }else{
        this.tableData = [...this.tableData, ...result.records]
      }
    }),
    //打开详情
    openPopover(row) {
      this.rowData = row
      this.showPopover = true
    },
    //打开分配弹框
    openDistributeUser() {
      if(!this.selectUser.length) {
        this.$message.error('请选择要分配的用户')
        return
      }

      this.showDistribute = true
    },
    //选择所有用户
    selectUserAll(type) {
      if(type) {
        this.selectUser = [...this.tableData]
      }else{
        this.selectUser = []
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px 0 0;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: calc(100% - 72px);
    /deep/ {
      .screen-box {
        background: #FFF;
        padding: 24px;
        border-bottom: 24px solid #F0F2F5;
      }
    }
  }
}
</style>