<template>
  <div 
    class="view"
    :class="{ 'has-user': selectUserId }"
  >
    <top-data 
      @screen="fastScreen" 
      v-if="mode === 'ai'"
    />

    <el-layout-pro
      class="box"
      :class="{ 'has-top': mode === 'ai' }"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      :page-layout="mode === 'ai' ? 'normal' : 'default'"
      @page-change="getTableData()"
    >
      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        >
          <template #updateExternalMsg>
            <el-popover
              width="200"
              trigger="click"
              placement="top"
              class="syncmessage"
              v-model="showUpdateMsg"
              @hide="updateMsg()"
            >
              <el-input 
                placeholder="请输入用户ID"
                v-model="updateMsgUserId"
                clearable
                size="small"
              />
              <div style="text-align: right; margin: 12px 0 0">
                <el-button 
                  size="mini" 
                  type="text" 
                  @click="updateMsg()"
                >取消</el-button>
                <el-button 
                  type="primary" 
                  size="mini" 
                  @click="updateMsg(true)"
                >确定</el-button>
              </div>
              <el-button
                slot="reference"
                size="small"
              >同步聊天记录</el-button>
            </el-popover>
          </template>
        </el-screen-pro>
      </template>

      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData"
          @select="selectUserId = $event"
          :select-list.sync="selectList"
          :mode="mode"
          @upload="openUpload"
          @change="getTableData()"
          @open-tag="openEditTag"
          @open-drawer="openDrawer"
          ref="table"
        />
      </template>

      <!--弹框模块-->
      <template #popover>
        <popover-message 
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          :type="popoverType"
          :upload="hasUpload"
          :mode="mode"
        />
        <edit-data 
          v-if="showEdit"
          :show.sync="showEdit"
          :list="selectList"
          :mode="mode"
          @change="getTableData()"
        />
        <edit-tag 
          v-if="showEditTag"
          :show.sync="showEditTag"
          :data="rowData"
          :type="popoverType"
          @review="(e) => { $refs.table.reviewOrder(rowData, popoverType, e) }"
          @change="getTableData()"
        />
      </template>
    </el-layout-pro>

    <!--客户详情-->
    <el-layout-pro 
      class="user-box"
      :class="{ 'has-top': mode === 'ai' }"
      v-if="selectUserId"
    >
      <template #screen>
        <el-screen-pro :config="userDetailConfig">
          <template #close>
            <i 
              class="el-icon-close"
              @click="selectUserId = 0"
            ></i>
          </template>
        </el-screen-pro>
      </template>

      <template #scroll>
        <user-detail 
          class="user-detail-box" 
          :user-id="selectUserId"
          :key="selectUserId"
        />
      </template>
    
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import bus from '../../assets/js/bus'

import TopData from './topData'
import TableData from './tableData'
import UserDetail from '../../components/user-detail/index'
import PopoverMessage  from './popoverMessage'
import EditData  from './editData'
import EditTag  from './editTag'

export default {
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      selectList: [],
      //选择的用户ID
      selectUserId: 0,
      //是否显示弹框
      showPopover: false,
      showEdit: false,
      showEditTag: false,
      rowData: null,
      popoverType: 0,
      hasUpload: false,
      //筛选
      screen: {
        corpId: '',
        time: [],
        selected: '',
        archivesStatus: '',
        archivesServiceStatus: '',
        useType: '',
        search: ''
      },
      config: {
        corpId: {
          type: 'select-corp'
        },
        time: { 
          type: 'date-range',
          placeholder: ['录入时间', '结束日期'] 
        },
        selected: {
          type: 'select',
          placeholder: '过滤状态',
          options: [
            { value: 0, label: '待过滤' },
            { value: 1, label: '过滤通过' },
            { value: 2, label: '过滤未通过' }
          ]
        },
        archivesStatus: {
          type: 'select',
          placeholder: '营销审核状态',
          options: [
            { value: 0, label: '待上传' },
            { value: 1, label: '审核中' },
            { value: 2, label: '已通过' },
            { value: 4, label: '待补充' },
          ]
        },
        archivesServiceStatus: {
          type: 'select',
          placeholder: '服务审核状态',
          options: [
            { value: 0, label: '待上传' },
            { value: 1, label: '审核中' },
            { value: 2, label: '已通过' },
            { value: 3, label: '待补充' },
          ]
        },
        useType: {
          type: 'select',
          placeholder: '用户状态',
          options: [
            { value: 0, label: '服务期内' },
            { value: 1, label: '退费用户' },
            { value: 2, label: '内诉用户' },
            { value: 3, label: '外诉用户' },
            { value: 4, label: '过期用户' },
          ]
        },
        editSelected: {
          hide: () => !this.auth.includes('editfilter'),
          type: 'button',
          buttonType: 'primary',
          label: '修改过滤状态',
          click: () => {
            if(!this.selectList.length) {
              this.$message.error('请选择订单')
              return
            }

            this.showEdit = true
          }
        },
        updateExternalMsg: {
          hide: () => this.$store.state.managerInfo.roleList.findIndex(e => e.id === 311) === -1
        },
        split: { type: 'split' },
        search: {
          type: 'input',
          placeholder: '输入关键词',
          changeLog: true
        },
        excel: {
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title) },
          hide: () => this.mode === 'gm'
        }
      },
      userDetailConfig: {
        label: {
          type: 'label',
          label: '客户资料'
        },
        split: { type: 'split' },
        close: {}
      },

      showUpdateMsg: false,
      updateMsgUserId: '',
    }
  },
  props: {
    auth: Array,
    nav: Object,
    mode: {
      type: String,
      default: 'ai'
    }
  },
  provide() {
    return {
      auth: this.auth
    }
  },
  components: {
    TopData,
    TableData,
    UserDetail,
    PopoverMessage,
    EditData,
    EditTag
  },
  methods:{
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/buy/order/list.sdcrm',
        data: {
          token: true,
          size: this.pageSize,
          from: this.pageNum,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
          keyword: this.screen.search ? this.screen.search : undefined,
          selected: typeof this.screen.selected === 'number' ? this.screen.selected : undefined,
          archivesStatus: typeof this.screen.archivesStatus === 'number' ? this.screen.archivesStatus : undefined,
          archivesServiceStatus: typeof this.screen.archivesServiceStatus === 'number' ? this.screen.archivesServiceStatus : undefined,
          expire: this.screen.useType === 0 ? 0 : (this.screen.useType === 4 ? 1 : undefined),
          buyStatus: this.screen.useType === 1 ? 3 : undefined,
          useType: this.screen.useType === 2 ? 1103 : (this.screen.useType === 3 ? 1104 : undefined),
          //TODO visible
          visible: this.mode === 'gm' ? 1 : void 0
        }
      })

      this.total = result.total
      // let now = Date.now()
      this.tableData = result.records

      this.loading = false
    }),
    fastScreen(data) {
      this.screen = { 
        ...this.screen, 
        ...data 
      }
      this.getTableData(true)
    },
    openUpload(row, type, upload) {
      this.rowData = row
      this.popoverType = type
      this.hasUpload = upload
      this.showPopover = true

      this.$log(5, 16, 1, this.$store.state.nav.id, undefined, row.id, `${type === 1 ? '营销' : '服务'}内容`)
    },
    //打开工单
    async openDrawer(userId) {
      this.selectUserId = userId
      await this.$nextTick()
      bus.$emit('openDrawer')
    },
    openEditTag(row, type) {
      this.rowData = row
      this.popoverType = type
      this.showEditTag = true
    },
     //同步消息记录
    updateMsg: throttle(async function(status) {
      if(!status) {
        this.showUpdateMsg = false
        return
      }

      if(!this.updateMsgUserId) {
        this.$message.error('请填写用户ID')
        return
      }

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/api/update_external_msg.sdcrm',
        data: {
          token: true,
          userId: Number(this.updateMsgUserId)
        }
      })

      if(code !== 8200) {
        this.$message.error(`提交失败：${errmsg || msg}`)
        return
      }

      this.$message.success('正在同步：请稍等...')

      this.updateMsgUserId = ''
      this.showUpdateMsg = false
    }),
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px 0;
  box-sizing: border-box;
  display: flex;
  flex-wrap: wrap;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
  .user-box {
    width: 350px;
    height: 100%;
    margin-left: 24px;
    background: #FFF;
    .el-icon-close { cursor: pointer; }
    /deep/ {
      .screen-box { padding: 24px;}
      .scroll-box { background: #F5F5F5;}
    }
  }
  .has-top {
    height: calc(100% - 96px);
    margin-top: 24px;
  }
  &.has-user {
    .box { width: calc(100% - 374px);}
  }
}
</style>