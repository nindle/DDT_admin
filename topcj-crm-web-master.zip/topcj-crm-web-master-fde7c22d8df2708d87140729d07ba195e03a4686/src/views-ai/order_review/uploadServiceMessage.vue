<template>
  <div class="upload-box">

    <el-button
      class="top"
      type="primary" 
      plain
      size="small"
      icon="el-icon-download"
      v-open="`${SYS.URL}/xlsx/message_template.xls`"
      v-if="showDownload"
    >下载模板</el-button>

    <el-date-picker
      class="time"
      v-model="time"
      type="datetime"
      placeholder="选择消息时间"
      format="yyyy-MM-dd HH:mm:ss"
      value-format="timestamp"
      size="small"
    ></el-date-picker>

    <el-upload
      action=""
      accept=".xls,image/*"
      multiple
      drag
      :show-file-list="false"
      :file-list="fileList"
      :on-change="(e, fileList) => fileChange(fileList, 'image')"
      :auto-upload="false"
    >
      <i class="el-icon-upload"></i>
      <div class="el-upload__text">
        将文件拖到此处，或
        <em>点击上传</em>
      </div>
    </el-upload>
        <el-upload
      class="qy-app-image-upload"
      action=""
      accept="image/*"
      multiple
      drag
      :show-file-list="false"
      :file-list="fileList"
      :on-change="(e, fileList) => fileChange(fileList, 'qy_app_image')"
      :auto-upload="false"
    >
      <div class="el-upload__text">
        工作台图片请在此处上传
        <em>点击上传</em>

        <el-switch
          :width="30"
          value="qy_app_image"
          inactive-value="image"
          active-value="qy_app_image"
          inactive-text="其他图片"
          active-text="工作台图片"
        ></el-switch>
      </div>
    </el-upload>

    <el-scrollbar-pro class="file-list-scroll">
      <ul class="file-list">
        <li
          v-for="(e, i) in fileList"
          :key="e.uid"
        >
          <i class="el-icon-document"></i>
          <div class="file-name">{{e.raw.name}}</div>
          <el-switch
            v-if="e.type !== 'xls'"
            :width="30"
            v-model="e.type"
            inactive-value="image"
            active-value="qy_app_image"
          ></el-switch>
          <i 
            class="el-icon-close"
            @click="deleteFile(i)"
          ></i>
        </li>
      </ul>
    </el-scrollbar-pro>

    <div class="button">
      <el-button
        type="primary" 
        size="small"
        :loading="loading"
        @click="submit"
      >导 入</el-button>

      <el-button
        size="small"
        @click="close"
      >取 消</el-button>
    </div>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      time: null,
      fileList: [],
      loading: false
    }
  },
  props:{
    userId: Number
  },
  //在mode=ai下此处报错tag not found为正常现象
  inject: ['tag'],
  computed: {
    showDownload() {
      if(this.tag) {
        return this.tag.v165.visible
      }

      return true
    }
  },
  methods:{
    //上传文件
    fileChange(fileList, type) {
      this.fileList = fileList.map(e => {
        return {
          ...e,
          type: e.type || (e.name.indexOf('.xls') > -1 ? 'xls' : type)
        }
      })
    },
    //删除文件
    deleteFile(index) {
      this.fileList.splice(index, 1)
    },
    //上传消息
    submit: throttle(async function() {
      if(!this.fileList.length) {
        this.$message.error('请上传文件')
        return
      }
      if(!this.time) {
        this.$message.error('请选择消息时间')
        return
      }
      if(this.time > Date.now()) {
        this.$message.error('禁止穿越（请选择过去的时间）')
        return
      }

      this.loading = true

      let allData = []

      for(let i in this.fileList) {
        let e = this.fileList[i]
        if(e.type === 'xls') {
          //excel文件
          allData.push({
            mode: 'form',
            url: '%CRM%/user/message/upload_exfile.sdcrm',
            data: {
              token: true,
              uploadFile: e.raw,
              userId: this.userId,
              ctimeStamp: this.time,
              isSave: 1
            }
          })
        }else{
          //图片文件
          let { result } = await this.$http({
            mode: 'form',
            url: '%CRM%/info/upload_file.sdcrm',
            data: {
              token: true,
              uploadFile: e.raw
            }
          })

          allData.push({
            url: '%CRM%/user/message/insert_record.sdcrm',
            data: {
              token: true,
              type: 0,
              userId: this.userId,
              msgType: e.type,
              imgUrl: result.url,
              ctimeStamp: this.time + Number(i) * 1000,
              isSave: 1
            }
          })
        }
      }



      let data = await this.$http({
        mode: 'relay',
        all: allData
      })

      this.loading = false

      if(data.length === 1) {
        if(data[0].code === 8200) {
          this.$message.success('导入成功')
        }else{
          this.$message.error(`导入失败：${data[0].errmsg || data[0].msg}`)
        }
      }else{
        let successCount = data.filter(e => e.code === 8200).length
        let fileCount = data.length - successCount

        this.$message.success(`导入成功${successCount}个文件，导入失败${fileCount}个文件`)
      }

      this.$emit('update')
      this.close()
    }),
    //关闭
    close() {
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.upload-box {
  width: 320px;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  /deep/ {
    .el-upload-list,
    .el-upload-dragger {
      width: 280px;
    }
    .el-upload-list {
      height: 300px;
      overflow-y: auto;
      &::-webkit-scrollbar{
        width: 6px;
        height: 6px;
      }
      &::-webkit-scrollbar-thumb{
        border-radius: 4px;
        background: rgba(144, 147, 153, 0.3);
      }
      &::-webkit-scrollbar-track{
        opacity: 0;
      }
    }
    .qy-app-image-upload {
      .el-upload-dragger {
        height: 80px;
        .el-upload__text { margin-top: 14px;}
        .el-switch { margin-top: 12px;}
      }
    }
  }
  .file-list-scroll {
    width: 100%;
    height: 300px;
  }
  .file-list {
    margin: 0 auto;
    width: 280px;
    li {
      display: flex;
      align-items: center;
      padding: 4px 0;
      .el-icon-document { margin-right: 6px;}
      .file-name {
        width: 196px;
        margin-right: auto;
        @include ellipsis;
      }
      .el-icon-close {
        cursor: pointer;
        opacity: 0;
        transition: .3s;
      }
      &:hover {
        .el-icon-close { opacity: 1;}
      }
    }
  }
  .time {
    margin: 60px 0 24px;
  }
  .top {
    margin: 60px 0 0;
  }
  .button {
    margin: auto auto 20px;
  }
}
</style>