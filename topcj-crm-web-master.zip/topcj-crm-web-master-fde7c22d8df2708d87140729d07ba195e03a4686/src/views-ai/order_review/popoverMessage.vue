<template>
  <el-dialog-pro 
    @close="close" 
    max-height
    top="24px"
  >
    <!-- 标题 -->
    <template #title>
      {{title}}
    </template>

    <!-- 聊天信息 -->
    <message :data="messageList" />

    <!-- 底部按钮 -->
    <template #footer>
      <el-button 
        type="primary" 
        size="small"
        @click="showRight = 'voice'"
        v-if="type === 1 && [0,3,4].includes(data.archivesStatus)"
      >录音</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="showRight = 'uploadVoice'"
        v-if="auth.includes('editfilter') && mode === 'ai'"
      >上传语音</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="showRight = 'upload'"
        v-if="upload"
      >上传{{title}}</el-button>
    </template>

    <template 
      #right
      v-if="showRight"
    >
      <upload-marketing-message 
        @close="showRight = ''"
        @update="getMessage"
        :sn="data.sn"
        :order="data"
        v-if="type === 1 && showRight === 'upload'"
      />
      <upload-service-message 
        @close="showRight = ''"
        @update="data.archivesServiceStatus = 1; getMessage()"
        :user-id="data.userId"
        v-if="type === 2 && showRight === 'upload'"
      />
      <upload-voice
        @close="showRight = ''"
        @update="getMessage"
        :sn="data.sn"
        :order="data"
        :user-id="data.userId"
        :type="type"
        v-if="auth.includes('editfilter') && showRight === 'uploadVoice'"
      />
      <add-voice
        @close="showRight = ''"
        :user-id="data.userId"
        v-if="showRight === 'voice'"
      />
    </template>
  </el-dialog-pro>
</template>
<script>
import Message from '../../components/message'
import UploadMarketingMessage from './uploadMarketingMessage'
import UploadServiceMessage from './uploadServiceMessage'
import UploadVoice from './uploadVoice'
import AddVoice from './addVoice'

export default {
  data() {
    return {
      //消息列表
      messageList: [],
      //展示
      showRight: ''
    }
  },
  computed: {
    title() {
      return this.type === 1 ? '营销记录' : '服务记录'
    }
  },
  inject: ['auth'],
  props:{
    show: Boolean,
    data: Object,
    upload: Boolean,
    type: Number,
    mode: String
  },
  components: {
    Message,
    UploadMarketingMessage,
    UploadServiceMessage,
    UploadVoice,
    AddVoice
  },
  methods:{
    //获取消息记录
    getMessage() {
      if(this.type === 1) {
        this.getMessageType1()
      }else{
        this.getMessageType2()
      }
    },
    //获取营销记录
    async getMessageType1() {
      let data = await this.$http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/user/message/order/:userId/:orderId.sdcrm',
            mode: 'get',
            data: {
              token: true,
              userId: this.data.userId,
              orderId: this.data.id
            }
          },
          {
            url: '%CRM%/user/message/call/:userId/:orderId.sdcrm',
            mode: 'get',
            data: {
              token: true,
              userId: this.data.userId,
              orderId: this.data.id
            }
          }
        ]
      })

      this.messageList = [
        ...(data[0].result.map(e => {
          if(this.$store.state.sysMode === 2 && this.mode !== 'ai') {
            //合规模式
            e.managerTitle = '智能投顾+客服'
            e.managerName = ''
          }else{
            e.managerTitle = '业务'
          }
          return e
        }) || []), 
        ...(data[1].result.map(e => {
          if(this.$store.state.sysMode === 2 && this.mode !== 'ai') {
            //合规模式
            e.managerTitle = '合规电话'
            e.managerName = ''
          }else{
            e.managerTitle = '合规电话'
          }
          return e
        }) || [])
      ]
    },
    //获取服务记录
    async getMessageType2() {
      let { result } = await this.$http({
        url: '%CRM%/user/message/service.sdcrm',
        data: {
          token: true,
          userId: this.data.userId,
          selected: null
        }
      })

      this.messageList = result.map(e => {
        if(this.$store.state.sysMode === 2 && this.mode !== 'ai') {
          //合规模式
          e.managerTitle = 'VIP投顾+客服'
          e.managerName = ''
        }else{
          e.managerTitle = '售后'
        }
        return e
      })
    },
    close(){
      this.$emit('update:show', false)
    }
  },
  created() {
    this.getMessage()
  }
}
</script>