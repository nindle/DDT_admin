<template>
  <div class="add-voice-main">
    <el-table-pro
      :head="headVoice"
      :data="dataVoice"
    >
      <template #body-url="{ row }">
        <div class="beginTime">{{ row.beginTime | timeFormat }}（来源：{{row.callType | callTypeFilter }}）</div>
        <msg-audio :audio="row.url" />
      </template>
    </el-table-pro>

    <el-button
      class="close"
      size="small" 
      @click="$emit('close')"
    >关 闭</el-button>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import MsgAudio from '../../components/message/msg-audio'

export default {
  data() {
    return {
      headVoice: [
        {
          key: 'url',
          label: '录音',
          minWidth: 228,
        }
      ],
      dataVoice: []
    }
  },
  props: {
    userId: Number
  },
  components: {
    MsgAudio
  },
  methods:{
    getVoiceData: throttle(async function() {
      let { result } = await this.$http({
        url: '%CRM%/user/message/get_tmp_call_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
          userId: this.userId
        }
      })

      this.dataVoice = result || []
    })
  },
  filters: {
    callTypeFilter(type) {
      switch(type) {
        case 0: return 'SCRM'
        case 1: return 'VAA'
        case 2: return 'SFTP'
        case 9: return 'APP'
        case 11: return 'SYNC'
        default: return '其他'
      }
    }
  },
  created() {
    this.getVoiceData()
  }
}
</script>

<style lang="scss" scoped>
.add-voice-main {
  position: relative;
  width: 100%;
  height: 100%;
  /* padding: 0 20px; */
  .beginTime {
    font-size: 12px;
  }
  .msg-audio {
    width: 220px;
    /deep/ {
      .el-slider {
        width: 100px;
      }
    }
  }
  .close {
    position: absolute;
    right: 24px;
    top: 10px;
  }
}
.el-table {
  /deep/ {
    th, td {
      padding: 14px 0 15px !important;
    }
  }
}
</style>