<template>
  <el-table-pro
    :data="data"
    :head="head"
    @selection-change="$emit('update:select-list', $event)"
  >

    <template #body-realname="{ row }">
      <scratch
        :data="row.realname"
        mode="name"
        :log="row.userId"
        no-data="未实名"
      />
    </template>

    <template #body-phone="{ row }">
      <callphone
        :user-id="row.userId"
        @call="$emit('open-drawer', $event)"
      />
    </template>

    <template #body-selected="{ row, content }">
      <template v-if="row.selected">
        {{content}}
      </template>
      <template v-else-if="auth.includes('filter')">
        <el-button
          type="primary"
          plain
          size="mini"
          @click="mode === 'gm' ? $emit('open-tag', row, 1) : reviewOrder(row, 1)"
        >通过</el-button>
        <el-button
          type="info"
          plain
          size="mini"
          @click="reviewOrder(row, 2)"
        >不通过</el-button>
      </template>
      <template v-else>{{content}}</template>
    </template>

    <template #body-archivesStatus="{ row, content }">
      <el-popover
        :disabled="![3, 4].includes(row.archivesStatus)"
        placement="top-start"
        trigger="hover"
      >
        <i class="el-icon-warning" style="color: #F56C6C; margin-right: 8px"></i>{{row.reviewRemark}}
        <span 
          slot="reference"
          :class="{ c: [3, 4].includes(row.archivesStatus)}"
        >{{content}}</span>
      </el-popover>

      <el-button
        v-if="[0, 3, 4].includes(row.archivesStatus) && auth.includes('upload')"
        type="text"
        size="mini"
        icon="el-icon-upload"
        @click="$emit('upload', row, 1, true)"
      >上传</el-button>

      <el-button
        v-else
        type="text"
        size="mini"
        icon="el-icon-view"
        @click="$emit('upload', row, 1)"
      >查看</el-button>
    </template>

    <template #body-archivesServiceStatus="{ row, content }">
      <el-popover
        :disabled="row.archivesServiceStatus !== 3"
        placement="top-start"
        trigger="hover"
      >
        <i class="el-icon-warning" style="color: #F56C6C; margin-right: 8px"></i>{{row.archivesServiceReason}}
        <span 
          slot="reference"
          :class="{ c: row.archivesServiceStatus === 3}"
        >{{content}}</span>
      </el-popover>

      <el-button
        v-if="auth.includes('upload')"
        type="text"
        size="mini"
        icon="el-icon-upload"
        @click="$emit('upload', row, 2, true)"
      >上传</el-button>

      <el-button
        v-else
        type="text"
        size="mini"
        icon="el-icon-view"
        @click="$emit('upload', row, 2)"
      >查看</el-button>
    </template>
  </el-table-pro>
</template>

<script>
import { md5 } from '../../assets/js/crypto'
import { throttle } from '../../assets/js/tool'

import Scratch from '../../components/other/scratch'
import Callphone from '../../components/other/callphone'

export default {
  data() {
    return {
      head: [
        {
          hide: () => !this.auth.includes('editfilter'),
          key: 'selection',
          type: 'selection',
          width: 14,
          excel: false
        },
        {
          key: 'sn',
          label: '订单号',
          minWidth: 150,
          copy: true,
          excel: `'{sn}`
        },
        {
          key: 'userId',
          label: '成交ID',
          minWidth: 70,
          click: row => { this.$emit('select', row.userId) }
        },
        {
          key: 'phone',
          label: '',
          width: 30,
          excel: false
        },
        {
          key: 'realname',
          label: '实名',
          minWidth: 90
        },
        {
          key: 'ctime',
          label: '成交时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'expTime',
          label: '到期时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'packageName',
          label: '购买套餐',
          minWidth: 200,
          tooltip: true
        },
        {
          key: 'money',
          label: '金额',
          minWidth: 50
        },
        {
          key: 'expTime,buyStatus,useType',
          label: '用户状态',
          minWidth: 56,
          format(expTime, buyStatus, useType) {
            if(useType === 1104) return '外诉用户'
            if(useType === 1103) return '内诉用户'
            if(buyStatus === 3) return '退费用户'
            if(new Date(expTime).getTime() > Date.now()) return '服务期内'
            return '过期用户'
          }
        },
        {
          key: 'selected',
          label: '过滤状态',
          minWidth: this.auth.includes('filter') ? 136 : 70,
          format: {
            '0': '待过滤',
            '1': '过滤通过',
            '2': '过滤不通过',
          }
        },
        {
          key: 'agreement',
          label: '协议',
          minWidth: 28,
          format: '合同',
          click: this.openAgreement,
          excel: false
        },
        {
          key: 'riskAuth',
          label: '风测',
          minWidth: 42,
          format: e => {
            if(!e) return '未风测'
            if(this.mode === 'ai') {
              return `${e}分`
            }

            if(e >= 18 && e <= 39) return 'C1'
            else if(e >= 40 && e <= 51) return 'C2'
            else if(e >= 52 && e <= 72) return 'C3'
            else if(e >= 73 && e <= 86) return 'C4'
            else if(e >= 87 && e <= 100) return 'C5'
          }
        },
        {
          key: 'archivesStatus',
          label: '营销审核状态',
          width: 102,
          format: {
            '0': '待上传',
            '1': '审核中',
            '2': '已通过',
            '3': '待补充',
            '4': '待补充',
          }
        },
        {
          key: 'archivesServiceStatus',
          label: '服务审核状态',
          width: 102,
          format: {
            '0': '待上传',
            '1': '审核中',
            '2': '已通过',
            '3': '待补充',
            '4': '待补充',
          }
        },
        {
          key: 'serviceLastPassTime',
          label: '服务内容最后审核时间',
          width: 140,
          format: e => e ? new Date(e).timeFormat() : '--'
        },
        // {
        //   hide: () => !this.auth.includes('filter'),
        //   key: 'serviceAiTime',
        //   label: '最后提交数据库',
        //   width: 140,
        //   format: e => e ? new Date(e).timeFormat() : '--'
        // },
        {
          hide: true,//() => !this.auth.includes('filter'),
          key: 'aireview',
          label: '提交数据库',
          minWidth: 92,
          format: '提交数据库',
          button: {
            type: 'warning',
            size: 'mini',
            click: this.aiReview
          }
        },
      ]
    }
  },
  inject: ['auth'],
  props: {
    data: Array,
    selectList: Array,
    mode: String
  },
  components: {
    Scratch,
    Callphone
  },
  methods: {
    openAgreement({ sn, id }) {
      let time = Date.now()
      let token = this.$store.state.token
      let mosaic = this.$store.state.sysMode === 2 ? '1' : ''
      let sign = md5(`7685ab5265c568c41024cca4b396efa1${token}${sn}${time}${mosaic}`)
      
      let url = `${this.SYS.WEBURL}/ns/#/agreement/12?gm=${token}&sn=${sn}&time=${time}&sign=${sign}${mosaic ? `&mosaic=${mosaic}` : ''}&size=16`

      this.$open(url)
      this.$log(5, 16, 1, this.$store.state.nav.id, undefined, id, '合同')
    },
    //过滤
    reviewOrder: throttle(async function(row, type, serverId) {
      if(type === 1) {
        let { code, msg } = await this.$http({
          url: '%CRM%/buy/order/order_compliance_check.sdcrm',
          data: {
            token: true,
            orderId: row.id
          }
        })

        if(code === 9101203) {
          this.$alert(msg, '', {
            showClose: false,
            confirmButtonText: '确定'
          })
          return
        }
      }

      // let { code, msg } = await this.$http({
      //   url: `%CRM%/buy/order/selected/:id/:type.sdcrm`,
      //   mode: 'get',
      //   data: {
      //     token: true,
      //     id: row.id,
      //     type
      //   }
      // })
      let { code, msg } = await this.$http({
        url: `%CRM%/buy/order/pass.sdcrm`,
        data: {
          token: true,
          orderId: row.id,
          selected: type,
          serviceId: serverId || null
        }
      })

      if(code !== 8200) {
        this.$message.error(`处理失败：${msg}`)
        return
      }

      this.$message.success('处理成功')

      await this.$http({
        url: '%CRM%/buy/order/ai_review.sdcrm',
        data: {
          token: true,
          id: row.id
        }
      })

      this.$emit('change')
    }),
    //AI审核
    aiReview: throttle(async function(row) {
      let time = new Date(row.serviceAiTime).getTime()
      let now = Date.now()
      if(now - time <= 20 * 24 * 3600 * 1000) {
        let type = await this.$confirm(`上次提交时间在20天内，请确认是否再次提交`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).catch(() => null)

        if(!type) return
      }

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/user/ai_service_review.sdcrm',
        data: {
          token: true,
          userId: row.userId,
          action: 1
        }
      })

      // await this.$http({
      //   url: '%CRM%/user/service_review.sdcrm',
      //   data: {
      //     token: true,
      //     userId: row.userId,
      //     action: 3
      //   }
      // })

      if(code !== 8200) {
        this.$message.error(`提交失败：${errmsg || msg}`)
        return
      }

      this.$message.success('提交成功')

      this.$emit('change')
    })
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.el-button--mini {
  padding: 7px 0px;
  width: 60px;
}
.c { color: $--color-main;}
</style>
