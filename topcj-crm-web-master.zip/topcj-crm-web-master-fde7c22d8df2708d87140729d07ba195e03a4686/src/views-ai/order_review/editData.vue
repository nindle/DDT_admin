<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      修改过滤状态（{{index + 1}} / {{list.length}}）
      <span class="tip">{{data.sn}}</span>
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >修 改</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      index: 0,
      form: {
        selected: '',
        visit: '',
        risk: '',
        userType: '',
        serverId: ''
      },
      config: {
        selected: {
          type: 'select',
          label: '过滤状态',
          options: [
            { value: 0, label: '待过滤' },
            { value: 1, label: '过滤通过' },
            { value: 2, label: '过滤未通过' }
          ],
          rule: [
            { required: true }
          ]
        },
        visit: {
          type: 'select',
          label: '访问情况',
          options: this.tag?.t14.filter(e => e.visible) ?? [],
          labelKey: 'valueName',
          valueKey: 'id',
          hide: () => this.mode !== 'gm'
        },
        risk: {
          type: 'select',
          label: '风险类型',
          options: this.tag?.t15.filter(e => e.visible) ?? [],
          labelKey: 'valueName',
          valueKey: 'id',
          hide: () => this.mode !== 'gm'
        },
        userType: {
          type: 'select',
          label: '用户类型',
          options: this.tag?.t8.filter(e => e.visible) ?? [],
          labelKey: 'valueName',
          valueKey: 'id',
          hide: () => this.mode !== 'gm'
        },
        serverId: {
          type: 'select',
          label: '分配售后',
          options: [],
          labelKey: 'realName',
          valueKey: 'id',
          rule: [
            { required: true }
          ]
        }
      },
      loading: false
    }
  },
  computed: {
    data() {
      return this.list[this.index]
    }
  },
  props: {
    show: Boolean,
    list: Array,
    mode: String
  },
  //在mode=ai下此处报错tag not found为正常现象
  inject: ['tag'],
  methods: {
    //初始化数据
    async initData() {
      let data = await this.$http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.id,
              labelId: 14,
            }
          },
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.id,
              labelId: 15,
            }
          },
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.userId,
              labelId: 8,
            }
          }
        ]
      })

      this.form.visit = data[0].result?.id
      this.form.risk = data[1].result?.id
      this.form.userType = data[2].result?.id

      if(this.data.corpId === 19) {
        this.config.serverId.options.splice(0, this.config.serverId.options.length, ...this.$store.state.baseData.managerList.filter(e => e.corpId === 19 && e.managerType === 1 && e.isLock === 0))
      }else{
        let { result } = await this.$http({
          url: '%CRM%/manager/get_default_managers.sdcrm',
          data: {
            token: true,
            corpId: this.data.corpId,
            attachType: 1
          }
        })
        this.config.serverId.options.splice(0, this.config.serverId.options.length, ...result.map(e => {
          e.id = e.managerId
          return e
        }))
      }

      if(this.data.serviceManagerId) {
        this.form.serverId = this.data.serviceManagerId
      }else{
        this.form.serverId = ''
      }
    },
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let allData = [
        {
          url: `%CRM%/buy/order/pass.sdcrm`,
          data: {
            token: true,
            orderId: this.data.id,
            selected: this.form.selected,
            serviceId: this.form.serverId || null
          }
        },
        {
          url: `%CRM%/label/set_label.sdcrm`,
          data: {
            token: true,
            targetId: this.data.id,
            labelId: 14,
            valueId: this.form.visit || undefined
          }
        },
        {
          url: `%CRM%/label/set_label.sdcrm`,
          data: {
            token: true,
            targetId: this.data.id,
            labelId: 15,
            valueId: this.form.risk || undefined
          }
        },
        {
          url: `%CRM%/label/set_label.sdcrm`,
          data: {
            token: true,
            targetId: this.data.userId,
            labelId: 8,
            valueId: this.form.userType || undefined
          }
        }
      ]

      let data = await this.$http({
        mode: 'relay',
        all: allData
      })

      if(data.filter(e => e.code === 8200).length !== data.length) {
        this.$message.error('保存失败')
        return
      } 

      this.loading = false

      if(this.index < this.list.length - 1) {
        this.index ++
        this.initData()
      }else{
        this.index ++
        this.close()
      }
    }),
    close() {
      if(this.index) {
        this.$emit('change')
      }
      this.$emit('update:show', false)
    }
  },
  created() {
    this.initData()
  }
}
</script>
<style scoped lang="scss">
.tip {
  font-size: 12px;
  color: #999;
  margin-left: 6px;
}
</style>