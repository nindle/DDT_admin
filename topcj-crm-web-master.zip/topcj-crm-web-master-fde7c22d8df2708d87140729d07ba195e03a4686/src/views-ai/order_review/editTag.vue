<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      请给该订单打上相应属性的标签
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >确认{{type === 1 ? '通过' : '不通过'}}</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        visit: '',
        risk: '',
        userType: '',
        serverId: ''
      },
      config: {
        visit: {
          type: 'select',
          label: '访问情况',
          options: this.tag.t14.filter(e => e.visible),
          labelKey: 'valueName',
          valueKey: 'id'
        },
        risk: {
          type: 'select',
          label: '风险类型',
          options: this.tag.t15.filter(e => e.visible),
          labelKey: 'valueName',
          valueKey: 'id'
        },
        userType: {
          type: 'select',
          label: '用户类型',
          options: this.tag.t8.filter(e => e.visible),
          labelKey: 'valueName',
          valueKey: 'id'
        },
        serverId: {
          type: 'select',
          label: '分配售后',
          options: [],
          labelKey: 'realName',
          valueKey: 'id',
          rule: [
            { required: true }
          ]
        }
      },
      loading: false
    }
  },
  props: {
    show: Boolean,
    data: Object,
    type: Number
  },
  inject: ['tag'],
  methods: {
    //初始化数据
    async initData() {
      let data = await this.$http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.id,
              labelId: 14,
            }
          },
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.id,
              labelId: 15,
            }
          },
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.userId,
              labelId: 8,
            }
          }
        ]
      })

      this.form.visit = data[0].result?.id
      this.form.risk = data[1].result?.id
      this.form.userType = data[2].result?.id

      if(this.data.corpId === 19) {
        this.config.serverId.options.push(...this.$store.state.baseData.managerList.filter(e => e.corpId === 19 && e.managerType === 1 && e.isLock === 0))
      }else{
        let { result } = await this.$http({
          url: '%CRM%/manager/get_default_managers.sdcrm',
          data: {
            token: true,
            corpId: this.data.corpId,
            attachType: 1
          }
        })
        this.config.serverId.options.push(...result.map(e => {
          e.id = e.managerId
          return e
        }))
      }

      if(this.data.serviceManagerId) {
        this.form.serverId = this.data.serviceManagerId
      }
    },
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return
      
      this.loading = true

      let allData = [
        {
          url: `%CRM%/label/set_label.sdcrm`,
          data: {
            token: true,
            targetId: this.data.id,
            labelId: 14,
            valueId: this.form.visit || undefined
          }
        },
        {
          url: `%CRM%/label/set_label.sdcrm`,
          data: {
            token: true,
            targetId: this.data.id,
            labelId: 15,
            valueId: this.form.risk || undefined
          }
        },
        {
          url: `%CRM%/label/set_label.sdcrm`,
          data: {
            token: true,
            targetId: this.data.userId,
            labelId: 8,
            valueId: this.form.userType || undefined
          }
        }
      ]

      let data = await this.$http({
        mode: 'relay',
        all: allData
      })

      if(data.filter(e => e.code === 8200).length !== data.length) {
        this.$message.error('保存失败')
        return
      } 

      this.loading = false

      this.$emit('change')
      this.$emit('review', this.form.serverId)
      
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  },
  created() {
    this.initData()
  }
}
</script>
