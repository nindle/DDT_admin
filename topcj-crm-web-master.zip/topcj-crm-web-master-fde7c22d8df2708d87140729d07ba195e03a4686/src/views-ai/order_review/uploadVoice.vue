<template>
  <div class="upload-box">
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <div class="button">
      <el-button
        type="primary" 
        size="small"
        :loading="loading"
        @click="submit"
      >导 入</el-button>

      <el-button
        size="small"
        @click="close"
      >取 消</el-button>
    </div>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      loading: false,
      form: {
        type: '',
        time: '',
        fileList: []
      },
      config: {
        type: {
          label: '语音类型',
          type: 'select',
          options: this.type === 1 ? [
            { value: 1, label: '业务' },
            { value: 3, label: '合规' },
          ] : [
            { value: 2, label: '售后' },
          ],
          rule: [
            { required: true }
          ]
        },
        time: {
          label: '语音时间',
          type: 'date-time',
          rule: [
            { required: true }
          ]
        },
        fileList: {
          label: '上传语音',
          accept: 'audio/*',
          type: 'file-list',
          rule: [
            { required: true, type: 'array' }
          ]
        }
      }
    }
  },
  props:{
    sn: String,
    order: Object,
    userId: Number,
    type: Number
  },
  methods:{
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let allData = this.form.fileList.map(e => {
        if(this.form.type === 1) {
          return {
            url: '%CRM%/user/message/insert_record.sdcrm',
            data: {
              token: true,
              type: 0,
              sn: this.sn,
              msgType: 'track',
              imgUrl: e.url,
              ctimeStamp: this.form.time
            }
          }
        }
        if(this.form.type === 2) {
          return {
            url: '%CRM%/user/message/insert_record.sdcrm',
            data: {
              token: true,
              type: 0,
              userId: this.userId,
              msgType: 'track',
              imgUrl: e.url,
              ctimeStamp: this.form.time
            }
          }
        }
        if(this.form.type === 3) {
          return {
            url: '%CRM%/user/message/insert_record.sdcrm',
            data: {
              token: true,
              type: 0,
              sn: this.sn,
              msgType: 'track',
              imgUrl: e.url,
              ctimeStamp: this.form.time,
              managerType: 4
            }
          }
        }
      })


      let data = await this.$http({
        mode: 'relay',
        all: allData
      })

      this.loading = false

      if(data.length === 1) {
        if(data[0].code === 8200) {
          this.$message.success('导入成功')
        }else{
          this.$message.error(`导入失败：${data[0].errmsg || data[0].msg}`)
        }
      }else{
        let successCount = data.filter(e => e.code === 8200).length
        let fileCount = data.length - successCount

        this.$message.success(`导入成功${successCount}个语音，导入失败${fileCount}个语音`)
      }


      this.$emit('update')
      this.close()
    }),
    //关闭
    close() {
      this.$emit('close')
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.upload-box {
  width: 420px;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  .button {
    margin: auto auto 20px;
  }
  .el-form {
    margin-top: 53px;
  }
}
</style>