<template>
  <div class="top-data">
    <i class="el-icon-pie-chart"></i>
    总订单数<span :class="{ 'el-icon-loading': loading }" @click="$emit('screen', {...screen})">{{data.allCount}}</span>条；
    待过滤数有<span :class="{ 'el-icon-loading': loading }" @click="$emit('screen', { ...screen, selected: 0 })">{{data.waitFilter}}</span>条；
    待补充营销档案的有<span :class="{ 'el-icon-loading': loading }" @click="$emit('screen', { ...screen, archivesStatus: 4 })">{{data.waitInBuild}}</span>条；
  </div>
</template>
<script>

export default {
  data() {
    return {
      loading: false,
      data: {},
      screen: {
        time: [],
        selected: '',
        archivesStatus: '',
        archivesServiceStatus: '',
        useType: '',
        search: ''
      }
    }
  },
  components: {
    
  },
  methods:{
    async getData() {
      this.loading = true

      let { result } = await this.$http({
        url: '%CRM%/buy/order/get_archiving_count.sdcrm',
        data: {
          token: true,
          corpId: this.$store.state.managerInfo.corpId || undefined
        }
      })

      this.loading = false

      result.allCount = result.allCount ?? 0
      result.waitFilter = result.waitFilter ?? 0
      result.waitInBuild = result.waitInBuild ?? 0

      this.data = result
    }
  },
  created() {
    this.getData()
  }
}
</script>
<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.top-data {
  width: 100%;
  height: 72px;
  background: #FFF;
  color: #333;
  line-height: 72px;
  padding: 0 24px;
  box-sizing: border-box;
  span { 
    color: $--color-main;
    margin: 0 5px;
    font-weight: bold;
    cursor: pointer;
    &:hover { border-bottom: 1px solid $--color-main;}
  }
  .el-icon-pie-chart {
    font-size: 24px;
    color: $--color-main;
    margin-right: 16px;
    vertical-align: sub;
  }
}
</style>