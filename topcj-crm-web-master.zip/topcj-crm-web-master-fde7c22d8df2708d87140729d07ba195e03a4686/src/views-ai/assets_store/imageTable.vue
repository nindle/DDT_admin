<template>
  <el-row>
    <el-card 
      :body-style="{ padding: '0px' }" 
      v-for="(e,i) in data" 
      :key="i"
      @mouseover.native="mouseOver"
      @mouseleave.native="mouseLeave"
    >
      <div class="count">
          <img 
          :src="e.picUrl" 
          class="image"
        >
        <div>
          <div class="bottom">
            <span>{{e.sourceTitle}}</span>
          </div>
        </div>
      </div>
      <div 
        :class="`${show ? 'isshow active' : 'isshow'}`" 
        ref="show" 
      >
        <el-button 
          icon="el-icon-zoom-in" 
          circle
          v-imageview="e.picUrl"
        ></el-button>
        <el-button 
          icon="el-icon-edit" 
          @click="$emit('edit',e)"
          circle
        ></el-button>
        <el-popconfirm
          title="这是一段内容确定删除吗？"
          @confirm="$emit('delete', e)"
        >
          <el-button 
            icon="el-icon-delete" 
            slot="reference"
            circle
          ></el-button>
        </el-popconfirm>
      </div>
    </el-card>
  </el-row>
</template>
<script>
export default {
  data() {
    return {
      show: false,
      id: this.$store.state.managerInfo.id
    }
  },
  props: {
    data: Array
  },
  methods: {
    mouseOver() {
      this.show = true
    },
    mouseLeave() {
      this.show = false
    }
  }
}
</script>
<style lang="scss" scoped>
.el-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  /deep/ {
    .el-card {
      width: 160px;
      margin-right: 20px;
      margin-top: 24px;
      height: 200px;
      overflow: hidden;
      position: relative;
      &:hover .isshow {
        z-index:1;
        cursor: no-drop ;
      }
      .image {
        height: 160px;
        width: 100%;
        object-fit: cover;
      }
      .bottom {
        padding: 8px 5px;
        span {
          width: 150px;
          display: inline-block;
          font-size: 13px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: pre;
        }
      }
      .isshow {
        width: 160px;
        height: 200px;
        display: flex;
        padding: 10px 28px 0;
        background-image: linear-gradient(rgba(0,0,0,.35),rgba(0,0,0,0)) ;
        position: absolute;
        top: 0;
        left: 0;
        z-index: -1;
        .el-button {
          width: 28px;
          height: 28px;
          padding: 0;
        }
        span {
          display: inline-block;
          margin-left: 10px;
        }
      }
    }
  }
  
}
</style>