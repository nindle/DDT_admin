<template>
  <div class="view">
    <div class="top">
      <el-tabs v-model="activeName">
        <el-tab-pane 
          v-for="e in tabList.filter(e => e.show)"
          :key="e.name"
          :name="e.name"
        >
          <span slot="label" :class="e.icon">{{e.label}}</span>
        </el-tab-pane>
      </el-tabs>
      <el-input 
        placeholder="搜索" 
        prefix-icon="el-icon-search" 
        class="search" 
        size="small" 
        v-model="search"
      />
    </div>
    <!-- 文字 -->
    <template v-if="activeName === 'text'">
      <text-data
        :show.sync="popoverShow"
        :searchData="search"
        @textAdd="openTextPopover"
      />
      <popover-text
        v-if="popoverShow"
        :show.sync="popoverShow"
        :data="popoverData"
      />
    </template>
    
    <!-- 图文 -->
    <template v-if="activeName === 'mpnews'">
      <mpnews-data
        :show.sync="mpnewsPoShow"
        :searchData="search"
        @mpnewsEdit="openMpnewsPopover"
      />
      <popover-mpnews
        v-if="mpnewsPoShow"
        :show.sync="mpnewsPoShow"
        :data="mpnewsPoData"
      />
    </template>

    <!-- 外链 -->
    <template v-if="activeName === 'news'">
      <news-data
        :show.sync="newsPoShow"
        :searchData="search"
        @newsEdit="openNewsPopover"
      />
      <popover-news
        v-if="newsPoShow"
        :show.sync="newsPoShow"
        :data="newsPoData"
      />
    </template>

    <!-- 图片 -->
    <template v-if="activeName === 'image'">
      <image-data
        :show.sync="imagePhotoShow"
        :showEdit.sync="imageEditShow"
        :searchData="search"
        :activeName="activeName"
        @imageEdit="openImagePopover"
      />
      <popover-image
        v-if="imagePhotoShow"
        :show.sync="imagePhotoShow"
      />
      <popover-image-edit
        v-if="imageEditShow"
        :show.sync="imageEditShow"
        :data="imageEditData"
      />
    </template>

    <!-- 话术库 -->
    <template v-if="activeName === 'message'">
      <message-data
        :show.sync="messagePopoverShow"
        :searchData="search"
        @add="openMessagePopover"
        ref="messageData"
      />
      <message-edit
        v-if="messagePopoverShow"
        :show.sync="messagePopoverShow"
        :data="messagePopoverData"
      />
      <message-add
        v-if="messagePopoverAddShow"
        :show.sync="messagePopoverAddShow"
        @update="$refs.messageData.getTableData(true)"
      />
    </template>
  </div>
</template>

<script>
import TextData from './textData'
import PopoverText from './popoverText'
import NewsData from './newsData'
import ImageData from './imageData'
import PopoverImage from './popoverImage'
import PopoverImageEdit from './popoverImageEdit'
import MpnewsData from './mpnewsData'
import PopoverMpnews from './popoverMpnews'
import PopoverNews from './popoverNews'
import MessageData from './messageData'
import MessageEdit from './messageEdit'
import MessageAdd from './messageAdd'

export default {
  data() {
    return {
      // 切换页面值
      activeName: 'text',
      tabList: [
        { name: 'text', label: '文字', show: true,icon:'text'},
        { name: 'mpnews', label: '图文', show: true,icon:'mpnews'},
        { name: 'news', label: '外链', show: true,icon:'news'},
        { name: 'image', label: '图片', show: true,icon:'image'},
        { name: 'message', label: '话术库', show: true,icon:'text'},
      ],
      search: '',
      // text弹窗显示
      popoverShow: false,
      popoverData: null,
      // image弹窗显示
        // 添加显示
      imagePhotoShow: false,
        // 编辑数据和显示
      imageEditData: null,
      imageEditShow: false,
      // mpnews弹窗显示
      mpnewsPoShow: false,
      mpnewsPoData: null,
      // news弹窗显示
      newsPoShow: false,
      newsPoData: null,
      //message弹框显示
      messagePopoverShow: false,
      messagePopoverAddShow: false,
      messagePopoverData: null
    }
  },
  methods: {
    openTextPopover(data) {
      this.popoverData = data
      this.popoverShow = true
    },
    openImagePopover(data) {
      this.imageEditData = data
      this.imageEditShow = true
    },
    openMpnewsPopover(data) {
      this.mpnewsPoData = data
      this.mpnewsPoShow = true
    },
    openNewsPopover(data) {
      this.newsPoShow = true,
      this.newsPoData = data
    },
    openMessagePopover(data) {
      if(data) {
        this.messagePopoverShow = true,
        this.messagePopoverData = data
      }else{
        this.messagePopoverAddShow = true
      }
    }
  },
  components: {
    TextData,
    PopoverText,
    MpnewsData,
    PopoverMpnews,
    NewsData,
    PopoverNews,
    ImageData,
    PopoverImage,
    PopoverImageEdit,
    MessageData,
    MessageEdit,
    MessageAdd
  },
  created() {
    if(this.$route.query.type) {
      this.activeName = this.$route.query.type
      switch (this.activeName) {
        case 'text': this.popoverShow = true
          break;
        case 'mpnews': this.mpnewsPoShow = true
          break;
        case 'news': this.newsPoShow = true
          break;
        case 'image': this.imagePhotoShow = true
          break;
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px 0;
  box-sizing: border-box;
  .box {
    height: calc(100% - 62px);
    background: #FFF;
    position: relative;
  }
  .top {
    display: flex;
    justify-content: space-between;
    padding: 0 25px;
    height: 60px;
    background: #FFF;
    border-bottom: 2px solid #EEE;
    .search {
      width: 232px;
      height: 32px;
      line-height: 62px;
    } 
    /deep/ {
      .el-tabs__nav {
        height: 62px;
        margin: 0;
        .el-tabs__item {
          font-size: 16px;
          line-height: 62px;
          span {
            padding-left: 24px;
            display: inline-block;
            &.text {
              background: url("../../assets/images/application_word_1.png") left/18px no-repeat;
            }
            &.mpnews {
              background: url("../../assets/images/application_picword_1.png") left/18px no-repeat;
            }
            &.news {
              background: url("../../assets/images/application_file_1.png") left/14px no-repeat;
            }
            &.image {
              background: url("../../assets/images/application_pic_1.png") left/18px no-repeat;
            }
          }
          &.is-active {
            font-weight: 600;
            span {
              &.text {
                background: url("../../assets/images/application_word_2.png") left/18px no-repeat;
              }
              &.mpnews {
                background: url("../../assets/images/application_picword_2.png") left/18px no-repeat;
              }
              &.news {
                background: url("../../assets/images/application_file_2.png") left/14px no-repeat;
              }
              &.image {
                background: url("../../assets/images/application_pic_2.png") left/18px no-repeat;
              }
            }
          }
        }
        i {
          margin-right: 5px;
        }
      }
    }
  }
}
</style>