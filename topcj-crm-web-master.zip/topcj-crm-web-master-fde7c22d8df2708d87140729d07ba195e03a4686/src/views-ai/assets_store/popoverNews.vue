<template>
  <el-dialog-pro
    @close="close"
    :loading="loading"
    full-screen
  >
    <template #title>{{data ? '编辑' : '新增'}}外链</template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
export default {
  data() {
    return {
      // 状态更新
      loading: false,
      // 表单数据
      form: {
        corpId: this.data ? this.data.corpId : '',
        sourceTitle: this.data?.sourceTitle ?? '',
        picUrl: this.data?.picUrl ?? '',
        digest: this.data?.digest ?? '',
        url: this.data?.url ?? '',
        share: this.data ? this.data.share? false : true : false
      },
      config: {
        corpId: {
          type: 'select-corp',
          label: '分公司',
          corpLock: true
        },
        sourceTitle: {
          type: 'input',
          label: '标题',
          rule: [
            { required: true }
          ]
        },
        picUrl: {
          type: 'image',
          label: '封面',
          rule: [
            { required: true }
          ]
        },
        digest: {
          type: 'textarea',
          label: '摘要',
          placeholder: '如不添，则自动抓取正文前40个字'
        },
        url: {
          type: 'input',
          label: '外链',
          rule: [
            { required: true }
          ]
        },
        share: {
          type: 'switch',
          label: '分享',
          activeValue: 0,
          inactiveValue: 1,
          unit:'选择的话，其他成员可见并可使用此素材'
        }
      },
      // 分享
      // share:this.data ? this.data.share? false : true : false 
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  methods: {
    close() {
      this.$emit("update:show",false)
    },
    async submit() {
      if(!await this.$refs.form.check()) return

      if(this.data) {
        let { code,msg } = await this.$http({
          url: '%CRM%/source/delete_source.sdcrm',
          data:{
            token: true,
            managerId: this.$store.state.managerInfo.id,
            sourceId: this.data.id,
          }
        })
        if(code === 8200) {
          this.setList()
          return
        } else {
          this.$message.error(msg)
          return
        }
      }
      this.setList()
    },
    async setList() {
      let { code,msg } = await this.$http({
        url: '%CRM%/source/set_source.sdcrm',
        data: {
          token: true,
          msgType: "news",
          createrId: this.$store.state.managerInfo.id,
          author: this.$store.state.managerInfo.id,
          share: typeof this.form.share === 'number' ? this.form.share : undefined,
          title: this.form.sourceTitle,
          picUrl: this.form.picUrl,
          digest: this.form.digest ? this.form.digest : this.form.sourceTitle.substring(0,39),
          sourceId: "-1",
          sourceTitle: this.form.sourceTitle,
          url: this.form.url,
          corpId: typeof this.form.corpId === 'number'?this.form.corpId : undefined
        }
      })
      if(code === 8200) {
          if(this.data) {
            this.$message.success('修改成功')
          } else {
            this.$message.success('新增成功')
          }
        } else {
          this.$message.error(msg)
        }
        this.$emit('change')
        this.close()
    }
  }
}
</script>
<style lang="scss" scoped>
.popover {
  .ps {
    font-size: 12px;
    margin-left: 10px;
    color: rgba(0,0,0,.45);
  }
}
</style>