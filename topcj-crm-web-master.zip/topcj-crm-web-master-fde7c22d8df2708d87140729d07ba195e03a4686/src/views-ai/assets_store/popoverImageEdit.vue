<template>
  <el-dialog-pro
    @close="close"
    :loading="loading"
  >
    <template #title>修改备注</template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
export default {
  data() {
    return {
      // 状态更新
      loading: false,
      // 表单数据
      form: {
        corpId: this.data ? this.data.corpId : undefined,
        sourceTitle: this.data?.sourceTitle ?? '' ,
        share: this.data ? this.data.share ? false : true : false
      },
      config: {
        corpId: {
          type: 'select-corp',
          label: '分公司',
          corpLock: true
        },
        sourceTitle: {
          type: 'input',
          label: '素材名称'
        },
        share: {
          type: 'switch',
          label: '分享',
          activeValue: 0,
          inactiveValue: 1,
          unit:'选择的话，其他成员可见并可使用此素材'
        }
      },
      // 是否分享
      
    }
  },
  props:{
    show: Boolean,
    data: Object
  },
  methods: {
    close() {
      this.$emit("update:show",false)
    },
    async submit() {
      let { code,msg } = await this.$http({
        url: '%CRM%/source/set_source.sdcrm',
          data: {
            token: true,
            msgType: 'image',
            createrId: this.$store.state.managerInfo.id,
            share: typeof this.form.share === 'number' ? this.form.share : undefined,
            sourceId: this.data.id,
            sourceTitle: this.form.sourceTitle,
            picUrl: this.data?.picUrl ?? undefined,
            corpId: typeof this.form.corpId === 'number'?this.form.corpId : undefined
          }
      })
      if(code === 8200) {
        this.$message.success('修改成功')
      }else {
        this.$message.error(msg)
      }
      this.close()
    }
  }
}
</script>
<style lang="scss" scoped>
.ps {
  font-size: 12px;
  margin-left: 10px;
  color: rgba(0,0,0,.45);
}
</style>