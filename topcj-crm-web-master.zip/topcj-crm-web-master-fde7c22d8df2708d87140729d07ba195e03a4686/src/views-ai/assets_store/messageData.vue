<template>
  <el-layout-pro
    :loading="loading"
    :total="total"
    :page-num.sync="pageNum"
    :page-size.sync="pageSize"
    page-layout="normal"
    class="box"
    @page-change="getTableData()"
  >
    <template #screen>
      <el-screen-pro
        :model="screen"
        :config="config"
        @change="getTableData(true)"
      >
      </el-screen-pro>
    </template>

    <template #table>
      <message-table
        :data="tableData"
        @edit="edit"
        @delete="deleteData"
      />
    </template>

  </el-layout-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import MessageTable from './messageTable'

export default {
  data() {
    return {
      // 状态更新
      loading: false,
      // 分页
      pageNum: 1,
      pageSize: 10,
      total: 0,
      // 筛选
      screen: {
        isLock: '',
        type: '',
        time: null,
        corpId: ''
      },
      config: {
        split: {type: 'split'},
        corpId: {
          type: 'select-corp'
        },
        isLock: {
          type: 'select',
          options: [
            { value: 1, label: '锁定' },
            { value: 0, label: '未锁定' },
          ],
          placeholder: '状态'
        },
        type: {
          type: 'select',
          options: [
            { value: 0, label: '营销类' },
            { value: 1, label: '服务类' },
          ],
          placeholder: '类型'
        },
        time: {
          type: 'date-range',
          format: 'yyyy/MM/dd'
        },
        add: {
          type: 'button',
          label: '+ 导入话术',
          click: () => {
            this.$emit('add', null)
          }
        }
      },
      // 表格数据
      tableData: []
    }
  },
  props: {
    show: Boolean,
    searchData: String
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }
      let { result } = await this.$http({
        url: '%CRM%/message_source/get_message_source_title.sdcrm',
        data: {
          token: true,
          isLock: typeof this.screen.isLock === 'number'? this.screen.isLock : undefined,
          type: typeof this.screen.type === 'number'? this.screen.type : undefined,
          corpId: typeof this.screen.corpId === 'number'? this.screen.corpId : undefined,
          keyWord:this.searchData ? this.searchData : undefined,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
        }
      })
      
      this.tableData = result.records
      this.total = result.total
      this.loading = false
    }),
    edit(data) {
      this.$emit('add', data)
    },
    async deleteData(data) {
      let { code, msg } = await this.$http({
        url: '%CRM%/message_source/clear_message_source.sdcrm',
        data: {
          token: true,
          msgSourceId: data.id,
          type: 1
        }
      })
      if(code !== 8200) {
        this.$message.error(msg)
        return
      }

      this.$message.success('删除成功')
      this.getTableData()
    }
  },
  watch: {
    show() {
      if(this.show === false) {
        if(this.screen.corpId) {
          this.getTableData(this.searchData)
          return
        }
        this.getTableData()
      }
    },
    searchData() {
      if(this.searchData !== '') {
        this.getTableData(this.searchData)
        return
      }
      this.getTableData()
    }
  },
  components: {
    MessageTable,
  },
  created() {
    if(this.$route.query.id) {
      this.$emit('add', {
        id: Number(this.$route.query.id),
        islock: 0
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.box {
  width: 100%;
  height: calc(100% - 62px);
  background: #FFF;
  .total {
    font-size: 12px;
    color: rgba(0,0,0,.45)
  }
}
</style>