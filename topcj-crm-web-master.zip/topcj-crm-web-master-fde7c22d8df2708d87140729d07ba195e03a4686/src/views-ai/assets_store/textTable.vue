<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-text="{ row }">
      <msg-text
        :text="row.text"
        :face="true"
        :br="true"
      />
    </template>

    <template #body-edit="{ row }">
      <el-button
        type="text"
        @click="$emit('edit',row)"
        icon="el-icon-edit"
      >编辑</el-button>
    </template>
    <template #body-delete="{ row }">
      <el-popconfirm
        title="这是一段内容确定删除吗？"
        @confirm="$emit('delete', row)"
      >
        <el-button 
          type="text"
          slot="reference"
          icon="el-icon-delete"
        >删除</el-button>
      </el-popconfirm>
    </template>
  </el-table-pro>
</template>
<script>
import MsgText from '../../components/message/msg-text'
export default {
  data() {
    return {
      head: [
        {
          key: 'text',
          minWidth: 600
        },
        {
          key: 'ctime',
          minWidth: 140,
          format: (e)=>new Date(e).timeFormat()
        },
        {
          key: 'edit',
          width: 44
        },
        {
          key: 'delete',
          width: 44
        }
      ],
      id: this.$store.state.managerInfo.id
    }
  },
  props: {
    data: Array
  },
  components: {
    MsgText
  }
}
</script>
<style lang="scss" scoped>

</style>