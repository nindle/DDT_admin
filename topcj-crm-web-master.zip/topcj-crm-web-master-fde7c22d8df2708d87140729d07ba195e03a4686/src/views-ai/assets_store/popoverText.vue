<template>
  <el-dialog-pro
    @close="close"
    :loading="loading"
  >
    <template #title>{{data ? '编辑' : '新增'}}文字</template>

    <el-form-pro
      :model="form"
      :config="config"
    >
      <template #textarea>
        <message-input 
          :tool="tool"
          ref="message"
        />
      </template>
    
    </el-form-pro>
    <!-- 表单内容 -->
    
    
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import MessageInput from '../../components/message-input'
export default {
  data() {
    return {
      // 状态更新
      loading: false,
      // 表单数据
      tool: ['face'] ,
      // 分享
      
      form: {
        corpId: this.data ? this.data.corpId : '',
        share: this.data ? this.data.share? false : true : false ,
      },
      config: {
        corpId: {
          type: 'select-corp',
          label: '分公司',
          corpLock: true
        },
        textarea: {},
        share: {
          type: 'switch',
          label: '分享',
          activeValue: 0,
          inactiveValue: 1,
          unit:'选择的话，其他成员可见并可使用此素材'
        }
      }
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  methods: {
    close() {
      this.$emit("update:show",false)
    },
    async submit() {
      if(this.data) {
        let { code,msg } = await this.$http({
          url: '%CRM%/source/delete_source.sdcrm',
          data: {
            token: true,
            managerId: this.$store.state.managerInfo.id,
            sourceId: this.data.id,
          }
        })
        if(code === 8200) {
          this.setList()
          return
        } else {
          this.$message.error(msg)
          return
        }
      }
      this.setList()
    },
    async setList() {
      let text = this.$refs.message.getMessage()
      let { code,msg } = await this.$http({
        url: '%CRM%/source/set_source.sdcrm',
        data: {
          token: true,
          msgType: 'text',
          createrId: this.$store.state.managerInfo.id,
          share: typeof this.form.share === 'number' ? this.form.share : undefined,
          text: text[0] ? text[0].content : undefined,
          sourceId: '-1',
          sourceTitle: text[0] ? text[0].content : undefined,
          corpId: typeof this.form.corpId === 'number'?this.form.corpId : undefined
        }
      })
        if(code === 8200) {
          if(this.data) {
            this.$message.success('修改成功')
          } else {
            this.$message.success('新增成功')
          }
        } else {
          this.$message.error(msg)
        }
        this.$emit('change')
        this.close()
    }
  },
  components: {
    MessageInput
  },
  async mounted() {
    await this.$nextTick()
    if(this.data) {
      this.$refs.message.inputHtml(this.data.text)
    }
  }
}
</script>
<style lang="scss" scoped>
.message-input {
  height: 100px;
  border: 1px solid rgba(0,0,0,.25);
  border-radius: 5px;
  margin: 24px 0;
}
.ps {
  font-size: 12px;
  margin-left: 10px;
  color: rgba(0,0,0,.45);
}
</style>