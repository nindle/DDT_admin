<template>
  <el-dialog-pro
    @close="close"
    :loading="loading"
  >
    <template #title>添加图片</template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
export default {
  data() {
    return {
      // 状态更新
      loading: false,
      // 表单数据
      form: {
        corpId: this.data ? this.data.corpId : '',
        image: [],
        share: this.data ? this.data.share ? false : true : false
      },
      config: {
        corpId: {
          type: 'select-corp',
          label: '分公司',
          corpLock: true
        },
        image: {
          type: 'image-list',
          label: '图片'
        },
        share: {
          type: 'switch',
          label: '分享',
          activeValue: 0,
          inactiveValue: 1,
          unit:'选择的话，其他成员可见并可使用此素材'
        }
      },
      // 是否分享
      // share: false
    }
  },
  props: {
    show: Boolean
  },
  methods: {
    close() {
      this.$emit("update:show",false)
    },
    async submit() {
      let list = []
      this.form.image.forEach(e => {
        list.push({
          url: '%CRM%/source/set_source.sdcrm',
          data: {
            token: true,
            msgType: 'image',
            createrId: this.$store.state.managerInfo.id,
            share: typeof this.form.share === 'number' ? this.form.share : undefined,
            sourceId: '-1',
            sourceTitle: e.name,
            picUrl: e.url,
            corpId: typeof this.form.corpId === 'number'?this.form.corpId : undefined
          }
        })
      })
      let data = await this.$http({
        all: list,
        mode: 'all'
      })
      let s = 0,err = 0
      data.map(e => {
        if(e.code === 8200) {
          s++
        }else {
          err++
        }
      })
      if(s) {
        this.$message.success(`成功上传了${s}张,失败了${err}张`)
      }else {
        this.$message.error('上传失败')
      }
      this.close()
    }
  }
}
</script>
<style lang="scss" scoped>
.ps {
  font-size: 12px;
  margin-left: 10px;
  color: rgba(0,0,0,.45);
}
</style>