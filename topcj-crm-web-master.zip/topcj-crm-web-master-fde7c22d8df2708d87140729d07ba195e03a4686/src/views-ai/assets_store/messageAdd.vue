<template>
  <el-dialog-pro 
    @close="close"
  >
    <!-- 标题 -->
    <template #title>
      导入话术库
    </template>

    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        corpId: '',
        type: '',
        title: null,
        time: null,
        url: []
      },
      config: {
        corpId: {
          type: 'select-corp',
          label: '分公司',
          rule:[
            { required: true }
          ],
        },
        title: {
          type: 'date',
          label: '话术库日期',
          rule:[
            { required: true }
          ],
          format: 'yyyy/MM/dd'
        },
        type: {
          type: 'select',
          label: '类型',
          options: [
            { value: 0, label: '营销类' },
            { value: 1, label: '服务类' },
          ],
          rule:[
            { required: true }
          ],
        },
        time: {
          type: 'date-time',
          label: '消息开始时间',
          rule:[
            { required: true }
          ]
        },
        url: {
          label: '导入文件',
          type: 'file-list',
          rule:[
            { required: true, type: 'array' }
          ],
          accept: '.xls',
          template: `${this.SYS.URL}/xlsx/message_template.xls`,
          autoUpload: false
        }
      },
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  methods:{
    close() {
      this.$emit('update:show', false)
    },
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      const { load } = await import('../../assets/js/excel')

      let list = []

      for(let i = 0, l = this.form.url.length; i < l; i ++) {
        list.push(...(await load(this.form.url[i].file)))
      }

      let { result } = await this.$http({
        url: '%CRM%/message_source/set_message_source_title.sdcrm',
        data: {
          token: true,
          title: this.form.title,
          corpId: this.form.corpId,
          type: this.form.type
        }
      })

      if(result.islock) {
        this.$message.error('该话术库已锁定')
        return
      }

      let allData = list.map((e, i) => {
        return {
          url: '%CRM%/message_source/set_message_source.sdcrm',
          data: {
            token: true,
            type: e.用户发送,
            msgType: 'text',
            content: e.内容,
            ctime: this.form.time + i * 1000,
            msgSourceId: result.id
          }
        }
      })

      await this.$http({
        mode: 'relay',
        all: allData
      })

      this.$message.success('添加成功')
      this.$emit('update')
      this.close()
    })
  }
}
</script>