<template>
  <el-dialog-pro 
    @close="close"
    width="680px"
    max-height
  >
    <!-- 标题 -->
    <template #title>
      编辑话术库
    </template>

    <!-- 消息内容 -->
    <el-table-pro
      :head="head"
      :data="listData"
      border
      @row-contextmenu="contextmenu"
    ></el-table-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-form-pro
        :model="form"
        :config="config"
      ></el-form-pro>

      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        isLock: this.data.islock
      },
      config: {
        isLock: {
          type: 'switch',
          label: '锁定',
          activeValue: 1,
          inactiveValue: 0,
          change: () => {
            this.head.forEach(e => {
              e.disabled = !!this.form.isLock
            })
          }
        }
      },
      head: [
        {
          key: 'ctime',
          label: '发送时间',
          width: 140,
          edit: 'date-time',
          hideNow: true,
          disabled: !!this.data.islock,
          change: () => {
            this.listData = this.listData.sort((a, b) => a.ctime - b.ctime)
          }
        },
        {
          key: 'type',
          label: '发送角色',
          width: 56,
          edit: 'select',
          disabled: !!this.data.islock,
          options: [
            { value: 0, label: '业务' },
            { value: 1, label: '用户' },
          ]
        },
        {
          key: 'content',
          label: '发送内容',
          width: 368,
          edit: row => {
            if(row.msgType === 'text') {
              return 'textarea'
            }

            return false
          },
          rows: 1,
          disabled: !!this.data.islock,
          format: '查看',
          click: row => {
            this.$imageview({
              list: [row.imageUrl]
            })
          }
        }
      ],
      listData: []
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  methods:{
    //初始化
    async init() {
      let { result } = await this.$http({
        url: '%CRM%/message_source/get_message_source.sdcrm',
        data: {
          token: true,
          msgSourceId: this.data.id
        }
      })

      this.listData = result.map(e => {
        e.ctime = new Date(e.ctime).getTime()
        return e
      })
    },
    //右键
    contextmenu(row, column, event) {
      if(this.form.isLock) return

      let index = this.listData.indexOf(row)

      this.$contextmenu({
        event,
        menu: [
          {
            icon: 'el-icon-top',
            title: '在上方插入',
            handler: () => {
              this.listData.splice(index, 0, {
                ctime: row.ctime - 1,
                type: row.type,
                content: '',
                msgType: 'text'
              })
            }
          },
          {
            icon: 'el-icon-bottom',
            title: '在下方插入',
            handler: () => {
              this.listData.splice(index + 1, 0, {
                ctime: row.ctime + 1,
                type: row.type,
                content: '',
                msgType: 'text'
              })
            }
          },
          {
            icon: 'el-icon-delete',
            title: '删除',
            handler: () => {
              this.listData.splice(index, 1)
            }
          }
        ]
      })
    },
    close() {
      this.$emit('update:show', false)
    },
    //提交
    submit: throttle(async function() {
      await this.$http({
        url: '%CRM%/message_source/set_message_source_title.sdcrm',
        data: {
          token: true,
          id: this.data.id,
          isLock: this.form.isLock
        }
      })

      await this.$http({
        url: '%CRM%/message_source/clear_message_source.sdcrm',
        data: {
          token: true,
          msgSourceId: this.data.id,
          type: 0
        }
      })

      let allData = this.listData.map(e => {
        return {
          url: '%CRM%/message_source/set_message_source.sdcrm',
          data: {
            token: true,
            msgSourceId: this.data.id,
            type: e.type,
            msgType: e.msgType,
            content: e.content,
            imageUrl: e.imageUrl,
            ctime: e.ctime,
            msgId: e.msgId
          }
        }
      })

      await this.$http({
        mode: 'relay',
        all: allData
      })

      this.$message.success('保存成功')

      this.close()
    })
  },
  created() {
    this.init()
  }
}
</script>

<style lang="scss" scoped>

.el-form {
  float: left;
}
</style>