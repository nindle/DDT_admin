<template>
   <div class="table">
    <el-card 
      class="box-card" 
      :body-style="{ padding: '0px' }" 
      v-for="e in data"
      :key="e.id"
    >
      <div 
        slot="header" 
        class="clearfix" 
      >
        <p>{{e.updateTime | timeFormat('yyyy-MM-dd')}}</p>
        <el-button 
          size="mini" 
          icon="el-icon-edit" 
          circle
          @click="$emit('edit',e)"
        ></el-button>
        <el-popconfirm
          title="这是一段内容确定删除吗？"
          @confirm="$emit('delete', e)"
        >
          <el-button 
            icon="el-icon-delete" 
            slot="reference"
            circle
          ></el-button>
        </el-popconfirm>
      </div>
      <div 
        class="item"
        @click="open(e.url)"  
      >
        <img :src="e.picUrl" /> 
      </div>
      <div class="bottom">
        <div>
          <span>{{e.sourceTitle}}</span>
          <i :class="`${e.createrId !== id ? 'user allshare' : e.share === 0 ? 'user doubleshare' : 'user share'}`"></i>
        </div>
        <div>
          {{e.digest}}
        </div>
      </div>
    </el-card>
  </div>
</template>
<script>
export default {
  data() {
    return {
      id:this.$store.state.managerInfo.id
    }
  },
  props: {
    data: Array
  },
  methods: {
    open(url) {
      window.open(url,'_blank')
    }
  }
}
</script>
<style lang="scss" scoped>
.table {
  display: flex;
  flex-wrap: wrap;
  .box-card {
    width: 280px;
    height: 207px;
    padding: 0;
    margin-left: 24px;
    margin-top: 24px;
    cursor: pointer;
    .item {
      img {
        width: 100%;
        height: 97px;
        object-fit: cover;
      }
    }
    /deep/ {
      .el-card__header {
        padding: 0;
        height: 38px;
        font-size: 12px;
        line-height: 38px;
        padding: 0 10px;
        .clearfix {
          display: flex;
          justify-content: space-between;
          p {
            display: inline-block;
            width: 187px;
          }
          .is-circle {
            background: #EEE;
          }
          /deep/ {
            .el-button {
              width: 28px;
              height: 28px;
             margin-top: 5px ;
            }
            .el-popover__reference {
              padding: 0;
            }
          }
        }
      }
    }
    .bottom {
      display: flex;
      flex-direction: column;
      padding: 0 10px;
      overflow: hidden;
      div {
        &:first-of-type {
          width: 100%;
          font-size: 14px;
          line-height: 22px;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        &:nth-of-type(2) {
          font-size: 12px;
          height: 35px;
          color: rgba(0,0,0,.45);
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          overflow: hidden;
          word-break: break-all;
          white-space: pre-wrap;
        }
      }
      .el-icon-s-custom {
        color: #3089FF;
      }
    }
  }
}
</style>