<template>
  <el-layout-pro
    :loading="loading"
    :total="total"
    :page-num.sync="pageNum"
    :page-size.sync="pageSize"
    page-layout="normal"
    class="box"
    @page-change="getTableData()"
  >
    <template #screen>
      <el-screen-pro
        :model="screen"
        :config="config"
        @change="getTableData(true)"
      >
      </el-screen-pro>
    </template>

    <template #table>
      <text-table
        :data="tableData"
        @edit="edit"
        @delete="deleteData"
      />
    </template>

  </el-layout-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TextTable from './textTable'

export default {
  data() {
    return {
      // 状态更新
      loading: false,
      // 分页
      pageNum: 1,
      pageSize: 10,
      total: 0,
      // 筛选
      screen: {
        corpId: '',
      },
      config: {
        split: {type: 'split'},
        corpId: {
          type: 'select-corp'
        },
        add: {
          type: 'button',
          label: '+ 添加文字',
          click: () => {
            this.$emit('update:show',true)
            this.$emit('textAdd',null)
          }
        }
      },
      // 表格数据
      tableData: []
    }
  },
  props: {
    show: Boolean,
    searchData: String
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }
      let { result } = await this.$http({
        url:'%CRM%/source/search_source_ai.sdcrm',
        data: {
          token: true,
          corpId: typeof this.screen.corpId === 'number'? this.screen.corpId : undefined,
          msgType: 'text',
          sort: 0,
          sortType: 1,
          searchTxt:this.searchData? this.searchData : undefined,
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      })
      this.tableData = result.records
      this.total = result.total
      this.loading = false
    }),
    edit(data) {
      this.$emit('textAdd',data)
    },
    async deleting(data) {
      let { code,msg } = await this.$http({
        url: '%CRM%/source/delete_source.sdcrm',
        data: {
          token: true,
          sourceId: data.id,
        }
      })
      if(code === 8200) {
        this.$message.success('删除成功')
      } else {
        this.$message.error(msg)
      }
      this.getTableData()
    },
    deleteData(data) {
      let leader = this.$store.state.managerInfo.isLeader
      let id = this.$store.state.managerInfo.id
      if(!leader) {
        if( id === data.createrId ) {
          this.deleting(data)
        } else {
          this.$message.error('不是素材创建人')
          return
        }
      } else {
        this.deleting(data)
      }
    }
  },
  watch: {
    show() {
      if(this.show === false) {
        if(this.screen.corpId) {
          this.getTableData(this.searchData)
          return
        }
        this.getTableData()
      }
    },
    searchData() {
      if(this.searchData !== '') {
        this.getTableData(this.searchData)
        return
      }
      this.getTableData()
    }
  },
  components: {
    TextTable,
  }
}
</script>
<style lang="scss" scoped>
.box {
  width: 100%;
  height: calc(100% - 62px);
  background: #FFF;
  .total {
    font-size: 12px;
    color: rgba(0,0,0,.45)
  }
}
</style>