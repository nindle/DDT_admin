<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      添加标记
    </template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
      >添 加</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        keyword: this.data.defaultValue || '',
        reason: [],
        otherReason: ''
      },
      config: {
        keyword: {
          label: '关键词',
          rule:[
            { required: true }
          ]
        },
        reason: {
          type: 'select',
          label: '原因',
          options: [],
          valueKey: 'id',
          labelKey: 'remark',
          multiple: true,
          rule: [
            { 
              validator: (rule, value, callback) => {
                if(!value.length && !this.form.otherReason) {
                  callback(new Error('请至少填写一个原因'))
                }else{
                  if(!this.form.otherReason) {
                    this.$refs.form.validateField('otherReason')
                  }
                  callback()
                }
              }
            }
          ]
        },
        otherReason: {
          type: 'textarea',
          label: '其他原因',
          rule: [
            { 
              validator: (rule, value, callback) => {
                if(!this.form.reason.length && !value) {
                  callback(new Error('请至少填写一个原因'))
                }else{
                  if(!this.form.reason.length) {
                    this.$refs.form.validateField('reason')
                  }
                  callback()
                }
              }
            }
          ]
        }
      }
    }
  },
  props: {
    show: String,
    data: Object
  },
  methods:{
    close() {
      this.$emit('update:show', '')
    },
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      let reason = this.config.reason.options.filter(e => this.form.reason.includes(e.id)).map(e => e.remark)

      if(this.form.otherReason) {
        reason.push(this.form.otherReason)
      }
      
      this.$emit('submit', {
        keyword: this.form.keyword,
        reason: reason.join('；'),
        data: this.data
      })

      this.close()
    }),
    //获取类型列表
    async getTypeList(){
      let { result } = await this.$http({
        url: '%CRM%/conformance/get_conformance_search.sdcrm',
        data: {
          token: true,
          callType: 0,
          status: 1,
          isPage: 0
        }
      })

      this.config.reason.options = result
    }
  },
  created() {
    this.getTypeList()
  }
}
</script>