<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      批量调整时间
    </template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
      >确 定</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        time: '',
        now: ''
      },
      config: {
        time: {
          type: 'date-time',
          label: '初始时间',
          disabled: true
        },
        now: {
          type: 'date-time',
          label: '调整为',
          hideNow: true,
          rule:[
            { required: true, message: '请选择调整后的时间' }
          ]
        }
      }
    }
  },
  props: {
    show: String,
    data: Object
  },
  methods:{
    close() {
      this.$emit('update:show', '')
    },
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.$emit('submit', {
        interval: this.form.now - this.form.time
      })      

      this.close()
    }),
    //初始化
    init(){
      let minTime = Date.now()
      this.data.list.forEach(e => {
        minTime = Math.min(minTime, new Date(e.lastTime).getTime())
      })
      
      this.form.time = minTime
      this.form.now = minTime
    }
  },
  created() {
    this.init()
  }
}
</script>