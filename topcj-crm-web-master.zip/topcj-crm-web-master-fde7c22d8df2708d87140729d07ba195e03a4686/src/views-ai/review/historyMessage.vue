<template>
  <div
    v-loading="loading"
    element-loading-text="拼命加载中"
    element-loading-background="rgba(255,255,255,.5)"  
  >
    <el-screen-pro
      :model="screen"
      :config="config"
      @change="getMessageList(true)"
    ></el-screen-pro>
    <message 
      class="message-box"
      :data="messageList"
      @contextmenu="contextmenu"
      :message-style="getMessageStyle"
    ></message>
    <div 
      class="page-box"
      :style="type === 1 && status === 1 ? { bottom: '56px', paddingBottom: '0' } : { bottom: '0', paddingBottom: '12px' }"
    >
      <el-page-pro
        :total="total"
        :page-num.sync="pageNum"
        :page-size.sync="pageSize"
        small
        layout="total, prev, pager, next, jumper"
        :background="false"
        @change="getMessageList(false)"
      ></el-page-pro>
    </div>
    <el-screen-pro
      v-if="type === 1 && status === 1"
      class="bottom-box"
      :model="screen"
      :config="bottomConfig"
    >
      <template #label>
        <span class="tip">聊天记录截止时间</span>
      </template>
    </el-screen-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'

import Message from '../../components/message'

export default {
  data() {
    return {
      //消息列表
      messageList: [],
      //筛选数据
      screen: {
        time: '',
        msgType: '',
        appType: ''
      },
      config: {
        msgType: {
          placeholder: '消息类型',
          type: 'select',
          options: [
            { value: 'text', label: '文字' },
            { value: 'image', label: '图片' },
            { value: 'track', label: '录音' },
            { value: 'voice', label: '语音' },
            { value: 'news', label: '外链' },
            { value: 'mpnews', label: '图文' },
            { value: 'link', label: '链接' },
            { value: 'video', label: '视频' },
            { value: 'file', label: '文件' },
          ]
        },
        appType: {
          placeholder: '聊天通道',
          type: 'select',
          options: [
            { value: 1, label: '工作台' },
            { value: 2, label: '微信' },
            { value: 3, label: '电话' },
            { value: 4, label: '外部联系人' },
            { value: 7, label: '短信' }
          ]
        }
      },
      bottomConfig: {
        label: {},
        time: {
          type: 'date-time',
          placeholder: '聊天记录截止时间',
          change: this.editMsgEndTime
        }
      },

      //分页
      total: 0,
      pageNum: 1,
      pageSize: 50,
      loading: false,

      prePageNum: 1,
    }
  },
  props:{
    orderId: Number,
    userId: Number,
    type: Number,
    status: Number,
  },
  components: {
    Message
  },
  methods:{
    //获取消息记录
    async getMessageList(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }

      if(this.type === 1) {
        await this.getMessageType1()
      }else{
        await this.getMessageType2()
      }

      if(this.prePageNum !== this.pageNum) {
        this.$parent.$parent.scrollTop(0)
        this.prePageNum = this.pageNum
      }

      this.loading = false
    },
    getMessageStyle(data) {
      return {
        background: this.type === 1 && data.timestamp >= this.screen.time ? '#EEE' : '',
        padding: '4px 12px'
      }
    },
    //获取营销记录
    getMessageType1: throttle(async function() {
      let { result } = await this.$http({
        url: '%CRM%/user/message/get_order_msg_date.sdcrm',
        data: {
          token: true,
          userId: this.userId,
          orderId: this.orderId,
        }
      })

      this.screen.time = new Date(result.msgEndTime).getTime()

      let data = await this.$http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/user/message/order/sales_page.sdcrm',
            mode: 'post',
            data: {
              token: true,
              userId: this.userId,
              orderId: this.orderId,
              msgType: this.screen.msgType || undefined,
              appType: this.screen.appType || undefined,
              remain: true,
              days: this.status === 1 ? 3 : 0,
              pageNum: this.pageNum,
              pageSize: this.pageSize
            }
          },
          {
            url: '%CRM%/user/message/call/:userId/:orderId.sdcrm',
            mode: 'get',
            data: {
              token: true,
              userId: this.userId,
              orderId: this.orderId
            }
          }
        ]
      })

      this.total = data[0].result.total + data[1].result.length
      this.messageList = [
        ...(data[0].result.records.map(e => {
          e.managerTitle = '业务'
          e.timestamp = new Date(e.lastTime).getTime()
          return e
        }) || []), 
        ...(data[1].result.filter(e => {
          return (this.screen.msgType ? this.screen.msgType === e.msgType : true) && (this.screen.appType ? this.screen.appType === e.appType : true)
        }).map(e => {
          e.managerTitle = '合规电话'
          return e
        }) || [])
      ].slice(0, this.pageSize)
    }),
     //获取售后记录
    getMessageType2: throttle(async function() {
      let { result } = await this.$http({
        url: '%CRM%/user/message/service_page.sdcrm',
        data: {
          token: true,
          userId: this.userId,
          selected: null,
          msgType: this.screen.msgType || undefined,
          appType: this.screen.appType || undefined,
          remain: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      })

      this.total = result.total
      this.messageList = result.records.map(e => {
        e.managerTitle = '售后'
        return e
      })
    }),
    //右击
    contextmenu(event, item) {
      this.$contextmenu({
        event,
        menu: [
          {
            hide: item.msgType !== 'text',
            icon: 'el-icon-document-copy',
            title: '复制文本',
            handler: () => {
              try {
                let d = document.createElement('div')
                d.appendChild(window.getSelection().getRangeAt(0).cloneContents())

                this.$copy(d.innerHTML || item.content)
              }catch {
                this.$copy(item.content)
              }
            }
          },
          {
            icon: 'el-icon-picture-outline',
            hide: item.msgType !== 'image',
            title: '复制图片',
            handler: () => {
              this.$copy(`<img src="${item.imageUrl}" />`)
            }
          },
          {
            hide: item.msgType !== 'image',
            icon: 'el-icon-download',
            title: '下载原图',
            handler: () => {
              this.$open(item.imageUrl)
            }
          }
        ]
      })
    },
    //修改聊天记录截止时间
    async editMsgEndTime() {
      if(!this.screen.time) return

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/user/message/update_msg_end_date.sdcrm',
        data: {
          token: true,
          orderId: this.orderId,
          msgEndDate: this.screen.time
        }
      })

      if(code !== 8200) {
        this.$message.error(`修改失败：${errmsg || msg}`)
        return
      }

      this.$message.success('修改成功')

      this.getMessageList()
      this.$emit('update-message')
    }
  }
}
</script>

<style lang="scss" scoped>
.screen {
  position: sticky;
  top: 0;
  padding-bottom: 12px;
  padding-left: 12px;
  width: 100%;
  background: #FFF;
  z-index: 1;
  box-sizing: border-box;
}
.message-box {
  padding: 12px 0;
  /deep/ {
    .msg-text {
      user-select: text;
    }
  }
}
.page-box {
  position: sticky;
  bottom: 56px;
  width: 100%;
  z-index: 99;
  background: #FFF;
  display: flex;
  justify-content: center;
  padding: 12px 0;
}
.bottom-box {
  position: sticky;
  bottom: 0;
  left: 0;
  top: auto;
  margin-top: 0;
  padding: 12px;
  height: 56px;
  .tip {
    font-size: 12px;
    color: #E6A23C;
  }
  /deep/ {
    .screen-item { margin-top: 0;}
  }
}
</style>