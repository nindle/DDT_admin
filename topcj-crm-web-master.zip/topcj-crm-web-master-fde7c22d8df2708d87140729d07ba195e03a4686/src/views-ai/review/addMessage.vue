<template>
  <div class="add-message">
    <i 
      class="el-icon-close"
      @click="close"
    ></i>

    <message-input 
      :tool="tool"
      ref="message"
    />

    <el-screen-pro
      :model="screen"
      :config="config"
    >
      <template #audio>
        <el-button size="small">
          <msg-audio @success="$refs.message.inputMessage({ type: 'voice', url: $event })" />
        </el-button>
      </template>
    </el-screen-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import MessageInput from '../../components/message-input'
import MsgAudio from '../../components/message-input/audio'

export default {
  data() {
    return {
      tool: this.type === 'add' ? ['face', 'file'] : ['face'],
      //底部按钮
      screen: {
        type: '',
        ctime: new Date(this.data.lastTime).getTime() + 1000
      },
      config: {
        type: {
          hide: this.type === 'edit',
          type: 'select',
          placeholder: '选择角色',
          options: [
            { value: 0, label: '业务' },
            { value: 1, label: '用户' },
          ]
        },
        ctime: {
          hide: this.type === 'edit',
          type: 'date-time',
          placeholder: '消息时间'
        },
        split: { type: 'split' },
        audio: { hide: this.type === 'edit',},
        submit: {
          label: this.type === 'add' ? '添 加' : '修 改',
          type: 'button',
          buttonType: 'primary',
          click: this.submit
        }
      }
    }
  },
  components: {
    MessageInput,
    MsgAudio
  },
  props: {
    show: String,
    data: Object,
    sn: String,
    type: String,
  },
  methods:{
    close() {
      this.$emit('update:show', '')
    },
    //提交
    submit: throttle(async function() {
      if(typeof this.screen.type !== 'number' && this.type === 'add') {
        this.$message.error('请选择发送角色')
        return
      }
      if(typeof this.screen.ctime !== 'number' && this.type === 'add') {
        this.$message.error('请选择消息时间')
        return
      }
      let messageList = this.$refs.message.getMessage()
      if(!messageList.length) {
        this.$message.error('请输入消息')
        return
      }

      this.$emit('submit', {
        messageList, 
        roleType: this.screen.type, 
        ctime: this.screen.ctime, 
        sn: this.sn,
        type: this.type,
        data: this.data
      })
      this.close()
    })
  },
  mounted() {
    if(this.type === 'edit' || this.data.defaultValue) {
      this.$refs.message.inputHtml(this.data.defaultValue || this.data.content)
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.add-message {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 280px;
  background: #FFF;
  z-index: 1;
  box-shadow: 0px -2px 14px 0px rgba(#000, .17);
  .el-icon-close {
    position: absolute;
    top: 16px;
    right: 20px;
    color: #909399;
    cursor: pointer;
    &:hover { color: $--color-main;}
  }
  .message-input {
    height: 226px;
  }
  .screen {
    padding: 10px 20px 0;
    box-sizing: border-box;
  }
}
</style>