<template>
  <el-dialog-pro 
    @close="close"
    width="680px"
    max-height
  >
    <!-- 标题 -->
    <template #title>
      提取消息
      <span class="tip">
        消息开始时间：
        <el-date-picker
          class="start-time"
          popper-class="hide-now"
          v-model="lastTime"
          type="datetime"
          placeholder="选择消息开始时间"
          :clearable="false"
          size="mini"
          format="yyyy-MM-dd HH:mm:ss"
          value-format="yyyy-MM-dd HH:mm:ss"
          @change="changeTime"
        ></el-date-picker>
      </span>
    </template>

    <!-- 消息内容 -->
    <el-table-pro
      :head="head"
      :data="listData"
      border
      @row-contextmenu="contextmenu"
    ></el-table-pro>

    <!--左侧展示图片-->
    <template #left>
      <el-scrollbar-pro class="image-view">
        <img :src="data.imageUrl"/>
      </el-scrollbar-pro>
    </template>

    <!-- 底部按钮 -->
    <template #footer> 
      <span class="warning">保存后，原图会被删除</span>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      head: [
        {
          key: 'ctime',
          label: '发送时间',
          width: 140,
          edit: 'date-time',
          hideNow: true,
          change: () => {
            this.listData = this.listData.sort((a, b) => a.ctime - b.ctime)
          }
        },
        {
          key: 'From',
          label: '发送角色',
          width: 56,
          edit: 'select',
          options: [
            { value: 0, label: '业务' },
            { value: 1, label: '用户' },
          ]
        },
        {
          key: 'content',
          label: '发送内容',
          width: 368,
          edit: 'textarea',
          rows: 1
        }
      ],
      listData: this.data.analysisList,
      saveTime: new Date(this.data.lastTime).getTime(),
      lastTime: this.data.lastTime
    }
  },
  props: {
    show: String,
    data: Object,
    sn: String
  },
  methods:{
    //初始化
    init() {
      let time = new Date(this.lastTime).getTime()
      this.listData = this.listData.map((e, i) => {
        return {
          ...e,
          ctime: time + i * 5000
        }
      })
    },
    changeTime(now) {
      let n = new Date(now).getTime()
      let c = n - this.saveTime
      this.saveTime = n

      this.listData.forEach(e => {
        e.ctime += c
      })
    },
    //右键
    contextmenu(row, column, event) {
      let index = this.listData.indexOf(row)

      this.$contextmenu({
        event,
        menu: [
          {
            icon: 'el-icon-top',
            title: '在上方插入',
            handler: () => {
              this.listData.splice(index, 0, {
                ctime: row.ctime - 1,
                From: row.From,
                content: ''
              })
            }
          },
          {
            icon: 'el-icon-bottom',
            title: '在下方插入',
            handler: () => {
              this.listData.splice(index + 1, 0, {
                ctime: row.ctime + 1,
                From: row.From,
                content: ''
              })
            }
          },
          {
            icon: 'el-icon-delete',
            title: '删除',
            handler: () => {
              this.listData.splice(index, 1)
            }
          }
        ]
      })
    },
    close() {
      this.$emit('update:show', '')
    },
    //提交
    submit: throttle(async function() {
      this.$emit('submit', {
        type: 'analysis',
        messageList: this.listData.filter(e => e.content).map(e => {
          return {
            ctime: e.ctime,
            content: e.content,
            type: e.From
          }
        }),
        sn: this.sn,
        data: this.data
      })

      this.close()
    })
  },
  created() {
    this.init()
  }
}
</script>

<style lang="scss" scoped>
.tip {
  font-size: 12px;
  color: #999;
  margin-left: 6px;
}
.warning {
  font-size: 12px;
  color: #E6A23C;
  padding-right: 12px;
}
.image-view {
  width: 600px;
  background: #FFF;
  img { max-width: 600px;}
}
.start-time {
  width: 160px;
  /deep/ {
    .el-input__inner { padding-right: 0;}
  }
}
</style>