<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      添加个股
    </template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
      >添 加</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        stock: '',
        corpId: '',
        type: '',
        time: null,
        fromprice: ''
      },
      config: {
        stock: {
          type: 'select-stock',
          label: '个股',
          format: '{code}.{type}.{name}',
          rule:[
            { required: true }
          ]
        },
        corpId: {
          type: 'select-corp',
          label: '分公司',
          rule:[
            { required: true }
          ]
        },
        type: {
          type: 'select',
          label: '类型',
          options: [],
          labelKey: 'typeName',
          valueKey: 'id',
          rule:[
            { required: true }
          ]
        },
        time: {
          type: 'date-time',
          label: '时间',
          rule:[
            { required: true }
          ]
        },
        fromprice: {
          label: '入选价',
          rule:[
            { required: true }
          ]
        }
      }
    }
  },
  props: {
    show: String
  },
  methods:{
    close() {
      this.$emit('update:show', '')
    },
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      let stock = this.form.stock.split('.')

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/stock/add.sdcrm',
        data: {
          token: true,
          stockId: stock[0],
          marketType: Number(stock[1]),
          stockName: stock[2],
          type: this.form.type,
          fromprice: this.form.fromprice,
          corpId: this.form.corpId,
          ctime: this.form.time,
        }
      })

      if(code !== 8200) {
        this.$message.error(`添加失败：${errmsg || msg}`)
        return
      }

      this.$message.success('添加成功')

      this.close()
    }),
    //获取类型列表
    async getTypeList(){
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/stock/get_gold_stock_type.sdcrm',
        data: {
          token: true
        }
      })

      this.config.type.options = result
    }
  },
  created() {
    this.getTypeList()
  }
}
</script>