<template>
  <el-dialog-pro 
    @close="close"
    max-height
    top="24px"
  >
    <!-- 标题 -->
    <template #title>
      提交违规点
    </template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
    </el-form-pro>

    <template #right>
      <el-scrollbar-pro class="right-box">
        <el-form-pro
          class="right-form"
          :model="form"
          :config="configRight"
          ref="rightForm"
        >
          <template #content>
            <message 
              :data="form.content"
              translate
            ></message>
          </template>
        </el-form-pro>
      </el-scrollbar-pro>
    </template>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
      >提 交</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import Message from '../../components/message'

export default {
  data() {
    let managerList = {}
    let sensitiveIds = []
    this.data.list.forEach(e => {
      if(!managerList[e.managerId]) {
        managerList[e.managerId] = e.managerName
      }
      if(e.sensitiveWords) {
        sensitiveIds.push(...e.sensitiveWords.split('|'))
      }
    })
    managerList = Object.keys(managerList).map(e => {
      return {
        value: Number(e),
        label: managerList[e]
      }
    })

    sensitiveIds = Array.from(new Set(sensitiveIds)).filter(e => e)

    let sensitiveWords = sensitiveIds.map(e => {
      let item = this.$store.state.baseData.riskDictionary.find(a => a.riskCode === e)

      if(item) {
        return item.riskName
      }else{
        return e
      }
    })

    let content = this.data.list.map(e => {
      return {
        id: e.id,
        type: e.type,
        nickname: e.nickname,
        managerName: e.managerName,
        lastTime: e.lastTime,
        appType: e.appType,
        msgType: e.msgType,
        content: e.content,
        imageUrl: e.imageUrl,
        title: e.title,
        description: e.description,
        digest: e.digest,
        url: e.url,
        sourceId: e.sourceId,
      }
    })

    return {
      form: {
        sn: this.sn,
        userId: this.userId,
        riskType: '',
        riskName: '',
        type: this.type - 1,
        typeLabel: this.type === 1 ? '营销档案' : '服务档案',
        violatorId: managerList.length > 1 ? '' : managerList[0].value,
        sensitiveIds: sensitiveIds,
        sensitiveWords: sensitiveWords,
        msgIds: this.data.list.map(e => e.id),
        content: content,
        memo: ''
      },
      config: {
        sn: {
          type: 'label',
          label: '订单号',
          hide: this.type === 2
        },
        userId: {
          type: 'label',
          label: '用户ID',
        },
        typeLabel: {
          type: 'label',
          label: '档案类型',
        },
        riskType: {
          type: 'select',
          label: '违规点',
          options: this.$store.state.baseData.riskDictionary,
          valueKey: 'id',
          labelKey: 'riskName',
          filterable: true,
          change: id => {
            if(id) {
              this.form.riskName = this.$store.state.baseData.riskDictionary.find(e => e.id === id)?.riskName ?? ''
            }else{
              this.form.riskName = ''
            }
          },
          rule:[
            { required: true }
          ]
        },
        violatorId: {
          type: 'select',
          label: '违规人',
          options: managerList,
          rule:[
            { required: true }
          ]
        },
        memo: {
          type: 'textarea',
          label: '备注',
        }
      },
      configRight: {
        content: {
          label: '消息记录'
        },
      }
    }
  },
  props: {
    show: String,
    data: Object,
    sn: String,
    userId: Number,
    type: Number,
  },
  components: {
    Message
  },
  methods:{
    close() {
      this.$emit('update:show', '')
    },
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/risk/set_risk_point.sdcrm',
        data: {
          token: true,
          sn: this.form.sn,
          userId: this.form.userId,
          type: this.form.type,
          riskType: this.form.riskType,
          riskName: this.form.riskName,
          violatorId: this.form.violatorId,
          sensitiveIds: this.form.sensitiveIds.join('|'),
          sensitiveWords: this.form.sensitiveWords.join('|'),
          content: JSON.stringify(this.form.content),
          msgIds: this.form.msgIds.join('|'),
          memo: this.form.memo,
          fmTime: new Date(this.form.content[0].lastTime).getTime(),
          status: 1
        }
      })

      if(code !== 8200) {
        this.$message.error(`提交失败：${errmsg || msg}`)
        return
      }

      this.$message.success('提交成功')

      this.$emit('submit')      
      this.close()
    })
  }
}
</script>

<style lang="scss" scoped>
.right-box {
  height: 100%;
  .right-form {
    width: 520px;
    padding: 8px 20px 20px;
    box-sizing: border-box;
    height: 100%;
    /deep/ {
      .form-item-content {
        margin-bottom: 0;
        .el-form-item__error {
          top: -31px;
          left: 75px;
        }
        .el-form-item__label-wrap {
          float: none;
        }
        .el-form-item__content {
          line-height: unset;
          margin-left: 0 !important;
          height: calc(var(--popover-height) - 28px - 40px);
        }
      }
    }
  }
}
</style>