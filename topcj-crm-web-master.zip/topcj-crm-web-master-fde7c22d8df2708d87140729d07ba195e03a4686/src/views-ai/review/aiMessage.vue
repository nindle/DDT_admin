<template>
  <div
    v-loading="loading"
    element-loading-text="拼命加载中"
    element-loading-background="rgba(255,255,255,.5)"  
  >
    <el-screen-pro
      :model="screen"
      :config="config"
      @change="getMessageList(true)"
    >
      <template #selectAll>
        <el-checkbox
          :key="Date.now()"
          @change="selectAllMessage"
          :checked="selectList.length === messageList.length && selectList.length > 0"
          :indeterminate="selectList.length !== messageList.length && selectList.length > 0"
        >全选</el-checkbox>
      </template>
    </el-screen-pro>

    <!--提示-->
    <div 
      class="tip"
      v-if="type === 1 && messageShare === 1"
    >该订单营销内容请见服务档案</div>

    <message 
      :data="messageList"
      @contextmenu="contextmenu"
      translate
      select
      :select-list="selectList"
      :text-keyword="e => e.remark.map(e => e.k)"
    >
      <template #message-time="{ item }">
        <el-date-picker
          class="msg-time"
          popper-class="hide-now"
          v-model="item.lastTime"
          type="datetime"
          placeholder="选择消息时间"
          :clearable="false"
          size="mini"
          format="yyyy-MM-dd HH:mm:ss"
          value-format="yyyy-MM-dd HH:mm:ss"
          @change="editMessageTime(item)"
        ></el-date-picker>
      </template>

      <template #bottom="{ item }">
        <div class="remark-list">
          <el-popover
            v-for="(e, i) in item.remark"
            :key="`remark-${i}`"
            placement="top"
            width="160"
            :title="e.k"
            trigger="hover"
          >
            <p>{{e.r}}</p>
            <div style="text-align: right; margin: 2px 0 0">
              <el-button 
                type="danger" 
                size="mini"
                icon="el-icon-delete"
                @click="deleteRemark(item, e)"
              >删 除</el-button>
            </div>
            <div 
              slot="reference"
              class="remark-item"
            ></div>
          </el-popover>

          <el-popover
            v-for="(e, i) in item.sensitiveWordsList"
            :key="`sensitive-${i}`"
            placement="top"
            width="160"
            trigger="hover"
          >
            <p>{{e.text}}</p>
            <!-- <div style="text-align: right; margin: 2px 0 0">
              <el-button 
                type="danger" 
                size="mini"
                icon="el-icon-delete"
                @click="deleteRemark(item, e)"
              >删 除</el-button>
            </div> -->
            <div 
              slot="reference"
              class="sensitive-item"
            ></div>
          </el-popover>
        </div>
      </template>
    </message>

    <div class="page-box">
      <el-page-pro
        :total="total"
        :page-num.sync="pageNum"
        :page-size.sync="pageSize"
        small
        layout="total, prev, pager, next, jumper"
        :background="false"
        @change="getMessageList()"
      ></el-page-pro>
    </div>

  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import bus from '../../assets/js/bus'

import Message from '../../components/message'

export default {
  data() {
    return {
      selectList: [],
      //消息列表
      messageList: [],
      //筛选数据
      screen: {
        msgType: '',
        appType: '',
        search: '',
        messageShare: this.messageShare
      },
      config: {
        msgType: {
          placeholder: '消息类型',
          type: 'select',
          options: [
            { value: 'text', label: '文字' },
            { value: 'image', label: '图片' },
            { value: 'track', label: '录音' },
            { value: 'voice', label: '语音' },
            { value: 'news', label: '外链' },
            { value: 'mpnews', label: '图文' },
            { value: 'link', label: '链接' },
            { value: 'video', label: '视频' },
            { value: 'file', label: '文件' },
          ]
        },
        appType: {
          placeholder: '聊天通道',
          type: 'select',
          options: [
            { value: 1, label: '工作台' },
            { value: 2, label: '微信' },
            { value: 3, label: '电话' },
            { value: 4, label: '外部联系人' },
            { value: 7, label: '短信' },
            { value: 11, label: '其他' },
          ]
        },
        selectAll: {},
        split: { type: 'split' },
        search: {
          type: 'input',
          placeholder: '搜索聊天记录'
        },
        br: { type: 'br' },
        messageShare: {
          activeText: '营销档案同步至服务记录',
          type: 'switch',
          activeValue: 1,
          inactiveValue: 0,
          change: this.setMessageShare,
          hide: () => this.type !== 1
        }
      },

      //分页
      total: 0,
      pageNum: 1,
      pageSize: 50,
      loading: false,

      prePageNum: 1,
    }
  },
  props:{
    orderId: Number,
    userId: Number,
    type: Number,
    sn: String,
    messageShare: Number
  },
  components: {
    Message
  },
  methods:{
    //获取消息记录
    async getMessageList(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }

      this.selectList = []
      if(this.type === 1) {
        await this.getMessageType1()
      }else{
        await this.getMessageType2()
      }

      if(this.prePageNum !== this.pageNum) {
        this.$parent.$parent.scrollTop(0)
        this.prePageNum = this.pageNum
      }

      this.loading = false
    },
    //获取营销记录
    getMessageType1: throttle(async function() {
      let data = await this.$http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/user/message/order/sales_page.sdcrm',
            mode: 'post',
            data: {
              token: true,
              userId: this.userId,
              orderId: this.orderId,
              msgType: this.screen.msgType || undefined,
              appType: this.screen.appType || undefined,
              keyword: this.screen.search || undefined,
              pageNum: this.pageNum,
              pageSize: this.pageSize
            }
          },
          {
            url: '%CRM%/user/message/call/:userId/:orderId.sdcrm',
            mode: 'get',
            data: {
              token: true,
              userId: this.userId,
              orderId: this.orderId
            }
          }
        ]
      })

      this.total = data[0].result.total + data[1].result.length
      this.messageList = [
        ...(data[0].result.records.map(e => {
          e.managerTitle = '业务'

          // e.content = '[{"From": 1, "type": "txt", "content": "请问服务时间多长呢"},{"From": 0, "type": "txt", "content": "在原有的6个月的服务期的基础上额外赠送1个月,合计7个月"},{"From": 0, "type": "txt", "content": "邝先生今天能参加进来吗?转好了记得截图发我"}]'
          if(e.msgType === 'image' && e.content) {
            try {
              let list = JSON.parse(e.content)
              if(list instanceof Array) {
                e.analysisList = list.filter(e => typeof e === 'object')
                if(!e.analysisList.length) e.analysisList = ''
                e.content = ''
              }
            }catch{
              e.content
            }
          }

          e.sensitiveWordsList = (e.sensitiveWords || '').split('|').filter(e => e).map(e => {
            let item = this.$store.state.baseData.riskDictionary.find(a => a.riskCode === e)

            if(item) {
              return {
                text: item.riskName,
                code: item.riskCode
              }
            }else{
              return {
                text: e
              }
            }
          })

          return e
        }) || []), 
        ...(data[1].result.filter(e => {
          return (this.screen.msgType ? this.screen.msgType === e.msgType : true) && (this.screen.appType ? this.screen.appType === e.appType : true) && !this.screen.search
        }).map(e => {
          e.managerTitle = '合规电话'
          e.sensitiveWordsList = []
          return e
        }) || [])
      ].map(e => {
        if(e.reason) {
          e.remark = JSON.parse(e.reason)
        }else{
          e.remark = []
        }
        return e
      }).slice(0, this.pageSize)
    }),
    //获取售后记录
    getMessageType2: throttle(async function() {
      let { result } = await this.$http({
        url: '%CRM%/user/message/service_page.sdcrm',
        data: {
          token: true,
          userId: this.userId,
          selected: null,
          msgType: this.screen.msgType || undefined,
          appType: this.screen.appType || undefined,
          keyword: this.screen.search || undefined,
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      })
 
      this.total = result.total
      this.messageList = result.records.map(e => {
        e.managerTitle = '售后'

        if(e.msgType === 'image' && e.content) {
          try {
            let list = JSON.parse(e.content)
            if(list instanceof Array) {
              e.analysisList = list.filter(e => typeof e === 'object')
              if(!e.analysisList.length) e.analysisList = ''
              e.content = ''
            }
          }catch{
            e.content
          }
        }

        e.sensitiveWordsList = (e.sensitiveWords || '').split('|').filter(e => e).map(e => {
          let item = this.$store.state.baseData.riskDictionary.find(a => a.riskCode === e)

          if(item) {
            return {
              text: item.riskName,
              code: item.riskCode
            }
          }else{
            return {
              text: e
            }
          }
        })

        if(e.reason) {
          e.remark = JSON.parse(e.reason)
        }else{
          e.remark = []
        }
        return e
      })
    }),
    //右击
    contextmenu(event, item) {
      if(item.managerTitle === '合规电话') return

      this.$contextmenu({
        event,
        menu: [
          [
            {
              icon: 'el-icon-chat-line-square',
              hide: !item.analysisList,
              title: '提取消息',
              handler: () => {
                this.$emit('analysis-image', item)
              }
            },
          ],
          {
            icon: 'el-icon-plus',
            title: '新增',
            handler: () => {
              try {
                let d = document.createElement('div')
                d.appendChild(window.getSelection().getRangeAt(0).cloneContents())

                this.$emit('add-message', item, d.innerHTML)
              }catch {
                this.$emit('add-message', item)
              }
            }
          },
          {
            icon: 'el-icon-edit',
            hide: !(item.msgType === 'text' || (item.msgType === 'image' && item.content)),
            title: '修改',
            handler: () => {
              this.$emit('edit-message', item)
            }
          },
          {
            hide: !this.selectList.includes(item),
            icon: 'el-icon-delete',
            title: '删除勾选',
            handler: () => {
              this.$confirm(`将删除${this.selectList.length}条消息`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
              }).then(() => {
                this.deleteMessageList(this.selectList)
              })
            }
          },
          {
            hide: this.selectList.includes(item),
            icon: 'el-icon-delete',
            title: '删除',
            handler: () => {
              this.deleteMessage(item)
            }
          },
          {
            hide: !this.selectList.includes(item) || this.selectList.length < 2,
            icon: 'el-icon-date',
            title: '批量调整时间',
            handler: () => {
              this.$emit('edit-message-time', this.selectList)
            }
          },
          {
            icon: 'el-icon-data-line',
            title: '添加个股',
            handler: () => {
              this.$emit('add-stock')
            }
          },
          {
            icon: 'el-icon-news',
            title: '标记',
            handler: () => {
              try {
                let d = document.createElement('div')
                d.appendChild(window.getSelection().getRangeAt(0).cloneContents())

                this.$emit('add-remark', item, d.innerHTML)
              }catch {
                this.$emit('add-remark', item)
              }
            }
          },
          {
            icon: 'el-icon-chat-dot-square',
            title: '添加话术库',
            hide: !this.selectList.includes(item),
            handler: () => {
              this.$emit('add-msg-list', this.selectList)
            }
          },
          {
            hide: !this.selectList.includes(item) || this.selectList.length < 1,
            icon: 'el-icon-bangzhu',
            title: '提交违规点',
            handler: () => {
              this.$emit('set-risk-point', this.selectList)
            }
          },
          [
            {
              hide: item.msgType !== 'image',
              icon: 'el-icon-download',
              title: '下载原图',
              handler: () => {
                this.$open(item.imageUrl)
              }
            }
          ]
        ]
      })
    },
    //修改消息时间
    async editMessageTime(item) {
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/user/message/update_record.sdcrm',
        data: {
          token: true,
          messageId: item.id,
          ctime: new Date(item.lastTime).getTime()
        }
      })

      if(code !== 8200) {
        this.$message.error(`修改失败：${errmsg || msg}`)
        return
      }

      this.$message.success('修改成功')
      this.getMessageList()
    },
    //批量修改消息时间
    async editMessageTimeList({ interval }) {
      let allData = this.selectList.map(e => {
        return {
          url: '%CRM%/user/message/update_record.sdcrm',
          data: {
            token: true,
            messageId: e.id,
            ctime: new Date(e.lastTime).getTime() + interval
          }
        }
      })

      await this.$http({
        mode: 'relay',
        all: allData
      })

      this.$message.success('修改成功')
      this.getMessageList()
    },
    //修改消息
    async editMessage({ data, messageList, sn }) {
      let allData = []
      if(data.msgType === 'text') {
        //文字消息
        allData.push({
          url: '%CRM%/user/message/update_record.sdcrm',
          data: {
            token: true,
            messageId: data.id,
            content: messageList[0].content
          }
        })
      }else if(data.msgType === 'image') {
        allData.push({
          url: '%CRM%/user/message/delete_record.sdcrm',
          data: {
            token: true,
            messageId: data.id
          }
        })
        allData.push({
          url: '%CRM%/user/message/insert_record.sdcrm',
          data: {
            token: true,
            ctimeStamp: new Date(data.lastTime).getTime(),
            type: data.type,
            content: messageList[0].content,
            sn: this.type === 1 ? sn : undefined,
            userId: this.type === 2 ? this.userId : undefined,
            msgType: 'text'
          }
        })
      }

      await this.$http({
        mode: 'relay',
        all: allData
      })

      this.$message.success('修改成功')
      this.getMessageList()
    },
    //提取消息
    async analysisImage({ data, messageList, sn }) {
      let allData = []
      allData.push({
        url: '%CRM%/user/message/delete_record.sdcrm',
        data: {
          token: true,
          messageId: data.id
        }
      })

      messageList.forEach(e => {
        allData.push({
          url: '%CRM%/user/message/insert_record.sdcrm',
          data: {
            token: true,
            ctimeStamp: e.ctime,
            type: e.type,
            content: e.content,
            sn: this.type === 1 ? sn : undefined,
            userId: this.type === 2 ? this.userId : undefined,
            msgType: 'text'
          }
        })
      })

      await this.$http({
        mode: 'relay',
        all: allData
      })

      this.$message.success('提取成功')
      this.getMessageList()
    },
    //删除消息
    async deleteMessage(item) {
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/user/message/delete_record.sdcrm',
        data: {
          token: true,
          messageId: item.id
        }
      })

      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        return
      }

      this.$message.success('删除成功')
      this.getMessageList()
    },
    //批量删除消息
    async deleteMessageList(list) {
      let allData = list.map(e =>{
        return {
          url: '%CRM%/user/message/delete_record.sdcrm',
          data: {
            token: true,
            messageId: e.id
          }
        }
      })

      await this.$http({
        mode: 'relay',
        all: allData
      })

      this.$message.success('删除成功')
      this.getMessageList()
    },
    //添加消息
    async addMessage(result) {
      if(result.type === 'edit') {
        this.editMessage(result)
        return
      }
      if(result.type === 'analysis') {
        this.analysisImage(result)
        return
      }
      let { ctime, roleType, sn, messageList } = result

      let allData = messageList.map((e, i) => {
        return {
          url: '%CRM%/user/message/insert_record.sdcrm',
          data: {
            token: true,
            ctimeStamp: ctime + i * 1000,
            type: roleType,
            content: e.content,
            sn: this.type === 1 ? sn : undefined,
            userId: this.type === 2 ? this.userId : undefined,
            msgType: e.msgType,
            imgUrl: e.imageUrl,
            title: e.title,
            description: e.description,
            url: e.url,
            picurl: e.picurl,
            digest: e.digest,
            sourceId: e.sourceId
          }
        }
      })

      await this.$http({
        mode: 'relay',
        all: allData
      })

      this.$message.success('添加成功')
      this.getMessageList()
    },
    //添加标记
    async addRemark({ keyword, reason, data }) {
      data.remark.push({
        k: keyword,
        r: reason
      })

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/breakrule/set_break_rule.sdcrm',
        data: {
          token: true,
          messageId: data.id,
          reason: JSON.stringify(data.remark)
        }
      })

      if(code !== 8200) {
        this.$message.error(`添加失败：${errmsg || msg}`)
        return
      }

      this.$message.success('添加成功')
    },
    //删除标记
    async deleteRemark(item, e) {
      item.remark.splice(item.remark.indexOf(e), 1)

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/breakrule/set_break_rule.sdcrm',
        data: {
          token: true,
          messageId: item.id,
          reason: JSON.stringify(item.remark)
        }
      })

      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        item.remark.push(e)
        return
      }

      this.$message.success('删除成功')
    },
    //全选消息
    selectAllMessage(type) {
      if(type) {
        let list = this.messageList.filter(e => !['track', 'voice'].includes(e.msgType))
        this.selectList = [...list]
      }else{
        this.selectList = []
      }
    },
    //添加话术库
    async addMsgList(id) {
      let ids = []
      if(typeof id === 'number') {
        ids = [id]
      }else{
        ids = [...id]
      }

      this.$confirm(`将添加${ids.length}个话术库`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(async () => {
        for(let i in ids) {
          let { result } = await this.$http({
            url: '%CRM%/message_source/get_message_source.sdcrm',
            data: {
              token: true,
              msgSourceId: ids[i]
            }
          })

          let allData = result.map(e => {
            return {
              url: '%CRM%/user/message/insert_record.sdcrm',
              data: {
                token: true,
                ctimeStamp: new Date(e.ctime).getTime(),
                type: e.type,
                content: e.content,
                sn: this.type === 1 ? this.sn : undefined,
                userId: this.type === 2 ? this.userId : undefined,
                msgType: e.msgType,
                imgUrl: e.imageUrl,
                title: e.title,
                description: e.description,
                url: e.url,
                picurl: e.picurl,
                digest: e.digest,
                sourceId: e.sourceId
              }
            }
          })

          await this.$http({
            mode: 'relay',
            all: allData
          })
        }

        this.$message.success('添加成功')
        this.getMessageList()
      })      
    },
    setMessageShare: throttle(async function() {
      let { code,msg,errmsg } = await this.$http({
        url: '%CRM%/buy/order/set_message_share.sdcrm',
        data: {
          token: true,
          id: this.orderId,
          messageShare: this.screen.messageShare
        }
      })

      if(code !== 8200) {
        this.screen.messageShare = this.messageShare
        this.$message.error(`设置失败：${errmsg || msg}`)
        return
      }

      this.$message.success('设置成功')
      this.$emit('update:message-share', this.screen.messageShare)
    })
  },
  created() {
    bus.$on('addMessageSource', this.addMsgList)
  },
  beforeDestroy() {
    bus.$off('addMessageSource', this.addMsgList)
  }
}
</script>

<style lang="scss" scoped>
.page-box {
  position: sticky;
  bottom: 0;
  width: 100%;
  z-index: 1;
  background: #FFF;
  display: flex;
  justify-content: center;
  padding: 12px 0 0;
}
.screen {
  position: sticky;
  top: 0;
  padding-bottom: 12px;
  padding-left: 12px;
  width: calc(100% - 10px);
  background: #FFF;
  z-index: 99;
  box-sizing: border-box;
}
.message-box {
  padding: 12px;
  /deep/ {
    .msg-text {
      user-select: text;
    }
  }
}
.msg-time {
  width: 132px;
  /deep/ {
    .el-input__inner {
      padding: 0 !important;
      border-color: transparent;
      color: #999;
      text-align: right;
    }
    .el-input__prefix,
    .el-input__suffix { display: none;}
  }
}
.remark-list {
  display: flex;
  .remark-item {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #F56C6C;
    cursor: pointer;
    margin-right: 8px;
  }
  .sensitive-item {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #E6A23C;
    cursor: pointer;
    margin-right: 8px;
  }
}

.tip {
  font-size: 14px;
  color: #999;
  text-align: center;
  line-height: 240px;
}
</style>