<template>
  <div class="add-voice-main">
    <el-table-pro
      :head="headPhone"
      :data="dataPhone"
      class="phone-table"
    >
      <template #head-operation>
        <el-popover
          width="200"
          trigger="click"
          placement="top"
          v-model="showAddPhone"
          @hide="addPhone()"
        >
          <el-input 
            placeholder="请输入备份手机号"
            v-model="addPhoneValue"
            clearable
            size="small"
          />
          <div style="text-align: right; margin: 12px 0 0">
            <el-button 
              size="mini" 
              type="text" 
              @click="addPhone()"
            >取消</el-button>
            <el-button 
              type="primary" 
              size="mini" 
              @click="addPhone(true)"
            >确定</el-button>
          </div>
          <el-button
            slot="reference"
            size="mini"
            type="primary"
          >新增</el-button>
        </el-popover>
      </template>
    </el-table-pro>
    <el-table-pro
      :head="headVoice"
      :data="dataVoice"
    >
      <template #head-status>
        <el-button 
          size="small" 
          type="text" 
          icon="el-icon-refresh"
          @click="getVoiceData"
        >刷新</el-button>
      </template>
      <template #body-url="{ row }">
        <div class="beginTime">{{ row.beginTime | timeFormat }}（来源：{{row.callType | callTypeFilter }}）</div>
        <msg-audio :audio="row.url" />
      </template>
    </el-table-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import { Encode, Decode } from '../../assets/js/crypto'
import MsgAudio from '../../components/message/msg-audio'

export default {
  data() {
    return {
      headPhone: [
        {
          key: 'mobile',
          label: '备份手机号'
        },
        {
          key: 'operation',
          button: {
            size: 'small',
            type: 'text',
            icon: 'el-icon-delete',
            label: '删除',
            popconfirm: '确认删除吗？',
            click: this.deletePhone
          },
          width: 60
        }
      ],
      dataPhone: [],
      showAddPhone: false,
      addPhoneValue: '',

      headVoice: [
        {
          key: 'url',
          label: '录音',
          minWidth: 220,
        },
        {
          key: 'status',
          button: {
            size: 'small',
            type: 'text',
            icon: 'el-icon-plus',
            disabled: row => !!row.status,
            click: this.syncVoice
          },
          format: e => e ? '已同步' : '同步',
          width: 56
        }
      ],
      dataVoice: []
    }
  },
  props: {
    userId: Number
  },
  components: {
    MsgAudio
  },
  methods:{
    getPhoneData: throttle(async function() {
      let { result } = await this.$http({
        url: '%CRM%/user_mobile/get_user_mobile_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
          userId: this.userId
        }
      })

      this.dataPhone = result?.map(e => {
        if(e.enMobile) {
          e.mobile = Decode(e.enMobile)
        }
        return e
      }) ?? []
    }),
    addPhone: throttle(async function(status) {
      if(!status) {
        this.showAddPhone = false
        return
      }

      if(!this.addPhoneValue) {
        this.$message.error('请填写备份手机号')
        return
      }

      if(!/^1\d{10}$/.test(this.addPhoneValue)) {
        this.$message.error('备份手机号格式不正确')
        return
      }

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/user_mobile/set_user_mobile.sdcrm',
        data: {
          token: true,
          userId: this.userId,
          enMobile: Encode(this.addPhoneValue)
        }
      })

      if(code !== 8200) {
        this.$message.error(`添加失败：${errmsg || msg}`)
        return
      }

      this.$message.success('添加成功')

      this.getPhoneData()
      this.getVoiceData()
      this.showAddPhone = false
      this.addPhoneValue = ''
    }),
    deletePhone: throttle(async function(row) {
      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/user_mobile/del_user_mobile.sdcrm',
        data: {
          token: true,
          id: row.id,
        }
      })

      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        return
      }

      this.$message.success('删除成功')

      this.getPhoneData()
      this.getVoiceData()
    }),
    getVoiceData: throttle(async function() {
      let { result } = await this.$http({
        url: '%CRM%/user/message/get_tmp_call_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
          userId: this.userId
        }
      })

      this.dataVoice = result || []
    }),
    syncVoice: throttle(async function(row) {
      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/user/message/sync_user_call.sdcrm',
        data: {
          token: true,
          userId: this.userId,
          id: row.id,
        }
      })

      if(code !== 8200) {
        this.$message.error(`同步失败：${errmsg || msg}`)
        return
      }

      this.$message.success('同步成功')
      row.status = 1
      this.$emit('update')
    })
  },
  filters: {
    callTypeFilter(type) {
      switch(type) {
        case 0: return 'SCRM'
        case 1: return 'VAA'
        case 2: return 'SFTP'
        case 9: return 'APP'
        case 11: return 'SYNC'
        default: return '其他'
      }
    }
  },
  created() {
    this.getPhoneData()
    this.getVoiceData()
  }
}
</script>

<style lang="scss" scoped>
.add-voice-main {
  /* padding: 0 20px; */
  .beginTime {
    font-size: 12px;
  }
  .msg-audio {
    width: 220px;
    /deep/ {
      .el-slider {
        width: 100px;
      }
    }
  }
}
.phone-table {
  /deep/ {
    .noresult {
      height: 60px;
      background: none;
      &::before {
        line-height: 60px;
      }
    }
  }
}
.el-table {
  /deep/ {
    th, td {
      padding: 3px 0 !important;
    }
  }
}
</style>