<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      添加话术库
    </template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit()"
      >添 加</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit(true)"
      >添加并去编辑</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        time: null,
        type: this.type - 1
      },
      config: {
        time: {
          type: 'date',
          label: '话术库日期',
          rule:[
            { required: true }
          ],
          format: 'yyyy/MM/dd'
        },
        type: {
          type: 'select',
          label: '类型',
          options: [
            { value: 0, label: '营销类' },
            { value: 1, label: '服务类' },
          ],
          rule:[
            { required: true }
          ],
        }
      }
    }
  },
  props: {
    show: String,
    corpId: Number,
    data: Array,
    type: Number
  },
  methods:{
    close() {
      this.$emit('update:show', '')
    },
    //提交
    submit: throttle(async function(go) {
      if(!await this.$refs.form.check()) return

      let { result } = await this.$http({
        url: '%CRM%/message_source/set_message_source_title.sdcrm',
        data: {
          token: true,
          title: this.form.time,
          corpId: this.corpId,
          type: this.form.type
        }
      })

      if(result.islock) {
        this.$message.error('该话术库已锁定')
        return
      }

      let allData = this.data.map(e => {
        return {
          url: '%CRM%/message_source/set_message_source.sdcrm',
          data: {
            token: true,
            type: e.type,
            msgType: e.msgType,
            content: e.content,
            imageUrl: e.imageUrl,
            ctime: new Date(e.lastTime).getTime(),
            msgId: e.id,
            msgSourceId: result.id
          }
        }
      })

      await this.$http({
        mode: 'relay',
        all: allData
      })

      this.$message.success('添加成功')

      this.$emit('submit')

      if(go) {
        this.$router.push({
          name:'ai-assets_store',
          query:{
            type: 'message',
            id: result.id
          }
        })
      }

      this.close()
    })
  }
}
</script>