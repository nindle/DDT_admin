<template>
  <div class="review-box">
    <el-layout-pro 
      class="history-box"
      v-show="showHistory"
      scroll-bar-index="100"
    >
      <template #screen>
        <span class="label">聊天记录</span>
        <el-button
          class="hide"
          type="text"
          size="small"
          icon="el-icon-d-arrow-left"
          @click="showHistory = false"
        >隐藏</el-button>
      </template>
      <template #scroll>
        <history-message 
          :order-id="orderId"
          :user-id="userId"
          :type="type"
          :status="status"
          @update-message="updateMessage"
        />
      </template>
    </el-layout-pro>

    <div class="ai-box">
      <el-layout-pro>
        <template #screen>
          <el-button
            v-show="!showHistory"
            class="hide"
            type="text"
            size="small"
            icon="el-icon-d-arrow-right"
            @click="showHistory = true"
          >显示</el-button>

          <el-popover
            class="remark-button"
            :class="{ left: !showHistory }"
            width="340"
            trigger="click"
            placement="bottom-end"
            v-model="showRemark"
            v-if="type === 1"
            @hide="submitRemark()"
          >
            <el-input 
              placeholder="请输入处罚备注"
              v-model="remarkValue" 
              size="small"
              type="textarea"
              :autosize="{ minRows: 3 }"
              resize="none"
            />
            <div style="text-align: right; margin: 12px 0 0">
              <el-button 
                size="mini" 
                type="text" 
                @click="submitRemark()"
              >取消</el-button>
              <el-button 
                type="primary" 
                size="mini" 
                @click="submitRemark(true)"
              >确定</el-button>
            </div>
            <el-button
              type="text"
              slot="reference"
              size="small"
              icon="el-icon-document"
            >处罚备注</el-button>
          </el-popover>



          <el-popover
            width="200"
            trigger="click"
            placement="top"
            class="syncmessage"
            v-model="showUpdateMsg"
            @hide="updateMsg()"
            v-if="auth.includes('syncmessage')"
          >
            <el-input 
              placeholder="请输入用户ID"
              v-model="updateMsgUserId"
              clearable
              size="small"
            />
            <div style="text-align: right; margin: 12px 0 0">
              <el-button 
                size="mini" 
                type="text" 
                @click="updateMsg()"
              >取消</el-button>
              <el-button 
                type="primary" 
                size="mini" 
                @click="updateMsg(true)"
              >确定</el-button>
            </div>
            <el-button
              slot="reference"
              size="small"
            >同步聊天记录</el-button>
          </el-popover>
          <span class="label">AI合规学习库</span>
        </template>
        <template #scroll>
          <ai-message 
            :order-id="orderId"
            :sn="sn"
            :user-id="userId"
            :type="type"
            :message-share.sync="item.messageShare"
            @add-message="addMessage"
            @edit-message="editMessage"
            @add-stock="showPopover = 'stock'"
            @add-msg-list="addMsgList"
            @add-remark="addRemark"
            @analysis-image="analysisImage"
            @edit-message-time="editMessageTime"
            @set-risk-point="setRiskPoint"
            ref="content"
          />
        </template>
      </el-layout-pro>
      <div class="button-box">
        <el-button
          v-if="type === 1"
          style="float: left;"
          type="primary"
          plain
          size="small"
          @click="copyLink"
        >合同签署链接</el-button>
        
        <span class="back-count">退回{{backCount}}次</span>
        <el-popover
          width="200"
          trigger="click"
          placement="top"
          v-model="showReviewReason"
          @hide="openReview()"
          v-if="status === 1"
        >
          <el-input 
            placeholder="请输入退回理由"
            v-model="reviewReason" 
            size="small"
          />
          <div style="text-align: right; margin: 12px 0 0">
            <el-button 
              size="mini" 
              type="text" 
              @click="openReview()"
            >取消</el-button>
            <el-button 
              type="primary" 
              size="mini" 
              @click="openReview(2)"
            >确定</el-button>
          </div>
          <el-button
            slot="reference"
            size="small"
          >退回补充记录</el-button>
        </el-popover>

        <el-button
          size="small"
          @click="openReview(3)"
          v-if="status === 2"
        >退回重新审批</el-button>

        <el-button
          style="margin-left: 10px"
          type="primary"
          size="small"
          @click="openReview(1)"
          v-if="status === 1"
        >{{type === 1 ? '营销' : '服务'}}档案通过</el-button>

        <el-button
          v-if="type === 1"
          style="margin-left: 10px"
          type="warning"
          size="small"
          @click="aiReview"
          :disabled="!!aiStatus"
        >提交数据库</el-button>
      </div>

      <!--新增消息-->
      <add-message 
        v-if="showPopover === 'message'"
        :show.sync="showPopover"
        :data="addMessageItem"
        :key="`${addMessageItem.id}${addMessageType}`"
        :sn="sn"
        :type="addMessageType"
        @submit="$refs.content.addMessage"
      />
    </div>    


    <el-layout-pro class="asstes-box">
      <template #screen>
        <span class="label">合规素材库</span>
      </template>
      <template #table>
        <assets 
          :default-corp-id="corpId" 
          :config="type === 1 ? [{ key: 'groupmsg', label: '群发' }, { key: 'recordvoive', label: '录音' }] : []"
        >
          <template #groupmsg>
            <el-screen-pro
              class="groupmsg-screen"
              :model="groupModel"
              :config="groupConfig"
            ></el-screen-pro>
          </template>

          <template #recordvoive>
            <add-voice 
              :user-id="userId"
              @update="updateMessage"
            />
          </template>
        </assets>
      </template>
    </el-layout-pro>

    <!--新增个股-->
    <add-stock
      v-if="showPopover === 'stock'"
      :show.sync="showPopover"
    />

    <!--新增消息违规点-->
    <add-remark
      v-if="showPopover === 'remark'"
      :show.sync="showPopover"
      :data="addMessageItem"
      @submit="$refs.content.addRemark"
    />
    
    <!--解析图片-->
    <analysis-image
      v-if="showPopover === 'analysis'"
      :show.sync="showPopover"
      :data="addMessageItem"
      :sn="sn"
      @submit="$refs.content.addMessage"
    />

    <!--批量调整时间-->
    <edit-message-time
      v-if="showPopover === 'editMessageTime'"
      :show.sync="showPopover"
      :data="addMessageItem"
      @submit="$refs.content.editMessageTimeList"
    />

    <!--设置违规点-->
    <set-risk-point
      v-if="showPopover === 'setRiskPoint'"
      :show.sync="showPopover"
      :data="addMessageItem"
      :sn="sn"
      :type="type"
      :user-id="userId"
      @submit="$refs.content.selectList = []"
    />

    <!--添加话术库-->
    <add-msg-list 
      v-if="showPopover === 'msg-list'"
      :show.sync="showPopover"
      :data="addMessageItem"
      :corp-id="corpId"
      :type="type"
      @submit="$refs.content.selectList = []"
    />

    <!--添加标签-->
    <edit-tag 
      v-if="showEditTag"
      :show.sync="showEditTag"
      :data="{ id: orderId }"
      :type="editTagType"
      @review="() => { openReview(editTagType, true)}"
    />
  </div>
</template>

<script>
import HistoryMessage from './historyMessage'
import AiMessage from './aiMessage'
import Assets from '../../components/message-template'

import AddMessage from './addMessage'
import AddStock from './addStock'
import AddVoice from './addVoice'
import AddMsgList from './addMsgList'
import AddRemark from './addRemark'
import AnalysisImage from './analysisImage'
import EditMessageTime from './editMessageTime'
import SetRiskPoint from './setRiskPoint'
import EditTag from '../../views-gm/recorddot/editTag'
import { throttle } from '../../assets/js/tool'


export default {
  data() {
    return {
      addMessageItem: null,
      addMessageType: 'add',
      //展示添加个股
      showAddStock: false,
      //展示底部弹框
      showPopover: '',
      //审核相关
      reviewReason: '',
      showReviewReason: false,
      //显示原聊天记录
      showHistory: true,

      //群发记录
      groupModel: {
        time: null
      },
      groupConfig: {
        time: {
          type: 'date-range'
        },
        split: {type: 'split'},
        button: {
          type: 'button',
          buttonType: 'primary',
          label: '提 交',
          click: this.updateGroupMsg
        }
      },

      //同步聊天记录用户ID
      showUpdateMsg: false,
      updateMsgUserId: `${this.userId}`,

      //标签弹框
      showEditTag: false,
      editTagType: 0,

      //处罚备注
      showRemark: false,
      remarkValue: ''
    }
  },
  props: {
    sn: String,
    item: Object,
    orderId: Number,
    userId: Number,
    type: Number,
    corpId: Number,
    status: Number,
    backCount: Number,
    aiStatus: Number
  },
  inject: ['auth'],
  components: {
    HistoryMessage,
    AiMessage,
    Assets,
    AddMessage,
    AddStock,
    AddRemark,
    AnalysisImage,
    EditMessageTime,
    AddMsgList,
    EditTag,
    AddVoice,
    SetRiskPoint
  },
  methods: {
    //新增消息
    addMessage(item, defaultValue) {
      this.addMessageType = 'add'
      this.addMessageItem = {
        ...item,
        defaultValue
      }
      this.showPopover = 'message'
    },
    //修改消息
    editMessage(item) {
      this.addMessageType = 'edit'
      this.addMessageItem = item
      this.showPopover = 'message'
    },
    //解析图片
    analysisImage(item) {
      this.addMessageItem = item
      this.showPopover = 'analysis'
    },
    //新增标记
    addRemark(item, defaultValue) {
      this.addMessageItem = {
        ...item,
        defaultValue
      }
      this.showPopover = 'remark'
    },
    //添加话术库
    addMsgList(list) {
      this.addMessageItem = list
      this.showPopover = 'msg-list'
    },
    //批量修改时间
    editMessageTime(item) {
      this.addMessageItem = {
        list: item
      }
      this.showPopover = 'editMessageTime'
    },
    //批量修改时间
    setRiskPoint(item) {
      this.addMessageItem = {
        list: item
      }
      this.showPopover = 'setRiskPoint'
    },
    //添加群发消息
    updateGroupMsg: throttle(async function() {
      if(!this.groupModel.time) {
        this.$message.error('请选择时间')
        return
      }

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/user/message/add_bulk_message.sdcrm',
        data: {
          token: true,
          orderId: this.orderId,
          stime: this.groupModel.time[0],
          etime: this.groupModel.time[1],
        }
      })

      if(code !== 8200) {
        this.$message.error(`提交失败：${errmsg || msg}`)
        return
      }

      this.$message.success('提交成功')
      this.groupModel.time = null
      this.updateMessage()
    }),
    //合同签署链接
    copyLink() {
      let text = `合同签署链接:${this.SYS.WEBURL}/ns/#/signcontract?sn=${this.sn}&time=${Date.now()}`
      this.$copy(text)
    },
    //审核
    openReview: throttle(async function(status, flag) {
      let text = ''
      if(status === 2) {
        //退回
        if(!this.reviewReason) {
          this.$message.error('请输入退回理由')
          return
        }
        text = '退回'
      }else if(status === 1) {
        //审核通过
        text = '审核'
      }else if(status === 3) {
        text = '退回'
      }

      this.showReviewReason = false

      if(!status) {
        this.reviewReason = ''
        return
      }

      if(this.type === 1 && !flag && this.status === 1) {
        this.editTagType = status
        this.showEditTag = true
        return
      }

      let { code, msg, errmsg } = await this.$http({
        url: this.type === 1 ? '%CRM%/buy/order/review.sdcrm' : '%CRM%/user/service_review.sdcrm',
        data: {
          token: true,
          id: this.type === 1 ? this.orderId : undefined,
          userId: this.type === 2 ? this.userId : undefined,
          action: status,
          remark: status === 2 ? this.reviewReason : undefined,
          hgSys: true
        }
      })

      if(code !== 8200) {
        this.$message.error(`${text}失败：${errmsg || msg}`)
        return
      }

      this.$message.success(`${text}成功`)

      if(status === 1 && this.type === 1) {
        let { code, msg, errmsg } = await this.$http({
          url: '%CRM%/buy/order/ai_review.sdcrm',
          data: {
            token: true,
            id: this.orderId
          }
        })

        if(code !== 8200) {
          this.$message.error(`提交数据库失败：${errmsg || msg}`)
          this.$emit('review')
          return
        }

        this.$emit('update:ai-status', 1)
      }

      this.$emit('review')
    }),
    //同步消息记录
    updateMsg: throttle(async function(status) {
      if(!status) {
        this.showUpdateMsg = false
        return
      }

      if(!this.updateMsgUserId) {
        this.$message.error('请填写用户ID')
        return
      }

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/api/update_external_msg.sdcrm',
        data: {
          token: true,
          userId: Number(this.updateMsgUserId)
        }
      })

      if(code !== 8200) {
        this.$message.error(`提交失败：${errmsg || msg}`)
        return
      }

      this.$message.success('正在同步：请稍等...')

      this.updateMsgUserId = ''
      this.showUpdateMsg = false
    }),
    //更新消息
    updateMessage() {
      this.$refs.content.getMessageList()
    },
    //AI审核
    aiReview: throttle(async function() {
      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/buy/order/ai_review.sdcrm',
        data: {
          token: true,
          id: this.orderId
        }
      })

      if(code !== 8200) {
        this.$message.error(`提交失败：${errmsg || msg}`)
        return
      }

      this.$message.success('提交成功')
      this.$emit('update:ai-status', 1)
    }),
    //提交处罚备注
    submitRemark: throttle(async function(type) {
      if(type) {
        let { code,msg,errmsg } = await this.$http({
          url: '%CRM%/buy/order/setHandleRemark.sdcrm',
          data: {
            token: true,
            id: this.orderId,
            handleRemark: this.remarkValue
          }
        })

        if(code !== 8200) {
          this.$message.error(`保存失败：${errmsg || msg}`)
          return
        }

        this.$message.success('保存成功')
        this.item.handleRemark = this.remarkValue
      }

      this.remarkValue = this.item.handleRemark
      this.showRemark = false
    }),
  },
  watch: {
    item: {
      immediate: true,
      handler() {
        this.remarkValue = this.item.handleRemark
      }
    }
  },
}
</script>

<style lang="scss" scoped>

.review-box {
  height: 100%;
  background: #FFF;
  display: flex;
  .history-box {
    width: 350px;
    height: 100%;
    border-left: 1px solid #EEE;
    /deep/ .screen-box { 
      background: #F6F6F6;
      padding: 12px 24px;
    }
    .hide { 
      margin-left: auto;
      height: 18px;
    }
  }
  .ai-box {
    position: relative;
    flex-grow: 1;
    flex-basis: 0;
    height: 100%;
    border-right: 1px solid #EEE;
    border-left: 1px solid #EEE;
    .button-box {
      padding: 12px;
      height: 56px;
      width: 100%;
      box-sizing: border-box;
      text-align: right;
      .back-count { 
        font-size: 12px;
        color: #E6A23C;
        padding-right: 12px;
      }
    }
    .layout {
      height: calc(100% - 56px);
    }
    /deep/ .screen-box { 
      background: #F6F6F6;
      padding: 12px 24px;
      justify-content: center;
      .label {
        padding-left: 0;
        &::before { display: none;}
      }
      .hide { 
        position: absolute;
        left: 24px;
        height: 18px;
      }
      .remark-button {
        position: absolute;
        left: 24px;
        height: 18px;
        &.left {
          left: 80px;
        }
      }
      .syncmessage {
        position: absolute;
        right: 12px;
      }
    }
  }
  .asstes-box {
    width: 350px;
    height: 100%;
    /deep/ {
      .screen-box { 
        background: #F6F6F6;
        padding: 12px 24px;
      }
      .table-box { padding: 0;}
      .parent .corpBox { top: -44px;}
    }
    .groupmsg-screen {
      width: 100%;
      padding: 0 12px 0 20px;
      box-sizing: border-box;
    }
  }
}
</style>