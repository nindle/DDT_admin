<template>
  <div class="top-data">
    <div class="left">
      <i class="el-icon-pie-chart"></i>
      服务留痕总数<span :class="{ 'el-icon-loading': loading }">{{data.waitCount}}</span>条；
    </div>
    <div class="right">
      <slot />
    </div>
    <div class="line"></div>
  </div>
</template>
<script>

export default {
  data() {
    return {
      loading: false,
      data: {}
    }
  },
  components: {
    
  },
  methods:{
    async getData() {
      this.loading = true

      let { result } = await this.$http({
        url: '%CRM%/buy/order/get_archives_status_count.sdcrm',
        data: {
          token: true,
          managerId:this.$store.state.managerInfo.isLeader ? undefined : this.$store.state.managerInfo.id,
          type:1,
        }
      })

      this.loading = false

      result.waitCount = result.waitCount ?? 0

      this.data = result
    }
  },
  created() {
    this.getData()
  }
}
</script>
<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.top-data {
  width: 100%;
  height: 72px;
  background: #FFF;
  color: #333;
  line-height: 71px;
  padding: 0 24px;
  box-sizing: border-box;
  display: flex;
  flex-wrap: wrap;
  .left {
    span { 
      color: $--color-main;
      padding: 0 5px;
      font-weight: bold;
    }
    .el-icon-pie-chart {
      font-size: 24px;
      color: $--color-main;
      margin-right: 16px;
      vertical-align: sub;
    }
  }
  .right { margin-left: auto;}
  .line {
    width: 100%;
    border-bottom: 1px dashed #E9E9E9;
  }
}
</style>