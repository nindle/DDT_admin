<template>
  <div class="view">
    <el-layout-pro 
      class="select-box"
      @scroll-bottom="getListData()"
    >
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getListData(true)"
        >
          <template #more>
            <el-button
              icon="el-icon-more" 
              type="text"
              size="small"
              @click="showMore"
            ></el-button>
          </template>
        </el-screen-pro>
      </template>
      <template #scroll>
        <div class="list-box">
          <div 
            class="item"
            v-for="e in listData"
            :key="e.id"
            @click="selectItem = e"
            :class="{ active: selectItem === e }"
          >
            <span v-copy>{{e.userId}}</span>
            <span v-copy>{{e.sn}}</span>
          </div>
        </div>
        <el-button
          v-if="!$store.state.managerInfo.isLeader && listData.length < maxLength && $route.params.status === 1 && !loading && !screen.search"
          type="primary"
          size="small"
          class="get-order"
          @click="getOrder"
        >获取营销档案 {{ maxLength - listData.length }} 个</el-button>
      </template>
    </el-layout-pro>

    <review 
      v-if="selectItem"
      :item="selectItem"
      :sn="selectItem.sn"
      :order-id="selectItem.id"
      :user-id="selectItem.userId"
      :corp-id="selectItem.corpId"
      :key="selectItem.sn"
      :type="1"
      :back-count="selectItem.archivesReturnCount"
      :status="selectItem.archivesStatus"
      :ai-status.sync="selectItem.aiStatus"
      @review="reviewSuccess"
    />

    <ReviewDistribute 
      v-if="showPopover"
      :show.sync="showPopover"
      :type="1"
    />
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'

import Review from '../review/index'
import ReviewDistribute from './reviewDistribute'

export default {
  data() {
    return {
      maxLength: 10,
      showPopover: false,
      loading: false,
      screen: {
        search: ''
      },
      config: {
        search: {
          type: 'input',
          placeholder: '搜索订单号/用户ID'
        },
        split: { type: 'split'},
        back: {
          type: 'button',
          buttonType: 'text',
          label: '返回',
          icon: 'el-icon-back',
          click: () => {
            this.$router.go(-1)
          }
        },
        more: {
          hide: this.$route.params.status !== 1 || !this.$store.state.managerInfo.isLeader
        }
      },
      listData: [],
      selectItem: null
    }
  },
  props: {
    auth: Array,
    tag: Object
  },
  provide() {
    return {
      auth: this.auth,
      tag: this.tag
    }
  },
  components: {
    Review,
    ReviewDistribute
  },
  methods: {
    getListData: throttle(async function(toFirst) {
      let from = toFirst ? 1 : (Math.ceil(this.listData.length / 30) + 1)

      this.loading = true

      let { result } = await this.$http({
        url: '%CRM%/buy/order/list.sdcrm',
        data: {
          token: true,
          size: 30,
          from,
          archivesStatus: this.$route.params.status,
          keyword: this.screen.search ? this.screen.search : undefined,
          reviewer: this.$route.params.status === 1 ? (this.$store.state.managerInfo.isLeader ? undefined : this.$store.state.managerInfo.id) : undefined
        }
      })

      this.loading = false

      if(from === 1) {
        this.listData = result.records
      }else{
        this.listData = [...this.listData, ...result.records]
      }

      if(!this.selectItem && this.listData.length) {
        this.selectItem = this.listData[0]
      }
    }),
    async reviewSuccess() {
      let index = this.listData.indexOf(this.selectItem)

      await this.getListData(true)

      if(this.listData.length) {
        this.selectItem = this.listData[index] ?? this.listData[this.listData.length - 1]
      }else{
        this.selectItem = null
      }
    },
    getOrder: throttle(async function() {
      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/buy/order/order_review_distribute.sdcrm',
        data: {
          token: true,
          num: this.maxLength - this.listData.length
        }
      })

      if(code !== 8200) {
        this.$message.error(`获取失败：${msg || errmsg}`)
        return
      }
      
      this.$message.success('获取成功')
      this.getListData()
    }),
    showMore(event) {
      this.$contextmenu({
        event,
        menu: [
          {
            icon: 'el-icon-copy-document',
            title: '分配营销档案',
            handler: () => {
              this.showPopover = true
            }
          },
        ]
      })
    }
  },
  beforeRouterEnter(to, from, next) {
    if(!to.params.status) {
      next({
        name: 'ai-marketing_record'
      })
    }else{
      next()
    }
  }
}
</script>
<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.view {
  width: 100%;
  height: 100%;
  padding: 24px 0;
  box-sizing: border-box;
  display: flex;
  .select-box {
    width: 308px;
    height: 100%;
    background: #FFF;
    /deep/ {
      .screen-box { padding: 0;}
    }
    .screen {
      margin-top: 0;
      padding: 12px 12px;
      box-sizing: border-box;
      background: #F6F6F6;
      width: 100%;
      /deep/ {
        .screen-item {
          margin-top: 0;
          .el-input { width: 200px;}
        }
      }
    }
    .list-box {
      .item {
        display: flex;
        align-items: center;
        margin: 0 24px;
        line-height: 50px;
        font-size: 14px;
        border-bottom: 1px solid #EEE;
        cursor: pointer;
        &.active {
          margin: 0;
          padding: 0 24px;
          background: rgba($--color-main, .2);
          color: $--color-main;
        }
        &::before {
          content: "";
          width: 2px;
          height: 14px;
          background: $--color-main;
          margin-right: 4px;
        }
        span:last-child { margin-left: auto;}
      }
    }
    .get-order {
      margin: 24px auto;
      display: block;
    }
  }
  .review-box {
    flex-grow: 1;
    flex-basis: 0;
  }
}
</style>