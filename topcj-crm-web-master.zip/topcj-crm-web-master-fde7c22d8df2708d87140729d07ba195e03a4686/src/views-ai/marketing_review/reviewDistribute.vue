<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      分配{{type === 1 ? '营销' : '服务'}}档案
    </template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
      >分 配</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        num: 1,
        reviewer: ''
      },
      config: {
        reviewer: {
          type: 'select-manager',
          label: '分配员工',
          filter: {
            managerType: 4,
            corpId: 0,
            isLock: 0
          },
          rule:[
            { required: true }
          ]
        },
        num: {
          type: 'number',
          label: '分配数量',
          min: 1,
          rule:[
            { required: true }
          ]
        }
      }
    }
  },
  props: {
    show: Boolean,
    type: Number
  },
  methods:{
    close() {
      this.$emit('update:show', false)
    },
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      let { code, msg, errmsg } = await this.$http({
        url: this.type === 1 ? '%CRM%/buy/order/order_review_distribute.sdcrm' : '%CRM%/user/service_review_distribute.sdcrm',
        data: {
          token: true,
          num: this.form.num,
          reviewer: this.form.reviewer
        }
      })

      if(code !== 8200) {
        this.$message.error(`分配失败：${msg || errmsg}`)
        return
      }
      
      this.$message.success('分配成功')
      this.close()
    })
  }
}
</script>