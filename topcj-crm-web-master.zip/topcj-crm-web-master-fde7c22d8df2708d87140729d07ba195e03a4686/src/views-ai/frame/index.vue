<template>
  <div class="ai-frame">
    <div class="top-box">
      <div class="logo"></div>
      <navigation @nav="selectNav" />
      <top-info />
    </div>
    <div class="bottom-box">
      <router-view 
        v-if="nav.auth"
        class="view-box"
        :auth="nav.auth"
        :nav="nav"
        :tag="tagList"
        :key="$route.name"
      />
    </div>
  </div>
</template>

<script>
import navigation from './navigation'
import TopInfo from './topInfo'

export default {
  data() {
    return {
      nav: {},
      tagList: {},
    }
  },
  components: {
    navigation,
    TopInfo
  },
  methods: {
    selectNav(nav) {
      //导航
      this.nav = nav

      let group = this.$store.state.baseData.tagTreeList.filter(e => !e.navId || e.navId === nav.id)
      let tagList = {}
      let sysModeFlag = this.$store.state.sysMode === 2
      group.forEach(e => {
        e.labels.forEach(e => {
          tagList[`t${e.id}`] = e.values.map(e => {
            tagList[`v${e.id}`] ={
              ...e,
              visible: sysModeFlag ? e.visible : 1
            }
            return {
              ...e,
              visible: sysModeFlag ? e.visible : 1
            }
          })
        })
      })
      this.tagList = tagList

      this.$store.commit('setNav', nav)

      this.$log(5, 1, 1, nav.id)
    }
  },
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.ai-frame {
  width: 100%;
  height: 100%;
  .top-box {
    height: 64px;
    background: #28292B;
    padding: 0 calc(50vw - 808px);
    display: flex;
    align-items: center;
    .logo {
      width: 113px;
      height: 26px;
      @include image(ai_logo);
      margin-right: 50px;
    }
  }
  .bottom-box {
    position: relative;
    width: 100%;
    height: calc(100% - 64px);
    .view-box {
      position: relative;
      width: 100%;
      height: 100%;
      padding-left: calc(50vw - 808px);
      padding-right: calc(50vw - 808px);
      background: #F0F2F5;
      box-sizing: border-box;
    }
  }
}
</style>
