<template>
  <div class="user">
    <el-dropdown @command="command">
      <span class="el-dropdown-link">
        <div 
          class="headimg"
          :style="{backgroundImage: `url(${managerInfo.avatarPath || managerHead})`}"
        ></div>
        {{managerInfo.realName}}
      </span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item command="openim">去顶点通</el-dropdown-item>
        <el-dropdown-item command="logout">退出登录</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  
  </div>
</template>

<script>
import managerHead from '../../assets/images/headimg_manager.png'

export default {
  data() {
    return {
      managerHead
    }
  },
  props: {
    navLabel: String
  },
  computed: {
    managerInfo() {
      return this.$store.state.managerInfo
    },
  },
  methods: {
    command(type) {
      switch(type) {
        case 'openim': 
          window.open(`${this.SYS.IMURL}/gm?token=${this.$store.state.token}`)
          break
        case 'logout': 
          this.$store.commit('setToken',null)
          break
      }
    }
  }
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.user {
  margin-left: auto;
  margin-right: 24px;
  .el-dropdown-link {
    display: flex;
    cursor: pointer;
    color: #FFF;
    line-height: 40px;
  }
  .headimg {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 12px;
    @include cover;
  }
}
</style>
