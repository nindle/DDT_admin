<!--导航-->
<template>
  <div class="navigation">
    <el-menu 
      :default-active="routePath"
      mode="horizontal"
      router
      @select="select"
    >
      <el-menu-item 
        v-for="e in navList"
        :key="e.linkUrl"
        :index="e.linkUrl"
      >{{e.title}}</el-menu-item>
    </el-menu>
  </div>
</template>

<script>
import { deepcopy } from '../../assets/js/tool'

export default {
  data() {
    return {
      navList: []
    }
  },
  computed: {
    navigationTree() {
      return this.$store.state.baseData.navigationTree
    },
    managerNavigationName() {
      return this.$store.state.baseData.managerNavigation.map(e => e.name)
    },
    managerNavigation() {
      return this.$store.state.baseData.managerNavigation
    },
    routePath() {
      return this.$route.path
    }
  },
  methods: {
    getNav() {
      if(!this.navigationTree.length) return

      this.navList = deepcopy(this.navigationTree.filter(e => e.name === 'ai')[0].children).filter(e => {
        if(e.children && e.children.length) {
          e.children = e.children.filter(a => {
            return this.managerNavigationName.includes(a.name)
          })

          e.auth = e.children.map(e => {
            return e.name.substring(e.name.lastIndexOf('_') + 1)
          })

          return e.children.length
        }else{
          return this.managerNavigationName.includes(e.name)
        }
      })

      if(!this.navList.map(e => e.linkUrl).includes(this.routePath)) {
        this.$router.replace({
          name: 'ai'
        })
      }else{
        this.select(this.routePath)
      }
    },
    select(path) {
      let item = this.navList.filter(e => e.linkUrl === path)[0]
      this.$emit('nav', item)
    },
  },
  watch: {
    navigationTree: {
      immediate: true,
      handler() {
        this.getNav()
      }
    }
  }
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.navigation {
  /deep/ {
    .el-menu{
      background-color: transparent !important;
      &.el-menu--horizontal { border-bottom: none;}
      .el-menu-item {
        font-size: 16px;
        height: 24px;
        line-height: 24px;
        padding: 0;
        margin-right: 40px;
        box-sizing: content-box;
        background-color: transparent !important;
        color: rgba(#FFF, .65) !important;
        &.is-active { 
          font-weight: bold;
          color: $--color-main !important;
        }
      }
    }
  }
}
</style>
