import Vue from 'vue'
import VueRouter from 'vue-router'
import { SYS } from '../assets/js/http'

Vue.use(VueRouter)

//公共页面
const common = [
  //重定向到登录
  {
    path: '/',
    redirect: '/login'
  },
  //登录
  {
    path: '/login',
    name: 'login',
    meta: {
      noauth: true
    },
    component: () => import('../views/login/index.vue')
  }
]

//其他页面
const other = [
  //资讯预览
  {
    path: '/news',
    name: 'news',
    meta: {
      nologin: true,
      title: '',
      noauth: true
    },
    component: () => import('../views/news/index.vue')
  },
  //消息预警
  {
    path: '/qywx/message_warning',
    name: 'qywx-message_warning',
    meta: {
      title: '消息预警',
      noauth: true
    },
    component: () => import('../views-gm/message_warning/index.vue')
  },
  //年会出题系统
  // {
  //   path: '/nh/question',
  //   name: 'nh-question',
  //   meta: {
  //     nologin: true,
  //     title: '年会出题系统'
  //   },
  //   component: () => import('../views/nh-question/index.vue')
  // }
  // 未成交用户聊天记录
  {
    path: '/qywx/chatrecord',
    name: 'qywx-chatrecord',
    meta: {
      noauth: true,
      title: '未成交留痕监控'
    },
    component: () => import('../views-gm/chatrecord/index.vue')
  },
  // 证券从业人员统计
  {
    path: '/securities_practice',
    name: 'securities_practice',
    meta: {
      noauth: true,
      title: '从业资质数据统计'
    },
    component: () => import('../views-gm/securities_practice/index.vue')
  },
  // 企业微信资讯展现
  {
    path: '/qywx/article/:id',
    name: 'qywx-article',
    meta: {
      noauth: true,
      title: '资讯内容',
      preview: false
    },
    component: () => import('../views-gm/add_article/page.vue')
  },
  // 企业微信资讯展现
  {
    path: '/qywx/article/preview/:id',
    name: 'qywx-article-preview',
    meta: {
      noauth: true,
      title: '资讯内容预览',
      preview: true
    },
    component: () => import('../views-gm/add_article/page.vue')
  },
  // 企业微信入职信息填报
  {
    path: '/qywx/myInfo',
    name: 'qywx-myInfo',
    meta: {
      noauth: true,
      title: '入职信息'
    },
    component: () => import('../views-gm/myInfo/index.vue')
  },
  // 企业微信入职信息填报
  {
    path: '/qywx/top_system',
    name: 'qywx-top_system',
    meta: {
      noauth: true,
      title: '顶点制度'
    },
    component: () => import('../views-gm/top_system/page.vue')
  }
]

/*
routeName，组件名要相同
*/

//管理端
const gm = [
  {
    path: '/gm',
    name: 'gm',
    component: () => import('../views-gm/frame/index.vue'),
    children: [
      //企业微信
      {
        path: '/gm/qywx-next',
        name: 'gm-qywx-next',
        component: () => import('../views-gm/qywx/index.vue')
      },
      //黑名单
      {
        path: '/gm/blacklist',
        name: 'gm-blacklist',
        component: () => import('../views-gm/blacklist/index.vue')
      },
      //敏感词过滤
      {
        path: '/gm/sensitive',
        name: 'gm-sensitive',
        component: () => import('../views-gm/sensitive/index.vue')
      },
      //舆情监控列表
      {
        path: '/gm/consensus',
        name: 'gm-consensus',
        component: () => import('../views-gm/consensus/index.vue')
      },
      //花名册
      {
        path: '/gm/Roster',
        name: 'gm-roster',
        meta: {
          type: 1
        },
        component: () => import('../views-gm/roster/index.vue')
      },
      //财务资料
      {
        path: '/gm/cairoster',
        name: 'gm-cairoster',
        meta: {
          type: 2
        },
        component: () => import('../views-gm/roster/index-2.vue')
      },
      //元声资源报表
      {
        path: '/gm/resource_report',
        name: 'gm-resource_report',
        component: () => import('../views-gm/resource_report/index.vue')
      },
      //一般证券名单
      {
        path: '/gm/staff',
        name: 'gm-staff',
        component: () => import('../views-gm/staff/index.vue')
      },
      //退费汇总
      {
        path: '/gm/refundSummary',
        name: 'gm-refund_summary',
        component: () => import('../views-gm/refund_summary/index.vue')
      },
      //隐私协议
      {
        path: '/gm/Privacy',
        name: 'gm-privacy',
        component: () => import('../views-gm/privacy/index.vue')
      },
      //产品清单明细
      {
        path: '/gm/ProductList',
        name: 'gm-product_list',
        component: () => import('../views-gm/product_list/index.vue')
      },
      //产品登录
      {
        path: '/gm/loginsort',
        name: 'gm-loginsort',
        component: () => import('../views-gm/loginsort/index.vue')
      },
      //退费管理
      {
        path: '/gm/refund',
        name: 'gm-refund',
        component: () => import('../views-gm/refund/index.vue')
      },
      //资源分配
      {
        path: '/gm/admin_Branch',
        name: 'gm-admin_branch',
        component: () => import('../views-gm/admin_branch/index.vue')
      },
      //课程编排
      {
        path: '/gm/course',
        name: 'gm-course',
        component: () => import('../views-gm/course/index.vue')
      },
      //业绩汇总
      {
        path: '/gm/businessReport',
        name: 'gm-business_report',
        component: () => import('../views-gm/business_report/index.vue')
      },
      //审核员配置
      {
        path: '/gm/typeReviewer',
        name: 'gm-type_reviewer',
        component: () => import('../views-gm/type_reviewer/index.vue')
      },
      //栏目分类
      {
        path: '/gm/section',
        name: 'gm-section',
        component: () => import('../views-gm/section/index.vue')
      },
      //个股解答
      {
        path: '/gm/80unravel',
        name: 'gm-80unravel',
        component: () => import('../views-gm/80unravel/index.vue')
      },
      //服务覆盖
      {
        path: '/gm/servecover',
        name: 'gm-servecover',
        component: () => import('../views-gm/servecover/index.vue')
      },
      //产品权限
      {
        path: '/gm/classroom',
        name: 'gm-classroom',
        component: () => import('../views-gm/classroom/index.vue')
      },
      {
        path: '/gm/class_group',
        name: 'gm-class_group',
        component: () => import('../views-gm/class_group/index.vue')
      },
      //黑名单库
      {
        path: '/gm/blackuserlist',
        name: 'gm-blackuserlist',
        component: () => import('../views-gm/blackuserlist/index.vue')
      },
      //人员管理
      {
        path: '/gm/usermanager',
        name: 'gm-usermanager',
        component: () => import('../views-gm/usermanager/index.vue')
      },
      //套餐管理
      {
        path: '/gm/package',
        name: 'gm-package',
        component: SYS.ENV === 'prod' 
          ? () => import('../views-gm/package/index.vue')
          : () => import('../views-gm/package.next/index.vue')
      },
      //评分体系
      {
        path: '/gm/lessminute',
        name: 'gm-lessminute',
        component: () => import('../views-gm/lessminute/index.vue')
      },
      //内控管理
      {
        path: '/gm/audit_List',
        name: 'gm-audit_list',
        component: () => import('../views-gm/audit_list/index.vue')
      },
      {
        path: '/gm/audit_List_1',
        name: 'gm-audit_list-type-1',
        meta: {
          type: 1
        },
        component: () => import('../views-gm/audit_list/index-1.vue')
      },
      {
        path: '/gm/audit_List_2',
        name: 'gm-audit_list-type-2',
        meta: {
          type: 2
        },
        component: () => import('../views-gm/audit_list/index-2.vue')
      },
      {
        path: '/gm/audit_List_4',
        name: 'gm-audit_list-type-4',
        meta: {
          type: 4
        },
        component: () => import('../views-gm/audit_list/index-4.vue')
      },
      // 产品续费
      {
        path: '/gm/updataReport',
        name: 'gm-updataReport',
        component: () => import('../views-gm/updata_report/index.vue')
      },
      // 资源产出-业绩报表
      {
        path: '/gm/resourceresult',
        name: 'gm-resourceresult',
        component: () => import('../views-gm/resource_result/index.vue')
      },
      //推广策划
      {
        path: '/gm/banner',
        name: 'gm-banner',
        component: () => import('../views-gm/banner.next/index.vue')
      },
      //APP活动策划
      {
        path: '/gm/activity',
        name: 'gm-activity',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/activity/index.vue')
      },
      // 推广页面
      {
        path: '/gm/extension',
        name: 'gm-extension',
        component: () => import('../views-gm/extension/index.vue')
      },
      //热点选股
      {
        path: '/gm/hotspot',
        name: 'gm-hotspot',
        component: () => import('../views-gm/hotspot/index.vue')
      },
      //售后预警
      // {
      //   path:'/gm/servicemap',
      //   name:'gm-servicemap',
      //   component: () => import('../views-gm/servicemap/index.vue')
      // },
      //直播创建
      {
        path: '/gm/liveroom',
        name: 'gm-liveroom',
        component: () => import('../views-gm/liveroom/index.vue')
      },
      //直播间互动
      {
        path: '/gm/chatroom',
        name: 'gm-chatroom',
        meta: {
          hideNav: true,
          hideAI: true
        },
        component: () => import('../views-gm/chatroom/index.vue')
      },
      //资讯公告
      {
        path: '/gm/news',
        name: 'gm-news',
        component: () => import('../views-gm/news/index.vue')
      },
      //证券月报
      {
        path: '/gm/dataTrace',
        name: 'gm-data_trace',
        component: () => import('../views-gm/data_trace/index.vue')
      },
      //数据看板
      {
        path: '/gm/datacenter',
        name: 'gm-datacenter',
        component: () => import('../views-gm/datacenter/index.vue')
      },
      // 用户权限
      {
        path: '/gm/user_rights',
        name: 'gm-user_rights',
        component: () => import('../views-gm/user_rights/index.vue')
      },
      // 银行流水
      {
        path: '/gm/fina_entry',
        name: 'gm-fina_entry',
        component: () => import('../views-gm/fina_entry/index.vue')
      },
      // 合同查找
      {
        path: '/gm/fina_url',
        name: 'gm-fina_url',
        component: () => import('../views-gm/fina_url/index.vue')
      },
      // 订单详情（开票/退费）
      {
        path: '/gm/orderDetails',
        name: 'gm-orderDetails',
        component: () => import('../views-gm/order_details/index.vue')
      },
      // 手绘视频
      // {
      //   path: '/gm/painting',
      //   name: 'gm-painting',
      //   meta: {
      //     name: 'painting'
      //   },
      //   component: () => import('../views-gm/video/index.vue')
      // },
      // 视频审核
      {
        path: '/gm/video',
        name: 'gm-video',
        meta: {
          name: 'video'
        },
        component: () => import('../views-gm/video/index.vue')
      },
      // 直播审核推流
      {
        path: '/gm/live_open',
        name: 'gm-live_open',
        component: () => import('../views-gm/live_open/index.vue')
      },
      // 产品选股
      {
        path: '/gm/selectstock',
        name: 'gm-selectstock',
        component: () => import('../views-gm/selectstock/index.vue')
      },
      // 企业微信外部联系人统计报表
      {
        path: '/gm/qywxContactReport',
        name: 'gm-qywx_contact_report',
        component: () => import('../views-gm/qywx_contact_report/index.vue')
      },
      // 配置同步发送
      {
        path: '/gm/maintenancesend',
        name: 'gm-maintenancesend',
        component: () => import('../views-gm/maintenancesend/index.vue')
      },
      // 策略池
      {
        path: '/gm/strategy',
        name: 'gm-strategy',
        component: () => import('../views-gm/strategy/index.vue')
      },
      // 指标选股
      {
        path: '/gm/screening',
        name: 'gm-screening',
        component: () => import('../views-gm/screening/index.vue')
      },
      // 数据监控
      {
        path: '/gm/coreData',
        name: 'gm-coreData',
        component: () => import('../views-gm/coreData/index.vue')
      },
      // 企业微信报表-总计表
      {
        path: '/gm/wkTotalReport',
        name: 'gm-wk_total_report',
        component: () => import('../views-gm/wk_total_report/index.vue')
      },
      // 企业微信外部联系人报表
      {
        path: '/gm/wkPartContactReport',
        name: 'gm-wk_part_contact_report',
        component: () => import('../views-gm/wk_part_contact_report/index.vue')
      },
      // 营销图库
      {
        path: '/gm/marketimage',
        name: 'gm-marketimage',
        component: () => import('../views-gm/marketimage/index.vue')
      },
      // 投诉处理
      {
        path: '/gm/complaint',
        name: 'gm-complaint',
        component: () => import('../views-gm/complaint/index.vue')
      },
      // 加专属号
      {
        path: '/gm/exclusive',
        name: 'gm-exclusive',
        component: () => import('../views-gm/exclusive/index.vue')
      },
      // 手机录音报表
      {
        path: '/gm/imei_report',
        name: 'gm-imei_report',
        component: () => import('../views-gm/imei_report/index.vue')
      },
      {
        path: '/gm/liveReport',
        name: 'gm-live_report',
        component: () => import('../views-gm/live_report/index.vue')
      },
      // 分公司管理
      {
        path: '/gm/corp_list',
        name: 'gm-corp_list',
        component: () => import('../views-gm/corp_list/index.vue')
      },
      // 一分报表人数统计
      {
        path: '/gm/oneReportStatistics',
        name: 'gm-one_report_statistics',
        component: () => import('../views-gm/one_report_statistics/index.vue')
      },
      // 角色管理
      {
        path: '/gm/role',
        name: 'gm-role',
        component: () => import('../views-gm/role/index.vue')
      },
      // 群发列表
      {
        path: '/gm/groupmsglist',
        name: 'gm-groupmsglist',
        component: () => import('../views-gm/groupmsglist/index.vue')
      },
      // 企业微信工作台报表
      {
        path: '/gm/wkWorkReport',
        name: 'gm-wk_work_report',
        component: () => import('../views-gm/wk_work_report/index.vue')
      },
      // 员工资源报表
      {
        path: '/gm/setStaffReport',
        name: 'gm-setStaffReport',
        component: () => import('../views-gm/setStaffReport/index.vue')
      },
      // 用户搜索
      {
        path: '/gm/customer',
        name: 'gm-customer',
        component: () => import('../views-gm/customer/index.vue')
      },
      {
        path: '/gm/customer_1',
        name: 'gm-customer-type-1',
        meta: {
          type: 1
        },
        component: () => import('../views-gm/customer/index-1.vue')
      },
      {
        path: '/gm/customer_2',
        name: 'gm-customer-type-2',
        meta: {
          type: 2
        },
        component: () => import('../views-gm/customer/index-2.vue')
      },
      {
        path: '/gm/customer_4',
        name: 'gm-customer-type-4',
        meta: {
          type: 4
        },
        component: () => import('../views-gm/customer/index-4.vue')
      },
      // 用户搜索
      {
        path: '/gm/maintenanceapp',
        name: 'gm-maintenanceapp',
        component: () => import('../views-gm/maintenanceapp/index.vue')
      },
      // 企业微信应用菜单配置
      {
        path: '/gm/wechatMenu',
        name: 'gm-wechatMenu',
        component: () => import('../views-gm/wechatMenu/index.vue')
      },
      // 渠道导入
      {
        path: '/gm/importres',
        name: 'gm-importres',
        component: () => import('../views-gm/importres/index.vue')
      },
      // 菜单管理
      {
        path: '/gm/navigation',
        name: 'gm-navigation',
        component: () => import('../views-gm/navigation/index.vue')
      },
      // 头像库
      {
        path: '/gm/headroom',
        name: 'gm-headroom',
        component: () => import('../views-gm/headroom/index.vue')
      },
      // 大家都在搜
      {
        path: '/gm/hotsearch',
        name: 'gm-hotsearch',
        component: () => import('../views-gm/hotsearch/index.vue')
      },
      // 在线咨询
      {
        path: '/gm/onlinemsg',
        name: 'gm-onlinemsg',
        component: () => import('../views-gm/onlinemsg/index.vue')
      },
      // 在线咨询-讲师
      {
        path: '/gm/online_teacher',
        name: 'gm-online_teacher',
        component: () => import('../views-gm/online_teacher/index.vue')
      },
      // 私信反馈
      {
        path: '/gm/feedback',
        name: 'gm-feedback',
        component: () => import('../views-gm/feedback/index.vue')
      },
      // 资源产出-资源数量
      {
        path: '/gm/resourcecount',
        name: 'gm-resourcecount',
        component: () => import('../views-gm/resource_count/index.vue')
      },
      // 员工列表
      {
        path: '/gm/addressbook',
        name: 'gm-addressbook',
        component: () => import('../views-gm/addressbook/index.vue')
      },
      // 机会选股
      {
        path: '/gm/chance_stock',
        name: 'gm-chance_stock',
        component: () => import('../views-gm/chance_stock/index.vue')
      },
      // 版本列表
      {
        path: '/gm/version_list',
        name: 'gm-version-list',
        component: () => import('../views-gm/version_list/index.vue')
      },
      // 建群预警
      {
        path: '/gm/groupmonitor',
        name: 'gm-groupmonitor',
        component: () => import('../views-gm/groupmonitor/index.vue')
      },
      // 档案预建
      {
        path: '/gm/orderreview',
        name: 'gm-orderreview',
        component: () => import('../views-gm/orderreview/index.vue')
      },
      // 外部联系人详情列表
      {
        path: '/gm/extcontact_detail',
        name: 'gm-extcontact_detail',
        component: () => import('../views-gm/extcontact_detail/index.vue')
      },
      // 企微监控数据
      {
        path: '/gm/qywx_monitor',
        name: 'gm-qywx_monitor',
        component: () => import('../views-gm/qywx_monitor/index.vue')
      },
      {
        path: '/gm/screening_detail',
        name: 'gm-screening_detail',
        meta: {
          basePath: '/gm/screening'
        },
        component: () => import('../views-gm/screening_detail/index.vue')
      },
      // 消息预警
      {
        path: '/gm/message_warning',
        name: 'gm-message_warning',
        component: () => import('../views-gm/message_warning/index.vue')
      },
      // 客诉列表
      {
        path: '/gm/qywx_warning',
        name: 'gm-qywx_warning',
        component: () => import('../views-gm/qywx_warning/index.vue')
      },
      // 素材库
      // {
      //   path: '/gm/assets',
      //   name: 'gm-assets_depot',
      //   component: () => import('../views-gm/assetsDepot/index.vue')
      // },
      // 素材库
      {
        path: '/gm/assets_next',
        name: 'gm-assets_depot_next',
        component: () => import('../views-gm/assetsDepot/index.vue')
      },
      //客诉录音列表
      {
        path: '/gm/complaint_recording',
        name: 'gm-complaint_recording',
        component: () => import('../views-gm/complaint_recording/index.vue')
      },
      // 工作台自动回复
      {
        path: '/gm/auto_responder',
        name: 'gm-auto_responder',
        component: () => import('../views-gm/auto_responder/index.vue')
      },
      // 证件审核
      {
        path: '/gm/certificates',
        name: 'gm-certificates',
        component: () => import('../views-gm/certificates.prev/index.vue')
      },
      {
        path: '/gm/certificates_first',
        name: 'gm-certificates-1',
        component: () => import('../views-gm/certificates/index-1.vue')
      },
      {
        path: '/gm/certificates_second',
        name: 'gm-certificates-2',
        component: () => import('../views-gm/certificates/index-2.vue')
      },
      // 产品商城
      {
        path: '/gm/productshop',
        name: 'gm-productshop',
        component: () => import('../views-gm/productshop/index.vue')
      },
      // 合同查找-新流程 产品开通
      {
        path: '/gm/fina_url_new',
        name: 'gm-fina_url_new',
        component: () => import('../views-gm/fina_url_new/index.vue')
      },
      // 不结算-违规订单
      {
        path: '/gm/violation_order',
        name: 'gm-violation_order',
        component: () => import('../views-gm/violation_order/index.vue')
      },
      // 不结算-统计列表
      {
        path: '/gm/statistics_list',
        name: 'gm-statistics_list',
        component: () => import('../views-gm/statistics_list/index.vue')
      },
      {
        path: '/gm/corp_source',
        name: 'gm-corp_source',
        component: () => import('../views-gm/corpSource/index.vue')
      },
      // 风险识别
      {
        path: '/gm/risk_identification',
        name: 'gm-risk_identification',
        component: () => import('../views-gm/risk_identification/index.vue')
      },
      // 指标维护
      {
        path: '/gm/screening_modify',
        name: 'gm-screeningModify',
        component: () => import('../views-gm/screening_modify/index.vue')
      },
      // 全天退费列表
      {
        path: '/gm/refund_list',
        name: 'gm-refund_list',
        component: () => import('../views-gm/refund_list/index.vue')
      },
      // 退费列表-新
      {
        path: '/gm/refund_list_next',
        name: 'gm-refund_list_next',
        component: () => import('../views-gm/refund_list_next/index.vue')
      },
      // 埋点
      {
        path: '/gm/burying_point',
        name: 'gm-burying_point',
        component: () => import('../views-gm/burying_point/index.vue')
      },
      // 标准话术文本库
      {
        path: '/gm/text_library',
        name: 'gm-text_library',
        component: () => import('../views-gm/text_library/index.vue')
      },
      // 备案号码库
      {
        path: '/gm/number_library',
        name: 'gm-number_library',
        component: () => import('../views-gm/number_library/index.vue')
      },
      // 订单管理
      {
        path: '/gm/order_management',
        name: 'gm-order_management',
        component: () => import('../views-gm/order_management/index.vue')
      },
      //订单退款
      {
        path: '/gm/order_refund',
        name: 'gm-order_refund',
        component: () => import('../views-gm/order_refund/index.vue')
      },
      // 录音查询
      {
        path: '/gm/recording_query',
        name: 'gm-recording_query',
        component: () => import('../views-gm/recording_query/index.vue')
      },
      // 坐席统计
      {
        path: '/gm/seat',
        name: 'gm-seat',
        component: () => import('../views-gm/seat/index.vue')
      },
      // 业绩报表
      {
        path: '/gm/salesreport',
        name: 'gm-salesreport',
        component: () => import('../views-gm/salesreport/index.vue')
      },
      // 外部联系人
      {
        path: '/gm/extcontact',
        name: 'gm-extcontact',
        component: () => import('../views-gm/extcontact/index.vue')
      },
      // 发工作台
      {
        path: '/gm/group',
        name: 'gm-group',
        component: () => import('../views-gm/group/index.vue')
      },
      // 档案复审
      {
        path: '/gm/recorddot',
        name: 'gm-recorddot',
        component: () => import('../views-gm/recorddot/index.vue')
      },
      // 档案中心
      {
        path: '/gm/recordcenter',
        name: 'gm-recordcenter',
        component: () => import('../views-gm/recordcenter/index.vue')
      },
      // 档案原消息记录
      {
        path: '/gm/recordhistory',
        name: 'gm-recordhistory',
        component: () => import('../views-gm/recordhistory/index.vue')
      },
      // 接口域名配置
      {
        path: '/gm/apiconfig',
        name: 'gm-apiconfig',
        component: () => import('../views-gm/api_config/index.vue')
      },
      // 推广渠道管理
      {
        path: '/gm/res_channel_list',
        name: 'gm-res_channel_list',
        component: () => import('../views-gm/res_channel_list/index.vue')
      },
      // 推广商管理
      {
        path: '/gm/promoter_list',
        name: 'gm-promoter_list',
        component: () => import('../views-gm/promoter_list/index.vue')
      },
      // 推广账户管理
      {
        path: '/gm/res_account_list',
        name: 'gm-res_account_list',
        component: () => import('../views-gm/res_account_list/index.vue')
      },
      // 推广成本管理
      {
        path: '/gm/promotion_cost',
        name: 'gm-promotion_cost',
        component: () => import('../views-gm/promotion_cost/index.vue')
      },
      // 分类管理
      {
        path: '/gm/category_list',
        name: 'gm-category_list',
        component: () => import('../views-gm/category_list/index.vue')
      },
      // 产品功能管理
      {
        path: '/gm/function',
        name: 'gm-function',
        component: () => import('../views-gm/function/index.vue')
      },
      // 未成交用户预警
      {
        path: '/gm/warning_msg',
        name: 'gm-warning_msg',
        component: () => import('../views-gm/warning_msg/index.vue')
      },
      // 违规点数据统计
      {
        path: '/gm/filing_review',
        name: 'gm-filing_review',
        component: () => import('../views-gm/filing_review/index.vue')
      },
      // 推广二维码管理
      {
        path: '/gm/qr_code_management',
        name: 'gm-qr_code_management',
        component: () => import('../views-gm/qr_code_management/index.vue')
      },
      // 优惠券
      {
        path: '/gm/coupon',
        name: 'gm-coupon',
        component: () => import('../views-gm/coupon/index.vue')
      },
      // 创建推广页
      {
        path: '/gm/spread',
        name: 'gm-spread',
        component: () => import('../views-gm/spread/index.vue')
      },
      // 推广埋点
      {
        path: '/gm/popularize',
        name: 'gm-popularize',
        component: () => import('../views-gm/popularize/index.vue')
      },
      // 微工作台留痕
      {
        path: '/gm/work_report',
        name: 'gm-work_report',
        component: () => import('../views-gm/work_report/index.vue')
      },
      // 推广测试号
      {
        path: '/gm/test_number',
        name: 'gm-test_number',
        component: () => import('../views-gm/test_number/index.vue')
      },
      // 证券投资咨询机构留痕详细信息
      {
        path: '/gm/zqyb_security',
        name: 'gm-zqyb_security',
        component: () => import('../views-gm/zqyb_security/index.vue')
      },
      // 利润表
      // {
      //   path: '/gm/zqyb_rpt_profile_list',
      //   name: 'gm-zqyb_rpt_profile_list',
      //   component: () => import('../views-gm/zqyb_rpt_profile_list/index.vue')
      // },
      // 投资顾问业务汇总情况
      {
        path: '/gm/zqyb_invest_business',
        name: 'gm-zqyb_invest_business',
        component: () => import('../views-gm/zqyb_invest_business/index.vue')
      },
      // 投资顾问业务其他情况
      {
        path: '/gm/zqyb_other_invest',
        name: 'gm-zqyb_other_invest',
        component: () => import('../views-gm/zqyb_other_invest/index.vue')
      },
      // 投资顾问业务其他情况Data
      {
        path: '/gm/zqyb_other_data',
        name: 'gm-zqyb_other_data',
        component: () => import('../views-gm/zqyb_other_data/index.vue')
      },
      // 企业微信配置会话存档成员
      {
        path: '/gm/qywx_talk_member_list',
        name: 'gm-qywx_talk_member_list',
        component: () => import('../views-gm/qywx_talk_member_list/index.vue')
      },
      // 现金流量表
      // {
      //   path: '/gm/zqrb_cash_flow',
      //   name: 'gm-zqrb_cash_flow',
      //   component: () => import('../views-gm/zqrb_cash_flow/index.vue')
      // },
      // 文章发布
      {
        path: '/gm/add_article',
        name: 'gm-add_article',
        component: () => import('../views-gm/add_article/index.vue')
      },
      // 顶点制度
      {
        path: '/gm/top_system',
        name: 'gm-top_system',
        component: () => import('../views-gm/top_system/index.vue')
      },
      // 九分业绩报告
      {
        path: '/gm/nine_business_report',
        name: 'gm-nine_business_report',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/nine_business_report/index.vue')
      },
      // 证券投资咨询机构已登记的从业人员
      {
        path: '/gm/zqyb_register_info',
        name: 'gm-zqyb_register_info',
        component: () => import('../views-gm/zqyb_register_info/index.vue')
      },
      // 证券投资咨询机构业务各岗位人员
      {
        path: '/gm/zqyb_investment_post',
        name: 'gm-zqyb_investment_post',
        component: () => import('../views-gm/zqyb_investment_post/index.vue')
      },
      // 九分成交明细
      {
        path: '/gm/nine_transaction_details',
        name: 'gm-nine_transaction_details',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/nine_transaction_details/index.vue')
      },
      // 证券投资咨询机构留痕详细信息
      {
        path: '/gm/zqyb_trace_information',
        name: 'gm-zqyb_trace_information',
        component: () => import('../views-gm/zqyb_trace_information/index.vue')
      },
      // 证券投资咨询机构留痕信息
      {
        path: '/gm/zqyb_trace',
        name: 'gm-zqyb_trace',
        component: () => import('../views-gm/zqyb_trace/index.vue')
      },
      // 推广点击量报表
      {
        path: '/gm/popularize_click',
        name: 'gm-popularize_click',
        component: () => import('../views-gm/popularize_click/index.vue')
      },
      // 成交用户好友未删除
      {
        path: '/gm/scrm_follow_user',
        name: 'gm-scrm_follow_user',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/scrm_follow_user/index.vue')
      },
      // 资源分配日志
      {
        path: '/gm/attach_log',
        name: 'gm-attach_log',
        component: () => import('../views-gm/attach_log/index.vue')
      },
      // 客户案例留痕
      {
        path: '/gm/userstock_report',
        name: 'gm-userstock_report',
        component: () => import('../views-gm/userstock_report/index.vue')
      },
      // 客户案例留痕
      {
        path: '/gm/scrm_order_list',
        name: 'gm-scrm_order_list',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/scrm_order_list/index.vue')
      },
      // 客户案例留痕
      {
        path: '/gm/diagnose',
        name: 'gm-diagnose',
        component: () => import('../views-gm/diagnose/index.vue')
      },
      // 预警配置列表
      {
        path: '/gm/warning_manager_list',
        name: 'gm-warning_manager_list',
        component: () => import('../views-gm/warning_manager_list/index.vue')
      },
      // 注册用户
      {
        path: '/gm/register_user',
        name: 'gm-register_user',
        component: () => import('../views-gm/register_user/index.vue')
      },
      // 活码配置列表
      {
        path: '/gm/qywx_scrm_qr_code',
        name: 'gm-qywx_scrm_qr_code',
        component: () => import('../views-gm/qywx_scrm_qr_code/index.vue')
      },
      // APP文章类别
      {
        path: '/gm/news_app_type',
        name: 'gm-news_app_type',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/news_app_type/index.vue')
      },
      // APP消息推送
      {
        path: '/gm/postmessage',
        name: 'gm-postmessage',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/postmessage/index.vue')
      },
      // APP直播审核
      {
        path: '/gm/liveroom_msg_review',
        name: 'gm-liveroom_msg_review',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/liveroom_msg_review/index.vue')
      },
      // APP直播互动
      {
        path: '/gm/liveroom_msg_prev',
        name: 'gm-liveroom_msg_prev',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/liveroom_msg.prev/index.vue')
      },
      {
        path: '/gm/liveroom_msg',
        name: 'gm-liveroom_msg',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/liveroom_msg/index.vue')
      },
      // 阶段业绩-年龄
      {
        path: '/gm/performance_by_age',
        name: 'gm-performance_by_age',
        component: () => import('../views-gm/performance/index-age.vue')
      },
      // 阶段业绩-分公司
      {
        path: '/gm/performance_by_corp',
        name: 'gm-performance_by_corp',
        component: () => import('../views-gm/performance/index-corp.vue')
      },
      // 阶段业绩-地区
      {
        path: '/gm/performance_by_province',
        name: 'gm-performance_by_province',
        component: () => import('../views-gm/performance/index-province.vue')
      },
      // 外部联系人全量查询
      {
        path: '/gm/extcontact_all',
        name: 'gm-extcontact_all',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/extcontact_all/index.vue')
      },
      // 成交用户维护
      {
        path: '/gm/premium_user_flow',
        name: 'gm-premium_user_flow',
        component: () => import('../views-gm/premium_user_flow/index.vue')
      },
      // 资讯关键词
      {
        path: '/gm/newskeyword',
        name: 'gm-newskeyword',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/newskeyword/index.vue')
      },
      // 资讯专题
      {
        path: '/gm/newsspecial',
        name: 'gm-newsspecial',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/newsspecial/index.vue')
      },
      // 违规点列表
      {
        path: '/gm/risk_point_list',
        name: 'gm-risk_point_list',
        component: () => import('../views-gm/risk_point_list/index.vue')
      },
      // 营销审核详表
      {
        path: '/gm/marketing_audit_detail',
        name: 'gm-marketing_audit_detail',
        component: () => import('../views-gm/marketing_audit_detail/index.vue')
      },
      // 服务审核详表
      {
        path: '/gm/service_audit_detail',
        name: 'gm-service_audit_detail',
        component: () => import('../views-gm/service_audit_detail/index.vue')
      },
      // 营销档案总表
      {
        path: '/gm/marketing_file_detail',
        name: 'gm-marketing_file_detail',
        component: () => import('../views-gm/marketing_file_detail/index.vue')
      },
      // 服务档案总表
      {
        path: '/gm/service_file_detail',
        name: 'gm-service_file_detail',
        component: () => import('../views-gm/marketing_file_detail/index-1.vue')
      },
      //APP自选底部推荐
      {
        path: '/gm/recommend',
        name: 'gm-recommend',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/app_bottom_recommend/index.vue')
      },
      //推广二维码预警
      {
        path: '/gm/res_qrcode_detail',
        name: 'gm-res_qrcode_detail',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/res_qrcode_detail/index.vue')
      },
      //推广账号消耗
      {
        path: '/gm/ad_cost_report',
        name: 'gm-ad_cost_report',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/ad_cost_report/index.vue')
      },
      //推广直播数据
      {
        path: '/gm/ad_live_report',
        name: 'gm-ad_live_report',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/ad_live_report/index.vue')
      },
      //推广账号管理
      {
        path: '/gm/ad_account',
        name: 'gm-ad_account',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/ad_account/index.vue')
      },
      //资讯类型管理
      {
        path: '/gm/informationtype',
        name: 'gm-informationtype',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/informationtype/index.vue')
      },
      // 元和客户列表
      {
        path: '/gm/customer_yh',
        name: 'gm-customer_yh',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/customer_yh/index.vue')
      },
      // 元和客户维护报表
      {
        path: '/gm/server_report_yh',
        name: 'gm-server_report_yh',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/server_report_yh/index.vue')
      },
      // 推广小程序主备用
      {
        path: '/gm/res_app_list',
        name: 'gm-res_app_list',
        meta: {
          corp: [0, 19]
        },
        component: () => import('../views-gm/res_app_list/index.vue')
      },
      // 实名图片补传
      {
        path: '/gm/real_name_pic',
        name: 'gm-real_name_pic',
        component: () => import('../views-gm/real_name_pic/index.vue')
      },
      // 购买代金券纪录
      {
        path: '/gm/voucher_record',
        name: 'gm-voucher_record',
        component: () => import('../views-gm/voucher_record/index.vue')
      },
      // 异常退款
      {
        path: '/gm/fina_abnormal',
        name: 'gm-fina_abnormal',
        component: () => import('../views-gm/fina_abnormal/index.vue')
      },
      // 实名客户
      {
        path: '/gm/realname_user',
        name: 'gm-realname_user',
        component: () => import('../views-gm/realname_user/index.vue')
      },
      // 收款权限
      {
        path: '/gm/pay_channel',
        name: 'gm-pay_channel',
        component: () => import('../views-gm/pay_channel/index.vue')
      }
    ]
  }
]

//合规采集系统
const ai = [
  {
    path: '/ai',
    name: 'ai',
    component: () => import('../views-ai/frame/index.vue'),
    children: [
      {
        path: '/ai/order_review',
        name: 'ai-order_review',
        component: () => import('../views-ai/order_review/index.vue')
      },
      {
        path: '/ai/marketing_review',
        name: 'ai-marketing_review',
        component: () => import('../views-ai/marketing_review/index.vue')
      },
      {
        path: '/ai/service_review',
        name: 'ai-service_review',
        component: () => import('../views-ai/service_review/index.vue')
      },
      {
        path: '/ai/marketing_record',
        name: 'ai-marketing_record',
        component: () => import('../views-ai/marketing_record/index.vue')
      },
      {
        path: '/ai/service_record',
        name: 'ai-service_record',
        component: () => import('../views-ai/service_record/index.vue')
      },
      {
        path: '/ai/assets_store',
        name: 'ai-assets_store',
        component: () => import('../views-ai/assets_store/index.vue')
      }
    ]
  }
]

//文档
const doc = [
  {
    path: '/doc',
    name: 'doc',
    component: () => import('../views-doc/frame/index.vue'),
    children: [
      {
        path: '/doc/bus',
        name: 'doc-bus',
        component: () => import('../views-doc/doc-bus/index.vue')
      },
      {
        path: '/doc/md5',
        name: 'doc-md5',
        component: () => import('../views-doc/doc-md5/index.vue')
      },
      {
        path: '/doc/storage',
        name: 'doc-storage',
        component: () => import('../views-doc/doc-storage/index.vue')
      },
      {
        path: '/doc/throttle_debounce',
        name: 'doc-throttle-debounce',
        component: () => import('../views-doc/doc-throttle-debounce/index.vue')
      },
      {
        path: '/doc/deepcopy',
        name: 'doc-deepcopy',
        component: () => import('../views-doc/doc-deepcopy/index.vue')
      },
      {
        path: '/doc/ajax',
        name: 'doc-ajax',
        component: () => import('../views-doc/doc-ajax/index.vue')
      },
      {
        path: '/doc/timeFormat',
        name: 'doc-timeFormat',
        component: () => import('../views-doc/doc-timeFormat/index.vue')
      },
      {
        path: '/doc/copy',
        name: 'doc-copy',
        component: () => import('../views-doc/doc-copy/index.vue')
      },
      {
        path: '/doc/open',
        name: 'doc-open',
        component: () => import('../views-doc/doc-open/index.vue')
      },
      {
        path: '/doc/imageview',
        name: 'doc-imageview',
        component: () => import('../views-doc/doc-imageview/index.vue')
      },
      {
        path: '/doc/scrollbar',
        name: 'doc-scrollbar',
        component: () => import('../views-doc/doc-scrollbar/index.vue')
      },
      {
        path: '/doc/layout',
        name: 'doc-layout',
        component: () => import('../views-doc/doc-layout/index.vue')
      },
      {
        path: '/doc/dialog',
        name: 'doc-dialog',
        component: () => import('../views-doc/doc-dialog/index.vue')
      },
      {
        path: '/doc/table',
        name: 'doc-table',
        component: () => import('../views-doc/doc-table/index.vue')
      }
    ]
  }
]

//数据中心
const datacenter = [
  {
    path: '/dc',
    name: 'dc',
    component: () => import('../views-data/frame/index.vue'),
    children: [
      //APP下载启动情况
      {
        path: '/dc/appdownload',
        name: 'dc-appdownload',
        component: () => import('../views-data/appdownload/index.vue')
      },
      //产品栏目使用
      {
        path: '/dc/appcolumn',
        name: 'dc-appcolumn',
        component: () => import('../views-data/appcolumn/index.vue')
      },
      // 新产品用户活跃情况
      {
        path: '/dc/appuseractivenew',
        name: 'dc-appuseractivenew',
        component: () => import('../views-data/appuseractivenew/index.vue')
      },
      // 新产品用户留存情况
      {
        path: '/dc/appuserkeepnew',
        name: 'dc-appuserkeepnew',
        component: () => import('../views-data/appuserkeepnew/index.vue')
      },
      // 用户留存
      {
        path: '/dc/appuserkeep',
        name: 'dc-appuserkeep',
        component: () => import('../views-data/appuserkeep/index.vue')
      },
      // 策略选股栏目
      {
        path: '/dc/appstrategycolumn',
        name: 'dc-appstrategycolumn',
        component: () => import('../views-data/appstrategycolumn/index.vue')
      },
      // 用户自选股情况
      {
        path: '/dc/userstock',
        name: 'dc-userstock',
        component: () => import('../views-data/userstock/index.vue')
      },
      // 策略运维
      {
        path: '/dc/strategymaintain',
        name: 'dc-strategymaintain',
        component: () => import('../views-data/strategymaintain/index.vue')
      },
      // 官网埋点
      {
        path: '/dc/topcj',
        name: 'dc-topcj',
        component: () => import('../views-data/topcj/index.vue')
      },
      // 产品售卖分布情况
      {
        path: '/dc/salesdistribution',
        name: 'dc-salesdistribution',
        component: () => import('../views-data/salesdistribution/index.vue')
      },
      // 销售总业绩情况
      {
        path: '/dc/salesperformance',
        name: 'dc-salesperformance',
        component: () => import('../views-data/salesperformance/index.vue')
      },
      // 年龄性别分析报表
      {
        path: '/dc/saleagesex',
        name: 'dc-saleagesex',
        component: () => import('../views-data/saleagesex/index.vue')
      },
      // 渠道分析情况
      {
        path: '/dc/saleschannel',
        name: 'dc-saleschannel',
        component: () => import('../views-data/saleschannel/index.vue')
      },
      // 合规分析表
      {
        path: '/dc/qualification',
        name: 'dc-qualification',
        component: () => import('../views-data/qualification/index.vue')
      },
      // 标签管理
      {
        path: '/dc/tags',
        name: 'dc-tags',
        component: () => import('../views-gm/tags/index.vue')
      },
      // 操作日志
      {
        path: '/dc/qylog',
        name: 'dc-qylog',
        component: () => import('../views-data/qylog/index.vue')
      },
      // 搜索日志
      {
        path: '/dc/qylogsearch',
        name: 'dc-qylogsearch',
        component: () => import('../views-data/qylogsearch/index.vue')
      },
      // 次数统计
      {
        path: '/dc/qylogcount',
        name: 'dc-qylogcount',
        component: () => import('../views-data/qylogcount/index.vue')
      }
    ]
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      component: () => import('../views/frame/index.vue'),
      children: [...common, ...other, ...gm, ...ai, ...doc, ...datacenter]
    }
  ]
})

router.beforeEach((to, from, next) => {
  if (to.meta?.noauth || SYS.MODE.indexOf(to.name.split('-')[0]) > -1) {
    next()
  } else {
    next({
      name: SYS.MODE.split('|')[0]
    })
  }
})

export default router
