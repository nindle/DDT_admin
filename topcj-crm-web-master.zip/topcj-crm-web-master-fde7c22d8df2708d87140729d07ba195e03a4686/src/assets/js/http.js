import axios from 'axios'
import store from '../../store/index'
import { storage } from './tool'
import { AesDecrypt, md5 } from './crypto'

//环境
const SYS = {
  //正式模式
  NORMALMODE: true,
  //环境
  ENV: '',
  //链接
  URL: '',
  //网页链接
  WEBURL: '',
  //接口环境
  APIENV: '',
  //接口
  API: {
    TES: 'https://tes.95105899.com/tbdp/stock',
    SDSS: 'https://sdss.topxlc.com/sdss',
    CDSS: 'https://cdss.topxlc.com/cdss',
    CC: 'https://cc2.topxlc.com'
  },
  //企业微信参数
  WK: {
    IN: (function() {
      return /wxwork/i.test(window.navigator.userAgent.toLowerCase())
    })(),
    APP: 'wxbc0108598acfbf05',
    AGENT: ''
  },
  WX: {
    IN: (function() {
      return /micromessenger/i.test(window.navigator.userAgent.toLowerCase())
    })()
  }
}

let hostname = global.location.hostname

if (hostname.indexOf('192.168') === 0) hostname = 'localhost'
if (hostname.indexOf('172.16') === 0) hostname = 'demo-im.topxlc.com'

if (hostname === 'demo-im.topxlc.com' && storage.local('super')) {
  let sign = AesDecrypt(storage.local('super')).split('-')
  if ([368, 369, 609].includes(Number(sign[1]))) {
    hostname = 'localhost'
  }
}

switch (hostname) {
  //测试环境
  case 'demo-im.topxlc.com':
    SYS.ENV = 'dev'
    SYS.URL = global.location.origin
    SYS.WEBURL = 'https://sd-demo-web.topxlc.com'
    SYS.APPZZBURL = 'https://demo-aweb.topcj.com'
    SYS.WEBVIDEOURL = 'https://sd-demo-web.topxlc.com'
    SYS.WEBSPREADURL = 'https://sd-demo-web.topxlc.com/ad'
    SYS.IMURL = 'https://demo-im.topxlc.com'
    SYS.HGURL = 'https://demo-hg.topxlc.com'
    SYS.BOOKURL = 'https://demo-im.topxlc.com'
    SYS.ZZBURL = 'https://demo-aweb.topcj.com'
    SYS.APIENV = 'dev'
    SYS.API.CRM = 'https://demo-sdcrm-api.topxlc.com'
    SYS.API.SD = 'https://demo-api.topxlc.com/sd'
    SYS.API.WC = 'https://demo-wechatreport.topxlc.com'
    SYS.API.WS = 'wss://demo-sdcrm-api.topxlc.com'
    SYS.API.MS = 'https://demo-m-api.topxlc.com'
    SYS.API.ZZB = 'https://demo-app-api.topcj.com'
    SYS.API.TP = 'https://demo-sdcloud.topxlc.com'
    SYS.API.YHTL = 'https://test-textlive.top6xlc.com'
    SYS.WK.AGENT = '1000044'
    SYS.IMAPPID = 1400028938
    SYS.MODE = 'gm|dc'
    SYS.LOGINMODE = ['qr', 'pw', 'wk']
    SYS.REFRESHTOKEN = true
    break
  //采集系统-测试
  case 'demo-hg.topxlc.com':
    SYS.ENV = 'dev'
    SYS.URL = global.location.origin
    SYS.WEBURL = 'https://sd-demo-web.topxlc.com'
    SYS.APPZZBURL = 'https://demo-aweb.topcj.com'
    SYS.WEBVIDEOURL = 'https://sd-demo-web.topxlc.com'
    SYS.WEBSPREADURL = 'https://sd-demo-web.topxlc.com/ad'
    SYS.IMURL = 'https://demo-im.topxlc.com'
    SYS.HGURL = 'https://demo-hg.topxlc.com'
    SYS.BOOKURL = 'https://demo-im.topxlc.com'
    SYS.ZZBURL = 'https://demo-aweb.topcj.com'
    SYS.APIENV = 'dev'
    SYS.API.CRM = 'https://demo-sdcrm-api.topxlc.com'
    SYS.API.SD = 'https://demo-api.topxlc.com/sd'
    SYS.API.WC = 'https://demo-wechatreport.topxlc.com'
    SYS.API.WS = 'wss://demo-sdcrm-api.topxlc.com'
    SYS.API.MS = 'https://demo-m-api.topxlc.com'
    SYS.API.ZZB = 'https://demo-app-api.topcj.com'
    SYS.API.TP = 'https://demo-sdcloud.topxlc.com'
    SYS.API.YHTL = 'https://test-textlive.top6xlc.com'
    SYS.WK.AGENT = '1000049'
    SYS.IMAPPID = 1400028938
    SYS.MODE = 'ai'
    SYS.LOGINMODE = ['qr', 'wk']
    SYS.REFRESHTOKEN = true
    break
  //采集系统-正式
  case 'hg.topxlc.com':
    SYS.ENV = 'prod'
    SYS.URL = global.location.origin
    SYS.WEBURL = 'https://www.topxlc.com'
    SYS.APPZZBURL = 'https://app-web.topcj.com'
    SYS.WEBVIDEOURL = 'https://video.topxlc.com'
    SYS.WEBSPREADURL = 'https://top9b1.topxlc6.com'
    SYS.IMURL = 'https://topcrm.topxlc.com'
    SYS.HGURL = 'https://hg.topxlc.com'
    SYS.BOOKURL = 'https://book.topxlc.com'
    SYS.ZZBURL = 'https://app-web.topcj.com'
    SYS.APIENV = 'prod'
    SYS.API.CRM = 'https://sdcrm-api.topxlc.com'
    SYS.API.SD = 'https://api-sd.topxlc.com/sd'
    SYS.API.WC = 'https://demo-wechatreport.topxlc.com'
    SYS.API.WS = 'wss://sdcrm-api.topxlc.com'
    SYS.API.MS = 'https://topms-api.topxlc.com'
    SYS.API.ZZB = 'https://app-api.topcj.com'
    SYS.API.TP = 'https://p-api.topxlc.com'
    SYS.API.YHTL = 'https://textlive.top6xlc.com'
    SYS.WK.AGENT = '1000086'
    SYS.IMAPPID = ''
    SYS.MODE = 'ai'
    SYS.LOGINMODE = ['qr', 'wk']
    SYS.REFRESHTOKEN = true
    break
  //本机环境
  case 'localhost':
    SYS.ENV = 'local'
    SYS.URL = global.location.origin
    SYS.MODE = 'gm|ai|dc|doc'
    if (storage.local('env') === 'prod') {
      SYS.WEBURL = 'https://www.topxlc.com'
      SYS.APPZZBURL = 'https://app-web.topcj.com'
      SYS.WEBVIDEOURL = 'https://video.topxlc.com'
      SYS.WEBSPREADURL = 'https://top9b1.topxlc6.com'
      SYS.IMURL = 'https://topcrm.topxlc.com'
      SYS.HGURL = 'https://hg.topxlc.com'
      SYS.BOOKURL = 'https://book.topxlc.com'
      SYS.ZZBURL = 'https://app-web.topcj.com'
      SYS.APIENV = 'prod'
      SYS.API.CRM = 'https://sdcrm-api.topxlc.com'
      SYS.API.SD = 'https://api-sd.topxlc.com/sd'
      SYS.API.WC = 'https://demo-wechatreport.topxlc.com'
      SYS.API.WS = 'wss://sdcrm-api.topxlc.com'
      SYS.API.MS = 'https://topms-api.topxlc.com'
      SYS.API.ZZB = 'https://app-api.topcj.com'
      SYS.API.TP = 'https://p-api.topxlc.com'
      SYS.API.YHTL = 'https://textlive.top6xlc.com'
      SYS.WK.AGENT = '2'
      SYS.IMAPPID = ''
      SYS.REFRESHTOKEN = true
      SYS.LOGINMODE = ['mid']
    } else {
      SYS.WEBURL = 'https://sd-demo-web.topxlc.com'
      SYS.APPZZBURL = 'https://demo-aweb.topcj.com'
      SYS.WEBVIDEOURL = 'https://sd-demo-web.topxlc.com'
      SYS.WEBSPREADURL = 'https://sd-demo-web.topxlc.com/ad'
      SYS.IMURL = 'https://demo-im.topxlc.com'
      SYS.HGURL = 'https://demo-hg.topxlc.com'
      SYS.BOOKURL = 'https://demo-im.topxlc.com'
      SYS.ZZBURL = 'https://demo-aweb.topcj.com'
      SYS.APIENV = 'dev'
      SYS.API.CRM = 'https://demo-sdcrm-api.topxlc.com'
      SYS.API.SD = 'https://demo-api.topxlc.com/sd'
      SYS.API.WC = 'https://demo-wechatreport.topxlc.com'
      SYS.API.WS = 'wss://demo-sdcrm-api.topxlc.com'
      SYS.API.MS = 'https://demo-m-api.topxlc.com'
      SYS.API.ZZB = 'https://demo-app-api.topcj.com'
      SYS.API.TP = 'https://demo-sdcloud.topxlc.com'
      SYS.API.YHTL = 'https://test-textlive.top6xlc.com'
      SYS.WK.AGENT = '1000044'
      SYS.IMAPPID = 1400028938
      SYS.REFRESHTOKEN = true
      SYS.LOGINMODE = ['mid']
      // SYS.ALLOWPATH = ['qywx-article']
    }
    break
  //合规环境
  case 'topim.topxlc.com':
    SYS.ENV = 'prod'
    SYS.URL = global.location.origin
    SYS.WEBURL = 'https://www.topxlc.com'
    SYS.APPZZBURL = 'https://app-web.topcj.com'
    SYS.WEBVIDEOURL = 'https://video.topxlc.com'
    SYS.WEBSPREADURL = 'https://top9b1.topxlc6.com'
    SYS.IMURL = 'https://' + hostname
    SYS.HGURL = 'https://hg.topxlc.com'
    SYS.BOOKURL = 'https://book.topxlc.com'
    SYS.ZZBURL = 'https://app-web.topcj.com'
    SYS.APIENV = 'comt'
    SYS.API.CRM = 'https://topapi.topxlc.com'
    SYS.API.SD = 'https://api-sd.topxlc.com/sd'
    SYS.API.WC = 'https://demo-wechatreport.topxlc.com'
    SYS.API.WS = 'wss://topapi.topxlc.com'
    SYS.API.MS = 'https://topms-api.topxlc.com'
    SYS.API.ZZB = 'https://app-api.topcj.com'
    SYS.API.TP = 'https://p-api.topxlc.com'
    SYS.API.YHTL = 'https://textlive.top6xlc.com'
    SYS.WK.AGENT = '1000060'
    SYS.IMAPPID = ''
    SYS.MODE = 'gm|dc'
    SYS.LOGINMODE = ['pw', 'wk']
    SYS.REFRESHTOKEN = true
    break
  //天津分公司普通版本
  case 'toptj.topxlc.com':
    SYS.ENV = 'prod'
    SYS.URL = global.location.origin
    SYS.WEBURL = 'https://www.topxlc.com'
    SYS.APPZZBURL = 'https://app-web.topcj.com'
    SYS.WEBVIDEOURL = 'https://video.topxlc.com'
    SYS.WEBSPREADURL = 'https://top9b1.topxlc6.com'
    SYS.IMURL = 'https://' + hostname
    SYS.HGURL = 'https://hg.topxlc.com'
    SYS.BOOKURL = 'https://book.topxlc.com'
    SYS.ZZBURL = 'https://app-web.topcj.com'
    SYS.APIENV = 'prod'
    SYS.API.CRM = 'https://sdcrm-api.topxlc.com'
    SYS.API.SD = 'https://api-sd.topxlc.com/sd'
    SYS.API.WC = 'https://demo-wechatreport.topxlc.com'
    SYS.API.WS = 'wss://sdcrm-api.topxlc.com'
    SYS.API.MS = 'https://topms-api.topxlc.com'
    SYS.API.ZZB = 'https://app-api.topcj.com'
    SYS.API.TP = 'https://p-api.topxlc.com'
    SYS.API.YHTL = 'https://textlive.top6xlc.com'
    SYS.WK.AGENT = '1000100'
    SYS.IMAPPID = ''
    SYS.MODE = 'gm|dc'
    SYS.LOGINMODE = ['pw', 'qr', 'wk']
    SYS.REFRESHTOKEN = true
    //天津分公司合规版本
    // SYS.ENV = 'prod'
    // SYS.URL = global.location.origin
    // SYS.WEBURL = 'https://www.topxlc.com'
    // SYS.WEBVIDEOURL = 'https://video.topxlc.com'
    // SYS.IMURL = 'https://' + hostname
    // SYS.APIENV = 'comt'
    // SYS.API.CRM = 'https://topapi.topxlc.com'
    // SYS.API.SD = 'https://api-sd.topxlc.com/sd'
    // SYS.API.WC = 'https://demo-wechatreport.topxlc.com'
    // SYS.API.WS = 'wss://topapi.topxlc.com'
    // SYS.WK.AGENT = '1000100'
    // SYS.MODE = 'gm|dc'
    break
  //顶点资讯
  case 'book.topxlc.com':
    SYS.ENV = 'prod'
    SYS.URL = global.location.origin
    SYS.WEBURL = 'https://www.topxlc.com'
    SYS.APPZZBURL = 'https://app-web.topcj.com'
    SYS.WEBVIDEOURL = 'https://video.topxlc.com'
    SYS.WEBSPREADURL = 'https://top9b1.topxlc6.com'
    SYS.IMURL = 'https://' + hostname
    SYS.HGURL = 'https://hg.topxlc.com'
    SYS.BOOKURL = 'https://book.topxlc.com'
    SYS.ZZBURL = 'https://app-web.topcj.com'
    SYS.APIENV = 'prod'
    SYS.API.CRM = 'https://sdcrm-api.topxlc.com'
    SYS.API.SD = 'https://api-sd.topxlc.com/sd'
    SYS.API.WC = 'https://demo-wechatreport.topxlc.com'
    SYS.API.WS = 'wss://sdcrm-api.topxlc.com'
    SYS.API.MS = 'https://topms-api.topxlc.com'
    SYS.API.ZZB = 'https://app-api.topcj.com'
    SYS.API.TP = 'https://p-api.topxlc.com'
    SYS.API.YHTL = 'https://textlive.top6xlc.com'
    SYS.WK.AGENT = '1000106'
    SYS.IMAPPID = ''
    SYS.MODE = 'gm|dc'
    SYS.REFRESHTOKEN = false
    SYS.ALLOWPATH = ['qywx-article', 'login', 'qywx-myInfo', 'qywx-top_system']
    SYS.LOGINMODE = ['qr', 'wk']
    SYS.BASEDATA = []
    break
  //正式环境
  case 'topcrm.topxlc.com':
  default:
    SYS.ENV = 'prod'
    SYS.URL = global.location.origin
    SYS.WEBURL = 'https://www.topxlc.com'
    SYS.APPZZBURL = 'https://app-web.topcj.com'
    SYS.WEBVIDEOURL = 'https://video.topxlc.com'
    SYS.WEBSPREADURL = 'https://top9b1.topxlc6.com'
    SYS.IMURL = 'https://' + hostname
    SYS.HGURL = 'https://hg.topxlc.com'
    SYS.BOOKURL = 'https://book.topxlc.com'
    SYS.ZZBURL = 'https://app-web.topcj.com'
    SYS.APIENV = 'prod'
    SYS.API.CRM = 'https://sdcrm-api.topxlc.com'
    SYS.API.SD = 'https://api-sd.topxlc.com/sd'
    SYS.API.WC = 'https://demo-wechatreport.topxlc.com'
    SYS.API.WS = 'wss://sdcrm-api.topxlc.com'
    SYS.API.MS = 'https://topms-api.topxlc.com'
    SYS.API.ZZB = 'https://app-api.topcj.com'
    SYS.API.TP = 'https://p-api.topxlc.com'
    SYS.API.YHTL = 'https://textlive.top6xlc.com'
    SYS.WK.AGENT = '2'
    SYS.IMAPPID = ''
    SYS.MODE = 'gm|dc'
    SYS.LOGINMODE = ['qr', 'pw', 'wk']
    SYS.REFRESHTOKEN = true
    break
}

//获取API
const getAPI = function(url, data) {
  url = url
    .split('/')
    .map(e => {
      let text, suffix
      e = e.split('.')
      text = e.splice(0, 1)[0]
      suffix = e.length ? `.${e.join('.')}` : ''

      if (text.indexOf(':') === 0) {
        let key = text.substr(1)
        text = data[key] ?? ''
        delete data[key]
      }

      return text + suffix
    })
    .join('/')

  for (let k in SYS.API) {
    let reg = new RegExp(`%${k}%`)
    url = url.replace(reg, SYS.API[k])
  }

  if (data.token && store.state.token) {
    url += `?token=${store.state.token}`
  }

  delete data.token

  return url
}

const getHeader = function(url, data) {
  let header = {}

  if (url.indexOf('%MS%') === 0 && data.token && store.state.token) {
    header.token = store.state.token
    delete data.token
  }

  //请求至尊版APP时增加鉴权信息
  if (url.indexOf('%ZZB%') === 0) {
    header['auth-time'] = Date.now()
    header.auth = md5(`${header['auth-time']}:TpQiU8f2QrgIFkjX`)
    data.$normal = true
    delete data.token
  }

  if (url.indexOf('%TP%') === 0) {
    delete data.token
  }

  if (url.indexOf('%SDSS%') === 0 || url.indexOf('%CDSS%') === 0) {
    header.Authorization = `Bearer wqaeNvGQRzzDdZHbzJEgxZLHHBzTDrJDi85XKZ8vavWA36RrBHt4Anm42YFkEDyC`
  }

  return header
}

//创建get请求
const createGet = function(url, data) {
  let set = {}
  let headers = getHeader(url, data)
  let ajax = getAPI(url, data)

  if (data?.$set) {
    set = {
      ...data.$set
    }
    delete data.$set
  }

  if (data?.$normal) {
    delete data.$normal
  }

  return axios.get(ajax, {
    ...set,
    params: data,
    headers
  })
}

//创建post请求
const createPost = function(url, data) {
  let set = {}
  let headers = getHeader(url, data)
  let ajax = getAPI(url, data)

  if (data?.$set) {
    set = {
      ...data.$set
    }
    delete data.$set
  }

  let d = null
  if (data?.$normal) {
    delete data.$normal
    d = data
  } else {
    d = {
      params: data
    }
  }

  return axios.post(ajax, d, {
    ...set,
    headers: {
      'Content-Type': 'application/json',
      ...headers
    }
  })
}

//创建form请求
const createForm = function(url, data) {
  let set = {}
  let headers = getHeader(url, data)
  let ajax = getAPI(url, data)

  if (data?.$set) {
    set = {
      ...data.$set
    }
    delete data.$set
  }

  if (data?.$normal) {
    delete data.$normal
  }

  let formData = new FormData()
  for (let k in data) {
    formData.append(k, data[k])
  }

  return axios.post(ajax, formData, {
    ...set,
    headers: {
      'Content-Type': 'multipart/form-data',
      ...headers
    }
  })
}

//创建all请求
const createAll = function(list) {
  let allData = list.map(e => {
    switch (e.mode) {
      case 'get':
        return createGet(e.url, e.data)
      case 'form':
        return createForm(e.url, e.data)
      case 'post':
      default:
        return createPost(e.url, e.data)
    }
  })
  return axios.all(allData)
}

//创建relay请求
const createRelay = function(list, interval, step) {
  return new Promise(function(resolve, reject) {
    let flag = 0
    let result = []
    const work = function() {
      http({
        ...list[flag]
      })
        .then(data => {
          result[flag] = data
          flag++
          if (typeof step === 'function') {
            step(data, flag)
          }
          if (flag === list.length) {
            resolve(result)
            return
          }
          if (interval) {
            setTimeout(() => {
              work()
            }, interval)
          } else {
            work()
          }
        })
        .catch(text => {
          reject(text)
        })
    }
    work()
  })
}

//格式化返回数据
const formatResult = function(url, data) {
  if (url.indexOf('%ZZB%') === 0) {
    return {
      code: data.success ? 8200 : 8999,
      msg: data.errMessage,
      errmsg: data.errMessage,
      result: data.data
    }
  }

  return data
}

//请求
const http = function({ mode = 'post', url, data = {}, all = [], interval, step, auth = true }) {
  switch (mode) {
    case 'get':
      return http.get(url, data, auth)
    case 'form':
      return http.form(url, data, auth)
    case 'all':
      return http.all(all)
    case 'relay':
      return http.relay(all, interval, step)
    case 'post':
    default:
      return http.post(url, data, auth)
  }
}

http.api = getAPI

http.post = function(url, data = {}, auth) {
  return new Promise(function(resolve) {
    createPost(url, data)
      .then(data => {
        if (data.data.code === 990502 && auth) {
          store.commit('setWindow', {
            onLine: false
          })
        }
        resolve(formatResult(url, data.data))
      })
      .catch(() => {
        resolve({
          code: '999999',
          msg: '请求超时'
        })
      })
  })
}

http.get = function(url, data = {}, auth) {
  return new Promise(function(resolve) {
    createGet(url, data)
      .then(data => {
        if (data.data.code === 990502 && auth) {
          store.commit('setWindow', {
            onLine: false
          })
        }
        resolve(formatResult(url, data.data))
      })
      .catch(() => {
        resolve({
          code: '999999',
          msg: '请求超时'
        })
      })
  })
}

http.form = function(url, data = {}, auth) {
  return new Promise(function(resolve) {
    createForm(url, data)
      .then(data => {
        if (data.data.code === 990502 && auth) {
          store.commit('setWindow', {
            onLine: false
          })
        }
        resolve(formatResult(url, data.data))
      })
      .catch(() => {
        resolve({
          code: '999999',
          msg: '请求超时'
        })
      })
  })
}

http.all = function(list = []) {
  if (!list.length) return []
  return new Promise(function(resolve, reject) {
    createAll(list)
      .then(data => {
        resolve(data.map(e => e.data))
      })
      .catch(text => {
        reject(text)
      })
  })
}

http.relay = function(list = [], interval = 0, step) {
  if (!list.length) return []
  return new Promise(function(resolve, reject) {
    createRelay(list, interval, step)
      .then(data => {
        resolve(data)
      })
      .catch(text => {
        reject(text)
      })
  })
}

export { http, SYS }
