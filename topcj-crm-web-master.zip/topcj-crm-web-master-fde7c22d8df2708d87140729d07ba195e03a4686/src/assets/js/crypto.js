const crypto = require('crypto')

const key = 'gosotech@ddcjksn'
const iv = 'gosotech*ddcjksn'
const encoding1 = 'utf8'
const encoding2 = 'base64'

const AesEncrypt = function(data) {
  let chunks = []
  const cipher = crypto.createCipheriv('aes-128-cbc', key, iv)
  cipher.setAutoPadding(true)
  chunks.push(cipher.update(data, encoding1, encoding2))
  chunks.push(cipher.final(encoding2))
  return chunks.join('')
}

const AesDecrypt = function(data) {
  let chunks = []
  const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv)
  decipher.setAutoPadding(true)
  chunks.push(decipher.update(data, encoding2, encoding1))
  chunks.push(decipher.final(encoding1))
  return chunks.join('')
}

const md5 = function(text) {
  const hash = crypto.createHash('md5')
  hash.update(text)

  return hash.digest('hex').toLowerCase()
}



const key2 = '0102030405060708'
const iv2 = '0102030405060708'
const clearCode = 'utf8'
const cipherCode = 'base64'

const Encode = function(data) {
  let chunks = []
  let cipher = crypto.createCipheriv('aes-128-cbc', key2, iv2)
  cipher.setAutoPadding(true)
  chunks.push(cipher.update(data, clearCode, cipherCode))
  chunks.push(cipher.final(cipherCode))
  return chunks.join('')
}

const Decode = function(data) {
  let chunks = []
  const decipher = crypto.createDecipheriv('aes-128-cbc', key2, iv2)
  decipher.setAutoPadding(true)
  chunks.push(decipher.update(data, cipherCode, clearCode))
  chunks.push(decipher.final(clearCode))
  return chunks.join('')
}

export { md5, AesEncrypt, AesDecrypt, Encode, Decode }