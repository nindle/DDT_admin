import store from '../../store'
import { SYS } from './http'
/*
 * 数据储存
 */
const storage = {
  local(key, value) {
    let _ = localStorage.getItem('$_$') === null ? {} : JSON.parse(localStorage.getItem('$_$'))
    if(typeof key !== 'undefined'){
      if(typeof value !== 'undefined'){
        if(value !== null){
          //set
          _[key] = value
        }else{
          //remove
          delete _[key]
        }
      }else{
        //get
        return _[key]
      }
    }
    localStorage.setItem('$_$', JSON.stringify(_))
  },
  session(key, value) {
    let _ = sessionStorage.getItem('$_$') === null ? {} : JSON.parse(sessionStorage.getItem('$_$'))
    if(typeof key !== 'undefined'){
      if(typeof value !== 'undefined'){
        if(value !== null){
          //set
          _[key] = value
        }else{
          //remove
          delete _[key]
        }
      }else{
        //get
        return _[key]
      }
    }
    sessionStorage.setItem('$_$', JSON.stringify(_))
  }
}

//节流
const throttle = function(fn, wait = 0) {
  let valid = true
  return async function() {
    if(!valid) return
    valid = false
    try {
      await fn.apply(this, arguments)
    }catch(e) {
      console.log(e)
    }
    
    setTimeout(() => {
      valid = true
    }, wait)
  }
}

//防抖
const debounce = function(fn, wait = 0) {
  let timer = null
  return function() {
    clearTimeout(timer)
    timer = setTimeout(() => {
      try {
        fn.apply(this, arguments)
      }catch(e) {
        console.log(e)
      }
    }, wait)
  }
}

//深拷贝
const deepcopy = function(item) {
  let result
  switch(Object.prototype.toString.apply(item).slice(8, -1).toLowerCase()) {
    case 'number':
    case 'string':
    case 'boolean':
    case 'symbol':
    case 'bigint':
    case 'promise':
      result = item
      break
    case 'null':
      result = null
      break
    case 'undefined':
      result = undefined
      break
    case 'function':
      result = function() { item.apply(this, arguments) }
      break
    case 'asyncfunction':
      result = async function() { await item.apply(this, arguments) }
      break
    case 'array':
      result = []
      for(let i in item) {
        result.push(deepcopy(item[i]))
      }
      break
    case 'object':
      result = {}
      for(let i in item) {
        result[i] = deepcopy(item[i])
      }
      break
    case 'date':
      result = new Date(item.valueOf())
      break
    case 'regexp':
      result = new RegExp(item)
      break
    case 'set':
      result = new Set([...item])
      break
    case 'map':
      result = new Map([...item])
      break
    default:
      result = item
      break
  }
  return result
}

//查询字符串转对象
const search2json = function(str) {
  const arr = str.substring(str.indexOf('?') + 1, str.length).split('&')
  let obj = {}
  for(let i in arr) {
    let k = arr[i].split('=')
    obj[k[0]] = k[1]
  }
  return obj
}

//对象转查询字符串
const json2search = function(obj = {}) {
  let str = []
  for(let i in obj){
    if(typeof obj[i] !== 'undefined') {
      str.push(`${i}=${obj[i]}`)
    }
  }

  if(str.length){
    return '?' + str.join('&')
  }else{
    return ''
  }
}

//生成链接
const createLink = function(url, query = {}, other = []) {
  let newquery = { ...query }
  for(let i in other) {
    switch(other[i]){
      case 'mid-corp-19':
        if(store.state.managerInfo.corpId === 19) {
          newquery.mid = store.state.managerInfo.id
          newquery.corpid = 19
        }
        break
      case 'mid-res-19':
        if(store.state.managerInfo.corpId === 19) {
          newquery.mid = store.state.baseData.corpList.find(e => e.id === store.state.managerInfo.corpId)?.resManagerId ?? undefined
        }
        break
      case 'mid-corp':
        if(store.state.managerInfo.corpId > 0) {
          newquery.mid = store.state.managerInfo.id
        }
        break
      case 'mid-res':
        newquery.mid = store.state.baseData.corpList.find(e => e.id === store.state.managerInfo.corpId)?.resManagerId ?? undefined
        break
      case 'mid':
        newquery.mid = store.state.managerInfo.id
        break
      case 'alipay':
        if(store.state.managerInfo.corpId === 19) {
          newquery.a = '12'
        }
        if(SYS.ENV !== 'prod') {
          newquery.a = void 0
        }
        break
      case 'wxpay':
        if(store.state.managerInfo.corpId === 19) {
          newquery.w = '39'
        }
        if(SYS.ENV !== 'prod') {
          newquery.w = void 0
        }
        break
      case 'spread-wxpay':
        if([0, 19].includes(store.state.managerInfo.corpId)) {
          newquery.w = '40'
        }
        break
      case 'corpId':
        newquery.cid = store.state.managerInfo.corpId
        break
    }
  }

  return url + json2search(newquery)
}

//休眠
const sleep = function(time) {
  return new Promise(function(resolve) {
    setTimeout(() => {
      resolve()
    }, time)
  })
}

//加载图片
const loadimage = function(src) {
  return new Promise(function(resolve) {
    let image = new Image()
    image.src = src
    image.onload = function() {
      resolve(image)
    }
  })
}
const loadfile = function(src) {
  return new Promise(function(resolve) {
    let file = new FileReader()
    file.readAsDataURL(src)
    file.onload = function() {
      resolve(file)
    }
  })
}
const base2file = function(dataurl, filename) {
  let arr = dataurl.split(','), 
      mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]), 
      n = bstr.length, 
      u8arr = new Uint8Array(n)
  while(n--){
    u8arr[n] = bstr.charCodeAt(n)
  }
  return new File([u8arr], filename, {type:mime})
}

const random = function(a = 0, b = 1) {
  if(typeof a === 'number') {
    return Math.floor(Math.random() * (Math.abs(a - b) + 1)) + Math.min(a, b)
  }else{
    return a[random(0, a.length - 1)]
  }
}

const device = {
  isMobile: (function() {
    return (/iphone|ipod|android.*mobile|windows.*phone|blackberry.*mobile/i.test(window.navigator.userAgent.toLowerCase()))
  })(),
  isiOS: (function() {
    return (/iphone|ipod/i.test(window.navigator.userAgent.toLowerCase()))
  })(),
  isAndroid: (function() {
    return (/android.*mobile/i.test(window.navigator.userAgent.toLowerCase()))
  })(),
  isWechat: (function() {
    return (/micromessenger/i.test(window.navigator.userAgent.toLowerCase()))
  })(),
  isWxwork: (function() {
    return (/wxwork/i.test(window.navigator.userAgent.toLowerCase()))
  })()
}

export { storage, throttle, debounce, deepcopy, search2json, json2search, sleep, loadimage, loadfile, createLink, base2file, device, random }