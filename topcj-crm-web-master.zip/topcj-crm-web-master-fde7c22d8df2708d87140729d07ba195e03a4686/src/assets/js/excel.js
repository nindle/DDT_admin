const XLSX = require('xlsx')

const download = function(table, excelName) {
  let workbook = {
    SheetNames: [],
    Sheets: {}
  }
  
  let dom = document.createElement('div')
  dom.innerHTML = table
  let sheet = XLSX.utils.table_to_sheet(dom.querySelector('table'))

  let sheetName = excelName.substring(0, 30)
  workbook.SheetNames.push(sheetName)
  workbook.Sheets[sheetName] = sheet
  
  let wopts = {
    bookType: 'xlsx',
    bookSST: false,
    type: 'binary'
  }
  let wbout = XLSX.write(workbook, wopts)
  let s2ab = function(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i=0; i!=s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }
  let blob = new Blob([s2ab(wbout)], {type: 'application/octet-stream'})
  let url = URL.createObjectURL(blob)
  let aLink = document.createElement('a')
  aLink.href = url
  aLink.download = excelName + ' - ' + new Date().timeFormat('yyyy_MM_dd hh_mm') + '.xlsx'
  aLink.click()
}

const load = function(file) {
  return new Promise(function(resolve) {
    let list = []

    const fileReader = new FileReader()

    fileReader.onload = e => {
      const data = e.target.result
      const workbook = XLSX.read(data, { type: 'binary' })
      for (let sheet in workbook.Sheets) {
        list.push(...XLSX.utils.sheet_to_json(workbook.Sheets[sheet]))
      }
      resolve(list)
    }

    fileReader.readAsBinaryString(file)
  })
}

export { download, load }