<template>
  <el-table-pro
    :data="data"
    :head="head"
    border
    summary
  ></el-table-pro>
</template>

<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: 'ID',
          minWidth: 60,
          fixed: true,
          summary: '总计'
        },
        {
          key: 'corpName',
          label: '分公司',
          minWidth: 70,
          fixed: true,
          summary: '/'
        },
        {
          key: 'packageName',
          label: '购买套餐',
          minWidth: 100,
          fixed: true,
          summary: data => data.length
        },
        {
          key: 'money',
          label: '定价',
          headtip: '套餐的价格（产品优惠后的价格）',
          minWidth: 56,
          summary: '/'
        },
        {
          key: 'existingCustomers',
          label: '期初数量',
          headtip: '历史购买该套餐的用户数（截止月初凌晨）',
          minWidth: 56,
        },
        {
          key: 'newCustomers,renewalCustomers',
          label: '本期新增数量（新客户|续费客户）',
          headtip: '指本月新|续费购买该套餐的用户数',
          minWidth: 110,
          format:'{newCustomers}|{renewalCustomers}',
          summary: (data, { $sum }) => `${$sum('newCustomers')}|${$sum('renewalCustomers')}`
        },
        {
          key: 'refundCustomers,expCustomers',
          label: '本期减少数量（退费|服务到期）',
          headtip: '指历史购买该套餐在本月退费|服务到期的用户数',
          minWidth: 110,
          format:'{refundCustomers}|{expCustomers}',
          summary: (data, { $sum }) => `${$sum('refundCustomers')}|${$sum('expCustomers')}`
        },
        {
          key: 'terminalCustomers',
          label: '期末存量',
          headtip: '期末存量=期初数量+本期增加数量（新客户）-本期减少（退费+服务到期），期末存量即为当前在服务期的客户数',
          minWidth: 56,
        },
        {
          key: 'perCustomerTransaction',
          label: '客单价（本期）',
          headtip: '客单价（本期）=本期总收入/本期客户数',
          minWidth: 56,
          summary: (data, { terminalCustomers, monthRevenue }) => (monthRevenue / terminalCustomers).toFixed(2)
        },
        {
          key: 'avgPrice',
          label: '平均收费金额（累计）',
          headtip: '平均收费金额=期末在服务期客户数对应业绩/期末在服务期客户数  期末是指从历史截止到本月最后一天',
          width: 80,
          summary: (data, { $sum, terminalCustomers }) => ($sum(a => a.avgPrice * a.terminalCustomers) / terminalCustomers).toFixed(2)
        },
        {
          key: 'avgServiceDay',
          label: '客户平均服务期限（本期）',
          headtip: '客户平均服务期限（本期）=本期客户剩余服务期总天数/本期客户总客户数，单位月',
          width: 100,
          summary: (data, { $sum }) => ($sum('avgServiceDay') / data.filter(e => e.avgServiceDay).length).toFixed(2)
        },
        {
          key: 'yearRenewalRate',
          label: '客户续费率（本年）',
          headtip: '客户续约率（本年）=当年累计实际续约客户数/当年累计应到期客户总数（特别点：每年1月、7月填报上年全年、当年半年情况，是否单独拉？）',
          width: 56,
          format: e => e ? `${(e * 100).toFixed(2)}%` : '',
          summary: (data, { $sum }) => ($sum('yearRenewalRate') / data.filter(e => e.yearRenewalRate).length * 100).toFixed(2) + '%'
        },
        {
          key: 'assetXs',
          label: '客户平均资产规模（10万以内）',
          headtip: '客户平均资产规模：取值风险测评第9题，给出选中的结果（ 10万元以内、10万元-30万元、30万元-100万元、100万元以上、从未从事过金融市场投资）（个数）',
          width: 100
        },
        {
          key: 'assetSmall',
          label: '客户平均资产规模（10万-30万）',
          width: 120
        },
        {
          key: 'assetMedium',
          label: '客户平均资产规模（30万-100万）',
          width: 120
        },
        {
          key: 'assetLarge',
          label: '客户平均资产规模（100万+）',
          width: 120
        },
        {
          key: 'assetOther',
          label: '客户平均资产规模（未从事）',
          width: 120
        },
        {
          key: 'yearCustomers',
          label: '本年累计服务客户数',
          headtip: '本年累计服务客户数=当年成交用户数',
          width: 56
        },
        {
          key: 'monthRevenue',
          label: '本期收入',
          width: 80
        },
        {
          key: 'yearRevenue',
          label: '本年累计收入',
          headtip: '当年成交总金额',
          width: 84
        },
        {
          key: 'monthRefund',
          label: '本期退费',
          width: 80
        },
        {
          key: 'yearRefund',
          label: '本年累计退费',
          width: 84
        },
      ]
    }
  },
  props:{
    data:Array
  }
}
</script>