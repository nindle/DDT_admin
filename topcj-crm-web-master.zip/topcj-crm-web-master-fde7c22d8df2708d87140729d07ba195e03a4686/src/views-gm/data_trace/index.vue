<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
    >  
      <!-- 筛选模块 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData()"
        ></el-screen-pro> 
      </template>
    
      <!--表格模块-->
      <template #table>
        <table-data :data="tableData"/>
      </template> 
    </el-layout-pro>
  </div>
</template>

<script>
import { json2search, throttle } from '../../assets/js/tool'
import TableData from './tableData'

export default {
  name: 'gm-data_trace',
  data() {
    return {
      //加载状态
      loading: false,
      //表格数据
      tableData: [],

      screen: {
        time: '',
        corpId: '',
      },
      config: {
        corpId: {
          type:'select-corp',
          placeholder: '选择公司',
        },
        time: {
          type: 'date-month',
          placeholder: '选择月份',
        },
        split:{
          type:'split'
        },
        excel: {
          type: 'button',
          label: '导出excel',
          click: () => {
            this.$open(this.$http.api('%CRM%/report/exp_monthly_finance_excel.sdcrm', {
              token: true
            }) + json2search({
              cdate: this.screen.time || undefined,
              corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined
            }).replace('?', '&'))
          }
        },
      }
    }
  },
  props:{
    nav: Object
  },
  components: {
    TableData,
  },
  methods: {
    //数据获取
    getTableData: throttle(async function() {
      this.loading = true

      let { result } = await this.$http({
        url:'%CRM%/report/get_monthly_finance.sdcrm',
        data: {
          token: true,
          cdate: this.screen.time,
          corpId: this.screen.corpId
        }
      })

      this.tableData = result

      this.loading = false
    })
  }
}
</script>

<style scoped lang="scss">
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>
