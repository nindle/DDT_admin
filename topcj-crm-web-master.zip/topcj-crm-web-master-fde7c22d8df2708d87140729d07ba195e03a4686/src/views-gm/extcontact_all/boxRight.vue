<template>
  <el-layout-pro
    class="box"
    @scroll-bottom="getMsg()"
  >
    <template #screen>
      <el-screen-pro :config="config"></el-screen-pro>
    </template>

    <template #scroll>
      <message :data="messageList"/>
    </template>
  </el-layout-pro>
</template>
<script>
import { md5 } from '../../assets/js/crypto'
import Message from '../../components/message'
export default {
  
  data() {
    return {
      config: {
        label: {
          type: 'label',
          label: '聊天记录'
        }
      },
      messageList: [],
    }
  },
  inject: ['select'],
  methods: {
    async getMsg() {
      let time = Date.now()
      let sign = md5(`075dfa7becf54cc4aff1d75080983eb9${time}`)

      let { code,result } = await this.$http({
        url: '%CRM%/external/chat_data_list.sdcrm',
        data: {
          token : true,
          sign,
          deadline: time,
          qyWx: this.select.qyWx,
          managerUserId: this.select.qyUserId,
          userId: this.select.externalUserid,
          pageNumber: this.messageList.length,
          pageSize: 30
        }
      })

      
      if(code !== 8200) return
      if(!result) result = []
      
      let list = result.map(e => {
        e.nickname = this.select.nickName
        e.managerName = this.select.qyUserId
        e.lastTime = e.msgtime
        e.msgType = e.msgtype
        e.imageUrl = e.mediaUrl
        if(e.sfrom === this.select.externalUserid) {
          e.type = 1
        }else{
          e.type = 0
        }

        return e
      })

      this.messageList = [...this.messageList, ...list]
    }
  },
  watch: {
    'select.id'() {
      this.messageList = []
      this.getMsg()
    }
  },
  components: { 
    Message 
  },
  created() {
    this.getMsg()
  }
}
</script>
<style lang="scss" scoped>
.box {
  /deep/ {
    .screen-box {
      padding-bottom: 0 !important;
    }
    .scrollbar-view {
      padding: 0 24px;
    }
  }
}
</style>