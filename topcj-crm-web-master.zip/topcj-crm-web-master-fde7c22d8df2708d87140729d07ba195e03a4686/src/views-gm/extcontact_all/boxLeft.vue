<template>
  <el-layout-pro
    class="box"
    :loading="loading"
    :total="total"
    :page-num.sync="pageNum"
    :page-size.sync="pageSize"
    @page-change="getTableData()"
  >
    <template #screen>
      <el-screen-pro
        :model="screen"
        :config="config"
        @change="getTableData(true)"
      ></el-screen-pro>
    </template>
    <!-- 表格 -->
    <template #table>
      <table-data 
        :data="tableData"
        @edit="openPopover"
        @change="getTableData()"
      />
    </template>
  </el-layout-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableDataLeft'

export default {
  data() {
    return {
       //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      loading: false,
      tableData: [],

      screen: {
        nickName: '',
        type: 0
      },
      config: {
        nickName: {
          type: 'input',
          placeholder: '用户昵称'
        },
        type: {
          type: 'switch',
          activeValue: 1,
          inactiveValue: 0,
          activeText: '精准查询'
        }
      }
    }
  },
  components: {
    TableData
  },
  methods: {
    getTableData: throttle(async function(toFirst){
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/external/get_external_user_list.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          nickName: this.screen.nickName || null,
          type: this.screen.type
        }
      })

      this.loading = false

      this.tableData = result.records
      this.total = result.total                              
    }),
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    }
  }
}
</script>