<template>
  <el-table-pro
    :head="head"
    :data="data"
    @row-click="getRowdata"
    row-key="id"
    highlight-current-row
    :current-row-key="select.id"
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'corpId',
          label: '分公司',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.corpList,
            value: 'corpName',
            key: 'id'
          }
        },
        {
          key: 'qyWx',
          label: '企业微信',
          minWidth: 120,
          format: {
            list: this.$store.state.baseData.qywxList,
            value: 'wxName',
            key: 'qyWx'
          }
        },
        {
          key: 'qyUserId',
          label: '服务人员ID',
          minWidth: 120
        },
        {
          key: 'nickName',
          label: '用户昵称',
          minWidth: 120
        }
      ]
    }
  },
  inject: ['select'],
  props: {
    data: Array
  },
  methods:{
    getRowdata(row){
      this.select.id = row.id
      this.select.qyUserId = row.qyUserId
      this.select.externalUserid = row.externalUserid
      this.select.nickName = row.nickName
      this.select.qyWx = row.qyWx
      this.select.corpId = row.corpId
    }
  }
}
</script>