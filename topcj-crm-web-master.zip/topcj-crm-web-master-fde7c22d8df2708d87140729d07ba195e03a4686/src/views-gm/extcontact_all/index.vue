<template>
  <div class="view">
    <box-left 
      class="box"
      :class="{ full: !select.id }"
    />
    <box-right 
      class="box"
      v-if="select.id"
    />
  </div>
</template>

<script>
import BoxLeft from './boxLeft'
import BoxRight from './boxRight'

export default {
  name: 'gm-extcontact_all',
  data() {
    return {
      select: {
        id: '',
        qyUserId: '',
        externalUserid: '',
        nickName: '',
        qyWx: '',
        corpId: ''
      }
    }
  },
  provide() {
    return {
      select: this.select
    }
  },
  components: {
    BoxLeft,
    BoxRight
  }
}
</script>

<style lang="scss" scoped>
.view{
  padding: 24px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  display: flex;
  flex-wrap: wrap;
  .box{
    width: calc(50% - 12px);
    height: 100%;
    background: #FFF;
    &:last-child { margin-left: 24px;}
    &.full {  
      width: 100%;
      margin-left: 0;
    }
  }
}
</style>