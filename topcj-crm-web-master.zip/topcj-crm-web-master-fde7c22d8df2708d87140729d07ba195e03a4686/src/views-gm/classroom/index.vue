<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :level-list="levelList"
          @edit="openPopover"
          @add="openPopover"
        />
      </template>

      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          :live-list="liveList"
          :course-list="courseList"
          :column-list="columnList"
          :sn-list="snList"
          :level-list="levelList"
          :subids-list="subIdsList"
          @change="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-classroom',
  data() {
    return {
      //状态更新
      loading: false,
      //分页
      pageNum: 1,
      pageSize: 10,
      total: 0,
      //新增展示修改
      showPopover: false,
      //编辑数据
      rowData: null,
      //表格数据
      tableData: [],
      //课程列表
      courseList: [],
      columnList: [],
      levelList: [],
      snList: [],
      subIdsList: [],
      //直播间列表
      liveList: [],
      // 筛选
      screen: {
        showStatus: '',
        keyword: ''
        // corpId: ''
      },
      config: {
        add: {
          type: 'button',
          label: '+ 新增',
          buttonType: 'primary',
          click: () => { this.openPopover({}, 'add') }
        },
        // corpId: {
        //   type: 'select-corp',
        // },
        showStatus: {
          placeholder: '状态',
          type: 'select',
          options: [
            { value: 0, label: '显示' },
            { value: 1, label: '隐藏' }
          ]
        },
        split: { type: 'split' },
        keyword: {
          type: 'input',
          placeholder: '搜索关键字/专题',
        },
      }
    }
  },
  methods:{
    //获取列表
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/class/list.sdcrm',
        data: {
          token: true,
          from: this.pageNum,
          size: this.pageSize,
          keyword: this.screen.keyword,
          showStatus: typeof this.screen.showStatus === 'number'? this.screen.showStatus : undefined,
          // corpId: typeof this.screen.corpId === 'number'? this.screen.corpId : undefined,
        }
      })

      let { result: data } = await this.$http({
        mode: 'get',
        url: '%CRM%/class/listAll.sdcrm',
        data: {
          token: true,
        }
      })
      this.tableData = result.records
      this.subIdsList = data
      this.total = result.total

      this.loading = false
    }),
    async getCourseList() {
      let { result } = await this.$http({
        url: '%CRM%/product/get_course_list.sdcrm',
        data: {
          token: true,
          pageNum: 1,
          pageSize: 9999
        }
      })

      this.courseList.splice(0, this.courseList.length, ...result.records)
    },
    async getLiveList() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/live/all.sdcrm',
        data: {
          token: true
        }
      })

      this.liveList.splice(0, this.liveList.length, ...result)
    },
    async getLevelList() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/setting/get_types/53.sdcrm',
        data: {
          token: true
        }
      })

      this.levelList.splice(0, this.levelList.length, ...result)
    },
    async getColumnList() {
      let { result } = await this.$http({
        url: '%CRM%/column/list.sdcrm',
        data: {
          token: true
        }
      })

      this.columnList.splice(0, this.columnList.length, ...result.filter(e => e.parentId))
    },
    async getSnList() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/setting/get_types/55.sdcrm',
        data: {
          token: true
        }
      })

      this.snList.splice(0, this.snList.length, ...result)
    },
    //打开弹框
    openPopover: throttle(async function(data = {}, mode = 'edit') {
      if(data.id) {
        let { result } = await this.$http({
          url: '%CRM%/class/info/:id.sdcrm',
          mode: 'get',
          data: {
            token: true,
            id: data.id
          }
        })

        this.rowData = result
      }else{
        this.rowData = data
      }

      if(mode === 'add') {
        this.rowData.id = undefined
      }

      this.showPopover = true
    })
  },
  components:{
    TableData,
    EditData
  },
  created(){
    this.getCourseList()
    this.getLiveList()
    this.getLevelList()
    this.getSnList()
    this.getColumnList()
  }
}
</script>
<style lang="scss" scoped>
.view{
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box{
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>