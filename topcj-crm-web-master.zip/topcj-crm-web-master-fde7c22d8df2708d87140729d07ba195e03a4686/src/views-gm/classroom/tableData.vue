<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
  </el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: '权限编号',
          minWidth: 60
        },
        {
          key: 'className',
          label: '产品权限名称',
          minWidth: 200
        },
        {
          key: 'level',
          label: '权限等级',
          minWidth: 56,
          format: {
            list: this.levelList,
            key: 'typeId',
            value: 'typeName',
          }
        },
        {
          key: 'ctime',
          label: '权限设置时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        // {
        //   key: 'videoName',
        //   label: '直播间可视权限',
        //   minWidth: 200,
        //   tooltip: true
        // },
        // {
        //   key: 'realName',
        //   label: '讲师',
        //   minWidth: 70
        // },
        // {
        //   key: 'corpId',
        //   label: '归属公司',
        //   minWidth: 70,
        //   format: {
        //     list: this.$store.state.baseData.corpList,
        //     key: 'id',
        //     value: 'corpName'
        //   }
        // },
        {
          key: 'showStatus',
          label: '套餐管理中',
          minWidth: 70,
          format: {
            '0': '显示',
            '1': '隐藏',
          }
        },
        {
          key: 'isVisible',
          label: '至尊版APP中',
          minWidth: 84,
          format: {
            '1': '显示',
            '2': '隐藏',
          }
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: row => { this.$emit('edit', row) }
          }
        },
        {
          key: 'add',
          label: '',
          width: 80,
          button: {
            type: 'text',
            icon: 'el-icon-plus',
            label: '复制为新增',
            click: row => { this.$emit('add', row, 'add') }
          }
        },
      ]
    }
  },
  props: {
    data: Array,
    levelList: Array
  }
}
</script>