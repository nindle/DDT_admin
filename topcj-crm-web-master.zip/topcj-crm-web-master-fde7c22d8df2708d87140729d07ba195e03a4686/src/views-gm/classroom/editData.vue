<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      {{data.id ? '编辑' : '新增'}}产品权限
    </template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <template #right>
      <el-scrollbar-pro class="auth-box">
        <el-form-pro
          class="right-form"
          :model="form"
          :config="configRight"
          ref="formRight"
        ></el-form-pro>
      </el-scrollbar-pro>
    </template>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >确 定</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      form: {
        name: this.data?.name ?? '',
        description: this.data?.description ?? '',
        sn: this.data?.sn ?? '',
        cover: this.data?.cover ?? '',
        serviceDay: this.data?.serviceDay ?? '',
        maxGiveday: this.data?.maxGiveday ?? '',
        useCorpIds: this.data?.useCorpIds?.split(',').filter(e => e).map(e => Number(e)) ?? [],
        level: this.data?.level ?? '',
        columnIds: this.data?.columnIds ?? [],
        courseIds: this.data?.courseIds ?? [],
        liveId: this.data?.liveId ?? '',


        teacherId: this.data?.teacherId ?? 9,
        stime: this.data.stime ? new Date(this.data.stime).getTime() : new Date().getTime(),
        baseId: this.data?.baseId ?? '',
        signCount: this.data?.signCount ?? 0,
        studyCount: this.data?.studyCount ?? 0,
        viewCount: this.data?.viewCount ?? 0,
        showStatus: this.data?.showStatus ?? 0,
        sort: this.data?.sort || undefined,
        isVisible: this.data?.isVisible ?? 1,

        showType: this.data?.showType ?? '',
        caseStock: this.data?.caseStock ?? '',
        subIds: this.data?.subIds ?  this.data?.subIds?.split(',') : [],
      },
      config: {
        name: {
          label: '产品权限名称',
          rule:[
            { required: true }
          ]
        },
        description: {
          type: 'textarea',
          label: '简介',
          rule: [
            { required: true }
          ]
        },
        sn: {
          label: '别名',
          type: 'select',
          filterable: true,
          options: this.snList,
          labelKey: 'typeName',
          valueKey: 'extValue',
          rule: [
            { required: true }
          ]
        },
        cover: {
          type: 'image',
          label: '图标',
          size: 'medium'
        },
        serviceDay: {
          type: 'number',
          label: '服务时长',
          unit: '天',
          min: 0,
          rule: [
            { required: true }
          ]
        },
        maxGiveday: {
          type: 'number',
          label: '最大赠送',
          unit: '天',
          min: 0,
          rule: [
            { required: true }
          ]
        },
        useCorpIds: {
          type: 'select-corp',
          label: '公用总部内容',
          multiple: true,
        },


        
        // baseId: {
        //   type: 'select',
        //   label: '配置权限',
        //   filterable: true,
        //   options: this.classList,
        //   labelKey: 'name',
        //   valueKey: 'id',
        //   rule: [
        //     { required: true }
        //   ]
        // },
        
        sort: {
          type: 'number',
          label: '排序',
          placeholder: '数字越大越靠前',
          min: 0
        },
        // viewCount: {
        //   type: 'number',
        //   label: '围观人数',
        //   min: 0,
        //   rule: [
        //     { required: true }
        //   ]
        // },
        // studyCount: {
        //   type: 'number',
        //   label: '学习人数',
        //   min: 0,
        //   rule: [
        //     { required: true }
        //   ]
        // },
        
        // functionIds: {
        //   type: 'select',
        //   label: '绑定功能',
        //   multiple: true,
        //   filterable: true,
        //   options: this.functionList,
        //   labelKey: 'name',
        //   valueKey: 'id',
        // },
        showStatus: {
          type: 'switch',
          label: '套餐管理是否显示',
          activeValue: 0,
          inactiveValue: 1,
        },
        isVisible: {
          type: 'switch',
          label: '至尊版APP是否显示',
          activeValue: 1,
          inactiveValue: 2,
        },
      },
      configRight: {
        level: {
          type: 'select',
          label: '权限等级',
          options: this.levelList,
          labelKey: 'typeName',
          valueKey: 'typeId',
          rule: [
            { required: true }
          ]
        },
        courseIds: {
          type: 'select',
          label: '绑定课程',
          multiple: true,
          filterable: true,
          options: this.courseList,
          labelKey: 'name',
          valueKey: 'id',
        },
        liveId: {
          type: 'select',
          label: '绑定直播间',
          filterable: true,
          options: this.liveList,
          labelKey: 'name',
          valueKey: 'id'
        },
        columnIds: {
          type: 'select',
          label: '绑定速递',
          multiple: true,
          filterable: true,
          options: this.columnList,
          labelKey: 'typeName',
          valueKey: 'id',
        },
        showType: {
          type: 'select',
          label: 'APP展示类型',
          options: [
            { value: 1, label: '原生' },
            { value: 2, label: 'H5直播间' },
            { value: 3, label: '案例股-文本' },
            { value: 4, label: '案例股-图片' },
          ]
        },
        caseStock: {
          type: 'select',
          label: '案例股',
          filterable: true,
          options: this.columnList,
          labelKey: 'typeName',
          valueKey: 'id',
        },
        subIds: {
          type: 'select',
          label: '子权限',
          multiple: true,
          filterable: true,
          options: this.subidsList,
          labelKey: 'className',
          valueKey: 'classId',
        },
      }
    }
  },
  props: {
    show: Boolean,
    data: Object,
    courseList: Array,
    liveList: Array,
    levelList: Array,
    snList: Array,
    columnList: Array,
    subidsList: Array,
  },
  methods: {
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return
      if(!await this.$refs.formRight.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: this.data.id ? '%CRM%/class/edit.sdcrm' : '%CRM%/class/add.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          name: this.form.name,
          sn: this.form.sn,
          description: this.form.description,
          teacherId: this.form.teacherId || undefined,
          stime: this.form.stime ? new Date(this.form.stime).timeFormat('yyyy-MM-dd hh:mm:ss') : undefined,
          liveId: this.form.liveId,
          baseId: this.form.baseId,
          cover: this.form.cover,
          level: this.form.level,
          sort: this.form.sort || 0,
          signCount: this.form.signCount,
          viewCount: this.form.viewCount,
          studyCount: this.form.studyCount,
          courseIds: this.form.courseIds,
          showStatus: this.form.showStatus,
          isVisible: this.form.isVisible,
          serviceDay: this.form.serviceDay,
          maxGiveday: this.form.maxGiveday,
          useCorpIds: this.form.useCorpIds.join(','),
          columnIds: this.form.columnIds,
          showType: this.form.showType,
          caseStock: this.form.caseStock,
          subIds: this.form.subIds.join(','),
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>

<style lang="scss" scoped>
.auth-box {
  margin-top: 54px;
  height: calc(100% - 54px);
  .right-form {
    width: 520px;
    padding: 20px;
    box-sizing: border-box;
  }
}
</style>