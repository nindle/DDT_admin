<template>
  <div class="view">
    <el-layout-pro class="box">
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
        ></el-screen-pro>
      </template>

      <template #table>
        <left-box 
          v-if="leftShow"
          :data="dataList"
          @scroll="getList(true)"
          @message="getMsgChange"
        />

        <right-box 
          v-if="selectIndex !== -1"
          :item="dataList[selectIndex]"
          :userid="screen.manager"
          :qywx="screen.company"
          :manager="config.manager.options"
          :route-type="tag.v23.visible"
          ref="message"
        />
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { md5 } from '../../assets/js/crypto'
import LeftBox from './leftBox'
import RightBox from './rightBox'
export default {
  name: 'gm-extcontact',
  data() {
    return {
      screen: {
        company: '',
        group: '',
        manager: ''
      },
      config: {
        company: {
          type: 'select-qywx',
          change: () => {
            this.screen.group = ''
            this.screen.manager = ''
          }
        },
        group: {
          type: 'select',
          placeholder: '部门',
          options: [
            { label: '销售部', value: 2 },
            { label: '客服部', value: 1 },
          ],
          change: this.getManagerList
        },
        manager: {
          type: 'select',
          placeholder: '员工',
          options: [],
          labelKey: 'realName',
          valueKey: 'qyUserId',
          change: this.getList
        }
      },
      dataList: [],
      // 展示
      leftShow: false,
      selectIndex: -1,
    }
  },
  props: {
    tag: Object
  },
  methods: {
    async getManagerList() {
      let time = Date.now()
      let sign = md5(`075dfa7becf54cc4aff1d75080983eb9${time}`)

      let url = this.tag.v23.visible ? '%CRM%/external/get_manager_list.sdcrm' : '%CRM%/msg_external/get_manager_list.sdcrm'
      let { result } = await this.$http({
        url,
        data: {
          token: true,
          qyWx: Number(this.screen.company),
          deadline: time,
          sign,
          managerType: this.screen.group
        }
      })
      
      let obj = {}
      this.screen.manager = ''
      let list = result? result.reduce((pre,e) => {
        obj[e.id] ? '' : obj[e.id] = pre.push(e)
        return pre
      },[]) : []

      if(this.tag.v23.visible) {
        this.config.manager.options = list.map(e => {
          e.realName = e.name
          e.qyUserId = e.userid
        })
      }
      
      this.config.manager.options = list

    },
    async getList(scroll) {
      let time = Date.now()
      let sign = md5(`075dfa7becf54cc4aff1d75080983eb9${time}`)
      if(!scroll) {
        this.selectIndex = -1
        this.dataList = []
      }
      
      let url = ''
      let data = {
        token: true,
        deadline: time,
        sign,
        qyWx: this.screen.company
      }

      if(this.tag.v23.visible) {
        url = '%CRM%/external/get_external.sdcrm'
        data.userId = this.screen.manager
        data.pageSize = 30
        data.pageNumber = Math.ceil(this.dataList.length/ 30) + 1
      } else {
        url = '%CRM%/msg_external/get_external.sdcrm'
        data.qyUserId = this.screen.manager
        data.managerId = this.config.manager.options.filter(e => e.qyUserId === this.screen.manager)[0].managerId
      }
      
      let { code,result } = await this.$http({
        url,
        data
      })
      
      if(code !== 8200) return
      if(!result) result = []

      let managerName = this.config.manager.options.filter(e => e.qyUserId === this.screen.manager)[0].realName
      let list = []
      if(this.tag.v23.visible) {
        list = result.map(e => {
          e.contactJson = JSON.parse(e.contactJson)
          e.managerName = managerName
          e.userName = e.contactJson.external_contact.name
          e.avatarPath = e.contactJson.external_contact.avatar

          return e
        })
      } else {
        list = result.map(e => {
          e.managerName = managerName
          e.userName = e.externalName
          e.avatarPath = e.avatar
          e.id = e.userId

          return e
        })
      }
      

      this.leftShow = true
      this.dataList = [...this.dataList, ...list]
    },
    getMsgChange(index) {
      this.selectIndex = index
      // this.$nextTick(() => {
      //   this.$refs.message.getMsg()
      // })
    }
  },
  components: { 
    LeftBox,
    RightBox
  },
  created() {
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    /deep/ {
      .screen-box {
        background: #FFF;
        padding-bottom: 24px;
      }
      .table-box {
        height: 100%;
        padding: 0;
        display: flex;
        justify-content: space-between;
      }
    }
    .box-scroll {
      height: calc(100% - 24px);
      display: flex;
      justify-content: space-between;
      margin-top: 24px;
      .two-box {
        width: calc(50% - 12px);
        background: #FFF;
      }
    }
  }
}
</style>