<template>
  <div class="left-view">
    <el-layout-pro 
      class="left-box"
      @scroll-bottom="$emit('scroll')"
    >
      <template #screen>
        <el-screen-pro :config="config"></el-screen-pro>
      </template>
      <template #scroll>
        <div 
          v-for="(e,i) in data"
          :key="e.id"
          class="left-content"
          :class="{active: i === index}"
          @click="clickMsg(i)"
        >
          <div 
            class="head"
            :style="{ backgroundImage: `url(${e.avatar})` }"  
          ></div>
          <div class="name">{{e.userName}}</div>
        </div>
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
export default {
  data() {
    return {
      config: {
        label: {
          type: 'label',
          label: '客户列表'
        }
      },
      index: -1,
    }
  },
  props: {
    data: Array
  },
  methods: {
    clickMsg(data) {
      this.index = data
      this.$emit('message',data)
    }
  }
}
</script>
<style lang="scss" scoped>
@import "../../assets/css/common.scss";
.left-view {
  width: 240px;
  height: calc(100% - 24px);
  margin-top: 24px;
  .left-box {
    width: 100%;
    height: 100%;
    background: #FFF;
    /deep/ {
      .screen-box {
        padding-bottom: 0 !important;
      }
      .scrollbar-view {
        height: 100%;
        display: block !important;
        padding: 0 24px;
      }
    } 
    .left-content {
      display: flex;
      line-height: 52px;
      padding: 0 12px;
      box-sizing: border-box;
      align-items: center;
      border: 1px solid rgba(0,0,0,0);
      border-bottom-color: #E9E9E9;
      cursor: pointer;
      .head {
        width: 40px;
        height: 40px;
        border-radius: 2px;
        background-size: cover;
        background-position: center;
      }
      .name {
        margin-left: 12px;
        @include ellipsis;
      }
      &.active {
        border: 1px solid #3288FF;
        background: rgba(48,137,255,0.12);
      }
    }
  }
}
</style>