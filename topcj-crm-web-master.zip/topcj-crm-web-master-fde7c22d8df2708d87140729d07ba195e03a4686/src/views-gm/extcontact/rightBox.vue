<template>
  <div class="right-view">
    <el-layout-pro
      class="right-box"
      @scroll-bottom="getMsg()"
    >
      <template #screen>
        <el-screen-pro :config="config"></el-screen-pro>
      </template>

      <template #scroll>
        <message :data="messageList"/>
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { md5 } from '../../assets/js/crypto'
import Message from '../../components/message'
export default {
  
  data() {
    return {
      config: {
        label: {
          type: 'label',
          label: '聊天记录'
        }
      },
      messageList: [],
    }
  },
  props: {
    item: Object,
    userid: String,
    qywx: String,
    manager: Array,
    routeType: Number
  },
  methods: {
    async getMsg() {
      let time = Date.now()
      let sign = md5(`075dfa7becf54cc4aff1d75080983eb9${time}`)

      let url = this.routeType === 1 ? '%CRM%/external/chat_data_list.sdcrm' : '%CRM%/msg_external/chat_data_list.sdcrm'
      let data = {
        token : true,
        sign,
        deadline: time,
        qyWx: this.qywx
      }
      if(this.routeType === 1) {
        data.managerUserId = this.userid
        data.userId = this.item.externalUserid
        data.pageNumber = this.messageList.length
        data.pageSize = 30
      } else {
        data.userId = this.item.userId
        data.qyUserId = this.userid
        data.form = this.messageList.length
        data.managerId = this.manager.filter(e => e.qyUserId === this.userid)[0].managerId
      }

      let { code,result } = await this.$http({
        url,
        data
      })

      
      if(code !== 8200) return
      if(!result) result = []
      
      let list = []
      if(this.routeType === 1) {
        list = result.map(e => {
          e.nickname = this.item.userName
          e.managerName = this.item.managerName
          e.lastTime = e.msgtime
          e.msgType = e.msgtype
          e.imageUrl = e.mediaUrl
          if(e.sfrom === this.item.externalUserid) {
            e.type = 1
          }else{
            e.type = 0
          }

          return e
        })
      } else {
        list = result.map(e => {
          e.nickname = this.item.userName
          e.lastTime = e.ctime
          e.managerName = this.manager.filter(e => e.qyUserId === this.userid)[0].realName
          return e
        })
      }
      

      this.messageList = [...this.messageList, ...list]
    }
  },
  watch: {
    item() {
      this.messageList = []
      this.getMsg()
    }
  },
  components: { Message },
  created() {
    this.getMsg()
  },
}
</script>
<style lang="scss" scoped>
.right-view {
  width: 84%;
  height: calc(100% - 24px);
  margin-top: 24px;
  .right-box {
    width: 100%;
    height: 100%;
    background: #FFF;
    /deep/ {
      .screen-box {
        padding-bottom: 0 !important;
      }
      .scrollbar-view {
        padding: 0 24px;
      }
    }
    
  }
}
</style>