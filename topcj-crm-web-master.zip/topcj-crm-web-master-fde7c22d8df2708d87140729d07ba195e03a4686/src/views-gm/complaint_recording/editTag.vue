<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      请给该处理信息打上相应属性的标签
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        degree: '',
        servise: '',
        userType: ''
      },
      config: {
        degree: {
          type: 'select',
          label: '投诉程度',
          options: this.tag.t6.filter(e => e.visible),
          labelKey: 'valueName',
          valueKey: 'id'
        },
        servise: {
          type: 'select',
          label: '服务情况',
          options: this.tag.t7.filter(e => e.visible),
          labelKey: 'valueName',
          valueKey: 'id'
        },
        userType: {
          type: 'select',
          label: '用户类型',
          options: this.tag.t8.filter(e => e.visible),
          labelKey: 'valueName',
          valueKey: 'id'
        }
      },
      loading: false
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  inject: ['tag'],
  methods: {
    //初始化数据
    async initData() {
      let data = await this.$http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.userId,
              labelId: 6,
            }
          },
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.userId,
              labelId: 7,
            }
          },
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.userId,
              labelId: 8,
            }
          }
        ]
      })

      this.form.degree = data[0].result?.id
      this.form.servise = data[1].result?.id
      this.form.userType = data[2].result?.id
    },
    //提交
    submit: throttle(async function() {
      this.loading = true

      let allData = [
        {
          url: `%CRM%/label/set_label.sdcrm`,
          data: {
            token: true,
            targetId: this.data.userId,
            labelId: 6,
            valueId: this.form.degree || undefined
          }
        },
        {
          url: `%CRM%/label/set_label.sdcrm`,
          data: {
            token: true,
            targetId: this.data.userId,
            labelId: 7,
            valueId: this.form.servise || undefined
          }
        },
        {
          url: `%CRM%/label/set_label.sdcrm`,
          data: {
            token: true,
            targetId: this.data.userId,
            labelId: 8,
            valueId: this.form.userType || undefined
          }
        }
      ]

      let data = await this.$http({
        mode: 'relay',
        all: allData
      })

      if(data.filter(e => e.code === 8200).length !== data.length) {
        this.$message.error('保存失败')
        return
      } 

      this.loading = false

      this.$emit('change')
      this.$emit('review')
      
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  },
  created() {
    this.initData()
  }
}
</script>
