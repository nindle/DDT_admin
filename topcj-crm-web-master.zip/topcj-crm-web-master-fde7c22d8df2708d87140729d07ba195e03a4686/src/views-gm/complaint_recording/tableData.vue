<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-imageUrl="{ row }">
      <msg-audio :audio="row.imageUrl" />
    </template>
  </el-table-pro>
</template>
<script>
import MsgAudio from '../../components/message/msg-audio'

export default {
  data() {
    return {
      head: [
        {
          key: 'corpId',
          label: '分公司',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.corpList,
            key: 'id',
            value: 'corpName'
          }
        },
        {
          key: 'managerName',
          label: '接线员',
          minWidth: 70
        },
        {
          key: 'appType',
          label: '类型',
          minWidth: 84,
          format:{
            '3': '热线',
            '9': '手机录音上传'
          }
        },
        {
          key: 'lastTime',
          label: '录音时间',
          minWidth: 90,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd') : '--'
        },
        {
          key: 'imageUrl',
          label: '投诉录音',
          minWidth: 180,
        },
        {
          key: 'tag',
          label: '标签',
          width: 44,
          button: {
            icon: 'el-icon-price-tag',
            label: '标签',
            type: 'text',
            click: row => { this.$emit('open-tag', row) }
          }
        }
      ]
    }
  },
  props: {
    data: Array
  },
  components: {
    MsgAudio
  }
}
</script>