<template>
  <div class="view">
    <el-layout-pro 
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tabledata"
          @open-tag="openEditTag"
        />
      </template>

      <template #popover>
        <edit-tag 
          v-if="showEditTag"
          :show.sync="showEditTag"
          :data="rowData"
        />
      </template>

    </el-layout-pro>  
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditTag from './editTag'

export default {
  name: 'gm-complaint_recording',
  data() {
    return {
      //加载状态
      loading: false,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      //表格数据
      tabledata: [],
      // 筛选
      screen: {
        corpId: '',
        managerId: '',
        appType:null,
        time: []
      },
      config: {
        corpId: {
          type: 'select-corp'
        },
        managerId: {
          type: 'select-manager',
          placeholder: '接线员',
          filter: () => {
            if(typeof this.screen.corpId === 'number') {
              return {
                corpId: this.screen.corpId
              }
            }
            return {}
          }
        },
        appType: {
          type: 'select',
          placeholder:'请选择类型' ,
           options:[
            {
              value: 3,
              label: '热线'
            },
            {
              value: 9,
              label: '手机录音上传'
            },
           ]
        },
        time: {
          type: 'date-range'
        }
      },
      showEditTag: false,
      rowData: null
    }
  },
  props: {
    tag: Object
  },
  provide() {
    return {
      tag: this.tag
    }
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/user/message/get_complaint_recording.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          managerId: this.screen.managerId,
          userId:this.screen.keyword? this.screen.keyword : undefined,
          appType:this.screen.appType? this.screen.appType : undefined,
          stime: this.screen.time?.[0] ?? undefined,
          etime: this.screen.time?.[1] ?? undefined,
          corpId:typeof this.screen.corpId === 'number'? this.screen.corpId : undefined
        }
      })
      this.total = result.total
      this.tabledata = result.records

      this.loading = false
    }),
    openEditTag(data) {
      this.rowData = data
      this.showEditTag = true
    }
  },
  components: {
    TableData,
    EditTag
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>