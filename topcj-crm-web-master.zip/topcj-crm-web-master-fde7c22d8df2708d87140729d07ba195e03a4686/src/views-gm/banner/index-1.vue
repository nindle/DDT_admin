<template>
  <index :type="1"/>
</template>
<script>
import Index from './index.vue'
export default {
  name: 'gm-extension',
  components: {
    Index
  }
}
</script>