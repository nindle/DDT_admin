<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>批量设置分组</template>
    <!-- 表单内容 -->
    <el-form-pro :model="form" :config="config" ref="form">
    </el-form-pro>

    <!-- 底部按钮 -->
    <template #footer>
      <el-button size="small" @click="close">取 消</el-button>
      <el-button type="primary" size="small" @click="submit" :loading="loading">确 定</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {

    return {
      form: {
        groupId: '',
      },
      config: {
        groupId: {
          type: 'select',
          label: '活码分组',
          options: this.groupList,
          labelKey: 'groupName',
          valueKey: 'id',
          rule: [{ required: true }],
        }
      },
      loading: false,
    }
  },
  props: {
    show: Boolean,
    data: Array,
    groupList: Array
  },
  methods: {
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/ad/set_ad_group.sdcrm',
        data: {
          token: true,
          groupId: this.form.groupId,
          adIdList: this.data.map(e => e.id).join(',')
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>