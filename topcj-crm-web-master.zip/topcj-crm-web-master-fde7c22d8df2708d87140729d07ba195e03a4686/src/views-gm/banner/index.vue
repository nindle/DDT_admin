<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <!-- 筛选模块 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <!--表格模块-->
      <template #table>
        <table-data
          :data="tableData"
          :user-type-list="config.userTypeId.options"
          :select-list.sync="selectList"
          :page-type-list="config.pageType.options"
          :category-list="categoryList"
          :app-list="appList"
          :type="type"
          @edit="openPopover"
          @resources="openResources"
          @change="getTableData"
        />
      </template>

      <!--编辑模块-->
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          :promotion-list="promotionList"
          :user-type-list="config.userTypeId.options"
          :page-type-list="config.pageType.options"
          :group-list="config.groupId.options"
          :app-list="appList"
          :tag-list="tagList"
          :wxkf-list="wxkfList"
          :category-list="categoryList"
          :type="type"
          @change="getTableData()"
        />
        <edit-group
          v-if="showSetGroup"
          :show.sync="showSetGroup"
          :data="selectList"
          :group-list="config.groupId.options"
          @change="getTableData()"
        />

        <add-resources
          v-if="showResources"
          :show.sync="showResources"
          :data="resourcesData"
        />

        <review
          v-if="showReview"
          :show.sync="showReview"
          :review-list="reviewList"
          @success="getTableData()"
          custom-reason
          reason
          deduct
          source="t_sd_ad"
          reviewKey="state"
        />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'
import EditGroup from './editGroup'
import Review from '../../components/review/index'
import AddResources from './addResources.vue'

export default {
  name: 'gm-banner',
  data () {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      showSetGroup: false,
      //修改数据
      rowData: null,
      screen: {
        corpId: '',
        keyword: '',
        userTypeId: '',
        resChannelId: '',
        pageType: '',
        createrId: '',
        status: '',
        wxType: this.$route.params?.groupId ? 3 : '',
        groupId: this.$route.params?.groupId ?? ''
      },
      tagList: [],
      config: {
        corpId: {
          type: 'select-corp'
        },
        userTypeId: {
          placeholder: '推广公司',
          hide: this.type !== 1,
          type: 'select',
          options: [],
          labelKey: 'resName',
          valueKey: 'id'
        },
        pageType: {
          type: 'select',
          placeholder: '页面类型',
          hide: this.type !== 1,
          options: [
            { value: 0, label: '没有页面类型' },
            { value: 1, label: '手机号模式-无跳转' },
            { value: 2, label: '手机号模式-跳转加微' },
            { value: 6, label: '手机号模式-购买跳转加微' },
            { value: 3, label: '小程序模式-跳转加微' },
            { value: 4, label: '小程序模式-跳转客服会话加微' },
            { value: 5, label: '小程序模式-跳转获取手机号加微' },
            { value: 7, label: '微信客服模式-手机号跳转微信客服' },
            { value: 8, label: '微信客服模式-直接跳转微信客服' },
            { value: 9, label: '公众号模式-直接跳转加微' },
            { value: 10, label: '微信客服模式-手机号跳转微信客服再跳转页面' },
            { value: 11, label: '微信客服模式-直接跳转微信客服再跳转页面' },
          ]
        },
        createrId: {
          type: 'select',
          placeholder: '送审人',
          hide: this.type !== 1,
          options: [
            { value: this.$store.state.managerInfo.id, label: this.$store.state.managerInfo.realName },
          ]
        },
        pubStatus: {
          type: 'select',
          placeholder: '推广状态',
          hide: this.type !== 1,
          options: [
            { value: 0, label: '停用' },
            { value: 1, label: '启用' }
          ]
        },
        status: {
          type: 'select',
          placeholder: '审核状态',
          options: [
            { value: 0, label: '待审核' },
            { value: 1, label: '通过' },
            { value: 2, label: '不通过' }
          ]
        },
        resChannelId: {
          placeholder: '投放渠道',
          type: 'select',
          options: this.$store.state.baseData.resChannelList,
          labelKey: 'channelName',
          valueKey: 'id'
        },
        wxType: {
          type: 'select',
          placeholder: '推广轮询方式',
          options: [
            { value: 0, label: '默认方式' },
            { value: 1, label: '企业微信方式' },
            { value: 2, label: '外部联系人方式' },
            { value: 3, label: '活码分组方式' },
          ],
          hide: this.type !== 1,
          change: () => {
            this.screen.groupId = ''
          }
        },
        groupId: {
          type: 'select',
          placeholder: '活码分组',
          options: [],
          labelKey: 'groupName',
          valueKey: 'id',
          hide: () => this.type !== 1 || this.screen.wxType !== 3,
        },
        split: { type: 'split' },
        keyword: {
          type: 'input',
          placeholder: '搜索编号',
          changeLog: true
        },
        br: { type: 'br' },
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) }
        },
        setGroup: {
          type: 'button',
          buttonType: 'primary',
          label: '批量分组',
          click: this.setGroup,
          hide: () => this.type !== 1 || this.screen.wxType !== 3,
        },
        split2: { type: 'split' },
        reviewOnline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核通过',
          click: () => { this.openReview(1) }
        },
        reviewOffline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核不通过',
          click: () => { this.openReview(2) }
        },
      },
      //审核相关
      selectList: [],
      showReview: false,
      reviewList: [],
      // 资源弹窗
      showResources: false,
      resourcesData: {},


      //其他数据
      promotionList: [],

      // 推广页面风格
      categoryList: [],

      //小程序列表
      appList: [],

      //微信客服列表
      wxkfList: []
    }
  },
  props: {
    type: Number
  },
  components: {
    TableData,
    EditData,
    Review,
    AddResources,
    EditGroup
  },
  methods: {
    //数据获取
    getTableData: throttle(async function (toFirst) {
      this.loading = true

      if (toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/ad/get_ad_search.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          companyId: this.screen.corpId,
          keyword: this.screen.keyword || undefined,
          pageId: this.type,
          userTypeId: typeof this.screen.userTypeId === 'number' ? this.screen.userTypeId : undefined,
          resChannelId: typeof this.screen.resChannelId === 'number' ? this.screen.resChannelId : undefined,
          pageType: typeof this.screen.pageType === 'number' ? this.screen.pageType : undefined,
          pubStatus: typeof this.screen.pubStatus === 'number' ? this.screen.pubStatus : undefined,
          wxType: typeof this.screen.wxType === 'number' ? this.screen.wxType : undefined,
          groupId: typeof this.screen.groupId === 'number' ? this.screen.groupId : undefined,
          createrId: this.screen.createrId,
          status: typeof this.screen.status === 'number' ? this.screen.status : undefined,
          visible: this.type === 1 ? 1 : undefined
        }
      })

      let now = Date.now()

      this.total = result.total
      this.tableData = result.contents.map(e => {
        let linkState = 0
        if (e.link && [3, 4, 5].includes(e.pageType)) {
          let time = Number(e.link.split(';')[1] || 0)
          if (now - time < 169 * 24 * 3600 * 1000) {
            linkState = 1
          } else if (now - time < 179 * 24 * 3600 * 1000) {
            linkState = 2
          } else {
            linkState = 3
          }
        }

        return {
          ...e,
          linkState
        }
      })
      this.loading = false
    }),
    //打开弹框
    openPopover (data) {
      this.rowData = data
      this.showPopover = true
    },
    // 打开二维码
    openResources (data) {
      this.showResources = true
      this.resourcesData = data
    },
    //审核
    openReview (state) {
      this.reviewList = this.selectList.map(e => {
        return {
          url: '%CRM%/ad/audit.sdcrm',
          data: {
            token: true,
            id: e.id,
            state,
            corpId: this.$store.state.managerInfo.corpId,
          }
        }
      })

      this.showReview = true
    },
    //批量设置分组
    setGroup() {
      if(!this.selectList.length) {
        this.$message.warning('请选择需要修改的数据')
        return
      }
      this.showSetGroup = true
    },
    async getPromotionList () {
      let { result } = await this.$http({
        url: '%CRM%/promotion/get_list.sdcrm',
        data: {
          token: true,
          corpId: this.$store.state.managerInfo.corpId || undefined,
          status: 1
        }
      })

      this.promotionList.splice(0, this.promotionList.length, ...result)
    },
    //获取推广商
    async getUserTypeList () {
      let { result } = await this.$http({
        url: '%CRM%/lvm_user_type/get_lvm_user_type_search.sdcrm',
        data: {
          token: true,
          isPage: 1
        }
      })

      this.config.userTypeId.options.splice(0, this.config.userTypeId.options.length, ...result.reverse())
    },
    // 获取推广页面分类
    async getCategoryList () {
      let { result } = await this.$http({
        url: '%CRM%/setting/get_types/61.sdcrm',
        mode: 'get',
        data: {
          token: true,
        }
      })

      this.categoryList.splice(0, this.categoryList.length, ...result)
    },
    // 获取小程序列表
    async getAppList () {
      let { result } = await this.$http({
        url: '%CRM%/ad/get_wx_app.sdcrm',
        data: {
          token: true,
          type: 3,
          isPage: 1
        }
      })

      this.appList.splice(0, this.appList.length, ...result.map(e => {
        if (e.id === 36) {
          e.disabled = true
        }
        return e
      }))
    },
    //获取微信客服列表
    async getWxkfList () {
      let { result } = await this.$http({
        url: '%CRM%/ad/get_wxkf_list.sdcrm',
        data: {
          token: true,
          isPage: 1
        }
      })

      this.wxkfList.splice(0, this.wxkfList.length, ...result)
    },
    // 获取推送对象列表
    async getTagList () {
      let { result } = await this.$http({
        url: '%ZZB%/dragon/inside/message/tags',
        mode: 'get'
      })
      this.tagList.splice(0, this.tagList.length, ...result)
    },
    // 获取分组列表
    async getGroupList () {
      let { result } = await this.$http({
        url:'%CRM%/qywx/get_qywx_group_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
          status: 1
        }
      })

      this.config.groupId.options.splice(0, this.config.groupId.options.length, ...result)
    }
  },
  created () {
    if (this.type === 1) {
      this.getPromotionList()
      this.getUserTypeList()
      this.getCategoryList()
      this.getAppList()
      this.getWxkfList()
      this.getGroupList()
    }
    this.getTagList()
  }
}
</script>

<style scoped lang="scss">
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #fff;
  }
}
</style>
