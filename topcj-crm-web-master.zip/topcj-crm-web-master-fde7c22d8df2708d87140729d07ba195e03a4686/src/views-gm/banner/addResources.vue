<template>
  <el-dialog-pro @close="close">
    <template #title>二维码管理</template>

    <el-form :inline="true" :model="form" class="demo-form-inline">
      <el-form-item label="推广对象选择">
        <el-select
          v-model="form.keyWord"
          multiple
          filterable
          remote
          reserve-keyword
          placeholder="请输入关键词"
          :remote-method="remoteMethod"
          :loading="remoteLoading"
          @change="getTable"
          @visible-change="(e) => {if(!e) { options = []}}"
        >
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
            :disabled="item.disabled"
          >
          </el-option>
        </el-select>
      </el-form-item>
    </el-form>

    <el-table-pro
      :head="head"
      :data="tableData"
    ></el-table-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      form: {
        keyWord: []
      },
      options: [],
      remoteLoading:false,
      codeList: [],
      groupList: [],
      tableData: [],
      head: [
        {
          key: 'managerName',
          label: '选择对象',
          minWidth: 80
        },
        {
          key: 'group',
          label: '归属小组',
          minWidth: 70,
          default: '--'
        },
        {
          key: 'qwName',
          label: '归属企微',
          minWidth: 70,
          default: '--'
        },
        {
          key: 'qrcode',
          label: '二维码',
          minWidth: 70,
          default: '--'
        },
        {
         key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            label: '删除',
            icon: 'el-icon-delete',
            popconfirm: '确认删除吗？',
            click:(row) => { this.delet(row) }
          }
        },
      ]
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  computed: {
    qwList() {
      return this.$store.state.baseData.qywxList
    },
  },
  methods: {
    close() {
      this.$emit('update:show', false)
    },
    submit: throttle(async function() {

      let list = this.tableData.filter(e => e.codeGroupId)

      let codeContent = [...this.tableData.filter(e => !e.codeGroupId)]
      list.forEach(e => {
        e.content.split(',').forEach(item => {
          this.codeList.forEach(cItem => {
            if(cItem.id === Number(item)) {
              let qwName = this.qwList.find(qItem => qItem.qyWx === (cItem?.qyWx ?? null))?.wxName ?? '--'
              codeContent.push({
                ...cItem,
                label: `${cItem.managerName} ${qwName} ${cItem.name}`,
              })
            }
          })
        })
      })
      
      let obj = {}
      codeContent = codeContent.reduce((pre,item) => {
        obj[item.label] ? '' : obj[item.label] = pre.push(item)
        return pre
      },[])
      let { code,msg,errmsg } = await this.$http({
        url: '%CRM%/ad/set_ad_code.sdcrm',
        data: {
          token: true,
          adId: this.data.id,
          codeList: codeContent.map(e => {
            return {
              codeId: e.codeId || e.id,
              topNum: 0
            }
          }),
        }
      })

      if(code !== 8200) {
        this.$message.error('保存失败' + msg || errmsg)
        return
      }
      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    // 获取二维码关系数据
    async getAdCodeList() {
      let { result } = await this.$http({
        url: '%CRM%/ad/get_ad_code_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
          adId: this.data.id
        }
      })
      
      if(!result && !result.length) {
        this.tableData = result
        return
      }

      this.$nextTick(() => {
        this.init(result)
      })
      
    },
    getTable() {
      if(this.tableData.find(e => e.label === this.form.keyWord[0])) {
        this.$message('不可重复添加')
        this.form.keyWord = []
        return
      }
      let item = this.options.find(item => item.label === this.form.keyWord[0])
      this.tableData.push(item)

      this.form.keyWord = []

      let obj = {}
      
      this.tableData = this.tableData.reduce((pre,item) => {
        obj[item.label] ? '' : obj[item.label] = pre.push(item)
        
        return pre
      },[])
    },
    // 弹出筛选框
    remoteMethod(e) {
      this.options = []
      if(!e) {
        return
      }
      
      // this.getGroupList(e)
      this.options.push(...this.groupList.filter(groupE => groupE.name.includes(e)).map(item => {
        return {
          codeGroupId: item.id,
          group: '/',
          qyWx: '/',
          managerName: item.name,
          disabled: !!this.tableData.find(tableItem => tableItem.label === item.name),
          label: item.name,
          value: item.name,
          ...item
        }
      }))
      // this.getCodeList(e)
      this.options.push(...this.codeList.filter(codeE => codeE.name.includes(e) || codeE.managerName.includes(e)).map(item => {
        let groupItem = this.groupList.find(item => item.content.includes(String(item.id)))
        let qwName = this.qwList.find(qItem => qItem.qyWx === item.qyWx)?.wxName ?? '--'
        return {
          qwName: qwName,
          group: groupItem?.name ?? '--',
          qrcode: item.name,
          codeId: item.id,
          disabled: !!this.tableData.find(tableItem => tableItem.label === `${item.managerName} ${qwName} ${item.name ? item.name : '--'}`),
          label: `${item.managerName} ${qwName} ${item.name ? item.name : '--'}`,
          value: `${item.managerName} ${qwName} ${item.name ? item.name : '--'}`,
          ...item
        }
      }))


      let obj = {}
      
      this.options = this.options.reduce((pre,item) => {
        let qwName = this.qwList.find(qItem => qItem.qyWx === item.qyWx)?.wxName ?? '--'
        obj[item.label] ? '' : obj[item.label] = pre.push({
          ...item,
          qyWxName: qwName  
        })
        
        return pre
      },[])
    },
    // 获取小组数据
    async getGroupList() {
      let { result } = await this.$http({
        url: '%CRM%/ad/get_qr_code_group_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
        }
      })

        this.groupList = result
        this.getAdCodeList()

    },
    // 获取二维码数据
    async getCodeList() {
      let { result } = await this.$http({
        url: '%CRM%/ad/get_qr_code_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
        }
      })

      this.codeList = result
      this.getGroupList(undefined)
    },
    // 删除
    async delet(row){
      if(!row.delId) {
        let index = this.tableData.findIndex(e => e.label === row.label)
        this.tableData.splice(index,1)
        return
      }

      let { code,msg,errmsg } = await this.$http({
        url:'%CRM%/ad/del_ad_code.sdcrm',
        data:{
          token:true,
          id: row.delId
        }
      })

      if(code === 8200){
        let index = this.tableData.findIndex(e => e.label === row.label)
        this.tableData.splice(index,1)
        this.$message.success('删除成功')
      }else{
        this.$message.error(msg ? msg : errmsg)
      }
      
    },
    // 初始化
    init(data) {

      this.tableData = data.map(e => {
        let codeData = this.codeList.find(item =>e.codeId === item.id)
        let qwName = this.qwList.find(qItem => qItem.qyWx === codeData?.qyWx ?? null)?.wxName ?? '--'
        let groupItem = this.groupList.find(item => item.content.includes(String(codeData.id)))
        // this.form.keyWord.push(`${codeData?codeData.managerName : '--'} ${qwName} ${codeData ? codeData.name : '--'}`)
        return {
          ...codeData,
          qrcode: codeData?.name ?? '--',
          codeId: codeData?.id ?? '--',
          qwName: qwName,
          group: groupItem?.name ?? '--',
          delId: e.id,
          label: `${codeData?codeData.managerName : '--'} ${qwName} ${codeData ? codeData.name : '--'}`,
          value: `${codeData?codeData.managerName : '--'} ${qwName} ${codeData ? codeData.name : '--'}`
        }
      })
    }
  },
  created() {
    this.getCodeList(undefined)
  },
}
</script>
<style lang="scss" scoped>
// .code-form {
//   display: flex;
//   justify-content: space-between;
//   /deep/ {
//     .el-input {
//       width: calc((100% - 90px) / 2);
//       .el-input__inner {
//         width: 100%;
//       }
//     }

//     .el-select {
//       width: calc((100% - 90px) / 2);
//       .el-input {
//         width: 100%;
//         .el-input__inner {
//           width: 100%;
//         }
//       }
//     }

//     .el-input-number {
//       width: calc((100% - 90px) / 2);
//       .el-input {
//         width: 100%;
//         .el-input__inner {
//           width: 100%;
//         }
//       }
//     }
//   }
// }
</style>