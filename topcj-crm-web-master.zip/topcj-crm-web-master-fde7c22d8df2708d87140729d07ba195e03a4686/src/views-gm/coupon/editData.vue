<template>
<el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      {{data ? '编辑' : '新增'}}活动券
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        type: this.data?.type ?? '',
        couponName: this.data?.couponName ?? '',
        packageId:this.data?.packageId.split(',').map(e => Number(e)) ?? [],
        managerTypes:this.data?.managerTypes?.split(',').filter(e => e).map(e => Number(e)) ?? [],
        money: this.data?.money ?? 0,
        packageMoney: '',
        amount:this.data?.amount ?? 0,
        time: this.data? (this.data.startTime && this.data.endTime ? [this.data.startTime,this.data.endTime] : [] ): [],
        getTime: this.data? (this.data.startGetTime && this.data.endGetTime ? [this.data.startGetTime,this.data.endGetTime] : [] ): [],
        status:this.data?.status ?? 1,
        maxCount: this.data?.maxCount ?? 1,
        corpIds: this.data? (this.data.corpIds?.split(',').map(e => Number(e)) ?? []) : []
      },
      config: {
        type: {
          label: '类型',
          type: 'select',
          options: [
            { value: 0, label: '优惠券' },
            { value: 1, label: '代金券' },
          ],
          rule:[
            { required: true }
          ],
          disabled: !!this.data
        },
        couponName: {
          type: 'input',
          label: '活动券名称',
          rule:[
            { required: true }
          ]
        },
        packageId: {
          type: 'select',
          label: '适用产品',
          options: this.packageList,
          labelKey: 'name',
          valueKey: 'id',
          filterable: true,
          multiple: true,
          change: this.corpInit,
          rule:[
            { required: true }
          ]
        },
        packageMoney: {
          type: 'label',
          label: '最低金额',
        },

        money: {
          type: 'number',
          label: '活动券价格',
          min: 0.01,
          max: 999999,
          unit: '',
          rule:[
            { required: true }
          ],
          hide: () => this.form.type !== 1
        },
        amount: {
          type: 'number',
          label: '抵扣金额',
          min: 0.01,
          max: 999999,
          unit: '',
          rule:[
            { required: true }
          ]
        },
        getTime: {
          type: 'date-time-range',
          label: '领取时间',
          format: 'yyyy-MM-dd HH:mm:ss',
          rule:[
            { required: true }
          ]
        },
        time: {
          type: 'date-time-range',
          label: '使用时间',
          format: 'yyyy-MM-dd HH:mm:ss',
          rule:[
            { required: true }
          ]
        },
        maxCount: {
          type: 'number',
          label: '限领次数',
          min: 1,
          precision: 0,
          rule:[
            { required: true }
          ],
          hide: true
        },
        corpIds: {
          type: 'select',
          label: '使用范围',
          options: [],
          multiple: true,
          labelKey: 'corpName',
          valueKey: 'id',
        },
        managerTypes: {
          type: 'select',
          label: '可见账号类型',
          options: [
            { value: 0, label: '普通账号' },
            { value: 1, label: '售后' },
            { value: 2, label: '业务' },
          ],
          multiple: true,
        },
        status: {
          type: 'switch',
          label: '状态',
          activeValue: 1,
          inactiveValue: 0,
          rule:[
            { required: true }
          ]
        },
      },
      loading: false
    }
  },
  props: {
    show: Boolean,
    data: Object,
    packageList: Array
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return
      this.loading = true
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/coupon/saveOrUpdate.sdcrm',
        data: {
          token: true,
          couponId: this.data?.couponId ?? undefined,
          couponName: this.form.couponName,
          packageId: this.form.packageId.join(','),
          managerTypes: this.form.managerTypes.join(','),
          amount: this.form.amount,
          money: this.form.type === 0 ? 0 : this.form.money,
          startTime: this.form.time?.[0] ?? undefined,
          endTime: this.form.time?.[1] ?? undefined,
          startGetTime: this.form.getTime?.[0] ?? undefined,
          endGetTime: this.form.getTime?.[1] ?? undefined,
          status: this.form.status,
          type: this.form.type,
          maxCount: this.form.maxCount,
          corpIds: this.form.corpIds && this.form.corpIds.length ? this.form.corpIds.join(',') : undefined,
        }
      })
      this.loading = false
      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }
      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    },
    corpInit() {
      
      let packageItem = this.form.packageId.map(e => {
        return this.packageList.find(item => item.id === e)
      }).filter(e => e).sort((a,b) => {return a.money - b.money})
      
      let p = packageItem[0]
      if(!p) {
        this.config.amount.max = 999999  
        this.form.packageMoney = ''
        this.config.corpIds.options = []
        return 
      }

      this.config.amount.max = packageItem.length ? (p.money > 1 ? p.money - 1 : Number((p.money - 0.01).toFixed(2))) : 999999  
      this.form.packageMoney = packageItem.length ? `${p.money}元` : ''
      if(packageItem.find(e => !e.corpIds)) {
        this.config.corpIds.options = this.$store.state.baseData.corpList
        return 
      }
      let list = []

      packageItem.forEach(item => {

        list.push(...item.corpIds.split(','))
      })
      this.config.corpIds.options = this.$store.state.baseData.corpList.filter(e => list.includes(String(e.id)))
    }
  },
  created() {
    this.corpInit()
  }
}
</script>
<style lang="scss" scoped>
/deep/ {
  .el-form-item__content {
    .unit-text {
      position: absolute;
      top: -30px;
      left: 0;
      color: #C83B35;
    }
  }
  
}
</style>