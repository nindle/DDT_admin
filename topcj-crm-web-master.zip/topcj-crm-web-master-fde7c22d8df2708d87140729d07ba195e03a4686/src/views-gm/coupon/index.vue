<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >

      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :package-list="packageList"
          :auth="auth"
          @edit="popover"
          @readreceive="receivePopover"
        />
      </template>

      <template #popover>
        <edit-data 
          v-if="showPopover"
          :show.sync="showPopover"
          :package-list="packageList"
          :data="popoverData"
          @change="getTableData"
        />

        <receive 
          v-if="showReceive"
          :show.sync="showReceive"
          :data="receiveData"
        />
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import EditData from './editData'
import Receive from './receive.vue'
import TableData from './tableData'
export default {
  name: 'gm-coupon',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
        time: [],
        status: '',
        corpId: '',
        type: '',
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          hide: () => { return !this.auth.includes(2)},
          click: () => { this.popover(null) }
        },
        corpId: {
          type: 'select-corp'
        },
        time: {
          type: 'date-range'
        },
        status: {
          type: 'select',
          placeholder: '状态',
          options: [
            {value: 0 , label: '下线'},
            {value: 1 , label: '上线'},
          ]
        },
        type: {
          type: 'select',
          placeholder: '类型',
          options: [
            {value: 0 , label: '优惠券'},
            {value: 1 , label: '代金券'},
          ]
        },
      },
      // 弹窗
      showPopover: false,
      popoverData: {},
      packageList: [],
      // 领取记录弹窗
      showReceive: false,
      receiveData: {}
    }
  },
  props: {
    nav: Object,
    auth: Array
  },
  methods: {
    async getPackageList() {
      let { result } = await this.$http({
        url: '%CRM%/package/get_package_list.sdcrm',
        data: {
          token: true,
          status: 1
        }
      })
      
      this.packageList.splice(0,this.packageList.length,...result)
    },
    getTableData: throttle(async function(toFirst) {
      this.loading = true
      if(toFirst) {
        this.pageNum = 1
      }
      
      let { result } = await this.$http({
        url: '%CRM%/coupon/list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          ctime: this.screen.time?.[0] ?? undefined,
          etime: this.screen.time?.[1] ?? undefined,
          status: typeof this.screen.status === 'number' ? this.screen.status : undefined,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          type: typeof this.screen.type === 'number' ? this.screen.type : undefined,
          managerType: this.auth.includes(2) || this.auth.includes(3) ? undefined : this.$store.state.managerInfo.managerType
        }
      })
      
      this.total = result.total
      this.tableData = result.records.map(e => {
        return {
          ...e,
          disabled: (e.endGetTime ? new Date(e.endGetTime).getTime() < Date.now() : true) || e.status === 0 
        }
      })
      this.loading = false
    }),
    popover(data) {
      this.showPopover = true
      this.popoverData = data
    },
    receivePopover(data) {
      this.showReceive = true
      this.receiveData = data
    }
  },
  components: {
    TableData,
    EditData,
    Receive
  },
  created() {
    this.getPackageList()
  }
  
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>