<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-getTime="{ row }">
      <template v-if="row.startGetTime">{{ row.startGetTime | timeFormat }}</template>
      <template v-else>--</template>
      <br />
      <template v-if="row.endGetTime">{{ row.endGetTime | timeFormat }}</template>
      <template v-else>--</template>
    </template>
    <template #body-time="{ row }">
      <template v-if="row.startTime">{{ row.startTime | timeFormat }}</template>
      <template v-else>--</template>
      <br />
      <template v-if="row.endTime">{{ row.endTime | timeFormat }}</template>
      <template v-else>--</template>
    </template>
  </el-table-pro>
</template>
<script>
import coupon from '../../assets/images/coupon.png'
import coupon2 from '../../assets/images/coupon_2.png'
import logoImage from '../../assets/images/couponLogo.png'
import { createLink, loadimage, throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      head: [
        {
          key: 'ctime',
          label: '创建日期',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd hh:mm:ss') : '--'
        },
        {
          key: 'type',
          label: '类型',
          minWidth: 42,
          format: {
            '0' : '优惠券',
            '1' : '代金券'
          }
        },
        {
          key: 'couponName',
          label: '活动券名称',
          minWidth: 140,
          default: '--'
        },
        {
          key: 'maxCount',
          label: '限领次数',
          minWidth: 56,
          hide: true
        },
        {
          key: 'money,type',
          label: '价格',
          minWidth: 56,
          format: (money,type) => type === 0 ? '--' : money
        },
        {
          key: 'amount',
          label: '抵扣金额',
          minWidth: 56
        },
        {
          key: 'getTime',
          label: '领取时间',
          minWidth: 140,
        },
        {
          key: 'time',
          label: '使用时间',
          minWidth: 140,
        },
        {
          key: 'managerTypes',
          label: '可见账号类型',
          minWidth: 140,
          format: e => {
            const f = {
              '0': '普通账号',
              '1': '售后',
              '2': '业务',
            }
            return (e?.split(',').filter(e => e).map(e => f[e]) ?? []).join('、') || '--'
          }
        },
        {
          key: 'receive',
          label: '领取记录',
          minWidth: 70,
          button: {
            type: 'text',
            icon: 'el-icon-reading',
            label: '领取记录',
            click:row => { this.$emit('readreceive', row) }
          }
        },
        {
          key: 'status',
          label: '状态',
          minWidth: 28,
          format: {
            '0' : '下线',
            '1' : '上线'
          }
        },
        {
          key: 'copyLink',
          label: '操作',
          width: 70,
          button: {
            type: 'text',
            icon: 'el-icon-paperclip',
            label: '复制链接',
            disabled: (row) => { return row.disabled },
            click:row => { this.copyLink(row) }
          }
        },
        {
          key: 'copyQrCode',
          label: '',
          width: 84,
          button: {
            type: 'text',
            icon: 'el-icon-document-copy',
            label: '复制二维码',
            disabled: (row) => { return row.disabled },
            click:row => { this.copyCode(row) }
          }
        },
        {
          key: 'edit',
          label: '',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            disabled: () => { return !this.auth.includes(3) },
            click:row => { this.$emit('edit', row) }
          }
        },
      ]
    }
  },
  props: {
    data: Array,
    packageList: Array,
    auth: Array
  },
  methods: {
    copyLink(row) {
      if(row.type === 0) {
        //优惠券
        let link = createLink(`${this.SYS.WEBURL}/ns/#/coupon/${row.couponId}`, {}, ['mid-corp-19'])
        this.$copy(`优惠券名称：${row.couponName}\n优惠券：${row.amount}元\n优惠券链接：${link}`)
      }else if(row.type === 1) {
        //抵扣券
        let link = createLink(`${this.SYS.WEBURL}/ns/#/coupon/${row.couponId}`, {}, ['mid-corp-19', 'alipay', 'wxpay'])
        this.$copy(`代金券名称：${row.couponName}\n代金券价格：${row.money}\n代金券抵扣金额：${row.amount}元\n代金券购买链接：${link}`)
      }
    },
    copyCode: throttle(async function(row) {
      let url = createLink(`${this.SYS.WEBURL}/ns/#/coupon/${row.couponId}`, {}, 
        row.type === 0 ? ['mid-corp-19'] : ['mid-corp-19', 'alipay', 'wxpay'])

      const QRCode = await import('qrcode')

      let code = await QRCode.toDataURL(
        url,
        {
          errorCorrectionLevel: "H",
          version: 8,
          width: 385,
          margin: 0
        }
      )

      let canvas = document.createElement('canvas')
      canvas.width = 700
      canvas.height = 980

      let ctx = canvas.getContext('2d')
      if(row.type === 0) {
        let background = await loadimage(coupon)
        ctx.drawImage(background, 0, 0, 700, 980)

        let codeI = await loadimage(code)
        ctx.drawImage(codeI, 159, 363, 385, 385)

        ctx.font = 'normal 24px arial'
        ctx.fillStyle = 'white'
        ctx.textAlign = 'center'
        ctx.textBaseline='middle'

        ctx.fillText(row.couponName, 350, 300)

        let logo = await loadimage(logoImage)
        ctx.drawImage(logo, 314, 508, 87, 87)
      }else if(row.type === 1) {
        let background = await loadimage(coupon2)
        ctx.drawImage(background, 0, 0, 700, 980)

        let codeI = await loadimage(code)
        ctx.drawImage(codeI, 130, 270, 440, 440)

        ctx.font = 'normal 36px arial'
        ctx.fillStyle = 'white'
        ctx.textAlign = 'center'
        ctx.textBaseline='middle'

        ctx.fillText(row.couponName, 350, 124)

        let logo = await loadimage(logoImage)
        ctx.drawImage(logo, 306, 446, 87, 87)
      }
      
      
      let a = document.createElement('a')
      a.download = `${row.couponName}.png`
      a.href = canvas.toDataURL('image/png')
      a.click()
    })
  },
}
</script>