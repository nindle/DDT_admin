<template>
  <el-dialog-pro 
    @close="close"
    width="880px"
  >
    <!--标题-->
    <template #title>优惠券领取记录</template>
    <!--内容-->
    <el-layout-pro
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <el-table-pro
          :head="head"
          :data="tableData"
        ></el-table-pro>
      </template>
    </el-layout-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
    </template>
  </el-dialog-pro>  
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      // 筛选
      screen: {
        corpId: '',
        managerId: '',
        time: [],
        keyWord: ''
      },
      config: {
        corpId: {
          type: 'select-corp'
        },
        managerId: {
          type: 'select-group-manager'
        },
        time: {
          type: 'date-range'
        },
        split: {
          type: 'split'
        },
        keyWord: {
          type: 'input',
          placeholder: '搜索用户ID/手机号'
        }
      },
      // 表格
      head: [
        {
          key: 'id',
          label: '序号',
          minWidth: 60
        },
        {
          key: 'ctime',
          label: '领取时间',
          minWidth: 140
        },
        {
          key: 'userId',
          label: '领取用户',
          minWidth: 70,
          copy: true
        },
        {
          key: 'managerId',
          label: '归属人',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.managerList,
            key: 'id',
            value: 'realName'
          }
        },
        {
          key: 'isUse',
          label: '成交状态',
          minWidth: 56,
          format: {
            '0' : '未购买',
            '1' : '已购买',
            '2' : '购买中'
          }
        },
      ],
      tableData: []
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  methods: {
    close() {
      this.$emit('update:show', false)
    },
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let manager = this.screen.managerId.split('/')
      let managerid = 0
      if(manager[0] === 'manager') {
        managerid = Number(manager[1])
      } else {
        managerid = undefined
      }

      let { result } = await this.$http({
        url: '%CRM%/coupon/user_coupon.sdcrm',
        data: {
          token: true,
          pageNum:this.pageNum,
          pageSize: this.pageSize,
          couponId: this.data.couponId,
          corpId:typeof this.screen.corpId === 'number'? this.screen.corpId : undefined,
          managerId: managerid,
          keyWord: this.screen.keyWord ? this.screen.keyWord : undefined,
          ctime: this.screen.time?.[0] ?? undefined,
          etime: this.screen.time?.[1] ?? undefined
        }
      })

      this.tableData = result.records
      this.total = result.total
      this.loading = false
    })
  }
}
</script>
<style lang="scss" scoped>
/deep/ {
  .screen-box {
    padding: 0 !important;
  }
  .table-box {
    padding: 24px 0 !important;
  }
}
</style>