<template>
  <el-table-pro
    :data="data"
    :head="head"
    border
    custom-head
    default-sort-key="live_watch_count"
    @sort="$emit('change', $event)"
  ></el-table-pro>
</template>
<script>

export default {
  data() {
    return {
      head: [
        {
          key: 'date',
          label: '日期',
          minWidth: 80,
          format: e => new Date(e).timeFormat('yyyy-MM-dd'),
          customHead: false,
          copy: true
        },
        {
          key: 'type',
          label: '类型',
          minWidth: 56,
          format: {
            '0': '头条',
            '1': '广点通',
            '2': '百度',
          },
          customHead: false,
          copy: true
        },
        {
          key: 'lvmUserTypeId',
          label: '推广公司',
          minWidth: 120,
          format: {
            list: this.lvmUserTypeList,
            key: 'id',
            value: 'resName',
          },
          customHead: ['hide'],
          copy: true
        },
        {
          key: 'advertiserId',
          label: '账号ID',
          minWidth: 200,
          excel: `'{advertiserId}`,
          customHead: false,
          copy: true
          // format: {
          //   list: this.accountList,
          //   key: 'advertiserId',
          //   value: 'advertiserName'
          // }
        },
        {
          key: 'accMemo',
          label: '账号备注',
          minWidth: 120,
          copy: true
        },
        {
          key: 'anchorId',
          label: '抖音ID',
          minWidth: 120,
          copy: true
        },
        {
          key: 'anchorNick',
          label: '抖音名称',
          minWidth: 120,
          copy: true
        },
        {
          key: 'liveWatchCount',
          label: '观看数',
          minWidth: 80,
          sort: 'live_watch_count',
          copy: true
        },
        {
          key: 'liveDuration60sCountToLiveWatchCountRate',
          label: '超一分钟观看率',
          minWidth: 130,
          format: e => Number(e || 0).toFixed(2) + '%',
          sort: 'live_duration60s_count_to_live_watch_count_rate',
          copy: true
        },
        {
          key: 'liveAvgWatchDuration',
          label: '人均观看时长',
          minWidth: 120,
          sort: 'live_avg_watch_duration',
          copy: true
        },
        {
          key: 'liveFollowCount',
          label: '关注数',
          minWidth: 80,
          sort: 'live_follow_count',
          copy: true
        },
        {
          key: 'liveCommentCount',
          label: '评论数',
          minWidth: 80,
          sort: 'live_comment_count',
          copy: true
        },
        {
          key: 'liveShareCount',
          label: '分享数',
          minWidth: 80,
          sort: 'live_share_count',
          copy: true
        }
      ],
    }
  },
  props:{
    data:Array,
    accountList: Array,
    lvmUserTypeList: Array
  }
}
</script>