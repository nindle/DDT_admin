<template>
  <div class="view">
    <el-layout-pro 
      :loading="loading" 
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      class="box"
    >
      <!-- 筛选 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :account-list="config.advertiserId.options"
          :lvm-user-type-list="config.lvmUserTypeId.options"
          @change="getTableData(true, $event)"
          @edit="openPopover"
        />
      </template>  
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'

export default {
  name: 'gm-ad_live_report',
  data() {
    return {
      loading: false,
      pageNum: 1,
      pageSize: 10,
      total: 0,

      //展示修改
      showPopover: false,
      //修改数据
      rowData: null,

      tableData: [],
      screen: {
        time: [
          Date.now() - 24 * 3600 * 1000,
          Date.now() - 24 * 3600 * 1000
        ],
        type: '',
        advertiserId: '',
        lvmUserTypeId: '',
        keyWord: ''
      },
      config: {
        time: {
          type: 'date-range'
        },
        type: {
          type: 'select',
          placeholder: '类型',
          options: [
            { value: 0, label: '头条' },
            { value: 1, label: '广点通' },
            { value: 2, label: '百度' },
          ],
          change: () => {
            this.screen.advertiserId = ''
          },
          hide: true
        },
        lvmUserTypeId: {
          type: 'select',
          placeholder: '推广公司',
          labelKey: 'resName',
          valueKey: 'id',
          filterable: true,
          options: [],
          change: () => {
            this.screen.advertiserId = ''
          }
        },
        advertiserId: {
          type: 'select',
          placeholder: '推广账号',
          labelKey: 'advertiserId',
          valueKey: 'advertiserId',
          filterable: true,
          options: [],
          filter: () => {
            const result = {}
            if(typeof this.screen.type === 'number') {
              result.type = this.screen.type
            }
            if(typeof this.screen.lvmUserTypeId === 'number') {
              result.lvmUserTypeId = this.screen.lvmUserTypeId
            }
            return result
          }
        },
        split: { type: 'split' },
        keyWord: {
          type: 'input',
          placeholder: '搜索备注'
        },
        excel: {
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        }
      },

      sortData:{ key: 'live_watch_count', type: 'desc' }
    }
  },
  props: {
    nav: Object
  },
  components:{
    TableData,
  },
  methods:{
    getTableData: throttle(async function(toFirst, sort){
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      if(sort) {
        this.sortData = sort
      }

      let { result } = await this.$http({
        url: '%CRM%/ad/report/get_ad_live_report.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
          type: typeof this.screen.type === 'number' ? this.screen.type : void 0,
          advertiserId: this.screen.advertiserId || void 0,
          lvmUserTypeId: this.screen.lvmUserTypeId || void 0,
          sortKey: this.sortData.key,
          sortType: this.sortData.type,
          keyWord: this.screen.keyWord || void 0
        },
      })

      this.loading = false

      this.tableData = result.records
      this.total = result.total
    }),
    async getUserTypeList() {
      let { result } = await this.$http({
        url: '%CRM%/lvm_user_type/get_lvm_user_type_search.sdcrm',
        data: {
          token: true,
          isPage: 1
        }
      })

      this.config.lvmUserTypeId.options.splice(0, this.config.lvmUserTypeId.options.length, ...result)
    },
    async getAccountList() {
      let { result } = await this.$http({
        url: '%CRM%/ad/report/get_ad_account.sdcrm',
        data: {
          isPage: 1,
          token: true
        }
      })

      this.config.advertiserId.options.splice(0, this.config.advertiserId.options.length, ...result)
    },
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    }
  },
  created() {
    this.getAccountList()
    this.getUserTypeList()
  }
}
</script>
<style lang="scss" scoped>
.view{
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box{
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>