<template>
  <div class="view">
    <el-layout-pro class="box">
      <!-- 筛选 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getSearch"
          cancel-init-callback
        ></el-screen-pro>
      </template>

      <template #scroll>
        <left-box 
          :list="config.projectId.options"
          :project-data="screen.projectId"
          @edit="openPopover"
          ref="left"
        />
        <right-box 
          :list="config.projectId.options"
          :project-data="screen.projectId"
          @edit="openPopover"
          ref="right"
        />
      </template>

     <template #popover>
        <edit-data 
          v-if="showPopover"
          :show.sync="showPopover"
          :data="popoverData"
          :type="popoverType"
          :project="config.projectId.options"
          @change="getSearch()"
        />

        <project 
          v-if="showProject"
          :show.sync="showProject"
          @change="getSearchProject"
          ref="project"
        />
     </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import EditData from './editData'
import LeftBox from './leftBox.vue'
import Project from './project.vue'
import RightBox from './rightBox'

export default {
  name: 'gm-burying_point',
  data() {
    return {
      screen: {
        projectId: ''
      },
      config: {
        add: {
          type: 'button',
          label: '+ 新增',
          buttonType: 'primary',
          click: () => { this.openPopover(null) }
        },
        projectId: {
          type: 'select',
          placeholder: '项目',
          options: [],
          labelKey: 'name',
          valueKey: 'id'
        },
        edit: {
          type: 'button',
          label: '项目列表',
          buttonType: 'text',
          click: () => {  this.showProject = true}
        }
      },
      //展示修改
      showPopover: false,
      popoverData: {},
      popoverType: 0,
      showProject: false,
      ProTableData: []
    }
  },
  methods: {
    //获取项目埋点
    getSearchProject: throttle(async function() {
      let { result } = await this.$http({
        url: '%CRM%/project/search_project.sdcrm',
        data: {
          token: true,
          pageNum: 1,
          pageSize: 99
        }
      })
      this.config.projectId.options.splice(0,this.config.projectId.options.length,...result.records)
      this.screen.projectId = result.records?.[0]?.id ?? ''

      this.getSearch()
    }),
    //页面埋点和按钮埋点修改后
    async getSearch() {
      await this.$nextTick()
      this.$refs.left.getSearchPage()
      this.$refs.right.getSearchButton()
    },
    //打开弹窗
    openPopover(data) {
      this.showPopover = true
      this.popoverData = data ? data[0] : data
      this.popoverType = data ? data[1] : 0
    }
  },
  components: {
    EditData,
    LeftBox,
    RightBox,
    Project
  },
  created() {
    this.getSearchProject()
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
    /deep/ {
      .scrollbar-view {
        display: flex;
        justify-content: space-between;
        height: 100%;
      }
      .el-scrollbar {
        height: 100%;
        .el-scrollbar__view {
          height: 100%;
        }
      }
    }
  }
}
</style>