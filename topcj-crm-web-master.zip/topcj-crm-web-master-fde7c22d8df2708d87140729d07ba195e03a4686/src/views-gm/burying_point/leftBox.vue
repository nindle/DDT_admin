<template>
  <el-layout-pro
    class="left-box"
    :loading="loading"
    :total="total"
    :page-num.sync="pageNum"
    :page-size.sync="pageSize"
    @page-change="getSearchPage()"
  >
    <template #table>
      <el-table-pro
        :head="head"
        :data="tableData"
      >
      </el-table-pro>
    </template>
  </el-layout-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      loading: false,
      pageNum: 1,
      pageSize: 10,
      total: 0,
      // 表格
      head: [
        {
          key: 'id',
          label: '页面埋点ID',
          minWidth: 80,
        }, 
        {
          key: 'name',
          label: '页面埋点名称',
          minWidth: 84,
        }, 
        {
          key: 'url',
          label: '页面地址',
          minWidth: 70,
          button: {
            type: 'text',
            icon: 'el-icon-link',
            label: '网址',
            click: e => { this.$open(e.url)}
          }
        }, 
        {
          key: 'projectId',
          label: '项目名',
          minWidth: 56,
          format: {
            list: this.list,
            key: 'id',
            value: 'name'
          }
        }, 
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: e => { this.$emit('edit', [e,1]) }
          }
        }
      ],
      tableData: []
    }
  },
  props: {
    list: Array,
    projectData: [Number, String]
  },
  methods: {
    getSearchPage: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }
      
      let { result } = await this.$http({
        url: '%CRM%/page/search_page.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          projectId:typeof this.projectData === 'number' ? this.projectData : undefined
        }
      })

      this.tableData = result.records
      this.total = result.total

      this.loading = false
    }),
  }
}
</script>
<style lang="scss" scoped>
.left-box {
  width: calc(50% - 12px);
  height: 100%;
  background: #FFF;
}
</style>