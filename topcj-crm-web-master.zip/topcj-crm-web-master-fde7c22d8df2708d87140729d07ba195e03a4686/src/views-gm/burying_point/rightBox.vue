<template>
  <el-layout-pro
    class="right-box"
    :loading="loading"
    :total="total"
    :page-num.sync="pageNum"
    :page-size.sync="pageSize"
    @page-change="getSearchButton()"
  >
    <template #table>
      <el-table-pro
        :head="head"
        :data="tableData"
      >
      </el-table-pro>
    </template>
  </el-layout-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      loading: false,
      pageNum: 1,
      pageSize: 10,
      total: 0,
      // 表格
      head: [
        {
          key: 'id',
          label: '按钮埋点ID',
          minWidth: 80,
        }, 
        {
          key: 'name',
          label: '按钮埋点名称',
          minWidth: 84,
        }, 
        {
          key: 'projectId',
          label: '项目名',
          minWidth: 56,
          format: {
            list: this.list,
            key: 'id',
            value: 'name'
          }
        }, 
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: e => { this.$emit('edit', [e,2]) }
          }
        }
      ],
      tableData: []
    }
  },
  props: {
    list: Array,
    projectData: [Number, String]
  },
  methods: {
    getSearchButton :throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/button/search_button.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          projectId:typeof this.projectData === 'number' ? this.projectData : undefined
        }
      })

      this.tableData = result.records
      this.total = result.total
      this.loading = false
    }),
  }
}
</script>
<style lang="scss" scoped>
.right-box {
  width: 50%;
  height: 100%;
  background: #FFF;
}
</style>