<template>
  <el-dialog-pro 
    @close="close"
    width="620px"
  >
    <template #title>项目列表</template>
    <el-layout-pro
      class="pro_box"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getSearchProject()"
    >
      <template #table>
        <el-table-pro
          :head="head"
          :data="tableData"
          class="table"
        >
        </el-table-pro>
      </template>
    </el-layout-pro>
    

    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      pageNum: 1,
      pageSize: 10,
      //分页
      total: 0,
      head: [
        {
          key: 'id',
          label: '项目埋点ID',
          minWidth: 70,
        }, 
        {
          key: 'name',
          label: '项目埋点名称',
          minWidth: 84,
        }, 
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: e => { this.init(e) }
          }
        }
      ],
      form: {
        id: '',
        Pname: '',
      },
      config: {
        Pname: {
          type: 'input',
          label: '项目名',
          placeholder: '输入项目名，回车添加',
          change: this.submit,
          rule: [
            { required: true }
          ]
        }
      },
      tableData: []
    }
  },
  props: {
    show: Boolean,
  },
  methods: {
    close() {
      this.$emit('update:show', false)
      this.$emit('change')
    },
    init(data) {
      this.form.id = data.id
      this.form.Pname = data.name
    },
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/project/set_project.sdcrm',
        data: {
          token:true,
          id: this.form.id? this.form.id : undefined,
          name: this.form.Pname,
        }
      })
      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success(`保存成功`)
      this.init({id: null,name: null})
      this.getSearchProject()
    }),
    getSearchProject:throttle(async function() {
      let { result } = await this.$http({
        url: '%CRM%/project/search_project.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      })
      this.tableData = result.records
      this.total = result.total
    }),
  },
  created() {
    this.getSearchProject()
  }
}
</script>
<style lang="scss" scoped>
.pro_box {
  height: 450px;
}
/deep/ {
  .content-box-view {
    width: calc(100% - 40px);
    .table-box {
      // width: 100%;
      padding: 0;
      padding-bottom: 24px;
    }
  }
}

</style>