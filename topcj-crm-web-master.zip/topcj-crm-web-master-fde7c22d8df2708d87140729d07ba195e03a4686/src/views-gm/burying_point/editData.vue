<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      {{data ? '编辑' : '新增'}}埋点
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      form: {
        type: this.type? this.type : 1,
        name: this.data?.name ?? '',
        projectId: this.data?.projectId ?? '',
        url: this.data?.url ?? ''
      },
      config: {
        type: {
          label: '类型',
          type: 'select',
          options: [
            {value: 1,label: '页面'},
            {value: 2,label: '按钮'},
          ],
          disabled: !!this.data,
          rule:[
            { required: true }
          ]
        },
        name: {
          type: 'input',
          label: '埋点名称',
          rule:[
            { required: true }
          ]
        },
        projectId: {
          type: 'select',
          label: '项目',
          options: this.project,
          labelKey: 'name',
          valueKey: 'id',
          rule:[
            { required: true }
          ]
        },
        url: {
          type: 'input',
          label: '页面地址',
          hide: () => this.form.type !== 1,
          rule:[
            { required: true }
          ]
        }
      }
    }
  },
  props: {
    show: Boolean,
    project: Array,
    data: Object,
    type: Number
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      let url = this.form.type === 1 ? '%CRM%/page/set_page.sdcrm' : '%CRM%/button/set_button.sdcrm'

      let { code, errmsg, msg } = await this.$http({
        url: url,
        data: {
          token:true,
          id: this.data?.id ?? undefined,
          name: this.form.name,
          projectId: this.form.projectId,
          url: this.form.type === 1 ? this.form.url : undefined
        }
      })
      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success(`保存成功`)
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>