<template>
  <index :type="1" />
</template>

<script>
import Index from './index.vue'

export default {
  name:'gm-certificates-1',
  components: {
    Index
  }
}
</script>