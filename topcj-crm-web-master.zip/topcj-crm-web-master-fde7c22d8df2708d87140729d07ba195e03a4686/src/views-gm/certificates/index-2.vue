<template>
  <index :type="2" />
</template>

<script>
import Index from './index.vue'

export default {
  name:'gm-certificates-2',
  components: {
    Index
  }
}
</script>