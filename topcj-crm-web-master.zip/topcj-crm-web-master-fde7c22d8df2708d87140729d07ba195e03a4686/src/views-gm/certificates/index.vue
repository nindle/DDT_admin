<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
          :auto-change="false"
          ref="screen"
        ></el-screen-pro>
      </template>
      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData"
          :type="type"
          @change="getTableData()"
        />
      </template>

      <template #popover>
        <edit-data
          v-if="showPopover"
          :type="type"
          :show.sync="showPopover"
          @change="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-certificates',
  data() {
    return {
      //加载状态
      loading: false,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      //表格数据
      tableData: [],
      //筛选数据
      screen: {
        firstTime: [],
        firstStatus: '',
        secondStatus: '',
        corpId: this.$store.state.managerInfo.corpId ? this.$store.state.managerInfo.corpId : '',
        keyword: ''
      },
      config: {
        firstTime: {
          type: 'date-time-range',
          placeholderInLabel: '审核时间',
        },
        firstStatus: {
          type: 'select',
          placeholder: '全部',
          placeholderInLabel: '状态',
          options: [
            { value: 0, label: '未审核' },
            { value: 1, label: '审核通过' },
            { value: 2, label: '审核不通过' },
            { value: 9, label: '被驳回' },
          ],
          hide: this.type !== 1
        },
        secondStatus: {
          type: 'select',
          placeholder: '全部',
          placeholderInLabel: '状态',
          options: [
            { value: 0, label: '未处理' },
            { value: 1, label: '已处理' },
            { value: 2, label: '已驳回' },
          ],
          hide: this.type !== 2
        },
        corpId: {
          type: 'select-corp',
          placeholder: '全部',
          placeholderInLabel: '事业部',
        },
        split: { type: 'split' },
        search: {
          type: 'button',
          buttonType: 'primary',
          label: '查询',
          click: () => {
            this.$refs.screen.emitModel()
            this.getTableData(true)
          }
        },
        reset: {
          type: 'button',
          label: '重置',
          click: () => {
            this.$refs.screen.resetModel()
          }
        },        
        br: { type: 'br' },
        add: {
          type: 'button',
          label: '+ 新增',
          buttonType: 'primary',
          click: () => { this.openPopover() }
        },
        split2: { type: 'split' },
        keyword: {
          type: 'input',
          placeholder: '搜索用户ID/用户姓名/审核人/证件号码',
          change: (v) => {
            this.screen.keyword = v
            this.getTableData(true)
          }
        },
      },
      //新增展示修改
      showPopover: false,
    }
  },
  props: {
    type: Number
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.$refs.screen.cancelModel()
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let firstStatus = typeof this.screen.firstStatus === 'number' ? this.screen.firstStatus : undefined
      let secondStatus = typeof this.screen.secondStatus === 'number' ? this.screen.secondStatus : undefined

      if(this.screen.firstStatus === 9) {
        firstStatus = undefined
        secondStatus = 2
      }

      if(this.type === 2) {
        firstStatus = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/user/get_id_special_list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          keyword: this.screen.keyword || undefined,
          firstStartTime: this.screen.firstTime?.[0], 
          firstEndTime: this.screen.firstTime?.[1], 
          secondStatus,
          firstStatus,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
        }
      })

      this.total = result.total
      this.tableData = result.records

      this.loading = false
    }),
    openPopover() {
      this.showPopover = true
    }
  },
  components: {
    TableData,
    EditData
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>