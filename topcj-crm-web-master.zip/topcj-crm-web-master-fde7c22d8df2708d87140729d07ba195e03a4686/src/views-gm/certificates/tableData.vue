<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-name="{ row }">
      <scratch
        :data="row.name"
        mode="name"
        :log="row.userId"
        show-button
      />
    </template>

    <template #body-idNum="{ row }">
      <scratch
        :data="row.idNum"
        mode="idnum"
      />
    </template>

    <!-- <template #body-operation="{ row }">
      <el-popconfirm
        title="确认通过吗？"
        v-if="row.audit === 0"
        @confirm="reviewData(row, 1)"
      >
        <el-button
          slot="reference"
          type="text"
          size="small"
          icon="el-icon-check"
        >通过</el-button>
      </el-popconfirm>
      <el-popconfirm
        style="margin-left: 12px;"
        title="确认不通过吗？"
        v-if="row.audit === 0"
        @confirm="reviewData(row, 2)"
      >
        <el-button
          slot="reference"
          type="text"
          size="small"
          icon="el-icon-close"
        >不通过</el-button>
      </el-popconfirm>
      <span v-else>{{row.audit === 1 ? '审核通过' : '审核不通过'}}</span>
    </template> -->
  </el-table-pro>
</template>

<script>
import { throttle, debounce } from '../../assets/js/tool'
import Scratch from '../../components/other/scratch'

export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: '编号',
          minWidth: 28
        },
        {
          key: 'userId',
          label: '用户ID',
          minWidth: 90,
          copy: true
        },
        {
          key: 'name',
          label: '用户姓名',
          minWidth: 120
        },
        {
          key: 'firstStatus,secondStatus',
          label: '状态',
          minWidth: 80,
          format: (f, s) => {
            if(s === 2) return '被驳回'
            switch(f) {
              case 0: return '未审核'
              case 1: return '审核通过'
              case 2: return '审核不通过'
            }
          },
          tag: (f, s) => {
            if(s === 2) return 'danger'
            switch(f) {
              case 0: return 'primary'
              case 1: return 'success'
              case 2: return 'warning'
            }
          },
          hide: this.type !== 1
        },
        {
          key: 'secondStatus',
          label: '状态',
          minWidth: 80,
          format: {
            '0': '未处理',
            '1': '已处理',
            '2': '驳回',
          },
          tag: {
            '0': 'warning',
            '1': 'success',
            '2': 'danger',
          },
          hide: this.type !== 2
        },
        {
          key: 'idNum',
          label: '特殊证件号码',
          minWidth: 140
        },
        {
          key: 'birthday',
          label: '出生日期',
          minWidth: 80,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd') : '--'
        },
        {
          key: 'frontUrl,backUrl',
          label: '证件照片',
          minWidth: 56,
          button: {
            type: 'text',
            icon: 'el-icon-view',
            label: '查看',
            click: this.viewProcessed,
          }
        },
        {
          key: 'firstTrial',
          label: this.type === 1 ? '审核人' : '初审人',
          minWidth: 70,
          default: '--'
        },
        {
          key: 'corpId',
          label: '初审事业部',
          minWidth: 100,
          format: {
            list: this.$store.state.baseData.corpList,
            key: 'id',
            value: 'corpName'
          },
          hide: this.type !== 2
        },
        {
          key: 'firstTime',
          label: this.type === 1 ? '审核时间' : '初审时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '--'
        },
        {
          key: 'secondTrial',
          label: '复审人',
          minWidth: 70,
          default: '--',
          hide: this.type !== 2
        },
        {
          key: 'secondTime',
          label: '复审时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '--',
          hide: this.type !== 2
        },
        {
          key: 'operation',
          label: '操作',
          width: 56,
          fixed: 'right',
          hide: this.type !== 2,
          button: {
            disabled: row => row.secondStatus === 2,
            label: '驳回',
            type: 'danger',
            size: 'small',
            click: (row) => {
              this.secondAudit(row, 2)
            }
          }
        },
        {
          key: 'o1',
          label: '操作',
          width: 56,
          fixed: 'right',
          hide: this.type !== 1,
          button: {
            disabled: row => row.firstStatus !== 0,
            label: '通过',
            type: 'success',
            size: 'small',
            click: (row) => {
              this.firstAudit(row, 1)
            }
          }
        },
        {
          key: 'o2',
          label: '',
          width: 70,
          fixed: 'right',
          hide: this.type !== 1,
          button: {
            disabled: row => row.firstStatus !== 0,
            label: '不通过',
            type: 'danger',
            size: 'small',
            click: (row) => {
              this.firstAudit(row, 2)
            }
          }
        },
      ]
    }
  },
  props: {
    data: Array,
    type: Number
  },
  components: {
    Scratch
  },
  methods: {
    secondAudit: throttle(async function(row, status) {
      if(this.type === 1) return

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/user/audit_id_num.sdcrm',
        data: {
          token: true,
          id: row.id,
          pageType: 1,
          secondStatus: status
        },
      })

      if(code !== 8200) {
        this.$message.error(`审核失败：${errmsg || msg}`)
        return
      }

      if(status === 2) {
        this.$message.success(`审核成功`)
      }

      this.$emit('change')
    }),
    firstAudit: throttle(async function(row, status) {
      if(this.type === 2) return

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/user/audit_id_num.sdcrm',
        data: {
          token: true,
          id: row.id,
          pageType: 0,
          firstStatus: status
        },
      })

      if(code !== 8200) {
        this.$message.error(`审核失败：${errmsg || msg}`)
        return
      }

      this.$message.success(`审核成功`)

      this.$emit('change')
    }),
    viewProcessed(row) {
      this.$imageview({
        list: [{
          url: row.frontUrl,
          rotate: row.frontAngle
        }, {
          url: row.backUrl,
          rotate: row.backAngle
        }],
        onRotate: debounce(async (index, rotate) => {
          if(index === 0 && rotate === row.frontAngle) return
          if(index === 1 && rotate === row.backAngle) return

          await this.$http({
            url: '%CRM%/user/set_id_card_angle.sdcrm',
            data:{
              token: true,
              userId: row.userId,
              type: index,
              angle: rotate % 360
            }
          })

          if(index === 0) {
            row.frontAngle = rotate
          }else{
            row.backAngle = rotate
          }
        }, 300),
        onClose: () => {
          if(row.secondStatus !== 0) return
          this.secondAudit(row, 1)
        }
      })
    }
  }
}
</script>