<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
    summary
  ></el-table-pro>
</template>
<script>
export default {
  data(){
    return{
      head:[
        {
          key: 'corpName',
          label: '公司',
          minWidth: 70,
          summary: '总计',
          copy: true
        },
        // {
        //   key: 'employees',
        //   label: '业务人数',
        //   headtip: '按当月人数计算',
        //   minWidth: 56,
        //   copy: true
        // },
        {
          key: 'totalMoney',
          label: '业绩',
          minWidth: 70,
          copy: true
        },
        {
          key: 'users',
          label: '成交客户数',
          minWidth: 70,
          copy: true
        },
        {
          key: 'orderNum',
          label: '成交单数',
          minWidth: 56,
          copy: true
        },
        {
          key: 'avgMoney',
          label: '客单价',
          minWidth: 70,
          copy: true
        },
        {
          key: 'avgOrderMoney',
          label: '平均单价',
          minWidth: 70,
          copy: true
        },
        {
          key: 'actualMoney',
          label: '实际业绩',
          minWidth: 70,
          copy: true
        },
        {
          key: 'finalMoney',
          label: '最终业绩',
          minWidth: 70,
          copy: true
        },
        {
          key: 'refund',
          label: '当月进当月退',
          minWidth: 84,
          copy: true
        },
        {
          key: 'hisOrderRefund',
          label: '以前退费',
          minWidth: 70,
          copy: true
        },
        {
          key: 'totalRefund',
          label: '退费总计',
          minWidth: 70,
          copy: true
        },
      ]
    }
  },
  props:{
    data:Array
  }
}
</script>