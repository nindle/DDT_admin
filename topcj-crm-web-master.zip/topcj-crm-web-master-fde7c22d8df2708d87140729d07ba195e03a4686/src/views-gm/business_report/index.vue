<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
    >
      <!-- 筛选 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData()"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :class="{ 'hide-body': !tag.v123.visible }"
          :data="tabledata"
        />
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'

export default {
  name: 'gm-business_report',
  data(){
    return{
      //更新状态
      loading: false,
      // 表格数据
      tabledata: [],
      // 筛选
      screen: {
        time: [
          new Date(new Date().timeFormat('yyyy/MM/01 hh:mm:ss')).getTime(),
          Date.now()
        ],
        corpId: '',
        managerId: ''
      },
      config: {
        time: {
          type: 'date-range'
        },
        // corpId: {
        //   type: 'select-corp',
        //   change: () => { this.screen.managerId = '' }
        // },
        // managerId:{
        //   type: 'select-manager',
        //   filter: () => {
        //     if(this.screen.corpId === '') {
        //       return {}
        //     }else{
        //       return {
        //         corpId: this.screen.corpId
        //       }
        //     }
        //   }
        // },
        split: { type: 'split' },
        excel:{
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)},
          hide: () => this.$store.state.sysMode === 2
        }
      }
    }
  },
  props: {
    nav: Object,
    tag: Object
  },
  components:{
    TableData
  },
  methods:{
    // 获取表格数据
    getTableData:throttle(async function(){
      this.loading = true

      let { result } = await this.$http({
        url: '%CRM%/report/get_pay_report.sdcrm',
        data: {
          token: true,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          managerId: typeof this.screen.managerId === 'number' ? this.screen.managerId : undefined
        }
      })

      this.loading = false
      
      this.tabledata = result
    })
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
    .hide-body {
      /deep/ {
        .el-table__body { display: none;}
      }
    }
  }
}
</style>