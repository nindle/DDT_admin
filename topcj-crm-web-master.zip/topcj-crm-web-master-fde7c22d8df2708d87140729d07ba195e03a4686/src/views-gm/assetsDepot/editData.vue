<template>
  <el-dialog-pro 
    @close="close" 
    full-screen
  >
    <!-- 标题 -->
    <template #title>
      {{`${data ? '编辑' :'新增'}${compType}类型`}}
    </template>

    <!-- 表单 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
      <template #text>
        <message-input 
          :tool="tool"
          ref="message"
          style="border:1px solid #C0C4CC;padding-bottom:8px;border-radius:4px;height: 200px"
        />
      </template>
    </el-form-pro>
    <!-- 底部标签 -->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>

  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import MessageInput from '../../components/message-input'

export default {
  data() {
    return {
      form: {
        text:this.data?.text,
        sourceTitle:this.data?.sourceTitle,
        title:this.data?.title,
        picUrl:this.data?.picUrl,
        description:this.data?.description,
        url:this.data?.url,
        contentSourceUrl:this.data?.contentSourceUrl,
        content:this.data?.content,
        digest:this.data?.digest,
        share:this.data?.share,

      },
      config: {
        sourceTitle:{
          hide: () => ['mpnews','text'].includes(this.msgType),
          label: this.msgType === 'image' ? '图片名称' : '标题',
          rule:[
            { required: true }
          ]
        },
        text:{
          hide: () => this.msgType !== 'text',
          label: '文本素材内容',
          type: 'textarea',
        },
        title:{
          hide: () => this.msgType !== 'mpnews',
          label: '标题',
          rule:[
            { required: true }
          ]
        },
        picUrl: {
          hide: () => this.msgType === 'text',
          type: 'image',
          label: '图片',
          rule: [
            { required: true }
          ],
        },
        content:{
          hide: () => this.msgType !== 'mpnews',
          label: '消息内容',
          rule: [
            { required: true }
          ],
          type:'richtext'
        },
        // description:{
        //   hide: () => this.msgType !== 'mpnews',
        //   label: '描述',
        //   type:'textarea'
        // },
        url:{
          hide: () => this.msgType !== 'news',
          label: '跳转链接',
          rule: [
            { required: true }
          ],
        },
        // contentSourceUrl:{
        //   hide: () => this.msgType !== 'news',
        //   label: '原文链接',
        //   rule: [
        //     { required: true }
        //   ],
        // },
        
        digest:{
          hide: () => !['news','mpnews'].includes(this.msgType),
          label: '描述',
          type:'textarea'
        },
        share:{
          label: '是否公共',
          type: 'switch',
          activeText:'公共',
          activeValue:0,
          inactiveText:'私有',
          inactiveValue:1
        }

      },
      tool: ['face'] ,
      loading:false
    }
  },
  props: {
    show: Boolean,
    data: Object,
    msgType:String,
  },
  computed:{
    compType(){
      let value
      switch(this.msgType){
        case 'text':
          value = '文字'
          break
        case 'mpnews':
          value = '图文'
          break
        case 'news':
          value = '外链'
          break
        case 'image':
          value = '图片'
          break
      }
      return value
    }
  },
  components:{
    MessageInput,
  },
  async mounted(){
    await this.$nextTick()
    if(this.msgType === 'text'){
      this.$refs.message.inputHtml(this.data?.text)
    }
  },
  methods:{
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return
      let text,digest
      if(this.msgType === 'text'){
        text = this.$refs.message.getMessage()[0].content
      }
      if(this.msgType === 'mpnews' || this.msgType === 'news'){
        // text = this.$refs.message.getMessage()[0].content
        digest = this.form.digest ? this.form.digest : (this.form.content?.replace(/<\/?.+?\/?>/g,'').substring(0,50) ?? '')
        text = this.form.title
      }
      // if(this.msgType === 'image'){
      //   text = ''
      // }
      this.loading = true
      let { code, msg, errmsg } = await this.$http({
        url:'%CRM%/source/set_source.sdcrm',
        data: {
          token: true,
          msgType:this.msgType,
          createrId: this.$store.state.managerInfo.id,
          sourceId:this.data?.id ?? -1,
          share:this.form.share ?? undefined,
          text:text,
          sourceTitle:this.form.sourceTitle ? this.form.sourceTitle : text,
          picUrl:this.form?.picUrl ?? undefined,
          // description:this.form.description ?this.form.description : this.form.content.substring(0,50),
          url:this.form?.url ?? undefined,
          contentSourceUrl:this.form?.contentSourceUrl ?? undefined,
          content:this.form?.content ?? undefined,
          digest,
          title:this.form.title ? this.form.title : this.form.sourceTitle,
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close(){
      if(this.$route.query.type) {
        this.$store.commit('setTopNav', {
          path: this.$route.path
        })
        this.$router.go(-1)

      }else{
        this.$emit('update:show',false)
      }
    }
  }
}
</script>