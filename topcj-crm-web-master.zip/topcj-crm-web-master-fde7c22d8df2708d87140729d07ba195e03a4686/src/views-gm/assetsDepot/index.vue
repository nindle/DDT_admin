<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :msgType='msgType'
          :select-list.sync="selectList"
          @edit="openPopover"
          @dele='deletItem'
          @change="getTableData"
        />
      </template>

      <template #popover>
        <edit-data 
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          :msgType='msgType'
          @change="getTableData()"
          @dele='deletItem'
        />
        <review 
          v-if="showReview"
          :show.sync="showReview"
          :review-list="reviewList"
          @success="getTableData()"
          reason
          reviewKey="isauth"
          reasonKey='rejectReason'
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'
import Review from '../../components/review/index'

export default {
  name: 'gm-assets_depot_next',
  data() {
    return {
      // 状态更新
      loading: false,
      // 表格数据
      tableData: [], 
      // 新增展示修改
      showPopover: false,
      rowData: null,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      //审核相关
      selectList: [],
      showReview: false,
      reviewList: [],
      // 筛选
      screen: {
        msgType: this.$route.query.type || 'text',
        // share:null,
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) }
        },
        msgType: {
          type: 'select',
          clearable:false,
          options: [
            { value: 'text', label: '文字' },
            { value: 'mpnews', label: '图文' },
            { value: 'news', label: '外链' },
            { value: 'image', label: '图片' }
          ]
        },
        // share: {
        //   type: 'select',
        //   clearable:false,
        //   options: [
        //     { value: 0, label: '公共素材' },
        //     { value: 1, label: '私有素材' },
        //     { value: 2, label: '本人素材' },
        //     { value: null, label: '所有素材' }
        //   ]
        // },
        isauth: {
          type: 'select',
          placeholder:'审核状态',
          options: [
            { value: 0, label: '待审核' },
            { value: 1, label: '审核完成' },
            { value: 2, label: '未通过' },
          ]
        },
        split: { type: 'split' },
        reviewOnline:{
          type: 'button',
          buttonType: 'primary',
          label: '审核上线',
          click: () => { this.openReview(1) }
        },
        reviewOffline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核下线',
          click: () => { this.openReview(2) }
        }

      },
      msgType:'',
      sorts:{
        key: 'ctime',
        type: 'desc'
      },
    }
  },
  components:{
    TableData,
    EditData,
    Review
  },
  methods: {
    //审核
    openReview(isauth) {
      this.reviewList = this.selectList.map(e => {
        return {
          url: '%CRM%/source/set_source_auth.sdcrm',
          data: {
            token: true,
            sourceId: e.id,
            isauth,
          }
        }
      })
      this.showReview = true
    },
    async deletItem(id){
      let { code,errmsg,msg } = await this.$http({
        url:'%CRM%/source/delete_source.sdcrm',
        data: {
          token: true,
          sourceId:id
        }
      })
      if(code !== 8200){
        this.$message.error(errmsg ? errmsg : msg)
        return
      }else{
        this.$message.success('删除成功')
      }
      this.getTableData()
    },
    getTableData: throttle(async function(toFirst,sorts) {
      this.loading = true
      this.sorts = sorts ?? this.sorts
      if(toFirst) {
        this.pageNum = 1
      }

      let sortType
      switch(this.sorts.key){
        case 'ctime':
          sortType = 1
          break
        case 'count':
          sortType = 0
          break
      }

      let { result } = await this.$http({
        url:'%CRM%/source/get_source.sdcrm',
        data: {
          token: true,
          managerId: this.$store.state.managerInfo.id,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          isauth:this.screen.isauth ?? undefined,
          // share:2,
          msgType:this.screen?.msgType ?? 'text',
          sort:this.sorts.type === 'asc' ? 1 : 0,
          sortType
        }
      })

      this.loading = false
      this.tableData = result.contents
      this.total = result.total
      this.msgType = result.msgType
    }),
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    },
  },
  created() {
    if(this.$route.query.type) {
      this.openPopover(null)
    }
  }
}
</script>
<style lang="scss" scoped>
.view{
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box{
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>