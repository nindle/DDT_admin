<template>
  <el-table-pro
    ref="table"
    :head="head"
    :data="data"
    @selection-change="$emit('update:select-list', $event)"
    @sort="fusort"
    default-sort-key="ctime"
    default-sort-type="desc"
  >
    <!-- :default-sort-key="stageRate" -->
    <!-- 内容 -->
    <template v-if="msgType === 'text'" #body-msgType="{ row }">
     {{row.text}}
    </template>
    <template v-else #body-msgType="{ row }">
      <img 
        v-imageview 
        class="image" 
        :src="row.picUrl"
      />
    </template>

    <!-- 外链跳转url -->
    <template #body-url="{ row }">
      <el-button
        type="text"
        size="small"
        icon="el-icon-paperclip"
        @click="open(row)"
      >链接</el-button>
    </template>

    <template #body-operation="{ row }">
      <el-button
        type="text"
        size="small"
        icon="el-icon-edit"
        @click="$emit('edit', row)"
      >编辑</el-button>
    </template>

    <template #body-delete="{ row }">
      <el-popconfirm
        title="确定删除吗？"
        @confirm="$emit('dele', row.id)"
      >
        <template #reference>
          <el-button
            type="text"
            size="small"
            icon="el-icon-delete"
          >删除</el-button>
        </template>
      </el-popconfirm>
    </template>
  </el-table-pro>
</template>
<script>

export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'id',
          label: '编号',
          width: 60
        },
        {
          key: 'share',
          label: '状态',
          width: 30,
          format:{
            '0': '公共',
            '1': '私有'
          }
        },
        
        {
          hide: () => !['text'].includes(this.msgType),
          key:'msgType',
          label:'内容',
          minWidth:180,
          tooltip: true,
        },
        {
          hide: () => ['text'].includes(this.msgType),
          key:'msgType',
          label:'封面',
          width:180,
          tooltip: true,
        },
        {
          key: 'title',
          label: '标题',
          minWidth: 100,
          hide: () => !['mpnews'].includes(this.msgType),
        },
        {
          hide: () => ['mpnews','text','image'].includes(this.msgType),
          key: 'sourceTitle',
          label: '标题' ,
          tooltip: true,
          minWidth: 100,
        },
        {
          hide: () => !['image'].includes(this.msgType),
          key: 'sourceTitle',
          label: '图片名称' ,
          tooltip: true,
          minWidth: 100,
        },
        
        {
          hide: () => !['news','mpnews'].includes(this.msgType),
          key:'digest',
          label: '描述',
          tooltip: true,
          minWidth: 50,
        },
        // {
        //   key: 'description',
        //   label: '描述',
        //   tooltip: true,
        //   hide: () => this.msgType !== 'mpnews',
        //   minWidth: 50,
        // },
        {
          hide: () => !['mpnews','news'].includes(this.msgType),
          key: 'url',
          label: '链接',
          width: 30,
        },
        {
          key: 'isauth',
          label: '审核状态',
          width: 56,
          format:{
            '0': '待审核',
            '1': '审核完成',
            '2': '未通过'
          }
        },
        // {
        //   key: 'count',
        //   label: '使用次数',
        //   width: 82,
        //   sort:true,
        // }, 
        { 
          key: 'ctime',
          label: '创建时间',
          width: 140,
          sort: true,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'operation',
          label: '操作',
          width: 44
        },
        {
          key: 'delete',
          label: '',
          width: 44
        }
      ]
    }
  },
  methods:{
    open(e){
      if(this.msgType === 'mpnews'){
        window.open(`${this.SYS.URL}/news?id=${e.id}`)
      }else{
        this.$open(e.url)
        // window.open(e.url,"_blank")
      }
    },
    fusort(e){
      this.$emit('change',false ,e)
      // this.$emit('change', e)
    }
  },
  props: {
    data: Array,
    msgType:String,
  }
}
</script>
<style lang="scss" scoped>
.image {
  width: 176px;
  height: 88px;
  display: block;
  border-radius: 8px;
  cursor: pointer;
  object-fit: cover;
}
</style>