<template>
  <el-table-pro
    :data="data"
    :head="head"
    border
  ></el-table-pro>
</template>
<script>

export default {
  data() {
    return {
      head: [
        {
          key: 'type',
          label: '类型',
          minWidth: 56,
          format: {
            '0': '头条',
            '1': '广点通',
            '2': '百度',
          },
          copy: true
        },
        {
          key: 'lvmUserTypeId',
          label: '推广公司',
          minWidth: 120,
          format: {
            list: this.lvmUserTypeList,
            key: 'id',
            value: 'resName',
          }
        },
        {
          key: 'advertiserId',
          label: '账号ID',
          minWidth: 200,
          excel: `'{advertiserId}`,
          copy: true
        },
        {
          key: 'advertiserName',
          label: '账号名称',
          minWidth: 200,
          copy: true
        },
        {
          key: 'memo',
          label: '备注',
          minWidth: 200,
          copy: true
        },
        {
          key: 'qrCode',
          label: '对应活码',
          minWidth: 200,
          copy: true
        },
        {
          key: 'ctime',
          label: '添加时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat(),
          copy: true
        },
        {
          key: 'edit',
          label: '',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: e => {
              this.$emit('edit', e)
            }
          },
        }
      ],
    }
  },
  props:{
    data:Array,
    lvmUserTypeList: Array
  }
}
</script>