<template>
  <div class="view">
    <el-layout-pro 
      :loading="loading" 
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      class="box"
    >
      <!-- 筛选 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :lvm-user-type-list="config.lvmUserTypeId.options"
          @change="getTableData(true)"
          @edit="openPopover"
        />
      </template>

      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :lvm-user-type-list="config.lvmUserTypeId.options"
          :data="rowData"
          @change="getTableData()"
        />
      </template>   
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-ad_account',
  data() {
    return {
      loading: false,
      pageNum: 1,
      pageSize: 10,
      total: 0,

      //展示修改
      showPopover: false,
      //修改数据
      rowData: null,

      tableData: [],
      screen: {
        type: '',
        advertiserId: '',
        lvmUserTypeId: '',
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) },
        },
        type: {
          type: 'select',
          placeholder: '类型',
          options: [
            { value: 0, label: '头条' },
            { value: 1, label: '广点通' },
            { value: 2, label: '百度' },
          ]
        },
        lvmUserTypeId: {
          type: 'select',
          placeholder: '推广公司',
          labelKey: 'resName',
          valueKey: 'id',
          filterable: true,
          options: []
        },
        split: { type: 'split' },
        advertiserId: {
          type: 'input',
          placeholder: '搜索推广账号',
        },
      }
    }
  },
  props: {
    nav: Object
  },
  components:{
    TableData,
    EditData
  },
  methods:{
    getTableData: throttle(async function(toFirst){
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/ad/report/get_ad_account.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          type: typeof this.screen.type === 'number' ? this.screen.type : void 0,
          advertiserId: this.screen.advertiserId || void 0,
          lvmUserTypeId: this.screen.lvmUserTypeId || void 0
        },
      })

      this.loading = false

      this.tableData = result.records
      this.total = result.total
    }),
    // async getAccountList() {
    //   let { result } = await this.$http({
    //     url: '%CRM%/ad/report/get_ad_account.sdcrm',
    //     data: {
    //       isPage: 1,
    //       token: true
    //     }
    //   })

    //   this.config.advertiserId.options.splice(0, this.config.advertiserId.options.length, ...result)
    // },
    //获取推广商
    async getUserTypeList() {
      let { result } = await this.$http({
        url: '%CRM%/lvm_user_type/get_lvm_user_type_search.sdcrm',
        data: {
          token: true,
          isPage: 1
        }
      })

      this.config.lvmUserTypeId.options.splice(0, this.config.lvmUserTypeId.options.length, ...result)
    },
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    }
  },
  created() {
    // this.getAccountList()
    this.getUserTypeList()
  }
}
</script>
<style lang="scss" scoped>
.view{
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box{
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>