
<template>
  <el-dialog-pro 
    @close="close"
  >
    <!--标题-->
    <template #title>
      {{ data ? '编辑' : '新增' }}推广账号
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        advertiserId: this.data?.advertiserId ?? '',
        type: this.data?.type ?? '',
        accessToken: this.data?.accessToken ?? '',
        freshToken: this.data?.refreshToken ?? '',
        lvmUserTypeId: this.data?.lvmUserTypeId ?? '',
        memo: this.data?.memo ?? '',
        qrCode: this.data?.qrCode ?? '',
      },
      config: {
        advertiserId: {
          label: '账号ID',
          type: 'input',
          rule: [
            { required: true }
          ],
          disabled: [0, 2].includes(this.data?.type)
        },
        type: {
          label: '类型',
          type: 'select',
          options: [
            { value: 0, label: '头条', disabled: true },
            { value: 1, label: '广点通' },
            { value: 2, label: '百度', disabled: true },
          ],
          rule: [
            { required: true }
          ],
          disabled: [0, 2].includes(this.data?.type)
        },
        accessToken: {
          label: 'accessToken',
          type: 'textarea',
          rule: [
            { required: true }
          ],
          hide: [0, 2].includes(this.data?.type)
        },
        freshToken: {
          label: 'freshToken',
          type: 'textarea',
          rule: [
            { required: true }
          ],
          hide: [0, 2].includes(this.data?.type)
        },
        lvmUserTypeId: {
          label: '推广公司',
          type: 'select',
          options: this.lvmUserTypeList,
          filterable: true,
          labelKey: 'resName',
          valueKey: 'id',
        },
        memo: {
          label: '备注',
          type: 'textarea',
        },
        qrCode: {
          label: '对应活码',
          type: 'input',
        }
      },
      loading: false
    }
  },
  props: {
    data: Object,
    lvmUserTypeList: Array
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/ad/report/set_ad_account.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          advertiserId: this.form.advertiserId,
          type: this.form.type,
          accessToken: this.form.accessToken,
          freshToken: this.form.freshToken,
          lvmUserTypeId: this.form.lvmUserTypeId,
          memo: this.form.memo,
          qrCode: this.form.qrCode,
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>

