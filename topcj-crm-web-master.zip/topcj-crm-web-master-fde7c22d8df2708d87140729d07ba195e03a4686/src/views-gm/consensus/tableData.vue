<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-url="{ row }">
      <el-button
        icon="el-icon-link"
        type="text"
        size="small"
        v-open="row.url"
      >网址</el-button>
    </template>
  </el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: '编号',
          minWidth: 60
        },
        {
          key: 'title',
          label: '标题',
          minWidth: 180,
          tooltip: true
        },
        {
          key: 'url',
          label: '网址',
          minWidth: 28,
        },
        {
          key: 'content',
          label: '内容',
          minWidth: 200,
          tooltip: true
        },
        {
          key: 'ctime',
          label: '发布时间',
          width: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'refreshTime',
          label: '更新时间',
          width: 140,
          format: e => new Date(e).timeFormat()
        }
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>