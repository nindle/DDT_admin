<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
       <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>
      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData" 
        />
      </template>
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :keyword-list="config.keyword.options"
          @change="getKeywordList()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-consensus',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,

      screen: {
        time: [],
        keyword: '',
        title: '',
      },
      config: {
        time: {
          type: 'date-range'
        },
        keyword: {
          type: 'select',
          options: [],
          valueKey: 'keyword',
          labelKey: 'keyword',
          placeholder: '人员关键字'
        },
        edit: {
          type: 'button',
          buttonType: 'text',
          label: '编辑人员关键字',
          click: () => { this.showPopover = true }
        },
        split: {
          type: 'split'
        },
        title: {
          type: 'input',
          placeholder: '搜索标题关键字',
        }
      }
    }
  },
  components:{
    TableData,
    EditData
  },
  methods:{
    async getKeywordList(){
      let { result } = await this.$http({
        url: '%CRM%/management_personnel/select_page.sdcrm',
        data: {
          token: true,
        }
      })
      this.config.keyword.options.splice(0, this.config.keyword.options.length, ...result)
    },
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url:'%CRM%/management/select_page.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
          title: this.screen.title || undefined,
          keyWord: this.screen.keyword || undefined
        }
      })

      this.total = result.total
      this.tableData = result.records

      this.loading = false
    })
  },
  created(){
    this.getKeywordList()
  }
}
</script>
<style scoped lang="scss">
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>