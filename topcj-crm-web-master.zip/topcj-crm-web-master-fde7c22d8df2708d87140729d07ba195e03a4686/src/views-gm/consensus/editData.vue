
<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      编辑人员关键字
    </template>

    <el-table-pro
      :head="head"
      :data="keywordList"
      class="table"
    >
      <template #body-delete="{ row }">
        <el-popconfirm
          title="确定删除吗？"
          @confirm="deleteData(row)"
        >
          <template #reference>
            <el-button
              type="text"
              size="small"
              icon="el-icon-delete"
            >删除</el-button>
          </template>
        </el-popconfirm>
      </template>
    </el-table-pro>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        keyword: ''
      },
      config: {
        keyword: {
          label: '人员关键词',
          placeholder: '输入人员关键词，回车添加',
          change: this.submit,
          rule: [
            { required: true }
          ]
        }
      },
      head:[
        {
          key: 'id',
          label: '编号',
          width: 42
        },
        {
          key: 'keyword',
          label: '关键词',
          minWidth: 120
        },
        {
          key: 'ctime',
          label: '创建时间',
          width: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'delete',
          label: '删除',
          width: 44,
        },
      ]
    }
  },
  props: {
    show: Boolean,
    keywordList: Array,
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      let { code, errmsg, msg } = await this.$http({
        url:'%CRM%/management_personnel/add.sdcrm',
        data: {
          token:true,
          keyword:this.form.keyword
        }
      })
      if(code !== 8200) {
        this.$message.error(`添加失败：${errmsg || msg}`)
        return
      }
      this.form.keyword = ''
      this.$message.success(`添加成功`)
      this.$emit('change')
    }),
    deleteData: throttle(async function(row) {
      let { code, errmsg, msg } = await this.$http({
        mode:'get',
        url:'%CRM%/management_personnel/del/:id.sdcrm',
        data:{
          token:true,
          id: row.id
        },
      })
      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        return
      }
      this.$message.success(`删除成功`)
      this.$emit('change')
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>
<style lang="scss" scoped>
.table{
  height: 440px;
  margin-bottom: 20px;
}
</style>

