<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
  </el-table-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: '分组编号',
          minWidth: 60
        },
        {
          key: 'groupName',
          label: '分组名称',
          minWidth: 120
        },
        {
          key: 'ctime',
          label: '创建时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'auths',
          label: '分组权限',
          minWidth: 300,
          format: e => e.split(',').map(e => this.classList.find(a => a.id === Number(e))?.name ?? e).join('，')
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: row => { this.$emit('edit', row) }
          }
        },
        {
          key: 'add',
          label: '',
          width: 44,
          button: {
            popconfirm: '确认删除吗？',
            type: 'text',
            icon: 'el-icon-delete',
            label: '删除',
            click: this.deleteData
          }
        },
      ]
    }
  },
  props: {
    data: Array,
    classList: Array
  },
  methods: {
    deleteData: throttle(async function(row) {
      let { code, errmsg, msg } = await this.$http({
        url:'%CRM%/userClass/group/del_class_group.sdcrm',
        data:{
          token: true,
          id: row.id
        }
      })
      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        return
      }

      this.$message.success('删除成功')
      this.$emit('change')
    })
  }
}
</script>