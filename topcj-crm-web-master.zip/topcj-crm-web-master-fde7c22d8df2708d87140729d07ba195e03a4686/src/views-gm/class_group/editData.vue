<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      {{data ? '编辑' : '新增'}}产品分组
    </template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >确 定</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      form: {
        groupName: this.data?.groupName ?? '',
        auths: this.data?.auths.split(',').filter(e => e).map(e => Number(e)) ?? [],
      },
      config: {
        groupName: {
          label: '产品权限名称',
          rule:[
            { required: true }
          ]
        },
        auths: {
          type: 'select',
          label: '权限选择',
          multiple: true,
          filterable: true,
          options: this.classList,
          valueKey: 'id',
          labelKey: 'name',
          rule: [
            { required: true, type: 'array' }
          ]
        }
      }
    }
  },
  props: {
    show: Boolean,
    data: Object,
    classList: Array
  },
  methods: {
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/userClass/group/set_class_group.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          groupName: this.form.groupName,
          auths: this.form.auths.join(','),
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>