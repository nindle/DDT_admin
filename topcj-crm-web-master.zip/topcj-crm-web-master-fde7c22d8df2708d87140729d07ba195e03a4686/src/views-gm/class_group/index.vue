<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :class-list="classList"
          @edit="openPopover"
          @change="getTableData()"
        />
      </template>

      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          :class-list="classList"
          @change="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-class_group',
  data() {
    return {
      //状态更新
      loading: false,
      //分页
      pageNum: 1,
      pageSize: 10,
      total: 0,
      //新增展示修改
      showPopover: false,
      //编辑数据
      rowData: null,
      //表格数据
      tableData: [],
      //课程列表
      classList: [],
      // 筛选
      screen: {},
      config: {
        add: {
          type: 'button',
          label: '+ 新增',
          buttonType: 'primary',
          click: () => { this.openPopover(null) }
        }
      }
    }
  },
  methods:{
    //获取列表
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/userClass/group/get_class_group_list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      })

      this.tableData = result.records
      this.total = result.total

      this.loading = false
    }),
    //获取班级列表
    async getClassList(){
      let { result } = await this.$http({
        url: '%CRM%/package/get_class.sdcrm',
        mode: 'get',
        data: {
          token: true,
          showStatus: 0
        }
      })

      this.classList.splice(0, this.classList.length, ...result)
    },
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    }
  },
  components:{
    TableData,
    EditData
  },
  created(){
    this.getClassList()
  }
}
</script>
<style lang="scss" scoped>
.view{
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box{
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>