<template>
  <el-table-pro
    :head="head"
    :data="data"
    @row-click="getRowdata"
    row-key="categoryId"
    highlight-current-row
    :current-row-key="select.categoryId"
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'categoryId',
          label: '类别ID',
          minWidth: 56
        },
        {
          key: 'categoryName',
          label: '名称',
          minWidth: 120
        },
        {
          key: 'status',
          label: '启用',
          width: 56,
          edit: 'switch',
          clickStop: true,
          change: this.editStatus,
          inactiveValue: 0,
          activeValue: 1
        },
        {
          key: 'remark',
          label: '备注',
          minWidth: 120
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          clickStop: true,
          button: {
            type: 'text',
            label: '编辑',
            icon: 'el-icon-edit',
            click: row => { this.$emit('edit', row) }
          }
        },
      ]
    }
  },
  inject: ['select'],
  props: {
    data: Array
  },
  methods:{
    getRowdata(row){
      this.select.categoryId = row.categoryId
      this.select.categoryName = row.categoryName
    },
    async editStatus(row) {
      await this.$http({
        url: '%CRM%/category/set_category_def_status.sdcrm',
        data: {
          token: true,
          categoryId: row.categoryId,
          status: row.status,
        }
      })
    }
  }
}
</script>