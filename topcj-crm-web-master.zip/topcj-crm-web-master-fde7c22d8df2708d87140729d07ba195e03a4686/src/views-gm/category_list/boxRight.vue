<template>
  <el-layout-pro
    class="box"
    :loading="loading"
    :total="total"
    :page-num.sync="pageNum"
    :page-size.sync="pageSize"
    @page-change="getTableData()"
  >
    <template #screen>
      <el-screen-pro
        :model="screen"
        :config="config"
        @change="getTableData(true)"
      ></el-screen-pro>
    </template>

    <template #table>
      <table-data 
        :data="tableData"
        @edit="openPopover"
        @change="getTableData()"
      />
    </template>

    <!-- 编辑模块 -->
    <template #popover>
      <edit-data
        v-if="showPopover"
        :show.sync="showPopover"
        :data="rowData"
        @change="getTableData()"
      />
    </template>   
  </el-layout-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableDataRight'
import EditData from './editDataRight'

export default {
  data(){
    return{
       //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //获取数据
      tableData: [],
      //加载状态
      loading: false,

      //展示修改
      showPopover: false,
      //修改数据
      rowData: null,
      screen: {
        status: ''
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) }
        },
        status: {
          type: 'select',
          placeholder: '状态',
          options: [
            { value: 0, label: '失效' },
            { value: 1, label: '生效' },
          ]
        },
        br: { type: 'br' },
        label: {
          type: 'label',
          label: '详表：' + this.select.categoryName
        },
      }
    }
  },
  inject: ['select'],
  components:{
    TableData,
    EditData
  },
  methods:{
    getTableData: throttle(async function(toFirst){
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/category/get_category_list.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          status: typeof this.screen.status === 'number' ? this.screen.status : undefined,
          categoryId: this.select.categoryId
        }
      })

      this.loading = false

      this.tableData = result.records
      this.total = result.total     
    }),
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    }
  },
  watch: {
    'select.categoryId'() {
      this.config.label.label = '详表：' + this.select.categoryName
      this.getTableData()
    }
  }
}
</script>