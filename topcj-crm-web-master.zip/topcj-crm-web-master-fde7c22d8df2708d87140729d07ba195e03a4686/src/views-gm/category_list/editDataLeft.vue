
<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>{{data ? '编辑' : '新增'}}类别</template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        categoryCode: this.data?.categoryCode ?? '',
        categoryName: this.data?.categoryName ?? '',
        remark: this.data?.remark ?? '',
        status: this.data?.status ?? 1
      },
      config: {
        categoryName: {
          label: '名称',
          type: 'input',
          rule: [
            { required: true }
          ]
        },
        categoryCode: {
          label: '英文名',
          type: 'input',
          rule: [
            { required: true }
          ]
        },
        remark: {
          label: '备注',
          type: 'textarea'
        },
        status: {
          type: 'switch',
          label: '启用',
          inactiveValue: 0,
          activeValue: 1,
        }
      },
      loading: false
    }
  },
  props: {
    data: Object
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/category/category_def_edit.sdcrm',
        data: {
          token: true,
          categoryId: this.data?.categoryId,
          categoryCode: this.form.categoryCode,
          categoryName: this.form.categoryName,
          remark: this.form.remark,
          status: this.form.status
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    },
  }
}
</script>