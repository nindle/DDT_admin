
<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>{{data ? '编辑' : '新增'}}{{select.categoryName}}</template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        typeName: this.data?.typeName ?? '',
        typeDesc: this.data?.typeDesc ?? '',
        extValue: this.data?.extValue ?? '',
        orderId: this.data?.orderId ?? 0,
        corpIds: this.data?.corpIds?.split(',').filter(e => e).map(e => Number(e)) ?? [],
        status: this.data?.status ?? 1
      },
      config: {
        typeName: {
          label: '名称',
          type: 'input',
          rule: [
            { required: true }
          ]
        },
        typeDesc: {
          label: '备注',
          type: 'textarea'
        },
        extValue: {
          label: '扩展值',
          type: 'input'
        },
        orderId: {
          label: '排序',
          type: 'number',
          min: 0,
          precision: 0
        },
        corpIds: {
          type: 'select-corp',
          label: '分公司',
          multiple: true
        },
        status: {
          type: 'switch',
          label: '启用',
          inactiveValue: 0,
          activeValue: 1,
        }
      },
      loading: false
    }
  },
  inject: ['select'],
  props: {
    data: Object
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/category/category_edit.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          typeId: this.data?.typeId ?? null,
          categoryId: this.select.categoryId,
          typeName: this.form.typeName,
          typeDesc: this.form.typeDesc,
          extValue: this.form.extValue,
          status: this.form.status,
          corpIds: this.form.corpIds.join(','),
          orderId: this.form.orderId
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    },
  }
}
</script>