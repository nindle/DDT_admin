<template>
  <el-table-pro
    :head="head"
    :data="data"
  ></el-table-pro>  
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'typeId',
          label: '类型ID',
          minWidth: 56,
        },
        {
          key: 'typeName',
          label: '名称',
          minWidth: 120
        },
        {
          key: 'status',
          label: '启用',
          width: 56,
          edit: 'switch',
          clickStop: true,
          change: this.editStatus,
          inactiveValue: 0,
          activeValue: 1
        },
        {
          key: 'extValue',
          label: '扩展值',
          minWidth: 120
        },
        {
          key: 'orderId',
          label: '排序',
          minWidth: 28
        },
        {
          key: 'typeDesc',
          label: '备注',
          minWidth: 120
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          clickStop: true,
          button: {
            type: 'text',
            label: '编辑',
            icon: 'el-icon-edit',
            click: row => { this.$emit('edit', row) }
          }
        },
      ]
    }
  },
  props:{
    data: Array
  },
  methods:{
    async editStatus(row) {
      await this.$http({
        url: '%CRM%/category/set_category_status.sdcrm',
        data: {
          token: true,
          id: row.id,
          status: row.status,
        }
      })
    }
  }
}
</script>