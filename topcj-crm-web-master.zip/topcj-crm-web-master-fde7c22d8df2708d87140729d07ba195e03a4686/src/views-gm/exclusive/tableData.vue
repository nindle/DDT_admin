<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'userId',
          label: '用户ID',
          minWidth: 70
        },
        {
          key: 'realName',
          label: '用户姓名',
          minWidth: 70
        },
        {
          key: 'corpName',
          label: '分公司',
          minWidth: 70,
        },
        {
          key: 'externalName',
          label: '企业微信姓名',
          minWidth: 120,
        },
        {
          key: 'orderTime',
          label: '最近成交时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'expStatus',
          label: '用户状态',
          minWidth: 84,
          format: {
            '1': '服务期内用户',
            '0': '过期用户'
          }
        },
        {
          key: 'externalStatus',
          label: '添加专属号状态',
          minWidth: 98,
          format: {
            '1': '已添加',
            '0': '未添加'
          }
        }
      ]
    }
  },
  props: {
    data: Array,
  },
}
</script>