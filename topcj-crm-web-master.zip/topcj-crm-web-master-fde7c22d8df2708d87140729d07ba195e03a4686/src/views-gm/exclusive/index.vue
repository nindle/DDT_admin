<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <!-- 筛选 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data
          :data="tableData"
          ref="table"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'

export default {
  name: 'gm-exclusive',
  data() {
    return {
      //分页数据
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],

      screen: {
        corpId: '',
        time: [],
        keyword: '',
        expStatus: '',
        externalStatus: '',
      },
      config: {
        corpId: {
          type: 'select-corp'
        },
        expStatus: {
          type: 'select',
          placeholder: '用户状态',
          options: [
            {label: '服务期内用户', value: 1},
            {label: '过期用户', value: 0}
          ]
        },
        externalStatus: {
          type: 'select',
          placeholder: '添加专属号',
          options: [
            {label: '已添加', value: 1},
            {label: '未添加', value: 0}
          ]
        },
        time: {
          type: 'date-range'
        },
        split: {type: 'split'},
        keyword: {
          type: 'input',
          placeholder: '输入用户ID/手机号'
        },
        excel: {
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        }
      }
    }
  },
  props: {
    nav: Object
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }
      
      let { result } = await this.$http({
        url: '%CRM%/external/get_external_report.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
          expStatus: typeof this.screen.expStatus === 'number' ? this.screen.expStatus : undefined,
          externalStatus: typeof this.screen.externalStatus === 'number' ? this.screen.externalStatus : undefined,
          keyWord: this.screen.keyword || undefined,
        },
      })

      this.loading = false

      this.total = result.total
      this.tableData = result.records
    }),
  },
  components: {
    TableData
  }
}
</script>
<style lang="scss" scoped>
.view{
  padding: 24px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  .box{
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>