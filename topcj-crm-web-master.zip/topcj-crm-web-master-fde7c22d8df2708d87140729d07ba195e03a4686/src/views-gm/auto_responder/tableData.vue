<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-tags="{ row }">
      <span
        v-for="(e,i) in row.keyMatch?row.keyMatch.split(',') : []"
        :key="i"
      >{{i === 0 ? '' : '，'}}包含-{{e}}</span>
      <span
        v-for="(e,i) in row.keyWord?row.keyWord.split(',') : []"
        :key="row.keyMatch? i+row.keyMatch.split(',').length : -1"
      >{{row.keyMatch?(row.keyMatch.length === 0? '' : '，'): ''}}全覆盖-{{e}}</span>
    </template>
  </el-table-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      head: [
        {
          key: 'ruleName',
          label: '规则名',
          minWidth: 70
        },
        {
          key: 'tags',
          label: '关键字',
          minWidth: 70,
        },
        {
          key: 'isStatus',
          label: '是否启用',
          minWidth: 56,
          format: {
            '0' : '未开启',
            '1' : '已开启'
          }
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: e => { this.$emit('edit', e) }
          }
        },
        {
          key: 'delete',
          label: '',
          width: 44,
          button: {
            popconfirm: '确定删除吗？',
            type: 'text',
            icon: 'el-icon-delete',
            label: '删除',
            click: e => { this.deleteData(e) }
          }
        }
      ]
    }
  },
  props: {
    data: Array
  },
  methods: {
    deleteData: throttle(async function(data) {
      let { code,msg,errmsg } = await this.$http({
        mode: 'get',
        url: `%CRM%/qywx/del/${data.id}.sdcrm`,
        data: {
          token: true
        }
      })

      if(code !== 8200) {
        this.$message.error(`删除失败：${msg || errmsg}`)
        return
      }

      this.$message.success('删除成功')
      this.$emit('change')
    })
  }
}
</script>
<style lang="scss" scoped>

</style>