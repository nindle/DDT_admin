<template>
  <el-layout-pro
    class="left-box"
    :loading="loading"
  >
    <template #screen>
      <el-screen-pro :config="config"></el-screen-pro>
    </template>
    <template #scroll>
      <message 
        v-if="messageData"
        :data="[messageData]"
      />

      <div 
        v-if="messageData && !messageData.isStatus"
        class="status"
      >当前消息自动回复状态尚未启用</div>
    </template>
  </el-layout-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import Message from '../../components/message/index'

export default {
  data() {
    return {
      loading: false,
      messageData: null,
      config: {
        label: {
          type: 'label',
          label: '消息自动回复'
        },
        split: {type: 'split'},
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '新 增' ,
          click: () => {
            this.$emit('open', this.messageData, 1)
          }
        }
      },
    }
  },
  props: {
    agentId: String,
    qywx: String,
  },
  methods: {
    getMessage: throttle(async function() {
      this.loading = true

      let { result } = await this.$http({
        url: '%CRM%/qywx/receive_list.sdcrm',
        data: {
          token: true,
          type: 1,
          agentId: this.agentId,
          qyWx: this.qywx,
          pageNum: 1,
          pageSize: 1
        }
      })

      this.loading = false

      this.messageData = result.records?.[0] ?? null

      if(this.messageData) {
        this.config.add.label = '编 辑'
      } else {
        this.config.add.label = '新 增'
      }
    })
  },
  watch: {
    agentId: {
      handler: function(){
        this.getMessage()
      },
      immediate: true
    }
  },
  components: {
    Message
  },
}
</script>

<style lang="scss" scoped>
.left-box {
  /deep/ {
    .scrollbar-view {
      padding: 0 24px;
      box-sizing: border-box;
      .msg-head {
        display: none;
      }
    }
  }
  .status {
    margin-top: 48px;
    font-size: 14px;
    color: #999;
    text-align: center;
  }
}

</style>