<template>
  <el-layout-pro
    class="right-box"
    :loading="loading"
    :total="total"
    :page-num.sync="pageNum"
    :page-size.sync="pageSize"
    @page-change="getMessage()"
  >
    <template #screen>
      <el-screen-pro :config="config"></el-screen-pro>
    </template>

    <template #table>
      <table-data 
        :data="tableData"
        @edit="$emit('open', $event, 2)"
        @change="getMessage()"
      />
    </template>
  </el-layout-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'

export default {
  data() {
    return {
      loading: false,
      pageNum: 1,
      pageSize: 10,
      total: 0,
      // 表格数据
      tableData: [],
      config: {
        label: {
          type: 'label',
          label: '关键词自动回复'
        },
        split: {type: 'split'},
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '新 增' ,
          click: () => {
            this.$emit('open', null, 2)
          }
        }
      },
    }
  },
  props: {
    agentId: String,
    qywx: String,
  },
  methods: {
    getMessage: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/qywx/receive_list.sdcrm',
        data: {
          token: true,
          type: 2,
          agentId: this.agentId,
          qyWx: this.qywx,
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      })

      this.loading = false

      this.tableData = result.records
      this.total = result.total
    })
  },
  watch: {
    agentId: {
      handler: function(){
        this.getMessage(true)
      },
      immediate: true
    }
  },
  components: { 
    TableData 
  },
}
</script>

<style lang="scss" scoped>
.right-box {
  /deep/ {
    .screen-box {
      padding-bottom: 0 !important;
    }
    .table-box {
      padding: 24px !important;
    }
  }
}
</style>