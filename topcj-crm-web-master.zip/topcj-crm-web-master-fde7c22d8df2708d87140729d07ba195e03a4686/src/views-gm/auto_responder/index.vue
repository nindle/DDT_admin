<template>
  <div class="view">
    <el-layout-pro class="box">
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
        ></el-screen-pro>
      </template>

      <template 
        #table 
        v-if="screen.appId"
      >
        <div class="box-scroll">
          <left-box 
            class="two-box"
            :agent-id="screen.appId"
            :qywx="screen.qywxId"
            @open="openPopover"
            ref="leftBox"
          />
          <right-box 
            class="two-box"
            :agent-id="screen.appId"
            :qywx="screen.qywxId"
            @open="openPopover"
            ref="rightBox"
          />
        </div>
      </template>

      <template #popover>
        <edit-data 
          v-if="showPopover"
          :show.sync="showPopover"
          :type="popoverDataType"
          :agent-id="screen.appId"
          :qywx="screen.qywxId"
          :data="popoverData"
          @change="updateData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'

import LeftBox from './leftBox'
import RightBox from './rightBox'
import EditData from './editData'

export default {
  name: 'gm-auto_responder',
  data() {
    return {
      screen: {
        corpId: '',
        qywxId: '',
        appId: ''
      },
      config: {
        corpId: {
          type: 'select-corp',
          change: () => {
            this.screen.qywxId = ''
            this.screen.appId = ''
          }
        },
        qywxId: {
          type: 'select-qywx',
          placeholder: '企业微信',
          filter: () => {
            if(typeof this.screen.corpId === 'number') {
              return {
                corpId: this.screen.corpId
              }
            }
            return {}
          },
          change: this.getAppData
        },
        appId: {
          type: 'select',
          placeholder: '应用',
          options: [],
          labelKey: 'appName',
          valueKey: 'appId',
        }
      },
      showPopover: false,
      popoverDataType: 0,
      popoverData: null
    }
  },
  methods: {
    getAppData: throttle(async function() {
      this.screen.appId = ''
      if(this.screen.qywxId === '') return 

      let { result } = await this.$http({
        url: '%CRM%/qywx/get_qywx_app_list.sdcrm',
        data: {
          token: true,
          isPage: 0,
          corpId: this.screen.corpId,
          qyWx: `${this.screen.qywxId}`
        }
      })

      this.config.appId.options.splice(0, this.config.appId.options.length, ...result)
      
    }),
    updateData() {
      if(this.popoverDataType === 1) {
        this.$refs.leftBox.getMessage()
      }else{
        this.$refs.rightBox.getMessage()
      }
    },
    openPopover(data, type) {
      this.showPopover = true
      this.popoverDataType = type
      this.popoverData = data
    }
  },
  components: { 
    RightBox, 
    LeftBox,
    EditData 
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    /deep/ {
      .screen-box {
        background: #FFF;
        padding-bottom: 24px;
      }
      .table-box {
        padding: 0;
      }
    }
    .box-scroll {
      height: calc(100% - 24px);
      display: flex;
      justify-content: space-between;
      margin-top: 24px;
      .two-box {
        width: calc(50% - 12px);
        background: #FFF;
      }
    }
  }
}
</style>