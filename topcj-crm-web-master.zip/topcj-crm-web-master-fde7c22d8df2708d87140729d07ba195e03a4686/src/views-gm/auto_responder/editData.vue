<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      {{data ? '编辑' : '添加'}}自动回复
    </template>

    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
      <template #tags>
        <div v-if="form.tags.length">
          <el-tag
            v-for="(e, i) in form.tags"
            :key="i"
            closable
            @close="deleteTags(i)">
            {{e.key === 1 ? '包含' : '全覆盖'}}-{{e.tag}}
          </el-tag>
        </div>
        <span v-else></span>
      </template>
      <template #inputTags>
        <div class="tag-form">
          <el-select 
            class="select-new-tag"
            v-model="form.inputTagsType"
            placeholder="请选择"
          >
            <el-option
              v-for="e in config.inputTags.options"
              :key="e.value"
              :label="e.label"
              :value="e.value"
            ></el-option>
          </el-select>
          <el-input
            class="input-new-tag"
            v-model="form.inputTagsValue"
            @change="inputTag"
          ></el-input>
        </div>
      </template>

      <template #content>
        <message-input 
          :tool="tool"
          ref="message"
        />
      </template>
    </el-form-pro>
    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>

    <template #right>
      <message-template 
        :default-corp-id="-1"
        :table-lists="tableList"
      />
    </template>
  </el-dialog-pro>
</template>
<script>
import Bus from '../../assets/js/bus'
import { throttle } from '../../assets/js/tool'
import MessageInput from '../../components/message-input'
import MessageTemplate from '../../components/message-template'

export default {
  data() {
    return {
      tool: ['face','file','video','voice'],
      tableList:[
        {label:'文字',key:0},
        {label:'',key:1},
        {label:'外链',key:2},
        {label:'图片',key:3}
      ],

      loading: false,      
      form: {
        ruleName: this.data?.ruleName ?? '',
        tags: [],
        content: '',
        isStatus: this.data && this.data.msgType ? this.data.isStatus : 1,
        inputTagsType: 1,
        inputTagsValue: ''
      },
      config: {
        ruleName: {
          type: 'input',
          label: '规则名',
          hide: this.type === 1,
          rule: [
            { required: true }
          ]
        },
        tags: {
          label: '已选关键字',
          hide: this.type === 1,
          rule: [
            { required: true, message: '请选择关键字' }
          ]
        },
        inputTags: { 
          label: '关键字',
          hide: this.type === 1,
          options: [
            {value: 1 , label: '包含'},
            {value: 2 , label: '全覆盖'},
          ]
        },
        content: {},
        isStatus: {
          type: 'switch',
          label: '是否启用',
          activeValue: 1,
          inactiveValue: 0,
        }
      }
    }
  },
  props: {
    show: Boolean,
    data: Object,
    type: Number,
    agentId: String,
    qywx: String,
  },
  methods: {
    // 添加关键词
    deleteTags(index) {
      this.form.tags.splice(index, 1)
    },
    inputTag() {
      if(!this.form.inputTagsValue) return

      if(this.form.tags.findIndex(e => e.tag === this.form.inputTagsValue) > -1) return
        
      this.form.tags.push({
        key: this.form.inputTagsType,
        tag: this.form.inputTagsValue
      })

      this.form.inputTagsType = 1
      this.form.inputTagsValue = ''
    },
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      let text = this.$refs.message.getMessage()
      if(!text.length) {
        this.$message.error('回复消息不能为空，请输入内容')
        return
      }else if(text.length > 1) {
        this.$message.error('回复消息只能保留一个，请删除多余的消息')
        return
      } else if(text[0].msgType === 'file') {
        this.$message.error('回复消息不能回复文件，请重新输入')
        return
      }

      this.loading = true

      let AllKeyword = this.form.tags.filter(e => e.key === 2)
      let ContainKeyword = this.form.tags.filter(e => e.key === 1)
      let data = {
        token: true,
        msgType: text[0].msgType,
        id: this.data?.id,
        agentId: this.agentId,
        ruleName:this.type === 2 ? this.form.ruleName : '全回复',
        keyWord: this.type === 2 ? AllKeyword.map(e => e.tag).join(',') : undefined,
        keyMatch: this.type === 2 ? ContainKeyword.map(e => e.tag).join(',') : undefined,
        isStatus: typeof this.form.isStatus === 'number' ? this.form.isStatus : undefined,
        userQyId: this.$store.state.managerInfo.id,
        qyWx: this.qywx
      }

      switch(text[0].msgType) {
        case 'text':
          data.content = text[0].content
          break
        case 'news': 
          data.picUrl = text[0].imageUrl
          data.picurl = text[0].imageUrl
          data.imageUrl = text[0].imageUrl
          data.description = text[0].description
          data.title = text[0].title
          data.url = text[0].url
          break
        case 'mpnews':
          data.picUrl = text[0].imageUrl
          data.picurl = text[0].imageUrl
          data.imageUrl = text[0].imageUrl
          data.content = text[0].content
          data.digest = text[0].digest
          data.title = text[0].title
          data.sourceId = text[0].sourceId
          break
        default: 
          data.imageUrl = text[0].imageUrl
          break
      }

      let { code, msg, errmsg } = await this.$http({
        url: this.data ? '%CRM%/qywx/edit.sdcrm' : '%CRM%/qywx/qy_wx_bulk.sdcrm',
        data
      }) 

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${msg || errmsg}`)
        return
      }
      
      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    },
    async init() {
      await this.$nextTick()

      if(this.type === 2 && this.data) {
        this.data.keyMatch.split(',').filter(e => e).forEach(e => {
          this.form.tags.push({
            key: 1,
            tag: e
          })
        })
        this.data.keyWord.split(',').filter(e => e).forEach(e => {
          this.form.tags.push({
            key: 2,
            tag: e
          })
        })
      }

      switch(this.data.msgType) {
        case 'text':
          {
            Bus.$emit('inputMessage', {
              type: 'text',
              content: this.data.content
            })
          }
          break
        case 'news': 
          {
            Bus.$emit('inputMessage', {
              type: 'news',
              imageUrl: this.data.imageUrl,
              url: this.data.url,
              title: this.data.title,
              source: this.data.sourceId,
              description: this.data.description
            })
          }
          break
        case 'mpnews':
          {
            Bus.$emit('inputMessage', {
              type: 'mpnews',
              imageUrl: this.data.imageUrl,
              content: this.data.content,
              title: this.data.title,
              source: this.data.sourceId,
              description: this.data.digest
            })
          }
          break
        default: 
          {
            Bus.$emit('inputMessage', {
              type: this.data.msgType,
              imageUrl: this.data.imageUrl
            })
          }
          break
      }
    }
  },
  components: {
    MessageInput,
    MessageTemplate
  },
  mounted() {
    if(this.data) {
      this.init()
    }
  }
}
</script>
<style lang="scss" scoped>
/deep/ {
  .el-form-item__content {
    .el-tag {
      margin-right: 10px;
    }
    .tag-form {
      display: inline-block;
      .input-new-tag {
        width: 256px;
        vertical-align: bottom;
        .el-input__inner {
          border-radius: 0px 4px 4px 0px;
        }
      }
      .select-new-tag {
        width: 100px;
        .el-input {
          width: 100px;
          margin-right: 0;
          .el-input__inner {
            border-radius: 4px 0 0 4px;
            border-right: 0;
          }
        }
      }
    }
    .message-input {
      height: 300px;
      border: 1px solid #D9D9D9;
      border-radius: 5px;
      position: relative;
    }
  }
}
</style>