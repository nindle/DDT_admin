<!--AI小助手-->
<template>
  <el-layout-pro 
    class="ai-msg-box"
    @scroll-top="scrollTop"
  >
    <template #screen>
      <div class="title">AI小助手</div>
    </template>

    <template #scroll>
      <div
        class="msg"
        v-for="e in historyMsg"
        :key="e.id"
        :ref="`message-${e.id}`"
      >
        <div class="body">
          <!--事件-->
          <div 
            class="aitip"
            v-if="e.msgType === 'event'"
            v-html="getAiTip(e)"
          ></div>
        </div>
      </div>
    </template>
  </el-layout-pro>
</template>

<script>
import bus from '../../assets/js/bus'
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      historyMsg: [],
      saveId: 0
    }
  },
  computed: {
    isFocus() {
      return this.$store.state.window.isFocus
    },
    isAllow() {
      return this.$store.state.window.isAllow
    }
  },
  methods: {
    getHistoryMsg: throttle(async function() {
      let { result } = await this.$http({
        url: '%CRM%/user/message/get_user_event_msg.sdcrm',
        data: {
          token: true,
          from: this.historyMsg.length,
          size: 20,
          managerId: this.$store.state.managerInfo.id
        }
      })

      this.addMsg(result.records.reverse(), this.historyMsg.length ? true : false)            
    }),
    //新增消息
    async addMsg(data, isHistory) {
      if(isHistory) {
        //是历史消息
        this.historyMsg = data.concat(this.historyMsg)
      }else{
        //不是历史消息
        this.historyMsg = this.historyMsg.concat(data)
      }

      await this.$nextTick()

      if(this.saveId) {
        this.$refs[`message-${this.saveId}`][0].scrollIntoView()
      }else if(this.historyMsg.length){
        this.$refs[`message-${this.historyMsg[this.historyMsg.length - 1].id}`][0].scrollIntoView()
      }
    },
    scrollTop: throttle(async function() {
      this.saveId = this.historyMsg[0]?.id
      await this.getHistoryMsg()
    }, 300),
    getAiTip(e) {
      let time = new Date(e.lastTime).timeFormat('yyyy/MM/dd hh:mm:ss')
      let content = e.content.replace(/\{userId\}/g, `<span>${e.remarkName || e.nickname || e.userId}</span>`)

      return time + content
    },
    newMsg(newmsg) {
      if(newmsg.type === 2) {
        let newid = this.historyMsg.length ? this.historyMsg[this.historyMsg.length - 1].id + 1 : 1
        newmsg.id = newid
        newmsg.lastTime = newmsg.ctime
        this.addMsg([newmsg])

        this.$emit('newmsg', this.getAiTip(newmsg))
      }
    }
  },
  created() {
    this.getHistoryMsg()
    bus.$on('wsMessage', this.newMsg)
  },
  beforeDestroy() {
    bus.$off('wsMessage', this.newMsg)
  }
}
</script>

<style lang="scss" scoped>
.ai-msg-box {
  width: 100%;
  height: 100%;
  background: #F0F2F5;
  /deep/ {
    .screen-box { padding: 0;}
  }
  .title {
    width: 100%;
    line-height: 62px;
    font-size: 18px;
    color: rgba(#000, .85);
    text-align: center;
    border-bottom: 1px solid #E9E9E9;
  }
  .msg {
    &:last-child { padding-bottom: 20px;}
    padding-top: 20px;
    position: relative;
    .body {
      width: 90%;
      margin: 0 auto;
      position: relative;
      text-align: center;
      .aitip {
        display: inline-block;
        padding: 5px 15px;
        font-size: 12px;
        line-height: 20px;
        margin: 0 auto;
        border-radius: 4px;
        background: #E8E8E8;
        color: rgba(#000, .85);
        /deep/ span { color: #4796FE;}
      }
    }
  }
}
</style>