<!--消息主控-->
<template>
  <div></div>
</template>

<script>
import bus from '../../assets/js/bus'

export default {
  data() {
    return {
      ws: null,
      msgTip: [],
      notification: null,

      socketProtectTimer: null,
      socketProtect: true
    }
  },
  computed: {
    isFocus() {
      return this.$store.state.window.isFocus
    },
    isAllow() {
      return this.$store.state.window.isAllow
    }
  },
  methods: {
    //设置WebSocket
    setWebSocket() {
      this.ws = new WebSocket(`${this.SYS.API.WS}/ws/${this.$store.state.managerInfo.id}`)

      this.socketProtectTimer = setTimeout(() => {
        this.socketProtect = false
      }, 10 * 1000)

      //接收消息
      this.ws.onmessage = event => {
        if(event.data !== 'pong'){
          this.pushMessage(JSON.parse(event.data))
        }
      }

      //关闭
      this.ws.onclose = event => {
        if(this.socketProtect) {
          //socket链接保护期
          this.$notify.info({
            title: 'AI小助手',
            message: '请关闭企业微信中的顶点通',
            showClose: true,
            duration: 0,
            position: 'bottom-right'
          })
          return
        }
        if(event.code === 1000) {
          this.$store.commit('setWindow', {
            onLine: false,
          })
        }else{
          if(this.$store.state.token) {
            //登录中进行重连
            this.setWebSocket()
          }else{
            //未登录跳出掉线
            this.$store.commit('setWindow', {
              onLine: false,
            })
          }
        }
      }

      window.onbeforeunload = () => {
        this.safeClose()
      }  
    },
    //推送消息
    pushMessage(data) {
      if(data.msgType === 'event') {
        for(let i in this.msgTip) {
          let e = this.msgTip[i]
          if(e.name === data.event) {
            data.displayType = e.displayType
          }
        }
      }else{
        data.displayType = 3
      }

      bus.$emit('wsMessage', data)

      if(!this.isFocus && this.isAllow && [1,3].includes(data.displayType)) {
        this.notification = new Notification('收到新消息', {
          body: `你有未读消息，请尽快查看回复`,
          tag: 1
        })
        this.notification.onclick = function() {
          window.focus()
        }
      }
      
      console.log(data)
    },
    //安全关闭
    safeClose() {
      clearTimeout(this.socketProtectTimer)
      if(this.ws) {
        this.ws.onclose = () => {}
        this.ws.close()
      }
    },
    //浏览器通知
    initNotification() {
      if(!this.SYS.WK.IN) {
        if(navigator.userAgent.indexOf('AppleWebKit') > -1) {
          if (window.Notification) {
            window.Notification.requestPermission(status => {
              if(status !== 'granted' && this.env !== 'local') {
                this.$store.commit('setWindow', {
                  isAllow: false
                })
                this.$notify.warning({
                  title: '　　　↑↑↑',
                  message: '请允许浏览器通知',
                  showClose: false,
                  duration: 0,
                  position: 'top-left'
                })
              }
            })
          }else{
            this.$store.commit('setWindow', {
              isAllow: false
            })
            this.$notify.warning({
              title: '浏览器版本太低',
              dangerouslyUseHTMLString: true,
              message: '请更新您的浏览器，推荐使用Chrome <a href="https://www.google.cn/chrome/" style="color: #4796FE">点击下载</a>',
              showClose: false,
              duration: 0,
              position: 'top-left'
            })
          }
        }else{
          this.$store.commit('setWindow', {
            isAllow: false
          })
          this.$notify.warning({
            title: '请使用Chrome浏览器',
            dangerouslyUseHTMLString: true,
            message: '为了更好的体验，请使用Chrome浏览器 <a href="https://www.google.cn/chrome/" style="color: #4796FE">点击下载</a>',
            showClose: false,
            duration: 0,
            position: 'top-left'
          })
        }
      }

      global.onblur = () => {
        this.$store.commit('setWindow', {
          isFocus: false
        })
      }
      global.onfocus = () => {
        setTimeout(() => {
          this.$store.commit('setWindow', {
            isFocus: true
          })
          if(this.notification) {
            this.notification.close()
            this.notification = null
          }
        }, 20)
      }
    },
    //浏览器放大缩小
    initRatio() {
      if(Math.round(global.devicePixelRatio * 100) < 100) {
        this.$notify.warning({
          title: '请调整页面的缩放比例',
          message: '为了更好的体验，请调整缩放比例至100%',
          duration: 0,
          position: 'top-left'
        })
      }
    },
    async getMsgTip() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/setting/get_msg_event_list.sdcrm',
        data: {
          token: true,
          type: 0
        }
      })

      this.msgTip = result
    }
  },
  mounted() {
    this.setWebSocket()
    this.initNotification()
    this.initRatio()
    this.getMsgTip()
  },
  beforeDestroy() {
    this.safeClose()
  },
}
</script>