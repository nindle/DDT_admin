
<template>
  <el-dialog-pro 
    @close="close"
    width="436px"
    default-full
  >
    <!--标题-->
    <template #title>
      消息提醒设置
    </template>
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        size="small"
        type="primary"
        @click="submit"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        type1: [],
        type2: [],
      },
      config: {
        type1: {
          label: 'AI小助手',
          type: 'check-list',
          options: this.msgEventList.type1,
          valueKey: 'id',
          labelKey: 'description',
        },
        type2: {
          label: '消息列表',
          type: 'check-list',
          options: this.msgEventList.type2,
          valueKey: 'id',
          labelKey: 'description',
        }
      },
    }
  },
  props: {
    show: Boolean,
    msgEventList: Object
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      await this.$http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/setting/set_manager_msg_event.sdcrm',
            data: {
              token: true,
              type: 1,
              eventIds: this.form.type1
            },
          },
          {
            url: '%CRM%/setting/set_manager_msg_event.sdcrm',
            data: {
              token: true,
              type: 2,
              eventIds: this.form.type2
            },
          }
        ],
      })

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    },
    async getSetting() {
      let data = await this.$http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/setting/get_manager_msg_event.sdcrm',
            data: {
              token: true,
              type: 1
            },
          },
          {
            url: '%CRM%/setting/get_manager_msg_event.sdcrm',
            data: {
              token: true,
              type: 2
            },
          }
        ],
      })

      this.form.type1 = data[0].result.map(e => e.eventId)
      this.form.type2 = data[1].result.map(e => e.eventId)
    }
  },
  created() {
    this.getSetting()
  }
}
</script>

