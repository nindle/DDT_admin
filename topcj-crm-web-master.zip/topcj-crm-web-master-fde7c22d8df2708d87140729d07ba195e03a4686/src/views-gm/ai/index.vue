<template>
  <div 
    class="ai-robot"
    v-show="showAI"
  >
    <msg-controller @hide-ai="showAI = false"/>
    <div 
      class="ai-msg"
      :class="{ show: showMsgBox }"
    >
      <div 
        class="open-setai el-icon-setting"
        @click="openSetAi"
      ></div>
      <ai-robot @newmsg="hasnewmsg" />

      <edit-data
        v-if="showPopover"
        :show.sync="showPopover"
        :msg-event-list="msgEventList"
      />
    </div>

    <div 
      class="robot"
      :class="{ hide: !showMsgBox && !showRobotFlag }"
      @click="showMsgBox = !showMsgBox"
      @mouseover="showRobot"
      @mouseleave="hideRobot"
    ></div>
  </div>
</template>

<script>
import MsgController from './msgController'
import AiRobot from './aiRobot'
import EditData from './editData'

export default {
  data() {
    return {
      showAI: true,

      showMsgBox: false,
      showRobotFlag: false,
      timer: null,
      showPopover: false,
      msgEventList: {
        type1: [],
        type2: []
      }
    }
  },
  components: {
    MsgController,
    AiRobot,
    EditData
  },
  methods: {
    hasnewmsg(msg) {
      if(this.showMsgBox) return

      this.$notify.info({
        title: 'AI小助手',
        dangerouslyUseHTMLString: true,
        message: msg,
        showClose: true,
        duration: 0,
        position: 'bottom-right',
        onClick: () => {
          this.showMsgBox = true
          this.$notify.closeAll()
        }
      })
    },
    showRobot() {
      this.showRobotFlag = true
    },
    hideRobot() {
      this.timer = setTimeout(() => {
        this.showRobotFlag = false
      }, 3000)
    },
    openSetAi() {
      this.showPopover = true
    },
    async getSetting() {
      let data = await this.$http({
        mode: 'all',
        all: [
          {
            mode: 'get',
            url: '%CRM%/setting/get_msg_event_list.sdcrm',
            data: {
              token: true,
              type: 1
            }
          },
          {
            mode: 'get',
            url: '%CRM%/setting/get_msg_event_list.sdcrm',
            data: {
              token: true,
              type: 2
            }
          }
        ],
      })

      this.msgEventList.type1 = data[0].result.filter(e => e.status)
      this.msgEventList.type2 = data[1].result.filter(e => e.status)
    },
  },
  created() {
    this.getSetting()
  }
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";

.ai-robot {
  position: fixed;
  right: 0;
  bottom: 0;
  .robot {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 80px;
    height: 80px;
    @include image(airobot, top left no-repeat);
    cursor: pointer;
    padding: 0 20px 20px 0;
    &.hide {
      transform: translateX(66px) rotate(-23deg);
    }
    transition: transform .3s;
  }
  .ai-msg {
    position: absolute;
    right: -500px;
    bottom: 120px;
    width: 480px;
    height: calc(100vh - 185px);
    transition: right .3s;
    box-shadow: 0 0 12px rgba(#333, .26);
    &.show {
      right: 0;
    }
    .open-setai {
      position: absolute;
      right: 10px;
      top: 20px;
      color: #4796FE;
      font-size: 20px;
      z-index: 1;
      cursor: pointer;
    }
  }
}
</style>
