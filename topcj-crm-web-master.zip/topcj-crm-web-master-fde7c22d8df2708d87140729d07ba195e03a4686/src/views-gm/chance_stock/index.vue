<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :select-list.sync="selectList"
          @edit="openPopover"
        />
      </template>

      <template #popover> 
        <edit-data 
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          @change="getTableData()"
        />

        <review 
          v-if="showReview"
          :show.sync="showReview"
          :review-list="reviewList"
          @success="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'
import Review from '../../components/review/index'

export default {
  name: 'gm-chance_stock',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      // 筛选
      screen: {
        indexId: '',
        corpId: '',
        time: null
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => {this.openPopover(null)}
        },
        corpId: {
          type: 'select-corp'
        },
        indexId: {
          type: 'select',
          placeholder: "类型",
          options: this.$store.state.baseData.strategyIndexList,
          filter: {
            type: 1
          },
          labelKey: 'indexName',
          valueKey: 'id'
        },
        reviewOnline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核上线',
          click: () => { this.openReview(1) }
        },
        reviewOffline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核下线',
          click: () => { this.openReview(2) }
        },
        time: {
          type: 'date-range'
        }
      },
      // 审核相关
      selectList: [],
      showReview: false,
      reviewList: [],
      // 新增弹窗显示
      showPopover: false,
      rowData: null
    }
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/strategy/get_strategy_stock.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          indexId: typeof this.screen.indexId === 'number' ? this.screen.indexId : undefined,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
        }
      })

      this.loading = false

      this.total = result.total
      this.tableData = result.records
    }),
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    },
    openReview(status) {
      this.reviewList = this.selectList.map(e => {
        return {
          url: '%CRM%/strategy/trail_strategy_stock.sdcrm',
          data: {
            token: true,
            id: e.id,
            status
          }
        }
      })

      this.showReview = true
    }
  },
  components: {
    TableData,
    EditData,
    Review
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>