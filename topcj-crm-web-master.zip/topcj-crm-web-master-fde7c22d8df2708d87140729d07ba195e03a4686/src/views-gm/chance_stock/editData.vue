<template>
  <el-dialog-pro @close="close">
    <template #title>
      {{data? '编辑': '新增'}}机会选股
    </template>

    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
      <template #stockList>
        <span></span>
        <el-tag
          v-for="(e, i) in form.stockList"
          :key="i"
          closable
          @close="deleteStock(e)"
        >{{e.stockName}}</el-tag>
      </template>

      <template #referIndex>
        <el-select
          v-for="(e, i) in $store.state.baseData.strategyIndexList"
          :key="e.id"
          clearable
          v-model="form.referIndex[i].id"
          :placeholder="e.variName"
          size="small"
          class="index-select"
        >
          <el-option
            v-for="e in e.values"
            :key="e.id"
            :value="e.id"
            :label="e.variName"
          ></el-option>
        </el-select>
      </template>
    </el-form-pro>

    <!-- 底部按钮 -->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro> 
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    let userReferIndex = []

    if(this.data) {
      this.data.referIndex.split(',').map(e => {
        let s = e.split('|')
        userReferIndex.push({
          name: s[2],
          pid: Number(s[1]),
          id: Number(s[0])
        })
      })
    }


    let referIndex = this.$store.state.baseData.strategyIndexList.map(e => {
      let l = userReferIndex.filter(a => a.pid === e.id)
      return {
        name: e.variName,
        pid: e.id,
        id: l.length ? l[0].id : ''
      }
    })

    return {
      loading: false,
      form: {
        indexId: this.data?.indexId ?? '',
        indexValueId: this.data?.indexValueId ?? '',
        plateId: this.data?.plateId ? `${this.data.plateId}.${this.data.plateName}` : '',
        stockList: this.data?.stockList ?? [],
        stock: '',
        description: this.data?.description ?? '',
        referIndex,
      },
      config: {
        indexId: {
          type: 'select',
          label: '类型',
          options: this.$store.state.baseData.strategyIndexList,
          filter: {
            type: 1 
          },
          valueKey: 'id',
          labelKey: 'indexName',
          rule: [
            { required: true }
          ]
        },
        indexValueId: {
          type: 'select',
          label: '子类',
          options: this.$store.state.baseData.strategyIndexValueList,
          filter: () => {
            return {
              indexId: this.form.indexId
            }
          },
          valueKey: 'id',
          labelKey: 'displayName',
          rule: [
            { required: true }
          ]
        },
        plateId: {
          type: 'select-plate',
          label: '板块',
          rule: [
            { required: true }
          ]
        },
        stockList: {
          label: '已选股票',
          rule: [
            { required: true, message: '请选择股票', type: 'array' }
          ]
        },
        stock: {
          type: 'select-stock',
          label: '个股',
          format: '{code}#{type}#{name}',
          change: this.addStock
        },
        description: {
          type: 'textarea',
          label: '介绍',
          rule: [
            { required: true }
          ]
        },
        referIndex: {
          label: '涉及指标',
        }
      }
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  methods: {
    close() {
      this.$emit('update:show', false)
    },
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/strategy/set_strategy_stock.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          plateId: Number(this.form.plateId.split('.')[0]),
          plateName: this.form.plateId.split('.')[1],
          indexValueId: this.form.indexValueId,
          stockList: this.form.stockList.map(e => {
            return {
              stockId: e.stockId,
              stockName: e.stockName,
              marketType: e.marketType
            }
          }),
          description: this.form.description,
          referIndex: this.form.referIndex.filter(e => e.id).map(e => `${e.id}|${e.pid}|${e.name}`).join(',')
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    addStock() {
      if(!this.form.stock) return

      let s = this.form.stock.split('#')
      this.form.stockList.push({
        stockId: s[0],
        stockName: s[2],
        marketType: Number(s[1]),
      })

      this.form.stock = ''
      this.$refs.form.check()
    },
    deleteStock(item) {
      this.form.stockList.splice(this.form.stockList.indexOf(item), 1)
    }
  },
}
</script>

<style scoped lang="scss">
.popover {
  .el-tag {
    margin-right: 8px;
    margin-bottom: 8px;
  }
  .index-select {
    width: 120px;
    margin-right: 8px;
    /deep/ {
      .el-input { width: 120px; }
    }
  }
}
</style>
