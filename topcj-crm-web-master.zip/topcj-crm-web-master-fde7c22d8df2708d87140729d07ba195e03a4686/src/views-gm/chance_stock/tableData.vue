<template>
  <el-table-pro
    :head="head"
    :data="data"
    @selection-change="$emit('update:select-list', $event)"
  >
  
    <template #body-operation="{ row }">
      <el-button
        type="text"
        size="small"
        icon="el-icon-edit"
        @click="$emit('edit', row)"
      >编辑</el-button>
    </template>

  </el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'ctime',
          label: '添加时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'indexName',
          label: '类型',
          minWidth: 56,
        },
        {
          key: 'displayName',
          label: '子类',
          minWidth: 56
        },
        {
          key: 'plateName',
          label: '板块',
          minWidth: 80
        },
        {
          key: 'stockList',
          label: '涉及个股',
          minWidth: 200,
          format: e => e.map(e => e.stockName).join('，')
        },
        {
          key: 'description',
          label: '介绍',
          minWidth: 200,
          tooltip: true
        },
        {
          key: 'status',
          label: '状态',
          minWidth: 42,
          format: {
            '0' : '待审核',
            '1' : '已通过',
            '2' : '未通过',
          }
        },
        {
          key: 'operation',
          label: '操作',
          width: 44
        }
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>