<template>
  <!-- <div>
    <el-table-pro
      :head="head"
      :data="data"
      row-key="id"
      highlight-current-row
      :current-row-key="corpData.corpId"
      border
    ></el-table-pro>
  </div> -->
  
  <div 
    :style="{ '--length': listData.length + 1}"
    class="content" :class="{contentCorp:$store.state.managerInfo.corpId}">
    <ul class="head_tr" :class="{sectionShow:$store.state.managerInfo.corpId}">
      <li><span>监控数据</span></li>
      <li v-for="(e) in listData" :key="e.id"><span>{{e.corpName}}</span></li>
      <li><span>操作</span></li>
    </ul>
    <div v-if="listData.length" class="scroll">
      <el-scrollbar>
        <transition-group  name="list" tag="div">
          <ul v-for="(e,index) in itemList" :key="e.value" class="info_tr head_tr"  :class="{sectionShow:$store.state.managerInfo.corpId}">
            <li><span>{{e.label}}</span><span :title="e.title" class="explanation"></span></li>
            <!-- <li v-for="i in listData" :key="i.id"><span>{{i[e.value]}}</span></li> -->
            <li :class="colorClass(i[e.value],e.value)" v-for="i in listData" :key="i.id"><span v-if="i[e.value]===null">未对接</span><span v-else>{{i[e.value] ? '已更新 '+i[e.value] :'未更新'}}</span></li>
            <li class="modify"><span class="xfontImg" v-if="index!=0" @click="moveUp(index)">上移</span><span v-if="index!=itemList.length-1"  @click="moveDown(index)"  class="deleteImg">下移</span></li>
          </ul>
        </transition-group>
      </el-scrollbar>
    </div>
    <ul v-if="listData.length" class="head_tr" :class="{sectionShow:$store.state.managerInfo.corpId}">
      <li><span>数据缺失总计</span></li>
      <li v-for="(e,index) in allAdds" :key="index"><span>{{e}}</span></li>
      <li><span></span></li>
    </ul>
  </div>
</template>
<script>
export default {
  data(){
    return{
      listData: [],
      itemList:[
        {
          value:'corpName',
          label:'监控数据',
          title:''
        },
        {
          value:'resources',
          label:'资源入库数量',
          title:'每日正常入库资源数量'
        },
        {
          value:'workUsers',
          label:'工作台用户数',
          title:'通过工作台发送消息的用户数'
        },
        {
          value:'workMsg',
          label:'工作台留痕数',
          title:'通过工作台发送消息的消息数'
        },
        {
          value:'chatRoom',
          label:'建群留痕数量',
          title:'建群留痕的聊天记录条数'
        },
        {
          value:'externalUsers',
          label:'外联用户数量',
          title:'统计各分公司当日添加的外部联系人数量'
        },
        {
          value:'externalMsg',
          label:'外联留痕数量',
          title:'通过外部联系人有新增的留痕记录条数'
        },
        {
          value:'exclusiveUsers',
          label:'专属号添加数',
          title:'有添加专属号的成交用户数量'
        },
        {
          value:'loggedUsers',
          label:'产品登录数量',
          title:'统计为有登录记录的用户数量'
        },
        {
          value:'service',
          label:'服务覆盖数量',
          title:'售后与成交用户沟通记录的用户数量'
        },
        {
          value:'archivists',
          label:'用户建档数量',
          title:'有新增过滤通过且提交档案成功的订单数量'
        },
        {
          value:'loggedSales',
          label:'销售后台登录',
          title:'登录顶点通的业务人数'
        },
        {
          value:'loggedService',
          label:'售后后台登录',
          title:'登录顶点通的售后人数'
        },
      ],
      nowTime:null,
    }
  },
  props:{
    timer:String
  },
  created(){
    this.getList()
    this.nowTime = new Date().getHours()
  },
  computed:{
    colorClass(){
      // return ''
      return (value,key)=>{
        if(value === null){
          //null 白色 未对接
          return
        }else if(value){
          //有值 绿色 已跟新
          return 'green'
        }else if(value == 0){
          //0 黄色 未更新
          
          //key == resources  23点警戒点 key==loggedSales||loggedService 14点警戒 其他17点警戒
          // 警戒点变红色
          if(key == 'resources'){
            return this.nowTime>=23 ? 'red' : 'yellow'
          }else if(key == 'loggedSales'||key == 'loggedService' ){
            return this.nowTime>=14 ? 'red' : 'yellow'
          }else{
            this.nowTime>=17 ? 'red' :'yellow'
          }
          // return yellow
        }
      }
      // {green:i[e.value]}
    },
    allAdds(){
      let num = null
      let res = []
      this.listData.map(item=>{
        //公司
        this.itemList.map(e=>{
          if(item[e.value]===0){
            num++
          }
        })
        res.push(num)
        num = null
      })
      return res
    },
  },
  methods:{
    moveUp(index){
      let temp
      temp = this.itemList[index]
      this.$set(this.itemList, index, this.itemList[index-1])
      this.$set(this.itemList, index - 1, temp)
    },
    moveDown(index){
      let temp
      temp = this.itemList[index]
      this.$set(this.itemList, index, this.itemList[index+1])
      this.$set(this.itemList, index + 1, temp)
    },
    async getList(){
      let { result } = await this.$http({
        url:'%CRM%/report/get_core_data.sdcrm',
        data:{
          token:true,
          ctime:this.timer ? new Date(this.timer).getTime() : undefined
        }
      })
      let list = result.filter(e=>
        e.corpId == this.$store.state.managerInfo.corpId
      )
      this.itemList = list
      
      // this.itemList.forEach(item=>{
      //   list.forEach(e=>{
      //     [item.label] = e[item.value]
      //   })
      //   this.listData.push
      // })
    }
  },
}
</script>
<style lang="scss" scoped>

</style>