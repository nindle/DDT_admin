<template>
  <div>
    <p v-if="headDataList.length" style="box-sizing: border-box;padding: 20px 28px;">
      {{headDataList.corpId | fifteType(corpIdList,'id','corpName')}}
      分公司扣除总金额：{{headDataList.balance}},其中不结算总金额：{{headDataList.balanceDeny}}
      缓结算总金额{{headDataList.balancePostpone}},
      保证金为{{headDataList.balanceRemind}};
    </p>
    <p v-else  style="box-sizing: border-box;padding: 20px 28px;">
      暂无缓结算信息
    </p>
  </div>
</template>
<script>
export default {
  data(){
    return{
      headDataList:[]
    }
  },
  created(){
    this.get_headList()
  },
  filters:{
    //等于的是谁 返回的是谁
    fifteType(type,list,equalKey,retKey){
      for(var i=0;i<list.length;i++){
        let e = list[i]
        if(type === e[equalKey]){
          return e[retKey]
        }
      }
      return ''
    },
  },
  computed:{
    corpIdList(){
      return this.$store.state.baseData.corpList
    }
  },
  methods:{
    async get_headList(){
      let { result } = await this.$http({
        url:'%CRM%/conformance/get_conformance_balance_corp.sdcrm',
        data:{
          token:true,
          corpId:this.$store.state.managerinfo.corpId,
          cdate:this.timer ? new Date(this.timer).getTime() : undefined
        }
      })
      this.headDataList = result
    },
  }
}
</script>