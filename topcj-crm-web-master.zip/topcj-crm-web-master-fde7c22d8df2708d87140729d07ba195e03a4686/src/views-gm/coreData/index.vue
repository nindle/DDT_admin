<template>
  <div class="appgroup">
    <div class="main_content">
      
      <el-layout-pro
        class="box"
        @page-change="getTableData()"
      >
        <!--筛选模块-->
        <template #screen>
          <el-screen-pro
            :model="screen"
            :config="config"
          ></el-screen-pro>
        </template>

      </el-layout-pro>

      <div v-if="$store.state.managerInfo.corpId">
        <CorpDataTop/>
      </div>
      <div v-else class="font">
        <DataHead
          v-if="false"
          :cdate='screen.time'
        />
      </div>
      <div class="table">
        <table-data/>
      </div>
    </div>
  </div>
</template>

<script>
import DataHead from './dataTop'
import CorpDataTop from './corpTopdata'
import tableData from './table'
export default {
  name: 'gm-coreData',
  data () {
    return {
      screen: {
        time: new Date().getTime()
      },
      config:{
        time: { type:'datatime'},
        split: { type: 'split' },
        excel: {
          type: 'button',
          label: '查看详情',
          click: () => { this.$router.push({name:'CoredataDetailed'}) }
        }
      },
    }
  },
  components:{
    DataHead,
    CorpDataTop,
    tableData,
  },
}
</script>

<style scoped lang="scss">
@import "../../assets/css/common.scss";
.appgroup {
  background: #F0F2F5;
  flex: 1;
  height: 100%;
  font-size: 14px;
  display: flex;
  padding: 24px;
  box-sizing: border-box;
  padding: 24px;
  left: 0;right:0;
  .explanation::after{
    text-align: center;
    line-height: 16px;
    position: relative;
    left: 6px;
    top: 1px;
    content: "?";
    display: inline-block;
    cursor: pointer;
    width: 16px;
    height: 16px;
    color: #ffffff;
    background: #CC0000;
    // border: 1px solid #3089FF;
    border-radius: 50%;
    font-style: normal;
    font-weight: 600;
  }
  .pageList{
        margin: 40px auto;
  }
  .red{
    background-color: rgba($color: #F54346, $alpha: .1);
    color: #F54346;
    font-weight: 600;
  }
  .green{
    background-color: rgba($color: #14BB71, $alpha: .1);
    color: #000;
  }
  
  .yellow{
    background-color: rgba($color: #F69804, $alpha: .1);
    color: #000;
  }
}
.select_top{
  display: flex;
  justify-content:left;
  .add_btn{
    width: 78px;
    height: 32px;
    cursor: pointer;
    text-align: center;
    line-height: 32px;
    background:rgba(48,137,255,1);
    border-radius:4px;
    color: white;
  }
  .topItem{
    margin: 0 0 0 20px;
    line-height: 32px;
    
    >>> {
    .el-select{
      width: 136px;
      height: 32px;
      margin-right: 8px;
      .el-input--suffix .el-input__inner{
        padding: 0 5px;
        border: 1px solid rgba(#000,.15);
        height: 32px;
      }
    }
    .el-input__icon{
      line-height: 26px;
    }
  }
  }
  .ipt{
      width: 252px;
      height: 32px;
      box-sizing: border-box;
      margin-left: auto;
      position: relative;
      .close{
          position: absolute;
          right: 5px;
          top: 8px;
          width: 17px;
          height: 17px;
          font-size: 18px;
          text-align: center;
          line-height: 15px;
          border-radius: 50%;
          cursor: pointer;
          transform: rotate(45deg);
          background: #DBD9D8;
          color: #999;
      }
       &::before{
          content:"";
          position: absolute;
          left: 12px;
          top: 9px;
          width: 14px;
          height: 14px;
          @include image(search_icon)
        }
      input{
        width: 100%;
        height: 100%;
        border: 1px solid rgba(0,0,0,0.15);
        border-radius: 4px;
        line-height: 30px;
        font-size: 14px;
        &::placeholder{color: #999};
        padding:  0 34px;
        box-sizing: border-box;
       
      }
    }

}

.main_content{
  width: 100%;
  background:rgba(255,255,255,1);
  padding: 24px 32px;
  box-sizing: border-box;
}

.allShow{
  
}
.head_tr{
  box-sizing: border-box;
  border: 1px solid transparent;
  border-bottom: 1px solid rgba(233,233,233,1);
  width: 100%;
  line-height: 54px;
  background:rgba(0,0,0,0.02);
  border-radius:4px 4px 0px 0px;
  color: black;
  font-size: 14px;
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  // padding-left: 24px;
  // padding-right: 24px;
  >li{
    text-align: center;
    border-right: 1px solid rgba(233,233,233,1);
    &:nth-child(1){
      border-left: 1px solid rgba(233,233,233,1);
    }
    width: calc((100% - 80px)/ var(--length));
    &:nth-child(10){
      width: 80px;
    }
  }
}
.sectionShow{
  >li{
    &:nth-child(-n+9){
      width: 100%;
    }
  }
}
li{
  display: block;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.content{
  // margin-top: 24px;
  height: calc(100% - 298px);
  .scroll{
    height: calc(100% - 53px);
    .list-move{
      transition: transform 0.5s;
    }
  }
  .scroll ul:hover {
    border: 1px solid #3288FF;
    background: rgba(48,137,255,0.12);
  }
}
.contentCorp{
  height: calc(100% - 162px);
}
.info_tr{
  background: white;
  .imgLi{
    position: relative;
    cursor: pointer;
    .imglist{
      width: 100%;
      height: 100%;
      opacity: 0;
      position: absolute;
      left: 0;
      top: 0;
    }
  }

  .modify{
    cursor: pointer;
    display: flex;
    justify-content:center;
    .xfontImg{
      width: 40px;
      height: 50px;
    }
    .deleteImg{
      width: 40px;
      height: 50px;
    }
    span{
      color: #3089FF;
      margin-left: 3px;
    }
  }
  
}
>>> .el-input__icon { line-height: 32px;}
</style>
