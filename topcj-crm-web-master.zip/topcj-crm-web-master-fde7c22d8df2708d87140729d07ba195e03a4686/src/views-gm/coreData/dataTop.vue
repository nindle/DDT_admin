<template>
  <el-scrollbar class="tableScrollBox">
    <div class="headData">
      <div>
        <p>总共扣除金额</p>
        <div>
          <span class="compTitle">{{coMbalance ? number.format(coMbalance.toFixed(2)) : '--'}}</span>
          <!-- <img src="../../assets/images/datatopimg.png" alt=""> -->
        </div>
        <div>
          <span>不结算</span>
          <span>缓结算</span>
          <span>保证金</span>
        </div>
        <div>
          <span class="newfont">{{number.format(coMbalanceDeny)}}</span>
          <span class="newfont">{{number.format(coMbalancePostpone)}}</span>
          <span class="newfont">{{coMbalanceRemind ? number.format(coMbalanceRemind.toFixed(2)) :'--'}}</span>
        </div>
      </div>
      <div v-for="(e,index) in headCompanyList" :key="index">
        <p>{{e.corpName+'扣除总金额'}}</p>
        <div>
          <span  class="compTitle">{{e.balance ? number.format((e.balance).toFixed(2)) :'--'}}</span>
          <!-- <div class="imgBox"></div> -->
        </div>
        <div>
          <span>不结算</span>
          <span>缓结算</span>
          <span>保证金</span>
        </div>
        <div>
          <span class="newfont">{{number.format(e.balanceDeny)}}</span>
          <span class="newfont">{{number.format(e.balancePostpone)}}</span>
          <span class="newfont">{{e.balanceRemind ? number.format(e.balanceRemind.toFixed(2)) :'--'}}</span>
        </div>
      </div>
    </div>
    </el-scrollbar>
</template>
<script>
import { deepcopy } from '../../assets/js/tool'
export default {
  props:['cdate'],
  data(){
    return{
      headDataList:[],
      number: new Intl.NumberFormat('en')
    }
  },
  created(){
    this.get_list()
  },
  computed:{
    headCompanyList(){
      let list = deepcopy(this.$store.state.baseData.corpList)
      let score = deepcopy(this.headDataList)
      let data = []
      data = list.map(e=>{
        score.map(i=>{
          if(i.corpId === e.id){
            e = {...e,...i}
            return{
              e
            }
          }
        })
        return e
      })
      let headDataList = data
      let a = headDataList.filter(e=>!e.corpId)[0]
      let b = headDataList.filter(e=>e.corpId)
      data = b
      data.push(a)
      return data
    },
    coMbalance(){
      let res = null
      for(var i in this.headCompanyList){
        let e = this.headCompanyList[i]
        if(e.balance){
          res += e.balance
        }
      }
      return res
    },
    coMbalanceDeny(){
      let res = null
      for(var i in this.headCompanyList){
        let e = this.headCompanyList[i]
        if(e.balanceDeny){
          res += e.balanceDeny
        }
      }
      return res
    },
    coMbalancePostpone(){
      let res = null
      for(var i in this.headCompanyList){
        let e = this.headCompanyList[i]
        if(e.balancePostpone){
          res += e.balancePostpone
        }
      }
      return res
    },
    coMbalanceRemind(){
      let res = null
      for(var i in this.headCompanyList){
        let e = this.headCompanyList[i]
        if(e.balanceRemind){
          res += e.balanceRemind
        }
      }
      return res
    }
  },
  watch:{
    cdate(){
      this.get_list()
    }
  },
  methods:{
    async get_list(){
      let { result } = await this.$http({
        url:'%CRM%/conformance/get_conformance_balance_corp.sdcrm',
        data:{
          token:true,
          corpId:this.$store.state.managerInfo.corpId ? this.$store.state.managerInfo.corpId :undefined,
          cdate:this.cdate ? new Date(this.cdate).getTime() : new Date().getTime()
        }
      })
      this.headDataList = result
    }
  },
}
</script>
<style lang="scss" scoped>
@font-face {
  font-family: din_bold;
  src: url('../../assets/font/DIN-Bold.ttf') /* Safari, Android, iOS */
}
@font-face {
  font-family: din_regular;
  src: url('../../assets/font/DIN-Regular.otf') /* Safari, Android, iOS */
}
.tableScrollBox{
  margin-top: 24px;
  margin-bottom: 16px;
}
.headData{
  width: 2218px;
  // margin-top: 24px;
  height: 180px;
  display: flex;
  justify-content: left;
  padding-top: 4px;
  padding-left: 4px;
  >div{
    box-sizing: border-box;
    height: 162px;
    box-shadow:0px 2px 4px 0px rgba(0,18,41,0.12);
    border-radius:2px;
    box-sizing: border-box;
    padding: 24px;
    p{
      color:rgba(0,0,0,0.45);
      font-size: 14px;
      font-weight: 400;
      line-height: 22px;
    }
    >div{
      display: flex;
      justify-content: space-between;
      >span{
        color:rgba(0,0,0,0.45);
        font-size: 13px;
      }
      >.compTitle{
        font-size: 36px;
        color: #3089FF;
        font-weight: 500;
        line-height: 70px;
        font-family: din_bold;
      }
      >.newfont{
        font-family: din_regular;
        color: #333333;
        // letter-spacing: 0px;
        // font-weight: bold;
        font-size: 14px;
      }
    }
    
  }
  >div:nth-child(1){
    width: 340px;
    img{
      width: 73px;
      height: 71px;
      position: relative;
      top: -10px;
    }
  }
  >div:nth-child(n+2){
    margin-left: 24px;
    width: 288px;
    .imgBox{
      display: block;
      margin-top: 10px;
      width: 48px;
      height: 48px;
      border-radius: 50%;
      
    }
  }
  >div:nth-child(2){
    .imgBox{
      background:rgba(254,86,183,0.08);
      background-image: url("../../assets/images/datacenter_Data_5.png");
      background-repeat:no-repeat;
      background-position:center;
    }
  }
  >div:nth-child(3){
    .imgBox{
      background:rgba(48,137,255,0.08);
      background-image: url("../../assets/images/datacenter_Data_1.png");
      background-repeat:no-repeat;
      background-position:center;
      
    }
  }
  >div:nth-child(4){
    .imgBox{
      background:rgba(23,217,229,0.08);
      background-image: url("../../assets/images/datacenter_Data_2.png");
      background-repeat:no-repeat;
      background-position:center;
    }
  }
  >div:nth-child(5){
    .imgBox{
      background:rgba(245,127,49,0.08);
      background-image: url("../../assets/images/datacenter_Data_3.png");
      background-repeat:no-repeat;
      background-position:center;
    }
  }
  >div:nth-child(6){
    .imgBox{
      background:rgba(186,59,255,0.08);
      background-image: url("../../assets/images/datacenter_Data_4.png");
      background-repeat:no-repeat;
      background-position:center;
    }
  }
  >div:nth-child(7){
    .imgBox{
      background:rgba(254,86,183,0.08);
      background-image: url("../../assets/images/datacenter_Data_5.png");
      background-repeat:no-repeat;
      background-position:center;
    }
  }
  >div:nth-child(8){
    .imgBox{
      background:rgba(48,137,255,0.08);
      background-image: url("../../assets/images/datacenter_Data_1.png");
      background-repeat:no-repeat;
      background-position:center;
    }
  }
}
</style>