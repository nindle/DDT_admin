<template>
  <div class="view">
    <el-layout-pro 
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
    
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
        />
      </template>

    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'

export default {
  name:'gm-filing_review',
  data() {
    return {
      //加载状态
      loading: false,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      //新增展示修改
      showPopover: false,
      //编辑数据修改
      rowData: null,
      //表格数据
      tableData: [],
      //筛选数据
      screen: {
        time: [],
        corpId: '',
        balanceId: '',
        keyword: ''
      },
      config: {
        corpId: {
          type: 'select-corp'
        },
        time: {
          type: 'date-range',
        },
        balanceId: {
          type: 'select',
          placeholder: '违规条件',
          options: [],
          valueKey: 'id',
          labelKey: 'remark'
        },
        split: { type: 'split' },
        keyword: {
          type: 'input',
          placeholder: '搜索ID',
          changeLog: true
        }
      },
    }
  },
  components: {
    TableData,
  },
  methods: { 
    //获取表格数据
    getTableData: throttle(async function(toFirst){
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }
      
      let { result } = await this.$http({
        url:'%CRM%/balance/get_balance_order_list.sdcrm',
        data: {
          token: true,
          corpId: typeof this.screen.corpId === 'number'? this.screen.corpId : undefined,
          balanceId: typeof this.screen.balanceId === 'number'? this.screen.balanceId: undefined,
          startBuyTime:this.screen.time?.[0],
          endBuyTime: this.screen.time?.[1],
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          keyword: this.screen.keyword
        }
      })

      this.tableData = result.records
      this.total = result.total

      this.loading = false
    }),
    async getBalance() {
      let { result } = await this.$http({
        url: '%CRM%/balance/get_balance_list.sdcrm',
        data: {
          token: true,
        }
      })
      this.config.balanceId.options = result
      this.balanceList = result
    },
  },
  created() {
    this.getBalance()
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>