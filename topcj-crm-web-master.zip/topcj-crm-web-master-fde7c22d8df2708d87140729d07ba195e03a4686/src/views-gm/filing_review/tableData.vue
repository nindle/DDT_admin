<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-num="{ row }">
      <span style="padding-right: 10px">{{row.num}}条</span>
      <el-popover
        placement="right"
        width="500"
        trigger="hover"
        @show="getRecordList(row)"
      >
        <el-table :data="gridData">
          <el-table-column width="200" property="ctime" label="违规时间"></el-table-column>
          <el-table-column width="300" property="remark" label="违规条件"></el-table-column>
        </el-table>
        <el-button 
          slot="reference"
          type="text"
          size="small"
          icon="el-icon-tickets"
        >查看</el-button>
      </el-popover>
    </template>
  
  </el-table-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      head: [
        {
          key: 'sn',
          label: '订单号',
          minWidth: 140,
        },
        {
          key: 'userId',
          label: '用户ID',
          minWidth: 70,
        },
        {
          key: 'corpName',
          label: '分公司',
          minWidth: 70,
        },
        {
          key: 'managerName,superviseName,serviceName,',
          label: '业务/合规/售后',
          minWidth: 140,
          format:(a,b,c) => { return `${a ? a : '-'}/${b ? b : '-'}/${c ? c : '-'}`}
        },
        {
          key: 'money',
          label: '金额',
          minWidth: 56,
        },
        {
          key: 'buyTime',
          label: '成交时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat('yyyy-MM-dd hh:mm:ss'),
        },
        {
          key: 'num',
          label: '违规类型',
          minWidth: 56,
        },
      ],
      gridData: []
    }
  },
  props: {
    data: Array
  },
  methods: {
    getRecordList: throttle(async function(row) {
      let { result } = await this.$http({
        url: '%CRM%/balance/get_balance_record_list.sdcrm',
        data: {
          token: true,
          orderId: row.orderId,
        }
      })
      this.gridData = result
    })
  },
}
</script>