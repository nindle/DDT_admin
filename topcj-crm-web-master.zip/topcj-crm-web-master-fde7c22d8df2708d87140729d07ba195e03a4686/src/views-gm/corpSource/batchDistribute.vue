<template>
  <el-dialog-pro @close="close">
    <template #title>分配资源</template>
    
    <el-form-pro
      :model="form"
      :config="config"
    >
      <template #span>
        您已选中{{data.length}}人，请选择要分配的员工
      </template>
    </el-form-pro>
    
    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      canManagerList:[],//我能选的员工
      loading: false,
      form: {
        span: '',
        id: ''
      },
      config: {
        span: {},
        id: {
          type: 'select',
          label: '',
          options: this.canManagerList,
          valueKey: 'id',
          labelKey: 'realName',
          placeholder: '请输入员工名称/员工工号',
          filterable: true
        }
      },
    }
  },
  props: {
    data: Array,
    show: Boolean
  },
  methods: {
    initManager(list){
      if(this.$store.state.managerInfo){
        list.forEach(item=>{
          if(item.managerList.length){
            this.canManagerList.push(...item.managerList)
          }
          if(item.groupChildren.length){
            this.initManager(item.groupChildren)
          }else{
            return 
          }
        })
      }else{
        this.canManagerList = this.$store.state.managerInfo
        return this.$store.state.managerInfo
      }
    },
    close() {
      this.$emit('update:show', false)
    },
    submit:throttle(async function() {
      this.loading = true
      let list = {}
      this.config.id.options.map(e => {
        if(this.form.id === e.id) {
          list = e
        }
      })

      let { code,msg,errmsg } = await this.$http({
        url: '%CRM%/res/res_batch_distribute.sdcrm',
        data: {
          token: true,
          managerId: list.id,//
          // attachType: list.managerType,
          // userIds: [list.id], 后面的

          // managerId: e.id,
              // attachType: e.managerType,
          userIds: this.data.map(item => item.userId)
        }
      })

      if(code === 8200) {
        this.$message.success('分配成功')
      } else {
        this.$message.error(msg || errmsg)
      }

      this.loading = false
      this.close()
      this.$emit('change')
    }),
  },
  created() {
    this.initManager(this.$store.state.baseData.authGroupTree)
    this.canManagerList = this.canManagerList.filter(item=>item.managerType === 2 && item.isLock === 0)
    this.canManagerList.forEach(item=>item.batchNum = null)
    this.config.id.options = this.canManagerList
  }
}
</script>