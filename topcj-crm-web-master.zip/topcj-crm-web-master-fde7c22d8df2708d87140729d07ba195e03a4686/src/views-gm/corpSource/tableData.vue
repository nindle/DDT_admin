<template>
  <el-table-pro
    :head="head"
    :data="data"
    ref="table"
    @selection-change="$emit('update:select-list', $event)"
  >
    <template #body-phone="{ row }"> 
      <callphone
        :user-id="row.userId"
        @call="$emit('select', row)"
      />
    </template>
    <template #body-remarkName="{ row }">
      <span>{{row.remarkName || row.nickname}}</span>
    </template>

    <template #body-sales="{ row }">
      {{row.salesName?row.salesName : "无"}}/{{row.superviseManagerName?row.superviseManagerName : "无"}}/{{row.serviceManagerName?row.serviceManagerName : "无"}}
    </template>
  </el-table-pro>
</template>
<script>
import Callphone from '../../components/other/callphone'
export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'userId',
          label: '用户ID',
          minWidth: 70,
          click: row => { this.$emit('select', row) }
        },
        {
          key: 'phone',
          label: '',
          width: 30,
          excel: false
        },
        {
          key: 'nickname',
          label: '用户昵称',
          minWidth: 100
        },
        {
          key:'corpId',
          label:'分公司',
          minWidth:80,
          format: {
            list: this.$store.state.baseData.corpList,
            key: 'id',
            value:'corpName'
          }
        },
        {
          key: 'remarkName',
          label: '资源备注',
          minWidth: 70
        },
        {
          key: 'adId',
          label: '页面ID',
          minWidth: 56
        },
        {
          key: 'resChannelId',
          label: '渠道',
          minWidth: 70,
          format:{
            list: this.$store.state.baseData.resChannelList,
            key: 'id',
            value: 'channelName'
          },
          default: ''
        },
        {
          key: 'resType',
          label: '来源',
          minWidth: 70,
          format:{
            list: this.$store.state.baseData.secTypeList,
            key: 'id',
            value: 'resName'
          },
          default: '',
          hide: () => !this.tag.v160.visible
        },
        {
          key: 'salesName',
          label: '归属人',
          minWidth: 70,
          hide: () => !this.tag.v159.visible
        },
        {
          key: 'lastCalltime',
          label: '上次联系时间',
          minWidth: 140,
          default: '--'
        },
        {
          key: 'getTime',
          label: '分配时间',
          minWidth: 140,
          default: '--'
        },
        {
          key: 'lastActivationTime',
          label: '激活时间',
          minWidth: 140,
          default: '--'
        },
        // {
        //   key: 'realname',
        //   label: '实际姓名',
        //   minWidth: 70,
        // },
        // {
        //   key: 'riskType',
        //   label: '风险测评',
        //   minWidth: 98,
        // },
        // {
        //   key: 'score',
        //   label: '风测分数',
        //   minWidth: 56,
        // }
      ],
    }
  },
  components: {
    Callphone
  },
  props: {
    data: Array
  },
  inject: ['tag'],
  methods: {
    riskFormat(type, score) {
      switch (type){
        case 0:
          return this.$store.getters ? score+'(保守型)' : 'C1'
        case 1:
          return this.$store.getters ? score+'(相对保守型)' : 'C2'
        case 2:
          return this.$store.getters ? score+'(稳健型)' : 'C3'
        case 3:
          return this.$store.getters ? score+'(相对积极型)' : 'C4'
        case 4:
          return this.$store.getters ? score+'(积极型)' : 'C5'
        default:
          return '未风测'
      }
    },
    setSelect(val) {
      this.$refs.table.setSelection(this.data.slice(0, val))
    }
  }
}
</script>