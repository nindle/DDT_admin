<template>
  <div class="top-box">
    <span> 筛选条件：</span>
    <el-screen-pro
      :model="screen"
      :config="config"
      @change="screenChange"
      
    ></el-screen-pro>
  </div>
</template>
<script>
export default {
  data() {
    return {
      screen: {
        resType: '',
        resChannel: '',
        // pay: '',
        attach: this.$store.state.managerInfo.isLeader ? `group/${this.$store.state.managerInfo.dataGroupId}` : `manager/${this.$store.state.managerInfo.id}`,
        showLock: false,
        time: [],
        activation: [],
        // callTime:[],
        keyword: '',
        discardType: '',
        stage: '',
        classify: '',
        status: '',
        // corpId:'',
        // inTime:'',
      },
      config: {
        resType: {
          type: 'select',
          options: this.$store.state.baseData.secTypeList.filter(e => e.showStatus),
          valueKey: 'id',
          labelKey: 'resName',
          placeholder: '资源类型'
        },
        resChannel: {
          type: 'select',
          options: this.$store.state.baseData.resChannelList,
          valueKey: 'id',
          labelKey: 'channelName',
          placeholder: '资源来源'
        },
        // pay: {
        //   type: 'select',
        //   options: [
        //     { value: 0, label: '所有购买用户' },
        //     { value: 7, label: '近7天购买' },
        //     { value: 15, label: '近15天购买' },
        //     { value: 30, label: '近30天购买' },
        //     { value: 60, label: '近60天购买' },
        //     { value: 90, label: '近90天购买' },
        //     { value: 180, label: '近180天购买' }
        //   ],
        //   placeholder: '购买状态'
        // },
        attach: {
          type: 'select-group-manager',
          placeholder: '组织架构',
          clearable: false,
          filter: () => {
            if(this.screen.showLock)  {
              return {
                managerType: this.$store.state.managerInfo.managerType
              }
            }
            return {
              isLock: 0,
              managerType: this.$store.state.managerInfo.managerType
            }
          }
        },
        showLock: {
          type: 'switch',
          activeValue: true,
          inactiveValue: false,
          activeText: '显示离职'
        },
        time: {
          type: 'date-range',
          placeholder: ['入库时间', '结束时间']
        },
        activation: {
          type: 'date-range',
          placeholder: ['激活时间', '结束时间']
        },
        keyword: {
          type: 'input',
          placeholder: '输入编号/昵称/备注/名称/手机号',
          changeLog: true
        },
        discardType: {
          type: 'select',
          options: [
            // { value:700, label:'有意向' },
            // { value:701, label:'无意向' },
            { value:702, label:'空号' },
            { value:703, label:'拒接' },
            { value:704, label:'同行' },
            { value:705, label:'未接' }
          ],
          placeholder: '资源类型'
        },
        stage: {
          type: 'select',
          options: [
            { value:800, label:'新入资源' },
            { value:801, label:'第一阶段' },
            { value:802, label:'第二阶段' },
            { value:803, label:'第三阶段' }
          ],
          placeholder: '用户进程'
        },
        classify: {
          type: 'select',
          options: [
            { value:900, label:"A" },
            { value:901, label:"B" },
            { value:902, label:"C" },
            { value:903, label:"D" }
          ],
          placeholder: '用户分类'
        },
        adId: {
          type: 'select',
          options: [],
          valueKey: 'id',
          labelKey: 'name',
          placeholder: '页面',
          filterable: true
        },
        status: {
          type: 'select',
          options: [
            { value:0, label:'已激活' },
            { value:1, label:'未激活' },
            { value:2, label:'冻结' },
            { value:3, label:'被合并' }
          ],
          placeholder: '激活状态'
        },
        // corpId: {
        //   type: 'select-corp'
        // },
        // callTime: {
        //   type: 'date-range',
        //   startPlaceholder:'最后拨打时间',
        //   // placeholder: '最后拨打时间'
        // },
        // inTime: {
        //   type: 'date-range',
        //   placeholder: '注册时间'
        // },
      }
    }
  },
  props: {
    screenList: Object
  },
  methods: {
    screenChange() {
      this.$emit('update:screenList',this.screen)
      this.$emit('change')
    },
    async getAdList() {
      let { result } = await this.$http({
        url:'%CRM%/ad/get_ad_search.sdcrm',
        data: {
          token: true,
          pageSize: 500,
          pageNum: 1,
          companyId: this.$store.state.managerInfo.corpId || undefined,
          pageId: 1
        }
      })

      this.config.adId.options.splice(0, this.config.adId.options.length, ...result.contents)
    }
  },
  created() {
    this.getAdList()
  }
}
</script>
<style lang="scss" scoped>
.top-box {
  display: flex;
  padding: 0 24px 12px;
  /deep/ {
    .screen {
      width: calc(100% - 85px);
      margin-top: 0px;
    }
  }
  span {
    padding: 12px 12px 0 0;
    font-size: 14px;
    line-height: 32px;
  }
}
</style>