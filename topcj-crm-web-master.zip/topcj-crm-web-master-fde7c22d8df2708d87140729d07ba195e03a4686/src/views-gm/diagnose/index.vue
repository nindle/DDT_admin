<template>
  <div class="view">
    <el-layout-pro 
      class="box-left"
      :loading="loading"
    >  
      <template #screen>
        <el-screen-pro
          :model="form"
          :config="config"
        ></el-screen-pro>
      </template>

      <template #scroll>
        <diagnose-detail
          v-if="diagnoseData"
          :key="diagnoseData.stockId"
          :data="diagnoseData"
          ref="detail"
        />
      </template>

    </el-layout-pro>
    <box-right 
      class="box-right" 
      ref="table"
    />
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import BoxRight from './boxRight'
import DiagnoseDetail from './diagnoseDetail'

export default {
  name: 'gm-diagnose',
  data() {
    return {
      loading: false,
      form: {
        scode: ''
      },
      config: {
        scode: {
          type: 'select-stock',
          change: this.getDiagnoseDetail
        },
        split: { type: 'split' },
        download: {
          type: 'button',
          label: '下载报备',
          buttonType: 'primary',
          click: this.download,
          hide: () => !this.diagnoseData
        }
      },
      diagnoseData: null
    }
  },
  components: {
    BoxRight,
    DiagnoseDetail
  },
  methods: {
    //获取股票诊股详情
    async getDiagnoseDetail() {
      if(!this.form.scode) {
        this.diagnoseData = null
        return
      }

      this.loading = true

      let data = await this.$http({
        mode: 'all',
        all: [
          {
            mode: 'get',
            url: '%TES%/product/tes',
            data: {
              stockid: this.form.scode,
              datatypes: 'extremediagnose,minsline',
              parammap: JSON.stringify({
                last: 1
              })
            }
          },
          {
            mode: 'get',
            url: '%TES%/product/extremediagnosedetail',
            data: {
              stockid: this.form.scode,
              userid: 0
            }
          },
          {
            mode: 'get',
            url: '%TES%/product/stockhotscore',
            data: {
              stockid: this.form.scode,
              count: 1
            }
          },
          {
            mode: 'get',
            url: '%TES%/product/diagnosedescription',
            data: {
              stockid: this.form.scode.split('.')[0],
              marketid: this.form.scode.split('.')[1]
            }
          }
        ]
      })

      this.loading = false

      let extremediagnose = data[0].tes[this.form.scode].extremediagnose[0]
      let minsline = data[0].tes[this.form.scode].minsline[0]
      let extremediagnosedetail = data[1].extremediagnosedetail
      let stockhotscore = data[2].stockhotscore[0]
      let diagnosedescription = data[3].diagnosedescription

      if(!extremediagnose) {
        this.diagnoseData = null
        this.$message.error('该股票暂无诊股详情！')
        return
      }

      let diagnoseData = {
        //时间
        time: Date.now(),
        //股票ID
        stockId: this.form.scode,
        //股票名称
        stockName: extremediagnose.scodename,
        //股票代码
        stockCode: extremediagnose.scode,
        //当前价
        atrade: extremediagnose.atrade,
        //涨跌额
        atradeChangeValue: extremediagnose.atradechangevalue,
        //涨跌幅
        atradeRate: extremediagnose.atraderate,
        //策略建议
        tips: extremediagnosedetail,
        //买卖指标
        remark: extremediagnose.diagnoseremark,
        //突破分值
        topScore: extremediagnose.topscore,
        //热点分值
        hotScore: stockhotscore.hotscore,
        //趋势分值
        trendScore: extremediagnose.trendscore,
      }

      //主力总买额
      diagnoseData.mainBuy = Math.round(Number(minsline.agencybamt) / 100) / 100
      //主力总卖额
      diagnoseData.mainSell = Math.round(Number(minsline.agencysamt) / 100) / 100
      //散户总买额
      diagnoseData.pubBuy = Math.round((Number(minsline.allbamt) - Number(minsline.agencybamt)) / 100) / 100
      //散户总卖额
      diagnoseData.pubSell = Math.round((Number(minsline.allsamt) - Number(minsline.agencysamt)) / 100) / 100

      //当前排名
      diagnoseData.topTrain = Number(diagnosedescription.topval[0].toptrain)
      //昨日排名
      diagnoseData.yTopTrain = Number(diagnosedescription.topval[0].ytoptrain)
      //当前分值
      diagnoseData.score = Number(diagnosedescription.topval[0].topscore)
      //昨日分值
      diagnoseData.yScore = Number(diagnosedescription.topval[0].ytopscore)
      //击败数量
      diagnoseData.scodeCnt = Number(diagnosedescription.topval[0].scodecnt) - diagnoseData.topTrain
      //强于上证指数
      diagnoseData.changeSH = Math.round(diagnosedescription.changesz[0].change * 10000) / 100
      //动态估值
      diagnoseData.dynamicval = Number(diagnosedescription.dynamicval[0].dy_val)

      this.diagnoseData = diagnoseData
    },
    download: throttle(async function() {
      let { code, errmsg, msg } = await this.$http({
        url:'%CRM%/stock_diagnose/set_manager_diagnose.sdcrm',
        data: {
          token:true,
          stockId: this.diagnoseData.stockId,
          stockName: this.diagnoseData.stockName,
          content: JSON.stringify(this.diagnoseData),
          ctime: this.diagnoseData.time
        }
      })

      if(code !== 8200) {
        this.$message.error(`下载失败：${errmsg || msg}`)
        return
      }

      this.$refs.detail.download()
      this.$refs.table.getTableData()

    })
  }
}
</script>

<style scoped lang="scss">
.view {
  padding: 24px;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  display: flex;
  flex-wrap: wrap;
  .box-left {
    width: 375px;
    height: 100%;
    background: #FFF;
    /deep/ {
      .screen-box { padding: 24px;}
    }
  }
  .box-right {
    width: calc(100% - 399px);
    height: 100%;
    background: #FFF;
    margin-left: 24px;
  }
}
</style>
