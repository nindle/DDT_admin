<template>
  <el-table-pro
    :head="head"
    :data="data"
  ></el-table-pro>  
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'stockName',
          label: '诊断股票',
          minWidth: 70
        },
        {
          key: 'ctime',
          label: '诊断时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'managerId',
          label: '诊断人',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.managerList,
            key: 'id',
            value: 'realName'
          }
        },
        {
          key: 'corpId',
          label: '归属公司',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.corpList,
            key: 'id',
            value: 'corpName'
          }
        },
        {
          key: 'download',
          label: '诊断结果',
          width: 70,
          button: {
            type: 'text',
            size: 'small',
            icon: 'el-icon-document',
            label: '诊股报告',
            click: (row) => { this.$emit('report', row) }
          }
        }
      ]
    }
  },
  props:{
    data: Array
  }
}
</script>