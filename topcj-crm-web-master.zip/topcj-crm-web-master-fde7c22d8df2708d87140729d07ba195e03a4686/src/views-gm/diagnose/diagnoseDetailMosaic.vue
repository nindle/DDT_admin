<template>
  <div 
    class="mosaic-box"
  >
    <div 
      class="mosaic"
      v-for="(e, i) in mosaic"
      :key="i"
      :style="e"
    ></div>
  </div>
</template>

<script>
import { random } from '../../assets/js/tool'

export default {
  data() {
    return {
      stop: false,
      mosaic: []
    }
  },
  props: {
    active: Boolean,
    height: Number
  },
  methods: {
    setMosaic() {
      this.mosaic = Array.from({length: 5}).map(() => {
        return {
          width: random(50, 100) + 'px',
          height: random(50, 100) + 'px',
          left: random(0, 325) + 'px',
          top: random(0, this.height - 50) + 'px'
        }
      })
      if(this._isDestroyed) return
      if(!this.active) return
      if(this.stop) return

      window.requestAnimationFrame(() => {
        this.setMosaic()
      })
    }
  },
  watch: {
    active: {
      immediate: true,
      handler() {
        if(this.active) {
          this.setMosaic()
        }
      }
    }
  },
  activated() {
    this.stop = false
    this.setMosaic()
  },
  deactivated() {
    this.stop = true
  }
}
</script>

<style lang="scss" scoped>
.mosaic-box {
  position: absolute;
  left: 0;
  top: 0;
  .mosaic {
    position: absolute;
    /* background: #FFF; */
    backdrop-filter: blur(2px);
  }
}

</style>