<template>
  <div 
    class="diagnose-detail"
    :style="{ height: height ? `${height}px` : 'auto' }"
    :class="{ 'is-downLoad': isDownLoad }"
  >
    <div 
      class="diagnose-detail-view"
      ref="detail"
    >
      <div class="top">
        <div class="stock">
          <div>{{data.stockName}}</div>
          <div>({{data.stockCode}})</div>
        </div>
        <div class="price">
          <div>{{data.atrade}}</div>
          <div>
            <span
              v-number.percent="data.atradeRate"
            ></span>
            <span
              v-number="data.atradeChangeValue"
            ></span>
          </div>
        </div>
      </div>
      <div class="content">
        <div class="title">综合评论</div>
        <div class="text">排名<span>{{data.topTrain}}</span>名,击败{{data.scodeCnt}}只股票,较昨日{{data.score >= data.yScore ? '上升' : '下降' }}<em v-number.nosign.nocolor="Math.abs(data.score - data.yScore)"></em>分,{{data.topTrain >= data.yTopTrain ? '上升' : '下降' }}{{Math.abs(data.topTrain - data.yTopTrain)}}名。在过去的20个交易日里该股票强于上证指数<em v-number.nosign.percent.nocolor="data.changeSH"></em>。最新主力资金流{{mainProfit > 0 ? '入' : '出'}}<em v-number.nosign.nocolor="Math.abs(mainProfit)"></em>万，处于动态估值{{data.dynamicval | dynamicval}}。</div>
      </div>
      <div class="content">
        <div class="title">买卖情况</div>
        <div 
          class="text"
          v-if="mainProfit > 0"
        >主力买入<em v-number.nocolor.nosign="data.mainBuy"></em>万，净买入<span v-number.nosign="mainProfit"></span>万；</div>
        <div 
          class="text"
          v-else
        >主力卖出<em v-number.nocolor.nosign="data.mainSell"></em>万，净卖出<span v-number.nosign="-mainProfit" :data-number-base="data.mainSell"></span>万；</div>
        <div 
          class="text"
          v-if="pubProfit > 0"
        >散户买入<em v-number.nocolor.nosign="data.pubBuy"></em>万，净买入<span v-number.nosign="pubProfit"></span>万；</div>
        <div 
          class="text"
          v-else
        >散户卖出<em v-number.nocolor.nosign="data.pubSell"></em>万，净卖出<span v-number.nosign="-pubProfit" :data-number-base="data.pubSell"></span>万；</div>
        <div class="text">{{mainProfit > 0 ? '咦' : '哎'}}，主力都在<span v-number.nonumber="mainProfit">{{mainProfit > 0 ? '买' : '卖'}}</span>！</div>
      </div>
      <div class="content">
        <div class="title">了解详情</div>
        <div 
          class="text"
          v-if="data.remark"
        >买卖指标处于<span>主升段</span></div>
        <div 
          class="text"
          v-else
        >不在买卖指标内</div>
      </div>
      <div class="content">
        <div class="title">策略建议</div>
        <div class="tips">{{data.tips}}</div>
      </div>
      <div class="content">
        <div class="title">80分值</div>
        <div class="score">
          <div>突破： <span v-number.nosign="data.topScore" :data-number-base="80" data-number-format="0."></span></div>
          <div>热点： <span v-number.nosign="data.hotScore" :data-number-base="80" data-number-format="0."></span></div>
          <div>趋势： <span v-number.nosign="data.trendScore" :data-number-base="80" data-number-format="0."></span></div>
        </div>
        <div class="line">
          <span :style="{ width: `${data.topScore}%` }"></span>
          <span :style="{ width: `${data.hotScore}%` }"></span>
          <span :style="{ width: `${data.trendScore}%` }"></span>
        </div>
        <div class="line-tips">
          <span>突破</span>
          <span>热点</span>
          <span>趋势</span>
        </div>
      </div>
      <div class="risk">诊断结果通过摇钱术运算模型加工客观数据而成，仅供参考，不构成绝对投资建议；投资有风险，入市需谨慎。</div>
      <div class="time">({{data.time | timeFormat('yyyy-MM-dd hh:mm')}})</div>
    </div>
    <mosaic 
      :active="!isDownLoad"
      :height="height"
    />
  </div>
</template>

<script>
import html2canvas from 'html2canvas'
import { throttle } from '../../assets/js/tool'
import Mosaic from './diagnoseDetailMosaic.vue'

export default {
  data() {
    return {
      height: 0,
      isDownLoad: false
    }
  },
  props: {
    data: Object
  },
  computed: {
    mainProfit() {
      return this.data.mainBuy - this.data.mainSell
    },
    pubProfit() {
      return this.data.pubBuy - this.data.pubSell
    }
  },
  filters: {
    dynamicval(type) {
      switch(type) {
        case 1: return '低估区上方'
        case 2: return '低估区下方'
        case 3: return '中位区中高位'
        case 4: return '中位区中位'
        case 5: return '中位区中低位'
        case 6: return '高估区上方'
        case 7: return '高估区下方'
        default: return '--'
      }
    }
  },
  components: {
    Mosaic
  },
  methods: {
    download: throttle(async function() {
      this.isDownLoad = true
      await this.$nextTick()

      let canvas = await html2canvas(this.$refs.detail)

      this.isDownLoad = false

      let aLink = document.createElement('a')
      aLink.href = canvas.toDataURL('image/png')
      aLink.download = this.data.stockName + '_' + this.data.stockCode + ' - ' + new Date(this.data.time).timeFormat('yyyy_MM_dd hh_mm') + '.png'
      aLink.click()
      aLink = null
    }),
  },
  mounted() {
    this.height = this.$refs.detail.getBoundingClientRect().height
  }
}
</script>

<style lang="scss" scoped>
.diagnose-detail {
  position: relative;
  width: 100%;
  overflow: hidden;

  &.is-downLoad {
    .diagnose-detail-view { transform: scale(1);}
    /deep/ {
      .mosaic { display: none;}
    }
  }
  .diagnose-detail-view {
    width: 750px;
    transform: scale(0.5);
    transform-origin: left top;
    background: #FFF;
  }
  .top {
    position: relative;
    width: 750px;
    height: 183px;
    background: linear-gradient(135deg, #707789 0%, #353E59 100%);
    display: flex;
    &::before {
      content: "";
      position: absolute;
      left: 50%;
      width: 1px;
      height: 60px;
      top: 62px;
      background: rgba(#FFF, .6);
    }
    > div { 
      display: flex;
      flex-direction: column;
      justify-content: center;
      width: 50%;
    }
    .stock {
      div:nth-child(1) {
        font-size: 40px;
        line-height: 56px;
        font-weight: bold;
        text-align: center;
        color: #FFF;
      }
      div:nth-child(2) {
        margin-top: 5px;
        font-size: 30px;
        line-height: 42px;
        text-align: center;
        color: #FFF;
      }
    }
    .price {
      padding-left: 54px;
      box-sizing: border-box;
      div:nth-child(1) {
        font-size: 32px;
        line-height: 56px;
        font-weight: bold;
        color: #FFF;
      }
      div:nth-child(2) {
        margin-top: 5px;
        font-size: 32px;
        line-height: 42px;
        font-weight: bold;
        color: #FFF;
        span { padding-right: 12px;}
        span:nth-child(2)::before { content: "("}
        span:nth-child(2)::after { content: ")"}
      }
    }
  }
  .content {
    width: 750px;
    padding: 0 40px;
    box-sizing: border-box;
    .title {
      padding-top: 30px;
      font-size: 30px;
      line-height: 42px;
      color: #333;
      font-weight: bold;
      padding-bottom: 5px;
    }
    .text {
      font-size: 26px;
      line-height: 37px;
      color: #313745;
      text-align: justify;
      span {
        font-size: 36px;
        color: #414C66;
        font-weight: bold;
        padding: 0 4px;
      }
      em { font-style: normal;}
    }
    .tips {
      font-size: 28px;
      color: #FFA500;
      font-weight: bold;
      line-height: 40px;
    }
    .score {
      display: flex;
      font-size: 28px;
      line-height: 40px;
      color: #666;
      div { width: 188px;}
    }
    .line {
      margin-top: 30px;
      width: 100%;
      height: 170px;
      border-left: 1px solid #979797;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      justify-content: space-around;
      padding: 10px 0;
      span {
        width: 0%;
        height: 30px;
        &:nth-child(1) { background: #FFA500;}
        &:nth-child(2) { background: #DE2C2C;}
        &:nth-child(3) { background: #F65014;}
      }
    }
    .line-tips {
      margin-top: 20px;
      display: flex;
      span {
        display: flex;
        align-items: center;
        color: #8C8C8C;
        font-size: 24px;
        line-height: 33px;
        width: 140px;
        &::before {
          content: "";
          width: 16px;
          height: 16px;
          margin-right: 10px;
          margin-left: 16px;
        }
        &:nth-child(1)::before { background: #FFA500;}
        &:nth-child(2)::before { background: #DE2C2C;}
        &:nth-child(3)::before { background: #F65014;}
      }
    }
  }
  .risk {
    font-size: 22px;
    line-height: 30px;
    color: #999;
    text-align: center;
    margin-top: 82px;
    padding: 0 40px;
  }
  .time {
    font-size: 24px;
    line-height: 33px;
    color: #434C64;
    text-align: center;
    margin-top: 5px;
    padding-bottom: 27px;
  }
}
</style>