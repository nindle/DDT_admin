<template>
  <el-dialog-pro 
    @close="close"
    max-height
    top="24px"
    width="415px"
  >
    <!--标题-->
    <template #title>
      {{data.stockName}}诊股报告
    </template>
    <!--内容-->
    <diagnose-detail
      v-if="diagnoseData"
      :data="diagnoseData"
      ref="detail"
    />
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="download"
      >下 载</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import DiagnoseDetail from './diagnoseDetail'

export default {
  data() {
    return {
      diagnoseData: null
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  components: {
    DiagnoseDetail
  },
  methods: {
    download() {
      this.$refs.detail.download()
    },
    close() {
      this.$emit('update:show', false)
    }
  },
  created() {
    this.diagnoseData = JSON.parse(this.data.content)
  }
}
</script>