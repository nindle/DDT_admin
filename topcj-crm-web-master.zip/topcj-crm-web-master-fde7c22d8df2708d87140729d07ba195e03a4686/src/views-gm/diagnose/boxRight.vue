<template>
  <el-layout-pro 
    class="box"
    :loading="loading"
    :total="total"
    :page-num.sync="pageNum"
    :page-size.sync="pageSize"
    @page-change="getTableData()"
  >  
    <!-- 筛选模块 -->
    <template #screen>
      <el-screen-pro 
        :config="config"
        :model="screen"
        @change="getTableData(true)"
      ></el-screen-pro>
    </template>
  
    <template #table>
      <table-data 
        :data="tableData"
        @report="openPopover"
      />
    </template>

    <template #popover>
      <popover
        v-if="showPopover"
        :show.sync="showPopover"
        :data="rowData"
      />
    </template>
  </el-layout-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableDataRight'
import Popover from './popover'

export default {
  data() {
    return {
      loading: false,
      //分页
      pageNum: 1,
      pageSize: 10,
      total: 0,

      screen: {
        time: null,
        corpId: '',
        managerId: '',
        stockId: ''
      },
      config: {
        corpId: {
          type: 'select-corp',
          change: () => {  
            this.screen.managerId = ''
          }
        },
        managerId: {
          type: 'select-manager',
          filter: () => {
            if(typeof this.screen.corpId === 'number') {
              return {
                corpId: this.screen.corpId
              }
            }

            return {}
          }
        },
        stockId: {
          type: 'select-stock'
        },
        time: {
          type: 'date-range',
        },
      },
      tableData: [],

      showPopover: false,
      rowData: null,
    }
  },
  components:{
    TableData,
    Popover
  },
  methods: {
    getTableData: throttle(async function(toFirst){
      this.loading = true

      if(toFirst){
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/stock_diagnose/get_manager_diagnose_list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          managerId: typeof this.screen.managerId === 'number' ? this.screen.managerId : undefined,
          stockId: this.screen.stockId || undefined
        }
      })

      this.loading = false
      this.tableData = result.records
      this.total = result.total
    }),
    openPopover(data) {
      this.showPopover = true
      this.rowData = data
    }
  }
}
</script>