<template>
  <el-table-pro
    :head="head"
    :data="data"
    @selection-change="$emit('update:select-list', $event)"
  >
    <template #body-fileUrl="{ row }">
      <template v-if="row.fileUrl">
        <el-button
          type="text"
          v-for="(e, i) in row.fileUrl.split(',')"
          :key="i"
          size="small"
          icon="el-icon-download"
          style="margin: 0 8px 0 0"
          @click="openImage(row.fileUrl, i)"
        >附件{{i + 1}}</el-button>
      </template>
    </template>

    <template #body-resultsFileUrl="{ row }">
      <template v-if="row.resultsFileUrl">
        <el-button
          type="text"
          v-for="(e,i) in row.resultsFileUrl.split(',')"
          :key="i"
          size="small"
          icon="el-icon-download"
          style="margin: 0 8px 0 0"
          @click="openImage(row.resultsFileUrl, i)"
        >附件{{i + 1}}</el-button>
      </template>
    </template>

    <template #body-userId="{ row }">
      <scratch
        :data="row.userId"
        mode="userId"
        copy
      />
    </template>

    <template #body-operation="{ row }">
      <el-button
        type="text"
        size="small"
        icon="el-icon-edit"
        @click="$emit('edit',row)"
      >编辑</el-button>
    </template>

    <template #body-visible="{ row }">
      <el-button
        type="text"
        size="small"
        @click="hideData(row)"
        icon="el-icon-view"
      >{{row.visible ? '隐藏' : '显示'}}</el-button>
    </template>
  </el-table-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import Scratch from '../../components/other/scratch'

export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14,
          excel: false
        },
        {
          key: 'id',
          label: '编号',
          minWidth: 28
        },
        {
          key: 'realName',
          label: '用户姓名',
          minWidth: 70,
          format: e => e ? e.substring(0, 1).padEnd(e.length, '*') : '--'
        },
        // {
        //   key: 'idNum',
        //   label: '是否实名',
        //   minWidth: 56,
        //   format: e => e ? '已实名' : '未实名'
        // },
        {
          key: 'ctime',
          label: '投诉时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '--'
        },
        // {
        //   key: 'managerName',
        //   label: '业务员',
        //   minWidth: 70,
        //   default: '--'
        // },
        // {
        //   key: 'servicerName',
        //   label: '售后',
        //   minWidth: 70,
        //   default: '--'
        // },
        {
          key: 'type',
          label: '投诉类型',
          minWidth: 56,
          format: {
            '1' : '内诉',
            '2' : '外诉'
          }
        },
        {
          key: 'packageName',
          label: '购买产品',
          minWidth: 120,
          default: '--'
        },
        {
          key: 'reason',
          label: '投诉原因',
          minWidth: 200,
          default: '--'
        },
        {
          key: 'complaintWay',
          label: '投诉通道',
          minWidth: 70,
          default: '--'
        },
        {
          key: 'refund',
          label: '退费金额',
          minWidth: 56,
          default: '--'
        },
        {
          key: 'money',
          label: '成交金额',
          minWidth: 56,
          default: '--'
        },
        {
          key: 'resultsName',
          label: '处理结果',
          minWidth: 70,
          default: '--'
        },
        {
          key: 'utime',
          label: '完结时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '--'
        },
        {
          key: 'fileUrl',
          label: '相关附件',
          minWidth: 200,
          default: '/'
        },
        // {
        //   key: 'resultsFileUrl',
        //   label: '维护附件',
        //   minWidth: 200,
        //   default: '/'
        // },
        {
          key: 'afterService',
          label: '处理人',
          minWidth: 70,
          default: '--'
        },
        {
          key: 'userId',
          label: '查询',
          minWidth: 70,
          copy: true
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          excel: false
        },
        // {
        //   key: 'visible',
        //   label: '',
        //   width: 44,
        //   excel: false
        // }
      ]
    }
  },
  props: {
    data: Array
  },
  components: {
    Scratch
  },
  methods: {
    //隐藏
    hideData: throttle(async function(row){
      let { code, errmsg, msg } = await this.$http({
        url:'%CRM%/complaint/set_complaint.sdcrm',
        data:{
          token: true,
          id: row.id,
          visible: row.visible ? 0 : 1
        }
      })
      if(code !== 8200) {
        this.$message.error(`操作失败：${errmsg || msg}`)
        return
      }

      this.$message.success('操作成功')
      row.visible = row.visible ? 0 : 1
    }),
    openImage(data, i) {
      let list = data.split(',')

      let reg = /\.(png|jpg|jpeg|gif|webp)/

      if(!reg.test(list[i])) {
        this.$open(list[i])
      } else {
        let imgList = list.filter(e => reg.test(e))
        this.$imageview({
          list: imgList,
          index: imgList.indexOf(list[i])
        })
      }

    }
  }
}
</script>