<template>
  <div class="view">
    <el-layout-pro 
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
    
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :select-list.sync="selectList"
          @edit="openPopover"
        />
      </template>

      <template #popover>
        <edit-data 
          v-if="showPopover"
          :show.sync="showPopover" 
          :data="rowData"
          @change="getTableData()"
        />

        <review 
          v-if="showReview"
          :show.sync="showReview"
          :review-list="reviewList"
          reason
          deduct
          source="aa"
          idKey="complianceId"
          corpKey="meta.corpId"
          @success="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'
import Review from '../../components/review/index'

export default {
  name: 'gm-complaint',
  data() {
    return {
      //加载状态
      loading: false,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      // 表格数据
      tableData: [],
      // 筛选
      screen: {
        corpId: '',
        timer: [],
        results: '',
        type: ''
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => {this.openPopover(null)}
        },
        type: {
          type: 'select',
          placeholder: '投诉类型',
          options: [
            { label: '内诉', value: 1 },
            { label: '外诉', value: 2 },
          ]
        },
        results: {
          type: 'select',
          placeholder: '处理结果',
          options: [
            { label: '待处理', value: 0 },
            { label: '正在处理', value: 1 },
            { label: '处理完结', value: 2 },
          ]
        },
        corpId: {
          type: 'select-corp'
        },
        timer: {
          type: 'date-range',
        },
        // reviewOnline: {
        //   type: 'button',
        //   buttonType: 'primary',
        //   label: '审核上线',
        //   click: () => { this.openReview(1) }
        // },
        // reviewOffline: {
        //   type: 'button',
        //   buttonType: 'primary',
        //   label: '审核下线',
        //   click: () => { this.openReview(2) }
        // },
        // split: {
        //   type: 'split'
        // },
        // excel:{
        //   type:'button',
        //   label:'导出Excel',
        //   click: () => { this.$copyExcel(this, this.nav.title) }
        // }
      },
      // 审核
      selectList: [],
      showReview: false,
      reviewList: [],
      // 弹窗显示
      showPopover: false,
      rowData: null
    }
  },
  props:{
    nav: Object,
    tag: Object
  },
  provide() {
    return {
      tag: this.tag
    }
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/complaint/get_complaint_search.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          corpId: this.screen.corpId,
          stime: this.screen.timer?.[0],
          etime: this.screen.timer?.[1],
          results: this.screen.results,
          type: this.screen.type
        }
      })
      this.loading = false
      this.tableData = result.records
      this.total = result.total
    }),
    openPopover(data) {
      this.showPopover = true,
      this.rowData = data
    },
    openReview(status) {
      this.reviewList = this.selectList.map(e => {
        return {
          url: '%CRM%/compliance/set_compliance_trial.sdcrm',
          data: {
            token: true,
            complianceId: e.id,
            reason: e.reason,
            status
          },
          meta: {
            corpId: e.createrId
          }
        }
      })

      this.showReview = true
    }
  },
  components: {
    TableData,
    EditData,
    Review
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>