<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      {{data ? '编辑' : '新增'}}投诉处理
    </template>
    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    let fileUrl = this.data?this.data.fileUrl && this.data.fileUrl.length ? this.data.fileUrl.split(',').map(e => {
      let l = e.split('/')
      return {
        name: l[l.length - 1],
        url: e
      }
    }) : [] : []

    //平均分配文件大小
    let aFileSize = Math.round((this.data?.fileSize ?? 0) / (fileUrl.length || 1))

    return {
      loading: false,
      form: {
        id:this.data?.id ?? '',
        fileUrl: fileUrl.map(e => {
          return {
            ...e,
            size: aFileSize
          }
        }),
        resultsFileUrl: this.data?this.data.resultsFileUrl && this.data.resultsFileUrl.length ? this.data.resultsFileUrl.split(',').map(e => {
          let l = e.split('/')
          return {
            name: l[l.length - 1],
            url: e
          }
        }) : [] : [],
        ctime: this.data?.ctime ? new Date(this.data.ctime).getTime() : Date.now(),
        utime: this.data?.utime ? new Date(this.data.utime).getTime() : '',
        userId: this.data?.userId ??'',
        realName: this.data?.realName ??'',
        managerName: this.data?.managerName ??'',
        servicerName: this.data?.servicerName ??'',
        type: this.data?.type ??'',
        packageName: this.data?.packageName ??'',
        reason: this.data?.reason ??'',
        money: this.data?.money ??'',
        refund: this.data?.refund ??'',
        results: this.data?.results ??'',
        resultsName: this.data?.resultsName ??'',
        complaintWay: this.data?.complaintWay ??'',
        corpId: this.data?.corpId ?? '',
        afterService: this.data?.afterService ?? '',
        degree: '',
        servise: '',
        userType: ''
      },
      config: {
        userId: {
          type: 'input',
          label: '投诉ID'
        },
        realName: {
          type: 'input',
          label: '用户姓名'
        },
        complaintWay: {
          type: 'input',
          label: '投诉通道'
        },
        degree: {
          type: 'select',
          label: '投诉程度',
          options: this.tag.t6.filter(e => e.visible),
          labelKey: 'valueName',
          valueKey: 'id',
          hide: () => !this.form.userId
        },
        ctime: {
          type: 'date-time',
          label: '投诉时间',
          rule: [
            { required: true }
          ]
        },
        servise: {
          type: 'select',
          label: '服务情况',
          options: this.tag.t7.filter(e => e.visible),
          labelKey: 'valueName',
          valueKey: 'id',
          hide: () => !this.form.userId
        },
        userType: {
          type: 'select',
          label: '用户类型',
          options: this.tag.t8.filter(e => e.visible),
          labelKey: 'valueName',
          valueKey: 'id',
          hide: () => !this.form.userId
        },
        managerName: {
          type: 'input',
          label: '业务归属'
        },
        servicerName: {
          type: 'input',
          label: '售后归属'
        },
        type: {
          type: 'select',
          label: '投诉类型',
          options: [
            {value: 1,label: '内诉'},
            {value: 2,label: '外诉'}
          ],
          rule: [
            { required: true }
          ]
        },
        packageName: {
          type: 'input',
          label: '购买产品'
        },
        reason: {
          type: 'textarea',
          label: '投诉原因'
        },
        money: {
          type: 'number',
          label: '成交金额'
        },
        refund: {
          type: 'number',
          label: '退费金额'
        },
        results: {
          type: 'select',
          label: '处置结果',
          options: [
            {value: 0,label: '等待处理'},
            {value: 1,label: '正在处理'},
            {value: 2,label: '处理完结'}
          ]
        },
        resultsName: {
          type: 'textarea',
          label: '处理结果'
        },
        afterService: {
          type: 'input',
          label: '处理人'
        },
        corpId: {
          type: 'select-corp',
          label: '分公司'
        },
        utime: {
          type: 'date-time',
          label: '完结时间'
        },
        fileUrl: {
          type: 'file-list',
          label: '附件'
        },
        resultsFileUrl: {
          type: 'file-list',
          label: '维护'
        }
      }     
    }
  },
  props: {
    data: Object,
    show: Boolean
  },
  inject: ['tag'],
  methods: {
    //初始化数据
    async initData() {
      let data = await this.$http({
        mode: 'all',
        all: [
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.userId,
              labelId: 6,
            }
          },
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.userId,
              labelId: 7,
            }
          },
          {
            url: '%CRM%/label/get_target_label_value.sdcrm',
            data: {
              token: true,
              targetId: this.data.userId,
              labelId: 8,
            }
          }
        ]
      })

      this.form.degree = data[0].result?.id
      this.form.servise = data[1].result?.id
      this.form.userType = data[2].result?.id
    },
    close() {
      this.$emit('update:show', false)
    },
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return
      this.loading = true

      if(this.form.userId) {
        let allData = [
          {
            url: `%CRM%/label/set_label.sdcrm`,
            data: {
              token: true,
              targetId: this.form.userId,
              labelId: 6,
              valueId: this.form.degree || undefined
            }
          },
          {
            url: `%CRM%/label/set_label.sdcrm`,
            data: {
              token: true,
              targetId: this.form.userId,
              labelId: 7,
              valueId: this.form.servise || undefined
            }
          },
          {
            url: `%CRM%/label/set_label.sdcrm`,
            data: {
              token: true,
              targetId: this.form.userId,
              labelId: 8,
              valueId: this.form.userType || undefined
            }
          }
        ]

        let data = await this.$http({
          mode: 'relay',
          all: allData
        })

        if(data.filter(e => e.code === 8200).length !== data.length) {
          this.$message.error('保存失败')
          return
        }
      }
      
      /*标签保存结束*/

      let { code,msg,errmsg } = await this.$http({
        url: '%CRM%/complaint/set_complaint.sdcrm',
        data: {
          token: true,
          id: this.data ? this.data.id : undefined,
          fileUrl: this.form.fileUrl.map(e => e.url).join(','),
          fileSize: this.form.fileUrl.reduce((pre, e) => pre + e.size, 0),
          ctime: this.form.ctime || undefined,
          utime: this.form.utime || undefined,
          realName: this.form.realName || undefined,
          userId: this.form.userId || undefined,
          managerName: this.form.managerName,
          servicerName: this.form.servicerName,
          type: this.form.type,
          packageName: this.form.packageName,
          reason: this.form.reason ,
          money: this.form.money ,
          refund: this.form.refund ,
          results: this.form.results ,
          resultsName: this.form.resultsName,
          complaintWay: this.form.complaintWay ? this.form.complaintWay : undefined,
          resultsFileUrl: this.form.resultsFileUrl.map(e => e.url).join(','),
          corpId: this.form.corpId,
          afterService: this.form.afterService
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      
      this.$emit('change')
      this.close()
    })
  },
  created() {
    if(this.data?.userId) {
      this.initData()
    }
  }
}
</script>