<template>
  <div class="view">
    <el-layout-pro 
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      page-algin="right"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
    <template #screen>
      <el-screen-pro
        :model="screen"
        :config="config"
        @change="getTableData(true)"
        :auto-change="false"
        ref="screen"
      ></el-screen-pro>
    </template>

    <template #table>
      <table-data 
        :data="tabledata"
        :bankList="bankList"
      />
    </template>
    </el-layout-pro>  
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
export default {
  name: 'gm-fina_abnormal',
  data() {
    return {
      //加载状态
      loading: false,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      //表格数据
      tabledata: [],
      bankList: [],
      // 筛选
      screen: {
        stime: [],
        corpId: '',
        keyword:'',
        buyStatus: '',
        days: '',
        money: []
      },
      config: {
        corpId: {
          placeholderInLabel: '事业部',
          placeholder: '请选择',
          type: 'select-corp'
        },
        buyStatus: {
          type: 'select',
          placeholderInLabel: '订单状态',
          options: [
            { label: '未购买', value: 0 },
            { label: '已购买', value: 1 },
            { label: '已退订金', value: 2 }
          ]
        },
        days: {
          type: 'select',
          placeholderInLabel: '已支付天数',
          options: [
            { value: 7, label: '7天以上'},
            { value: 15, label: '15天以上'},
            { value: 30, label: '30天以上'},
            { value: 60, label: '60天以上'},
          ]
        },
        stime: {
          type: 'date-range',
          placeholderInLabel: '付款日期',
        },
        split:{
          type:'split'
        },
        search: {
          type: 'button',
          buttonType: 'primary',
          label: '查询',
          click: () => {
            this.$refs.screen.emitModel()
            this.getTableData(true)
          }
        },
        reset: {
          type: 'button',
          label: '重置',
          click: () => {
            this.$refs.screen.resetModel()
          }
        },
        br: { type: 'br' },
        money: {
          type: 'number-range',
          placeholderInLabel: '金额',
        },
        br2: { type: 'br' },
        split2:{
          type:'split'
        },
        excel: {
          type: 'button',
          buttonType: 'primary',
          label: '导出Excel',
          click: throttle(async () => {
            let data = await this.$http({
              url: '%CRM%/offline/exp_offline_list_excel.sdcrm',
              data: {
                $set: {
                  responseType: 'blob'
                },
                token: true,
                corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
                buyStatus: typeof this.screen.buyStatus === 'number' ? this.screen.buyStatus : undefined,
                stime: this.screen.stime?.[0],
                etime: this.screen.stime?.[1],
                smoney: this.screen.money?.[0] === '' ? undefined : this.screen.money?.[0],
                emoney: this.screen.money?.[1] === '' ? undefined : this.screen.money?.[1],
                days: this.screen.days || undefined
              }
            })

            let url = URL.createObjectURL(data)
            let link = document.createElement('a')
            link.setAttribute('href', url)
            link.setAttribute('download', '异常退款' + ' - ' + new Date().timeFormat('yyyy_MM_dd hh_mm') + '.xlsx')
            link.style.display = 'none'
            document.body.appendChild(link)
            link.click()
            URL.revokeObjectURL(url)
            document.body.removeChild(link)
          }),
        }
      }
    }
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.$refs.screen.cancelModel()
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/offline/get_list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          buyStatus: typeof this.screen.buyStatus === 'number' ? this.screen.buyStatus : undefined,
          stime: this.screen.stime?.[0],
          etime: this.screen.stime?.[1],
          smoney: this.screen.money?.[0] === '' ? undefined : this.screen.money?.[0],
          emoney: this.screen.money?.[1] === '' ? undefined : this.screen.money?.[1],
          days: this.screen.days || undefined
        }
      })

      this.total = result.total
      this.tabledata = result.records

      this.loading = false
    }),
    async getBankList() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/setting/get_types/33.sdcrm',
        data: {
          token: true,
          corpId: this.$store.state.managerInfo.corpId || undefined
        }
      })

      this.bankList.splice(0, this.bankList.length, ...result)
    },
  },
  components: {
    TableData
  },
  created() {
    this.getBankList()
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>