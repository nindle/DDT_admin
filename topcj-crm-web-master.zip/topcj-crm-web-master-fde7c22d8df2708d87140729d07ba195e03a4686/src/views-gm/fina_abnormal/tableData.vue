<template>
  <el-table-pro
    :head="head"
    :data="data"
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'corpName',
          label: '事业部',
          minWidth: 70
        },
        {
          key: 'payTime',
          label: '付款时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat(),
          copy: true
        },
        {
          key: 'bankId',
          label: '账户',
          minWidth: 84,
          format: {
            list: this.bankList,
            key: 'typeId',
            value: 'typeName'
          }
        },
        {
          key: 'bankTradeNo',
          label: '流水号',
          minWidth: 240,
          copy: true
        },
        {
          key: 'money',
          label: '金额',
          minWidth: 56,
          align: 'right',
          copy: true
        },
        {
          key: 'block',
          label: '',
          minWidth: 56,
        },
        {
          key: 'days',
          label: '已支付天数',
          minWidth: 80
        },
        {
          key: 'buyStatus',
          label: '状态',
          minWidth: 80,
          format: {
            '0': '待购买',
            '1': '已购买',
            '2': '已全额退款',
            '3': '作废',
            '4': '已部分退款'
          }
        },
      ]
    }
  },
  props: {
    data: Array,
    bankList: Array,
  }
}
</script>