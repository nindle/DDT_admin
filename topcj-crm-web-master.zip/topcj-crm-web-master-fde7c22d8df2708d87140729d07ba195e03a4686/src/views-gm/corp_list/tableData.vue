<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-operation="{ row }">
      <el-button
        icon="el-icon-edit"
        type="text"
        size="small"
        @click="$emit('edit', row)"
      >编辑</el-button>
    </template>

    <template #body-delete="{ row }">
      <el-popconfirm
        title="确定删除吗？"
        @confirm="deleteData(row)"
      >
        <template #reference>
          <el-button
            type="text"
            size="small"
            icon="el-icon-delete"
          >删除</el-button>
        </template>
      </el-popconfirm>
    </template>
  </el-table-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: '编号',
          minWidth: 60
        },
        {
          key: 'corpName',
          label: '分公司',
          minWidth: 100
        },
        {
          key: 'ctime',
          label: '创建时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'status',
          label: '状态',
          minWidth: 28,
          format: e => e ? '有效' : '无效'
        },
        {
          key: 'sort',
          label: '排序',
          minWidth: 40,
        },
        {
          key: 'sysMode',
          label: '模式',
          minWidth: 28,
          format:{
            '1':'普通',
            '2':'合规'
          }
        },
        {
          key: 'rootGroupId',
          label: '分公司部门节点',
          minWidth: 120,
          format: {
            list: this.$store.state.baseData.groupList,
            value: 'groupName',
            key: 'id'
          }
        },
        {
          key: 'hotLine',
          label: '热线电话',
          minWidth: 120,
        },
        {
          key: 'resManagerId',
          label: '资源公海',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.managerList,
            value: 'realName',
            key: 'id'
          }
        },
        {
          key: 'operation',
          label: '操作',
          width: 44
        },
        {
          key: 'delete',
          width: 44
        }
      ]
    }
  },
  props: {
    data: Array
  },
  methods:{
    deleteData: throttle(async function(row) {
      let { code, errmsg, msg } = await this.$http({
        mode:'get',
        url: '%CRM%/corp/del/:id.sdcrm',
        data:{
          token:true,
          id: row.id
        },
      })
      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        return
      }
      this.$message.success(`删除成功`)
      this.$emit('change')
    }),
  }
}
</script>