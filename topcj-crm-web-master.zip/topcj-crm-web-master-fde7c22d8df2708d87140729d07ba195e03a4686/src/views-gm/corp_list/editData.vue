
<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      编辑分公司信息
    </template>
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        size="small"
        type="primary"
        @click="submit"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        corpName:this.data?.corpName ?? '',
        status: this.data?.status ?? 1,
        sort: this.data?.sort ?? 0,
        sysMode: this.data?.sysMode ?? '',
        rootGroupId: this.data?.rootGroupId ?? '',
        hotLine: this.data?.hotLine ?? '',
        resManagerId: this.data?.resManagerId ?? '',
        isCorp: this.data?.isCorp ?? 1
      },
      config: {
        corpName: {
          label: '分公司名称',
          rule: [
            { required: true }
          ]
        },
        status: {
          type:'switch',
          label: '状态',
          activeValue:1,
          inactiveValue:0,
        },
        isCorp: {
          type:'switch',
          label: '是否为分公司',
          activeValue:1,
          inactiveValue:0,
        },
        sort: {
          type: 'number',
          label: '排序',
          min: 0
        },
        sysMode: {
          type:'select',
          label: '模式',
          options: [
            { value: 1, label: '正常' },
            { value: 2, label: '合规' }
          ],
        },
        rootGroupId: {
          type: 'select-group',
          label: '部门根节点',
        },
        hotLine: {
          label: '热线电话'
        },
        resManagerId: {
          type: 'select-manager',
          label: '资源公海',
          filter: {
            corpId: this.data?.id
          }
        }
      },
    }
  },
  props: {
    show: Boolean,
    data: Object,
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      let { code, errmsg, msg } = await this.$http({
        url:'%CRM%/corp/save.sdcrm',
        data: {
          token:true,
          id:this.data?.id ?? -1,
          corpName:this.form.corpName,
          status: this.form.status,
          isCorp: this.form.isCorp,
          sort: this.form.sort,
          sysMode: this.form.sysMode ?? undefined,
          rootGroupId: this.form.rootGroupId ?? undefined,
          hotLine: this.form.hotLine ?? undefined,
          resManagerId: this.form.resManagerId ?? undefined,
        }
      })
      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>

