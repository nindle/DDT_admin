<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
    >
      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :config="config"
          @change="getTableData()"
        ></el-screen-pro>
      </template>
      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData" 
          @edit="openPopover"
          @change="getTableData()"
        />
      </template>
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          @change="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-corp_list',
  data() {
    return {
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      rowData: null,
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) }
        },
      }
    }
  },
  components:{
    TableData,
    EditData
  },
  methods:{
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    },
    getTableData: throttle(async function() {
      this.loading = true

      let { result } = await this.$http({
        url:'%CRM%/corp/list.sdcrm',
        data: {
          token: true
        }
      })

      this.tableData = result

      this.loading = false
    })
  }
}
</script>
<style scoped lang="scss">
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>