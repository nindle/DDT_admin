<template>
  <el-layout-pro
    class="box"
    :loading="loading"
    :total="total"
    :page-num.sync="pageNum"
    :page-size.sync="pageSize"
    @page-change="getTableData()"
    page-layout="total, sizes, prev, pager, next"
    page-small
  >
    <template #screen>
      <el-screen-pro
        :model="screen"
        :config="config"
        @change="getTableData()"
      >
        <template #upload>
          <el-popover
            width="200"
            trigger="click"
            placement="top"
            v-model="showUpdateMsg"
          >
            <el-select
              v-model="screen.pay"
              placeholder="请选择支付方式"
            >
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              > </el-option>
            </el-select>
            <div style="text-align: right; margin: 12px 0 0">
              <el-button
                size="mini"
                @click="showUpdateMsg = false"
              >取消</el-button>
              <el-button
                type="primary"
                size="mini"
                @click="uploadFn(screen.pay)"
              >确定</el-button>
            </div>
            <el-button
              slot="reference"
              size="small"
              type="primary"
            >上传</el-button>
          </el-popover>
        </template>
      </el-screen-pro>
    </template>

    <template #table>
      <table-data
        :data="tableData"
        :title="screen.type"
      />
    </template>
  </el-layout-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableDataRight'

export default {
  data () {
    return {
      //分页数据
      total: 0,
      pageNum: 1,
      pageSize: 10,
      // 上传选择状态
      showUpdateMsg: false,
      //获取数据
      tableData: [],
      //加载状态
      loading: false,
      // 筛选
      screen: {
        pay: '',
        type: 1,
        month: Date.now()
      },
      options: [
        { label: '支付宝', value: 1 },
        { label: '微信', value: 2 }
      ],
      //筛选
      config: {
        type: {
          type: 'select',
          placeholder: '账单',
          options: [
            { label: '缺录账单', value: 1 },
            { label: '错误账单', value: 2 }
          ],
          clearable: false
        },
        month: {
          type: 'date-month',
          placeholder: '月份查询',
          clearable: false
        },
        split: {
          type: 'split'
        },
        upload: {
          label: '上传',
          type: 'button'
        }
      }
    }
  },
  components: {
    TableData
  },
  methods: {
    //获取数据
    getTableData: throttle(async function () {
      // this.loading = true
      let { result } = await this.$http({
        url: `%CRM%/offline/bill_info.sdcrm`,
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          type: this.screen.type,
          month: this.screen.month
        }
      })
      let list = []
      result.records.forEach(item => {
        let items = {}
        if (this.screen.type == 1) {
          items.bankWater = item
        } else if (this.screen.type == 2) {
          items.topWater = item
        }
        list.push(items)
      })
      this.loading = false
      this.total = result.total
      this.tableData = list
    }),
    // 上传文件
    uploadFn (value) {
      if (this.screen.pay == '') {
        this.$message.error('请选择支付方式')
        return
      } else {
        const input = document.createElement('input')
        input.style.position = 'absolute'
        input.style.left = '-9999px'
        input.type = 'file'
        input.accept = '.xlsx,.xls'
        input.click()
        input.onchange = async e => {
          if (!e.target.files[0]) return
          let file = e.target.files[0]
          let { code, msg, errmsg } = await this.$http({
            mode: 'form',
            url: '%CRM%/offline/batch_insert.sdcrm',
            data: {
              token: true,
              file: file,
              type: value
            }
          })
          this.showUpdateMsg = false
          if (code !== 8200) {
            this.$message.error(`上传失败：${errmsg || msg}`)
            return
          }
          this.$message.success('保存成功')
        }
      }
    }
  }
}
</script>
