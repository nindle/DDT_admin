<template>
  <el-layout-pro class="box" :loading="loading" :total="total" :page-num.sync="pageNum" :page-size.sync="pageSize" @page-change="getTableData()">
    <!-- 筛选 -->
    <template #screen>
      <el-screen-pro :model="screen" :config="config" @change="getTableData(true)"></el-screen-pro>
    </template>

    <template #table>
      <table-data :data="tableData" :bank-list="config.bankId.options" @edit="openPopover" @refund="openRefund" />
    </template>

    <template #popover>
      <edit-data v-if="showPopover" :show.sync="showPopover" :data="rowData" :bank-list="config.bankId.options" @change="getTableData()" />
      <refund v-if="showRefund" :show.sync="showRefund" :data="refundData" @change="getTableData()" />
    </template>
  </el-layout-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableDataLeft'
import EditData from './editData'
import Refund from './refund.vue'

export default {
  name: 'gm-fina_entry',
  data() {
    return {
      //分页数据
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //新增页面的隐藏展示修改
      showPopover: false,
      //修改数据
      rowData: null,
      // 筛选
      screen: {
        corpId: '',
        addtionalInfo: '',
        bankId: '',
        buyStatus: '',
        stime: [],
        startCTime: [],
        keyword: '',
        reconcileStatus: ''
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增到账',
          click: () => {
            this.openPopover(null)
          }
        },
        corpId: {
          type: 'select-corp',
          change: () => {
            if(![0,19,''].includes(this.screen.corpId)) {
              this.screen.addtionalInfo = ''
            }
          }
        },
        addtionalInfo: {
          type: 'select',
          placeholder: '附加信息',
          options: [
            { label: '一分' },
          ],
          valueKey: 'label',
          hide: () => ![0,19,''].includes(this.screen.corpId)
        },

        bankId: {
          type: 'select',
          options: [],
          valueKey: 'typeId',
          labelKey: 'typeName',
          placeholder: '银行'
        },
        buyStatus: {
          type: 'select',
          placeholder: '状态',
          options: [
            { label: '未购买', value: 0 },
            { label: '已购买', value: 1 },
            { label: '已退订金', value: 2 }
          ]
        },
        reconcileStatus: {
          type: 'select',
          placeholder: '对账过滤',
          options: [
            { label: '已对账', value: 1 },
            { label: '未对账', value: 0 }
          ]
        },
        stime: {
          type: 'date-range',
          placeholder: ['付款时间', '结束时间']
        },
        startCTime: {
          type: 'date-range',
          placeholder: ['开通时间', '结束时间']
        },
        split: {
          type: 'split'
        },
        keyword: {
          type: 'input',
          placeholder: '付款人、银行流水号查询',
          changeLog: true
        },
        excel: {
          type: 'button',
          label: '导出Excel',
          click: () => {
            this.$copyExcel(this, this.nav.title)
          },
          hide: () => !this.tag.v155.visible
        },
        recipientBtn: {
          type: 'button',
          label: '对账',
          click: () => {
            this.openRecipient()
          }
        }
      },
      // 退费
      showRefund: false,
      refundData: {}
    }
  },
  inject: ['auth', 'nav', 'tag', 'recipient'],
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if (toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/offline/get_list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          bankId: typeof this.screen.bankId === 'number' ? this.screen.bankId : undefined,
          buyStatus: typeof this.screen.buyStatus === 'number' ? this.screen.buyStatus : undefined,
          addtionalInfo: this.screen.addtionalInfo || undefined,
          stime: this.screen.stime?.[0],
          etime: this.screen.stime?.[1],
          startBuyTime: this.screen.startCTime?.[0],
          endBuyTime: this.screen.startCTime?.[1],
          keyword: this.screen.keyword || undefined,
          reconcileStatus: typeof this.screen.reconcileStatus === 'number' ? this.screen.reconcileStatus : undefined
        }
      })

      this.loading = false
      this.total = result.total
      this.tableData = result.records
    }),
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    },
    openRefund(data) {
      this.showRefund = true
      this.refundData = data
    },
    async getBankList() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/setting/get_types/33.sdcrm',
        data: {
          token: true,
          corpId: this.$store.state.managerInfo.corpId || undefined
        }
      })

      this.config.bankId.options.splice(0, this.config.bankId.options.length, ...result)
    },
    openRecipient() {
      if (this.recipient.value) {
        this.recipient.value = ''
      } else {
        this.recipient.value = 'show'
      }
    }
  },
  components: {
    TableData,
    EditData,
    Refund
  },
  created() {
    this.getBankList()
  }
}
</script>
<style lang="scss" scoped>
.box {
  width: 100%;
  height: 100%;
  background: #fff;
}
</style>
