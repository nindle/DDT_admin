<template>
  <el-dialog-pro @close="close">
    <template #title>{{title}}</template>

    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >退 费</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      isLook: false,
      title: '退款',
      form: {
        payer: this.data?.payer ?? '',
        money: this.data?.money ?? '',
        refundChannel: this.data?.refundChannel ?? 1,
        refundchannel:'',
        balance:this.data?.balance ?? 0,
        refundFee: 0,
        refundfee: '',
        remark: this.data?.remark ?? '',
        Remark: ''
      },
      config: {
        payer: {
          type: 'label',
          label: '付款人'
        },
        money: {
          type: 'label',
          label: '到账金额'
        },
        refundChannel: {
          type: 'select',
          label: '退款方式',
          options: [
            {value: 1,label : '原路退回'},
            {value: 2,label : '线下退款'}
          ],
          hide: this.isLook 
        },
        refundchannel: {
          type: 'label',
          label: '退款方式',
          hide: !this.isLook
        },
        balance: {
          type: 'label',
          label: '可退金额'
        },
        refundFee: {
          type: 'number',
          label: '退款金额',
          hide: this.isLook
        },
        refundfee: {
          type: 'label',
          label: '退款金额',
          hide: !this.isLook
        },
        remark: {
          type: 'textarea',
          label: '备注',
          hide: this.isLook
        },
        Remark: {
          type: 'label',
          label: '备注',
          hide: !this.isLook
        }
      }
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  methods: {
    close() {
      this.$emit('update:show',false)
    },
    submit: throttle(async function() {
      if(!this.isLook) {
        if(this.form.balance < this.form.refundFee) {
          this.$message.error('退款金额超出，请重新输入')
          return
        }
        this.isLook = true
        this.title = '退款确定'
        this.form.refundchannel = this.form.refundChannel === 1 ? '原路返回' : '线下退款'
        this.form.refundfee = this.form.refundFee
        this.form.Remark = this.form.remark
        this.config.refundFee.hide = true
        this.config.refundfee.hide = false
        this.config.refundChannel.hide = true
        this.config.refundchannel.hide = false
        this.config.remark.hide = true
        this.config.Remark.hide = false
        return
      }
      
      let { code, errmsg, msg } = await this.$http({
        url:'%CRM%/offline/refundPay.sdcrm',
        data:{
          token: true,
          id: this.data.id,
          outTradeNo: this.data.outTradeNo,
          money: `${this.data.money}`,
          bankId: this.data.bankId,
          payType: this.data.payType,
          refundFee: this.form.refundFee,
          refundChannel: this.form.refundChannel,
          refundMoney: this.data.refundMoney,
          castMoney: this.data.castMoney,
          remark: this.form.remark
        }
      })
      if(code !== 8200) {
        this.$message.error(`操作失败：${errmsg || msg}`)
        return
      }

      this.$message.success('操作成功')
      this.close()
      this.$emit('change')
      
    })
  },
}
</script>
<style lang="scss" scoped>

</style>