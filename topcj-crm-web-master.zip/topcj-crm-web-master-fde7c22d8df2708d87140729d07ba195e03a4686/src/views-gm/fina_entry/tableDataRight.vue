<template>
  <el-table-pro :head="head" :data="data">
    <template #body-payer="{ row }">
      <scratch :data="row.payer" mode="name" :log="row.userId" copy />
    </template>

    <template #body-buyStatus="{ row, content }">
      <span class="refund">{{ content }}</span>
      <el-button v-if="row.balance > 0" slot="reference" type="text" size="small" icon="el-icon-document-remove" @click="$emit('refund', row)">退费</el-button>
    </template>

    <template #body-userId="{ row }">
      <scratch :data="row.userId" mode="userId" copy />
    </template>
  </el-table-pro>
</template>
<script>
import Scratch from '../../components/other/scratch'

export default {
  data() {
    return {
      head: [
        {
          key: 'topWater',
          label: '顶点通流水号',
          minWidth: 84,
          copy: true,
          default: '--'
        },
        {
          key: 'bankWater',
          label: '银行流水号',
          minWidth: 200,
          copy: true,
          default: '--'
        }
      ]
    }
  },
  props: {
    data: Array,
    bankList: Array,
    title: Number
  },
  inject: ['auth'],
  components: {
    Scratch
  },
  watch: {
    title: function(newVal) {
      if (newVal == 1) {
        this.head[0].minWidth = 84
        this.head[1].minWidth = 200
      } else if (newVal == 2) {
        this.head[0].minWidth = 200
        this.head[1].minWidth = 84
      }
    }
  },
  methods: {}
}
</script>
<style lang="scss" scoped>
.refund {
  margin-right: 16px;
}
</style>
