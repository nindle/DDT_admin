<template>
  <el-table-pro :head="head" :data="data">
    <template #body-reconcileStatus="{ row }">
      <i :class="row.reconcileStatus == 1 ? 'el-icon-circle-check' : 'el-icon-circle-close'"></i>
    </template>

    <template #body-payer="{ row }">
      <scratch :data="row.payer" mode="name" :log="row.userId" copy />
    </template>

    <template #body-buyStatus="{ row, content }">
      <span class="refund">{{ content }}</span>
      <el-button v-if="row.balance > 0" slot="reference" type="text" size="small" icon="el-icon-document-remove" @click="$emit('refund', row)">退费</el-button>
    </template>

    <template #body-userId="{ row }">
      <scratch :data="row.userId" mode="userId" copy />
    </template>
  </el-table-pro>
</template>
<script>
import Scratch from '../../components/other/scratch'

export default {
  data() {
    return {
      head: [
        {
          key: 'reconcileStatus',
          label: '状态',
          minWidth: 30
        },
        {
          key: 'payTime',
          label: '付款日期',
          minWidth: 140,
          format: e => new Date(e).timeFormat(),
          copy: true
        },
        {
          key: 'payer',
          label: '付款人',
          minWidth: 120
        },
        {
          key: 'buyTime',
          label: '开通时间',
          minWidth: 140,
          format: e => (e ? new Date(e).timeFormat() : '未开通'),
          copy: true
        },
        {
          key: 'orderNo',
          label: '订单号',
          minWidth: 150,
          default: '未生成订单号',
          copy: true,
          excel: `'{orderNo}`
        },
        // {
        //   key: 'isReal',
        //   label: '是否实名',
        //   minWidth: 56,
        //   format: e => e ? '已实名' : '未实名'
        // },
        // {
        //   key: 'isRisk',
        //   label: '是否风测',
        //   minWidth: 56,
        //   format: e => e ? '已风测' : '未风测'
        // },
        {
          key: 'bankId',
          label: '到账银行',
          minWidth: 84,
          format: {
            list: this.bankList,
            key: 'typeId',
            value: 'typeName'
          }
        },
        {
          key: 'money',
          label: '到账金额',
          minWidth: 56,
          copy: true
        },
        {
          key: 'castMoney',
          label: '消费',
          minWidth: 56,
          format: e => (e ? e : 0),
          copy: true
        },
        {
          key: 'refundMoney',
          label: '退款',
          minWidth: 56,
          format: e => (e ? e : 0),
          copy: true
        },
        {
          key: 'balance',
          label: '余额', //余额大于0时，出现退费按钮
          minWidth: 56,
          copy: true
        },
        {
          key: 'addtionalInfo',
          label: '附加信息',
          minWidth: 56,
        },
        {
          key: 'bankTradeNo',
          label: '银行流水',
          minWidth: 240,
          excel: `'{bankTradeNo}`,
          copy: true
        },
        {
          key: 'channel',
          label: '退款方式',
          minWidth: 56,
          default: '--',
          copy: true
        },
        {
          key: 'outTradeNo',
          label: '录入方式',
          minWidth: 56,
          format: e => (e ? '自动' : '手动'),
          copy: true
        },
        {
          key: 'remark',
          label: '备注',
          minWidth: 200
        },
        {
          key: 'buyStatus',
          label: '状态',
          minWidth: 130,
          format: {
            '0': '待购买',
            '1': '已购买',
            '2': '已全额退款',
            '3': '作废',
            '4': '已部分退款'
          }
        },
        {
          key: 'userId',
          label: '查询',
          width: 70
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            label: '修改',
            icon: 'el-icon-edit',
            type: 'text',
            click: row => {
              this.$emit('edit', row)
            },
            disabled: row => !!row.outTradeNo
          },
          hide: () => !this.auth.includes(3),
          excel: false
        }
      ]
    }
  },
  props: {
    data: Array,
    bankList: Array
  },
  inject: ['auth'],
  components: {
    Scratch
  },
  methods: {
    //隐藏
    // hideData: throttle(async function(row){
    //   let { code, errmsg, msg } = await this.$http({
    //     url:'%CRM%/offline/set_visible.sdcrm',
    //     data:{
    //       token: true,
    //       id: row.id,
    //       visible: row.visible ? 0 : 1
    //     }
    //   })
    //   if(code !== 8200) {
    //     this.$message.error(`操作失败：${errmsg || msg}`)
    //     return
    //   }
    //   this.$message.success('操作成功')
    //   row.visible = row.visible ? 0 : 1
    // }),
    //退订金
    // backData: throttle(async function(row) {
    //   if(row.outTradeNo) {
    //     let { code, errmsg, msg } = await this.$http({
    //       url:'%CRM%/offline/refundPay.sdcrm',
    //       data:{
    //         token: true,
    //         id: row.id,
    //         outTradeNo: row.outTradeNo,
    //         money: `${row.money}`,
    //         bankId: row.bankId,
    //         payType: row.payType,
    //       }
    //     })
    //     if(code !== 8200) {
    //       this.$message.error(`操作失败：${errmsg || msg}`)
    //       return
    //     }
    //   }else{
    //     let { code, errmsg, msg } = await this.$http({
    //       url:'%CRM%/offline/set_status.sdcrm',
    //       data:{
    //         token: true,
    //         id: row.id,
    //         buyStatus: 2
    //       }
    //     })
    //     if(code !== 8200) {
    //       this.$message.error(`操作失败：${errmsg || msg}`)
    //       return
    //     }
    //   }
    //   this.$message.success('操作成功')
    //   row.buyStatus = 2
    // }),
  }
}
</script>
<style lang="scss" scoped>
.refund {
  margin-right: 16px;
}
/deep/.el-icon-circle-check:before {
  color: green;
}
/deep/.el-icon-circle-close:before {
  color: red;
}
</style>
