<template>
  <div class="view">
    <box-left class="box" />
    <box-right class="box-right" v-if="recipient.value" />
  </div>
</template>

<script>
import BoxLeft from './boxLeft'
import BoxRight from './boxRight'

export default {
  name: 'gm-fina_entry',
  data() {
    return {
      recipient: {
        value: ''
      }
    }
  },
  provide() {
    return {
      auth: this.auth,
      nav: this.nav,
      tag: this.tag,
      recipient: this.recipient
    }
  },
  components: {
    BoxLeft,
    BoxRight
  },
  props: {
    nav: Object,
    tag: Object,
    auth: Array
  }
}
</script>

<style scoped lang="scss">
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  display: flex;
  .box {
    flex: 1;
    width: 68%;
    height: 100%;
    background: #fff;
  }
  .box-right {
    margin-left: 24px;
    width: 400px;
  }
}
</style>
