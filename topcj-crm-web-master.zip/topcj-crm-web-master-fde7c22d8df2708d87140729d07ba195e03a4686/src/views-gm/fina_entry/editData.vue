<template>
  <el-dialog-pro @close="close">
    <template #title>
      {{data ? '编辑' : '新增'}}到账信息
    </template>

    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      form: {
        corpId: this.data?.corpId,
        payer: this.data?.payer ?? '',
        bankId: this.data?.bankId ?? '',
        bankTradeNo: this.data?.bankTradeNo ?? '',
        payTime: this.data ? new Date(this.data.payTime).getTime() : Date.now(),
        money: this.data?.money ?? '',
        remark: this.data?.remark ?? '',
      },
      config: {
        corpId: {
          type: 'select-corp',
          label: '分公司',
          rule: [
            { required: true }
          ],
          corpLock: true,
          hide: () => this.data && this.data?.buyStatus !== 0
        },
        payer: {
          label: '付款人',
          rule: [
            { required: true }
          ]
        },
        bankId: {
          type: 'select',
          label: '银行',
          options: this.bankList,
          valueKey: 'typeId',
          labelKey: 'typeName',
          rule: [
            { required: true }
          ]
        },
        bankTradeNo: {
          label: '银行流水',
          rule: [
            { required: true }
          ]
        },
        payTime: {
          type: 'date-time',
          label: '支付时间',
          rule: [
            { required: true }
          ],
          hide: () => this.data && this.data?.buyStatus !== 0
        },
        money: {
          type: 'number',
          label: '支付金额',
          min: 0,
          rule: [
            { required: true }
          ],
          hide: () => this.data && this.data?.buyStatus !== 0
        },
        remark: {
          type: 'textarea',
          label: '备注',
          hide: () => this.data && this.data?.buyStatus !== 0
        }
      }
    }
  },
  props: {
    show: Boolean,
    data: Object,
    bankList: Array
  },
  methods: {
    close() {
      this.$emit('update:show',false)
    },
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/offline/add_pay_record.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          corpId: this.form.corpId,
          payer: this.form.payer,
          bankId: this.form.bankId,
          bankTradeNo: this.form.bankTradeNo,
          payTime: this.form.payTime,
          money: this.form.money,
          remark: this.form.remark || undefined,
          productType: 0
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    })
  }
}
</script>