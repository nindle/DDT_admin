<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      page-layout="normal"
    >
      <!--筛选模块-->
      <!-- <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData()"
        ></el-screen-pro>
      </template> -->
      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'

export default {
  name: 'gm-attach_log',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //筛选数据
      screen: {
        
      },
      config: {
        
      }
    }
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/attach_log/list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
        }
      })

      this.tableData = result.contents
      this.total = result.total

      this.loading = false
    }),
  },
  components: {
    TableData,
  },
  created() {
    this.getTableData()
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>