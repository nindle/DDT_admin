<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  ></el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'ctime',
          label: '操作时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'userId',
          label: '用户ID',
          minWidth: 70,
          copy: true
        },
        {
          key: 'editor',
          label: '操作人',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.managerList,
            key: 'id',
            value: 'realName'
          }
        },
        {
          key: 'oldManager',
          label: '客户原归属',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.managerList,
            key: 'id',
            value: 'realName'
          }
        },
        {
          key: 'newManager',
          label: '客户新归属',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.managerList,
            key: 'id',
            value: 'realName'
          }
        }
      ]
    }
  },
  props: {
    data: Array
  },
}
</script>