<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <!-- 筛选 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          :select-list.sync="selectList"
          :bank-list="config.bankId.options"
          :package-list="packageList"
          @change="getTableData()"
        />
      </template>

      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="selectList"
          :type="popoverType"
          :package-list="packageList"
           @change="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-fina_url',
  data() {
    return {
      // 状态更新
      loading: false,
      // 分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      // 筛选
      screen: {
        corpId: '',
        bankId: '',
        buyStatus: '',
        stime: [],
        keyword: '',
      },
      config: {
        corpId: {
          type: 'select-corp'
        },
        bankId: {
          type: 'select',
          options: [],
          valueKey: 'typeId',
          labelKey: 'typeName',
          placeholder: '银行'
        },
        buyStatus: {
          type: 'select',
          placeholder: '状态',
          options: [
            { label: '未购买', value: 0},
            { label: '已购买', value: 1}
          ]
        },
        stime: {
          type: 'date-range',
          placeholder: ['付款时间', '结束时间']
        },
        split1: {type: 'split'},
        keyword: {
          type: 'input',
          placeholder: '付款人、银行流水号查询'
        },
        br: {type: 'br'},
        // add: {
        //   type: 'button',
        //   buttonType: 'primary',
        //   label: '+ 购买产品',
        //   click: () => { this.openPopover(0) }
        // },
        buy: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 补差价购买',
          click: () => { this.openPopover(1) }
        },
        split2: {type: 'split'},
        excel: {
          type: 'button',
          label: '导出Excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        }
      },
      // 表格数据
      tableData: [],
      // 弹窗隐藏显示
      showPopover: false,
      popoverType: 0,
      //选择的列表
      selectList: [],
      packageList: []      
    }
  },
  props: {
    nav: Object
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }
      
      let { result } = await this.$http({
        url: '%CRM%/offline/get_list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          bankId: typeof this.screen.bankId === 'number' ? this.screen.bankId : undefined,
          buyStatus: typeof this.screen.buyStatus === 'number' ? this.screen.buyStatus : undefined,
          stime: this.screen.stime?.[0],
          etime: this.screen.stime?.[1],
          keyword: this.screen.keyword || undefined,
        } 
      })

      this.loading = false

      this.total = result.total
      this.tableData = result.records
    }),
    openPopover(type) {
      if(this.selectList.length){
        this.showPopover = true
        this.popoverType = type
        return
      }
      this.$message.warning('请选择购买项')
    },
    async getBankList() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/setting/get_types/33.sdcrm',
        data: {
          token: true,
          corpId: this.$store.state.managerInfo.corpId || undefined
        }
      })

      this.config.bankId.options.splice(0, this.config.bankId.options.length, ...result)
    },
    async getPackageList() {
      let { result } = await this.$http({
        url: '%CRM%/package/get_package_list.sdcrm',
        data: {
          token: true
        }
      })

      this.packageList.splice(0, this.packageList.length, ...result)
    },
  },
  components: {
    TableData,
    EditData
  },
  created() {
    this.getPackageList()
    this.getBankList()
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>