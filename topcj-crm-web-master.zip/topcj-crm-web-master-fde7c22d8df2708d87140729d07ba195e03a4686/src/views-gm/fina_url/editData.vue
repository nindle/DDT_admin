<template>
  <el-dialog-pro @close="close">
    <template #title>购买信息</template>

    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
      <template #total>
        <span>还需要补差价{{tipsMoney}}元</span>
      </template>
    </el-form-pro>

    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      // 状态更新
      loading: false,
      // 筛选
      form: {
        userId: '',
        managerId: '',
        orderId: [],
        packageId: '',
        giftDays: '',
        tip: ''
      },
      config: {
        userId: {
          type: 'input',
          label: '客户ID/手机',
          rule: [
            { required: true }
          ],
          change: this.getOrderList
        },
        orderId: {
          type: 'select',
          label: '客户已购套餐',
          options: [],
          labelKey: 'packageName',
          valueKey: 'id',
          multiple: true,
          hide: () => !this.config.orderId.options.length,
          rule: [
            { required: true }
          ],
          change: this.getTips
        },
        managerId: {
          type: 'select-manager',
          label: '业务归属',
          rule: [
            { required: true }
          ]
        },
        packageId: {
          type: 'select',
          label: '待购买产品',
          options: this.packageList,
          valueKey: 'id',
          labelKey: 'name',
          rule: [
            { required: true }
          ],
          change: this.getGiftDay
        },
        tip: {
          type: 'label',
          hide: () => !(this.form.orderId.length && this.form.packageId && this.type === 1)
        },
        giftDays: {
          type: 'select',
          label: '赠送天数',
          options: [0, 30, 60, 90, 120, 150, 180].map(e => {
            return {
              value: e,
              label: `${e}天`,
              disabled: false
            }
          }),
          rule: [
            { required: true }
          ],
        }
      },
      orderList: [],
      tipsMoney: '',
      Textshow: false
    }
  },
  props: {
    show: Boolean,
    data: Array,
    packageList: Array,
    type: Number
  },
  methods: {
    close() { 
      this.$emit('update:show',false)
    },
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/offline/offline_pay.sdcrm',
        data: {
          token: true,
          userId: this.form.userId,
          managerId: this.form.managerId,
          packageId: this.form.packageId,
          giftDays: Number(this.form.giftDays),
          orderIds: this.type === 1 ? this.form.orderId : undefined,
          ids: this.data.map(e => e.id)
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`购买失败：${errmsg || msg}`)
        return
      }

      this.$message.success('购买成功')
      this.$emit('change')
      this.close()
    }),
    //获取可赠送天数
    getGiftDay() {
      this.form.giftDays = ''

      let detail = this.packageList.filter(e => e.id === this.form.packageId)[0]
      if(detail) {
        this.config.giftDays.options.forEach(e => {
          e.disabled = e.value > detail.giveDays
        })
      }

      this.getTips()
    },
    //获取订单记录
    async getOrderList() {
      if(this.type !== 1) return

      let { code, result } = await this.$http({
        url: '%CRM%/user/get_order_list.sdcrm',
        data: {
          token: true,
          userId: this.form.userId,
          pageNum: 1,
          pageSize: 30,
          buyStatus: 1,
          notExpired: 1
        }
      })

      if(code !== 8200 || !result.records.length) {
        this.config.orderId.options = []
        return
      }
      
      this.config.orderId.options = result.records
    },
    getTips() {
      if(!this.form.orderId.length || !this.form.packageId) return

      let orderMoney = this.config.orderId.options.filter(e => this.form.orderId.includes(e.id)).reduce((pre, e) => pre + e.money, 0)
      let packageMoney = this.packageList.filter(e=> e.id === this.form.packageId)[0].money

      this.form.tip = `需补差价${packageMoney - orderMoney}元`
    }
  }
}
</script>