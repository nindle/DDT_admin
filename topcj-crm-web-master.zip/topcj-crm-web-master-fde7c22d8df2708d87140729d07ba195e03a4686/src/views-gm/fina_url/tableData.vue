<template>
  <el-table-pro
    :head="head"
    :data="data"
    @selection-change="$emit('update:select-list', $event)"
  >
    <!-- 购买状态 -->
    <template #body-buyStatus="{ row, content }">
      <span style="margin-right: 8px">{{content}}</span>
      <el-popconfirm
        v-if="row.buyStatus === 1"
        title="确定撤销？"
        @confirm="cancelBuy(row)"
      >
        <el-button 
          slot="reference"
          type="text"
          size="small"
          icon="el-icon-document-remove"
        >撤销购买</el-button>
      </el-popconfirm>
    </template>

    <!-- 签署图片 -->
    <template #body-signPath="{ row }">
      <el-button 
        type="text"
        icon="el-icon-picture-outline"
        size="small"
        v-if="row.signPath"
        v-imageview="row.signPath"
      >查看</el-button>
    </template>

    <!-- 操作 -->
    <template #body-operation="{ row }">
      <el-button 
        type="text"
        size="small"
        icon="el-icon-link"
        v-if="row.buyStatus && row.agreementStatus !== 1"
        @click="copyLink(row)"
      >复制签署链接</el-button>
      <el-button
        type="text"
        size="small"
        icon="el-icon-download"
        v-if="row.agreementStatus === 1"
        @click="beforeDownPdf(row)"
      >下载合同PDF</el-button>
    </template>

    <!-- 签约 -->
    <template #body-sign="{ row }">
      <el-button 
        type="text"
        size="small"
        icon="el-icon-s-grid"
        v-if="row.buyStatus && row.agreementStatus !==1"
        @click="getQrCode(row)"
      >复制签署二维码</el-button>

      <el-popconfirm
        title="确定重新签约？"
        v-if="row.agreementStatus === 1"
        @confirm="resetAgreement(row)"
      >
        <el-button
          slot="reference"
          type="text"
          size="small"
          icon="el-icon-document-delete"
        >需重新签约点击</el-button>
      </el-popconfirm>
    </template>

    <!-- 查询ID -->
    <template #body-userId="{ row }">
      <scratch
        :data="row.userId"
        mode="userId"
        copy
      />
    </template>
  </el-table-pro>
</template>
<script>
import { md5 } from '../../assets/js/crypto'
import { throttle, loadimage } from '../../assets/js/tool'
import Scratch from '../../components/other/scratch'

import agreementImage from '../../assets/images/ns_agreement.png'
import logoImage from '../../assets/images/ns_logo.png'

export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          selectable: row => row.balance && row.buyStatus === 0,
          width: 14,
          excel: false
        },
        {
          key: 'payTime',
          label: '付款时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'payer',
          label: '付款人',
          minWidth: 120
        },
        {
          key: 'isReal',
          label: '是否实名',
          minWidth: 56,
          format: e => e ? '已实名' : '未实名'
        },
        {
          key: 'bankId',
          label: '到账银行',
          minWidth: 84,
          format: {
            list: this.bankList,
            value: 'typeName',
            key: 'typeId'
          }
        },
        {
          key: 'money',
          label: '到账金额',
          minWidth: 56
        },
        {
          key: 'balance',
          label: '余额',
          minWidth: 56
        },
        // {
        //   key: 'realName',
        //   label: '业务归属',
        //   minWidth: 70
        // },
        {
          key: 'corpName',
          label: '分公司',
          minWidth: 70
        },
        {
          key: 'buyStatus',
          label: '购买状态',
          minWidth: 120,
          format: {
            '0': '待购买',
            '1': '已购买',
            '2': '已全额退款',
            '4': '已部分退款',
          }
        },
        {
          key: 'signPath',
          label: '签署图片',
          minWidth: 56
        },
        {
          key: 'agreementStatus',
          label: '签署状态',
          minWidth: 56,
          format: {
            '0' : '未签署',
            '1' : '已签署',
          }
        },
        {
          key: 'operation',
          label: '操作',
          width: 84,
          excel: false
        },
        {
          key: 'sign',
          label: '签约',
          width: 90,
          excel: false
        },
        {
          key: 'userId',
          label: '查询',
          width: 70
        }
      ]
    }
  },
  components: {
    Scratch
  },
  props: {
    data: Array,
    bankList: Array,
    packageList: Array
  },
  methods: {
    //复制签署链接
    copyLink(e) {
      let packageName = this.packageList.filter(item => item.id === e.packageId)[0]?.name ?? ''
      
      let data = `购买人:${e.payer}\n购买时间:${e.payTime}\n购买产品:${packageName}\n签署合同链接:${this.SYS.WEBURL}/ns/#/signcontract?sn=${e.orderNo}&time=${Date.now()}`
      
      this.$copy(data)
    },
    //下载合同PDF
    async beforeDownPdf(e) {
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/buy/order/order_download_check.sdcrm',
        data: {
          token: true,
          orderId: e.orderId,
        }
      })

      if(code !== 8200) {
        this.$confirm(errmsg || msg, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.downPdf(e)
        })
        return 
      }

      this.downPdf(e)
    },
    //下载合同PDF
    downPdf(e) {
      const time = Date.now()
      const token = this.$store.state.token
      const sign = md5(`7685ab5265c568c41024cca4b396efa1${token}${e.orderNo}${time}`)
      
      let url = `${this.SYS.WEBURL}/ns/#/agreementfullpdf?gm=${token}&sn=${e.orderNo}&time=${time}&sign=${sign}`
      this.$open(url)
    },
    //复制签署链接
    getQrCode: throttle(async function({payer, packageId, orderNo}) {
      let packageName = this.packageList.filter(item => item.id === packageId)[0]?.name ?? ''

      let url = `${this.SYS.WEBURL}/ns/#/signcontract?sn=${orderNo}&time=${Date.now()}`

      const QRCode = await import('qrcode')

      let code = await QRCode.toDataURL(
        url,
        {
          errorCorrectionLevel: "H", 
          version: 8,
          width: 630,
          margin: 0
        }
      )

      let canvas = document.createElement('canvas')
      canvas.width = 846
      canvas.height = 1268
      let ctx = canvas.getContext('2d')

      let background = await loadimage(agreementImage)
      ctx.drawImage(background, 0, 0, 846, 1268)

      let codei = await loadimage(code)
      ctx.drawImage(codei, 108, 388, 630, 630)

      let logo = await loadimage(logoImage)
      ctx.drawImage(logo, 358, 638, 130, 130)

      let a = document.createElement('a')
      a.download = `${payer}-${packageName}.png`
      a.href = canvas.toDataURL('image/png')
      a.click()
    }),
    //重新签约
    resetAgreement: throttle(async function(e) {
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/buy/order/agreement_resetting.sdcrm',
        data: {
          token: true,
          sn: e.orderNo
        }
      })

      if(code !== 8200) {
        this.$message.error(`更改失败：${errmsg || msg}`)
        return
      }

      this.$message.success('更改成功')
      e.agreementStatus = 0
    }),
    //撤销购买
    cancelBuy: throttle(async function(e) {
      if(e.receiptStatus === 1){
        this.$message.warning('请先冲红后再撤销购买')
        return
      }

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/offline/cancel_offline_pay.sdcrm',
        data:{
          token: true,
          sn: e.orderNo
        }
      })

      if(code !== 8200) {
        this.$message.error(`撤销失败：${errmsg || msg}`)
        return
      }

      this.$message.success('撤销成功')
      this.$emit('change')
    })
  }
}
</script>