<template>
  <div 
    class="view"
    :class="{ 'has-user': selectUserId }"
  >
    <el-layout-pro
      class="out"
      :loading="loading"
    >
      <template #screen>
        <div class="top">
          <top 
            :screen-list.sync="screenList"
            @change="getTableData(true)"
          />
        </div>
      </template>

      <template #table>
        <div class="bottom">
          <el-layout-pro
            class="box"
            :total="total"
            :page-num.sync="pageNum"
            :page-size.sync="pageSize"
            @page-change="getTableData()"
          >
            <template #screen>
              <el-screen-pro
                :model="screen"
                :config="config"
              ></el-screen-pro>
            </template>

            <template #table>
              <table-data 
                :data="tableData"
                :select-list.sync="selectList"
                @select="selectUserId = $event"
                ref="table"
              />
            </template>

            <template #popover>
              <batch-distribute 
                v-if="showSingle"
                :show.sync="showSingle"
                :data="selectList"
                :screen-list="screenList"
                @change="getTableData"
              />

              <batch-distribute-two 
                v-if="showDouble"
                :show.sync="showDouble"
                :data="selectList"
                :screen-list="screenList"
                @change="getTableData"
              />
            </template>
          </el-layout-pro>

          <!--客户详情-->
          <el-layout-pro 
            class="user-box"
            v-if="selectUserId"
          >
            <template #screen>
              <el-screen-pro :config="userDetailConfig">
                <template #close>
                  <i 
                    class="el-icon-close"
                    @click="selectUserId = 0"
                  ></i>
                </template>
              </el-screen-pro>
            </template>

            <template #scroll>
              <user-detail 
                class="user-detail-box" 
                :user-id="selectUserId"
                :key="selectUserId"
                :userDetailConfig='userDetailConfigs'
              />
            </template>
          
          </el-layout-pro>
        </div>
      </template>

    </el-layout-pro>



    
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import UserDetail from '../../components/user-detail/index'
import BatchDistribute from './batchDistribute.vue'
import BatchDistributeTwo from './batchDistributeTwo.vue'
import TableData from './tableData.vue'
import Top from './top.vue'
export default {
  name: 'gm-customer',
  data() {
    return {
      //加载状态
      loading: false,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      // 筛选
      screenList: {},
      selectUserId:0,
      screen:{},
      config: {
        // ten: {
        //   type: 'button',
        //   // buttonType: 'info',
        //   label: '10条/次',
        //   click: () => {this.handCheck(10)}
        // },
        // fifty: {
        //   type: 'button',
        //   // buttonType: 'info',
        //   label: '50条/次',
        //   click: () => {this.handCheck(50)}
        // },
        // hundred: {
        //   type: 'button',
        //   // buttonType: 'info',
        //   label: '100条/条',
        //   click: () => {this.handCheck(100)}
        // },
        // split: {type: 'split'},
        single: {
          type: 'button',
          buttonType: 'primary',
          label: '批量分配单员工',
          click: () => { !this.selectList.length ?  this.$message.warning('请选择资源') : this.showSingle = true}
        },
        double: {
          type: 'button',
          buttonType: 'primary',
          label: '批量分配多员工',
          click: () => { !this.selectList.length ?  this.$message.warning('请选择资源') : this.showDouble = true}
        }
      },
      userDetailConfig: {
        label: {
          type: 'label',
          label: '客户资料'
        },
        split: { type: 'split' },
        close: {}
      },
      // 表格数据
      tableData: [],
      selectList: [],
      // 分配单员工
      showSingle: false,
      // 分配多员工
      showDouble: false,

    }
  },
  props: {
    tag: Object
  },
  provide() {
    return {
      tag: this.tag
    }
  },
  computed:{
    userDetailConfigs(){
      return {
        // name:'gm-corp_source',
      }
    }
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }


      //没有选择时删除数据
      if(this.$store.state.sysMode !== 1 &&
      typeof this.screenList.pay !== 'number' && 
      !this.screenList.time?.length &&
      !this.screenList.keyword &&
      !this.screenList.resState &&
      !this.screenList.stage &&
      !this.screenList.classify &&
      !this.screenList.serviceStatus
      ) {
        this.tableData = []
        this.total = 0
        this.loading = false
        return 
      }


      let arrt = this.screenList.attach.split('/')

      let { result } =  await this.$http({
        url: '%CRM%/user/get_user_list.sdcrm',
        data: {
          token: true,
          groupId: arrt[0] === 'group' ?  arrt[1] : undefined , //领导传部门id 也可以managerId
          managerId:arrt[0] === 'manager' ?  arrt[1] : undefined, //员工只能定自己的managerId
          resType: this.screenList.resType ? this.screenList.resType : undefined,
          resChannel:typeof this.screenList.resChannel === 'number' ? this.screenList.resChannel : undefined,
          pay: this.screenList.pay ? this.screenList.pay : undefined,
          stime: this.screenList.time?.[0],
          etime: this.screenList.time?.[1],
          keyword: this.screenList.keyword ? this.screenList.keyword : undefined,
          resState: this.screenList.resState ? this.screenList.resState : undefined,
          stage: this.screenList.stage ? this.screenList.stage : undefined,
          classify: this.screenList.classify ? this.screenList.classify : undefined,
          attachType: this.screenList.type,
          tagIds: '',
          queryType: 1,
          sortFieId: 0,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          serviceStatus: this.screenList.serviceStatus || undefined
        }
      })
      this.tableData = result.records
      this.total = result.total
      this.loading = false
    }),
    handCheck(val) {
      this.$refs.table.setSelect(val)
      if(this.tableData.length <= val) {
        this.selectList = this.tableData
      } else {
        for(let i in val) {
          this.selectList.push(this.tableData[i])
        }
      }
    }
  },
  components: { 
    TableData,
    UserDetail,
    BatchDistribute,
    BatchDistributeTwo,
    Top
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  .out {
    width: 100%;
    height: 100%;
    .top {
      width: 100%;
      background: #FFF;
    }
    .bottom {
      display: flex;
      width: 100%;
      height: 100%;
    }
  }
  .box {
    height: 100%;
    width: 100%;
    background: #FFF;
  }
  .user-box {
    width: 350px;
    flex-grow: 1;
    height: 100%;
    margin-left: 24px;
    background: #FFF;
    .el-icon-close { cursor: pointer; }
    /deep/ {
      .screen-box { padding: 24px;}
      .scroll-box { background: #F5F5F5;}
    }
  }
  &.has-user {
    .box { width: calc(100% - 374px);}
  }
}
</style>