<template>
  <div class="top-box">
    <span> 筛选条件：</span>
    <el-screen-pro
      :model="screen"
      :config="config"
      @change="screenChange"
      :cancel-init-callback="$store.state.sysMode !== 1"
    ></el-screen-pro>
  </div>
</template>
<script>
export default {
  data() {
    return {
      screen: {
        resType: '',
        resChannel: '',
        pay: '',
        attach: this.$store.state.managerInfo.isLeader ? `group/${this.$store.state.managerInfo.dataGroupId}` : `manager/${this.$store.state.managerInfo.id}`,
        showLock: false,
        time: [],
        keyword: '',
        resState: '',
        stage: '',
        classify: '',
        type: this.$route.meta.type ?? this.$store.state.managerInfo.managerType,
        serviceStatus: ''
      },
      config: {
        // resType: {
        //   type: 'select',
        //   options: this.$store.state.baseData.secTypeList.filter(e => e.showStatus),
        //   valueKey: 'id',
        //   labelKey: 'resName',
        //   placeholder: '资源类型'
        // },
        // resChannel: {
        //   type: 'select',
        //   options: this.$store.state.baseData.resChannelList,
        //   valueKey: 'id',
        //   labelKey: 'channelName',
        //   placeholder: '资源来源'
        // },
        pay: {
          type: 'select',
          options: [
            { value: 0, label: '所有购买用户' },
            { value: 7, label: '近7天购买' },
            { value: 15, label: '近15天购买' },
            { value: 30, label: '近30天购买' },
            { value: 60, label: '近60天购买' },
            { value: 90, label: '近90天购买' },
            { value: 180, label: '近180天购买' }
          ],
          placeholder: '购买状态'
        },
        type: {
          type: 'select',
          options: [
            { label: '业务', value: 2 },
            { label: '合规', value: 4 },
            { label: '售后', value: 1 }
          ],
          placeholder: '归属类型',
          clearable: false,
          hide: () => this.$store.state.managerInfo.roleList.findIndex(e => e.id === 73) === -1 || this.$store.state.sysMode !== 1 || this.$route.meta.type
        },
        attach: {
          type: 'select-group-manager',
          placeholder: '组织架构',
          clearable: false,
          filter: () => {
            if(this.screen.showLock)  {
              return {
                managerType: this.screen.type
              }
            }
            return {
              isLock: 0,
              managerType: this.screen.type
            }
          },
          hide: () => this.$store.state.sysMode !== 1
        },
        showLock: {
          type: 'switch',
          activeValue: true,
          inactiveValue: false,
          activeText: '显示离职',
          hide: () => this.$store.state.sysMode !== 1
        },
        time: {
          type: 'date-range',
        },
        keyword: {
          type: 'input',
          placeholder: '输入编号/昵称/备注/名称/手机号',
          changeLog: true
        },
        resState: {
          type: 'select',
          options: [
            { value:700, label:'有意向' },
            { value:701, label:'无意向' },
            { value:702, label:'空号' },
            { value:703, label:'拒接' },
            { value:704, label:'同行' }
          ],
          placeholder: '资源状态'
        },
        stage: {
          type: 'select',
          options: [
            { value:800, label:'新入资源' },
            { value:801, label:'第一阶段' },
            { value:802, label:'第二阶段' },
            { value:803, label:'第三阶段' }
          ],
          placeholder: '用户进程'
        },
        classify: {
          type: 'select',
          options: [
            { value:900, label:"A" },
            { value:901, label:"B" },
            { value:902, label:"C" },
            { value:903, label:"D" }
          ],
          placeholder: '用户分类'
        },
        serviceStatus: {
          type: 'select',
          placeholder: '服务状态',
          options: [
            { value: 1, label: '服务期内'},
            { value: 2, label: '已到期'},
          ]
        }
      }
    }
  },
  props: {
    screenList: Object
  },
  methods: {
    screenChange() {
      this.$emit('update:screen-list', this.screen)
      this.$emit('change')
    }
  }
}
</script>
<style lang="scss" scoped>
.top-box {
  display: flex;
  padding: 0 24px 12px;
  /deep/ {
    .screen {
      width: calc(100% - 85px);
      margin-top: 0px;
    }
  }
  span {
    padding: 12px 12px 0 0;
    font-size: 14px;
    line-height: 32px;
  }
}
</style>