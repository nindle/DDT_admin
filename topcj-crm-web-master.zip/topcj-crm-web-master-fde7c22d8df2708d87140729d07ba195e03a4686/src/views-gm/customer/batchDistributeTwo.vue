<template>
  <el-dialog-pro @close="close">
    <template #title>用户分配</template>
    
    <div 
      class="tip"
      v-if="num === 0 && !loading"
    >您已选择{{data.length}}个资源,请分配指定数量</div>
    <div 
      class="tip"
      v-if="num && num < data.length && !loading"
    >您已选择{{data.length}}个资源,已指定{{num}}个,请分配指定数量</div>
    <div 
      class="tip red"
      v-if="num && num > data.length && !loading"
    >您已选择{{data.length}}个资源,已指定{{num}}个,超过资源总数,请删减</div>
    <div 
      class="tip"
      v-if="loading"
    >分配中,请稍后</div>
    <el-table-pro
      :head="head"
      :data="canManagerList"
    >
      <template #body-user="{ row }">
        <el-input 
          v-model="row.batchNum" 
          @input="inputNum"
        />
      </template>
    </el-table-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      head: [
        {
          key: 'idCardName',
          label: '姓名',
          minWidth: 70
        },
        {
          key: 'groupName',
          label: '小组',
          minWidth: 84
        },
        {
          key: 'userNum',
          label: '今日已分配',
          minWidth: 84
        },
        {
          key: 'user',
          label: '待分配数量',
          minWidth: 84
        }
      ],
      canManagerList: [],
      num: 0
    }
  },
  props: {
    data: Array,
    show: Boolean,
    screenList: Object
  },
  methods: {
    async getResnum(){
      let { result } = await this.$http({
        url: '%CRM%/user/manager_user_num.sdcrm',
        data:{
          token: true,
          managerIds: this.canManagerList.map(e => e.id)
        }
      })
      this.canManagerList = this.canManagerList.map(e => {
        e.batchNum = null
        e.userNum = 0
        for(let i in result) {
          if(e.id === result[i].managerId) {
            e.userNum = result[i].userNum
            result.splice(i, 1)
            return e
          }
        }
        return e
      })
    },
    
    initManager(list){
      if(this.$store.state.managerInfo){
        list.forEach(item=>{
          if(item.managerList.length){
            this.canManagerList.push(...item.managerList)
          }
          if(item.groupChildren.length){
            this.initManager(item.groupChildren)
          }else{
            return 
          }
        })
      }else{
        this.canManagerList = this.$store.state.managerInfo
        return this.canManagerList
      }
    },
    inputNum() {
      let count = 0

      this.canManagerList = this.canManagerList.map(e => {
        if(e.batchNum) {
          e.batchNum = e.batchNum.replace(/[^0-9]/g,'')
        }
        count += Number(e.batchNum)
        return e
      })

      this.num = count
    },
    close() {
      this.$emit('update:show', false)
    },
    submit:throttle(async function() {
      this.loading = true

      if(this.num > this.data.length) {
        this.$message.error('指定数大于资源总数，请删减')
        this.loading = false
        return
      }

      let all = []
      let list = [...this.data]

      this.canManagerList.map(e => {
        let batch = Number(e.batchNum)
        if(batch) {
          all.push({
            url: '%CRM%/user/user_batch_distribute.sdcrm',
            data: {
              token: true,
              managerId: e.id,
              attachType: e.managerType,
              userIds: list.splice(0,batch).map(a=>a.userId)
            }
          })
        }
        return e
      })

      let data = await this.$http({
        mode: 'relay',
        all: all
      })
    
      
      let successCount = 0
      let errorCount = 0
      let successList = []
      let dataList = []

      data.map((result, i) => {
        if(result.code === 8200) {
          successCount++
          successList.push(all[i])
        }else{
          errorCount++
          dataList.push(`ID：${all[i].data.managerId}，错误信息：${result.errmsg || result.msg}`)
        }
      })

      if(data.length === 1) {
        //只有一条数据
        if(successCount === 1) {
          this.$message.success(`分配成功`)
        }else{
          this.$message.error(data[0].errmsg || data[0].msg)
        }
      }else{
        if(dataList.length){
          this.$copy(dataList.join('\n'), () => {
            this.$message.success(`分配成功${successCount}条，失败${errorCount}条；失败信息已复制`)
          }, false)
        }else{
          this.$message.success(`分配成功${successCount}条，失败${errorCount}条`)
        }
      }


      this.loading = true
      this.$emit('change')
      this.close()
    })
  },
  created() {
    this.initManager(this.$store.state.baseData.authGroupTree)
    this.canManagerList = this.canManagerList.filter(item=>this.screenList.type === item.managerType && item.isLock === 0)
    this.canManagerList.forEach(item=>item.batchNum = null)
    this.getResnum()
  }
}
</script>
<style lang="scss" scoped>
.tip {
  color: rgba(0, 0, 0, .45);
  margin: 24px 0;
}
.red {
  color: rgba(255, 0, 0, 1);
}
</style>