<template>
  <el-table-pro
    :head="head"
    :data="data"
    ref="table"
    @selection-change="$emit('update:select-list', $event)"
  >
    <template #body-phone="{ row }"> 
      <callphone
        :user-id="row.userId"
        @call="$emit('select', $event)"
      />
    </template>

    <template #body-realname="{ row }">
      <scratch
        v-if="row.isReal"
        :data="row.realname"
        mode="name"
        :log="row.userId"
        show-button
      />
      <span v-else>未实名</span>
    </template>

    <template #body-riskType="{ row }">
      <span>{{riskFormat(row.riskType,row.score)}}</span>
    </template>

    <template #body-sales="{ row }">
      {{row.salesName?row.salesName : "无"}}/{{row.superviseManagerName?row.superviseManagerName : "无"}}/{{row.serviceManagerName?row.serviceManagerName : "无"}}
    </template>
  </el-table-pro>
</template>
<script>
import Scratch from '../../components/other/scratch'
import Callphone from '../../components/other/callphone'

export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'userId',
          label: '用户编号',
          click: row => { this.$emit('select', row.userId) },
          minWidth: 70
        },
        {
          key: 'phone',
          label: '',
          width: 30,
          excel: false
        },
        {
          key: 'nickname',
          label: '用户昵称',
          minWidth: 100
        },
        {
          key: 'realname',
          label: '实际姓名',
          minWidth: 70,
        },
        // {
        //   key: 'remarkName',
        //   label: '用户备注',
        //   minWidth: 70
        // },
        {
          key: 'resChannelId',
          label: '渠道',
          minWidth: 70,
          format:{
            list: this.$store.state.baseData.resChannelList,
            key: 'id',
            value: 'channelName'
          },
          default: ''
        },
        {
          key: 'resType',
          label: '来源',
          minWidth: 70,
          format:{
            list: this.$store.state.baseData.secTypeList,
            key: 'id',
            value: 'resName'
          },
          default: '',
          hide: () => !this.tag.v161.visible
        },
        // {
        //   key: 'sales',
        //   label: '业务/合规/售后',
        //   minWidth: 140
        // },
        // {
        //   key: 'lastCalltime',
        //   label: '上次联系时间',
        //   minWidth: 140,
        //   default: '--'
        // },
        // {
        //   key: 'riskType',
        //   label: '风险测评',
        //   minWidth: 98,
        // },
        {
          key: 'isPass',
          label: '监察过滤',
          minWidth: 56,
          format: e => e ? '已审核' : '未审核'
        }
      ],
    }
  },
  props: {
    data: Array
  },
  inject: ['tag'],
  components: {
    Scratch,
    Callphone
  },
  methods: {
    riskFormat(type, score) {
      switch (type){
        case 0:
          return this.$store.getters ? score+'(保守型)' : 'C1'
        case 1:
          return this.$store.getters ? score+'(相对保守型)' : 'C2'
        case 2:
          return this.$store.getters ? score+'(稳健型)' : 'C3'
        case 3:
          return this.$store.getters ? score+'(相对积极型)' : 'C4'
        case 4:
          return this.$store.getters ? score+'(积极型)' : 'C5'
        default:
          return '未风测'
      }
    },
    setSelect(val) {
      this.$refs.table.setSelection(this.data.slice(0, val))
    }
  }
}
</script>