<template>
  <el-dialog-pro @close="close" width="100%">
    <div class="one-delete">
      <div 
        v-show="twoShow"
        class="title"
      >是否删除评论？</div>
      <div class="button">
        <div @click="close">取消</div>
        <div 
          class="sure"
          @click="deleteData"
        >{{twoShow ? '确定' : '删除评论'}}</div>
      </div>
    </div>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      twoShow: false
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  methods: {
    close() {
      this.twoShow = false
      this.$emit('update:show', false)
    },
    deleteData: throttle(async function() {
      if(!this.twoShow) {
        this.twoShow = true
        return
      }

      let { code,msg,errmsg } = await this.$http({
        url: '%CRM%/hr_info_message/del_qy_info_comment.sdcrm',
        data: {
          token: true,
          id: this.data.id
        }
      })

      if(code !== 8200) {
        this.$message.error('删除失败'+ msg || errmsg)
        return
      }
      
      this.$emit('change')
      this.close()
    })
  },
}
</script>
<style lang="scss" scoped>
/deep/ {
  .el-dialog {
    // margin: auto !important;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    border-radius: 5px !important;
    .el-dialog__header {
      display: none;
    }
    .el-dialog__footer {
      display: none;
    }
  }
  
}
.one-delete {
  width: 100%;
  height: 190px;
  padding-top: 50px;
  .title {
    font-size: 32px;
    line-height: 45px;
    color: #333;
    text-align: center;
  }
  .button {
    width: 535px;
    margin:0 auto 40px;
    padding-top: 40px;
    display: flex;
    justify-content: space-between;
    div {
      width: 224px;
      height: 66px;
      border: 2px solid #F6AC01;
      border-radius: 50px;
      font-size: 32px;
      line-height: 66px;
      text-align: center;
      color: #F09001;
      cursor: pointer;
      &.sure {
        color: #FFF;
        border: 0;
        width: 228px;
        height: 70px;
        line-height: 70px;
        background: linear-gradient(180deg, #F6AD01 0%, #EB7601 100%);
      }
    }
  }
}
</style>