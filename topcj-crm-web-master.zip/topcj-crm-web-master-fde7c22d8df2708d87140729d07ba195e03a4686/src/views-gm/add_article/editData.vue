<template>
  <el-dialog-pro
    @close="close"
    max-height
    top="24px"
  >
    <!-- 标题 -->
    <template #title>
      {{data ? '编辑' : '新增'}}文章内容
    </template>

    <!-- 表单内容 -->
    <el-form-pro
      class="left-form"
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <template #right>
      <el-form-pro
        class="right-form"
        :model="form"
        :config="rightConfig"
        ref="formRight"
      ></el-form-pro>
    </template>

    <!-- 底部按钮 -->
    <template #footer>
      <el-button
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button
        type="primary"
        size="small"
        @click="submit(0)"
        :loading="loading"
      >确 定</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data () {

    const groupList = []
    const search = function(list, options) {
      list.forEach(e => {
        const group = {
          prefixIcon: 'el-icon-folder',
          label: e.groupName,
          value: `group/${e.id}`,
          type: 'group',
          id: e.id,
          children: []
        }
        
        if(e.groupChildren.length) {
          search(e.groupChildren, group.children)
        }
        if(e.managerList.length) {
          group.children.push(...e.managerList.filter(e => e.isLock === 0).map(e => {
            return {
              prefixIcon: 'el-icon-user',
              label: e.realName,
              value: `manager/${e.id}`,
              type: 'manager',
              id: e.id,
            }
          }))
        }
        options.push(group)
      })
    } 

    search(this.$store.state.baseData.corpGroupTree, groupList)

    const formGroupList = []
    if(this.data?.groupList) {
      formGroupList.push(
        ...this.data.groupList.split(',').filter(e => e).map(e => `group/${e}`)
      )
    }
    if(this.data?.managerList) {
      formGroupList.push(
        ...this.data.managerList.split(',').filter(e => e).map(e => `manager/${e}`)
      )
    }

    return {
      loading: false,
      form: {
        title: this.data?.title ?? '',
        agentId: this.data ? String(this.data.agentId) : (this.isTopSystem ? this.agentList[0].appId : ''),
        description: this.data?.description ?? '',
        picurl: this.data?.picurl ?? '',
        isSign: this.data?.isSign === 1 ? true : false,
        groupList: formGroupList,
        fileUrl: this.data?.fileUrl ?? '',
        insType: this.data?.insType ?? '',
        content: this.data?.content ?? '',
      },
      config: {
        title: {
          type: 'input',
          label: '标题',
          wordLimit: 24,
          rule: [
            { required: true }
          ],
        },
        agentId: {
          type: 'select',
          label: '应用',
          options: this.agentList,
          valueKey: 'appId',
          labelKey: 'appName',
          rule: [
            { required: true }
          ],
          hide: this.isTopSystem
        },
        description: {
          type: 'textarea',
          label: '描述',
          hide: this.isTopSystem
        },
        insType: {
          type: 'select',
          label: '类别',
          options: this.categoryList,
          labelKey: 'typeName',
          valueKey: 'typeId',
          hide: !this.isTopSystem,
          rule: [
            { required: true }
          ],
        },
        fileUrl: {
          type: 'file',
          label: '文件上传',
          accept: '.pdf',
          hide: !this.isTopSystem
        },
        picurl: {
          type: 'image',
          label: '封面',
          rule: [
            { required: true }
          ],
        },
        groupList: {
          type: 'select-tree',
          options: groupList,
          label: '可见范围',
          filterable: true,
          multiple: true,
          hide: !this.isTopSystem,
          rule: [
            { required: true, type: 'array' }
          ],
        },
        isSign: {
          type: 'switch',
          label: '是否签署',
          hide: !this.isTopSystem,
        },
      },
      rightConfig: {
        content: {
          label: '内容',
          type: 'richtext',
          uploadImgMaxLength: 9,
          rule: [
            { required: true }
          ]
        },
      }
    }
  },
  props: {
    show: Boolean,
    data: Object,
    agentList: Array,
    categoryList: Array,
    isTopSystem: Boolean
  },
  methods: {
    submit: throttle(async function () {
      if (!await this.$refs.form.check()) return
      if (!await this.$refs.formRight.check()) return

      this.loading = true

      const groupList = []
      const managerList = []

      this.form.groupList.forEach(e => {
        if(e.indexOf('group') === 0) {
          groupList.push(e.split('/')[1])
        }
        if(e.indexOf('manager') === 0) {
          managerList.push(e.split('/')[1])
        }
      })

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/hr_info_message/set_qy_message.sdcrm',
        data: {
          token: true,
          id: this.data?.id ?? undefined,
          agentId: this.form.agentId,
          title: this.form.title,
          description: this.form.description ? this.form.description : '',
          picurl: this.form.picurl ? this.form.picurl : '',
          content: this.form.content,
          isSign: this.form.isSign ? 1 : 0,
          groupList: groupList.join(','),
          managerList: managerList.join(','),
          fileUrl: this.form.fileUrl,
          insType: typeof this.form.insType === 'number' ? this.form.insType : void 0,
          type: this.isTopSystem ? 2 : 1
        }
      })
      this.loading = false

      if (code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close () {
      this.$emit('update:show', false)
    },
  },
}
</script>
<style lang="scss" scoped>
.right-form {
  width: 690px;
  padding: 8px 20px 20px;
  box-sizing: border-box;
  height: 100%;
  /deep/ {
    .el-form-item__error {
      top: -31px;
      left: 50px;
    }
    .el-form-item__label-wrap {
      float: none;
    }
    .el-form-item__content {
      margin-left: 0 !important;
      height: calc(var(--popover-height) - 28px - 40px);
    }
  }
}
.select-group-manager-item-group::before {
  content: "1"
}
.select-group-manager-item-manager::before {
  content: "2"
}
</style>