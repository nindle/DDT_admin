<template>
  <div
    class="box"
    :class="isMobile ? 'mobile' : 'pc'"
    :style="viewStyle"
  >
    <div
      class="info-box"
      :class="{ 'scale-box': scale }"
    >
      <div class="info">
        <el-scrollbar-pro
          class="info-content"
          :class="{ nophone: scale }"
          ref="scrollbar"
        >
          <!-- 标题 -->
          <div class="content-title">
            <div>{{ infoItem.title }}</div>
            <div class="time">{{ infoItem.publishTime }}</div>
          </div>
          <!-- 内容模块 -->
          <msg-text
            class="content"
            :text="infoItem.content"
            face
            :face-theme="`new`"
            ref="msgtext"
          />

          <!-- PDF预览 -->
          <pdf
            ref="pdf"
            :src="pdfUrl"
            v-for="i in numPages"
            :key="i"
            :page="i"
          />

          <!-- 阅读人数模块 -->
          <div
            v-if="!isPreview && showisPreview"
            class="read"
            ref="readBox"
          >
            <span>已有{{ infoItem.readCount }}人阅读</span>
            <div
              class="read-list"
              v-show="readList.length"
            >
              <span class="list">{{ readList.join('、') }}</span>
            </div>
          </div>

          <!-- 评论区模块 -->
          <div
            v-if="!isPreview && showisPreview && !isTopSystem"
            class="comment"
          >
            <div
              v-for="(e, i) in commentList"
              :key="i"
              class="com-item"
              ref="comment"
            >
              <div class="com-head">
                <div
                  class="com-image"
                  :style="{ backgroundImage: `url(${e.type ? e.avatar : articleAnonymousHaed})` }"
                ></div>
                <div class="com-name">
                  <span :class="{ show: !e.type }">{{ e.name }}</span>
                  <span>{{ e.ctime | timeDistance }}</span>
                </div>
              </div>
              <div
                class="com-content"
                @click="popover(e)"
              >
                <div
                  class="quote"
                  v-if="e.quoteId"
                >
                  {{ e.quoteVisible ? `回复${commentList.find(item => item.id === e.quoteId).name}` : '该评论已删除' }}
                  <span v-if="e.quoteVisible">
                    <msg-text
                      :text="e.quoteContent"
                      face
                      :face-theme="`new`"
                    />
                  </span>
                </div>
                <msg-text
                  class="comment-content"
                  :text="e.content"
                  face
                  :face-theme="`new`"
                />
              </div>
              <div class="operation">
                <div @click="reply(e)">回复</div>
                <div
                  @click="setCommentLike(e)"
                  class="com-like"
                  :class="{ tolike: !!e.flag }"
                >{{ e.likesCount ? `${e.likesCount}` : 0 }}</div>
              </div>
            </div>
          </div>
        </el-scrollbar-pro>

        <!-- 写评论模块 -->
        <div
          v-if="!isPreview && showisPreview && !isTopSystem"
          class="fixed-input"
          :class="{ 'show-face': showFace }"
          ref="inputView"
        >
          <div
            class="quota"
            v-if="isQuote"
          >
            回复：{{ isQuote.name }}
            <i
              class="el-icon-close"
              @click="isQuote = null"
            ></i>
          </div>
          <div class="input-box">
            <input
              ref="input"
              enterkeyhint="send"
              v-model="commentInput"
              placeholder="写评论..."
              @focus="focusInput"
              @keyup.enter="send"
            />
            <div class="fixed-operation">
              <div
                class="face"
                :class="{ 'yes-face': showFace }"
                @click="showFace = !showFace"
              ></div>
              <div
                class="face no-anonymous"
                :class="{ anonymous: isAnonymous }"
                @click="anonymous"
              ></div>
              <div
                v-show="!commentInput.length"
                class="face like"
                @click="setInfoLike()"
                :class="{ 'yes-like': infoItem.flag, 'like-count': !infoItem.likesCount }"
                :data-text="`${infoItem.likesCount > 99 ? '+99' : infoItem.likesCount}`"
              ></div>
              <div
                v-show="commentInput.length"
                class="face send"
                @click="send()"
              ></div>
            </div>
          </div>

          <transition name="slide">
            <el-scrollbar-pro
              v-show="showFace"
              class="face-list"
            >
              <select-face
                @select="inputHtml"
                :length="55"
                :face-theme="`new`"
              ></select-face>
            </el-scrollbar-pro>
          </transition>
        </div>

        <!-- 签署确认 -->
        <div
          :class="infoItem.signImg !== null ?  'signed signednone' : 'signed'"
          @click="addSignedFn"
          v-if="!isPreview && infoItem.isSign == 1"
        >
          {{infoItem.signImg !== null ? '已签字确认' :'制度签收确认 >>'}}
        </div>

        <!-- 签署画板 -->

        <div
          :class="signedConcentShow? 'boxShow':''"
          v-show="signedConcentShow"
        >
          <div
            class="signedconcent"
            v-show="signedConcentShow"
            ref="signedconcent"
          >
            <div
              class="closeX el-icon-circle-close"
              @click="deleteSignedFn"
            ></div>

            <div
              class="concent"
              ref="concent"
            >
              <div 
                class="confirm"
                v-if="false"  
              >* 请输入<span>本人理解并接受此公司内部考核管理办法并严格遵守</span> 进行确认。
                <el-input
                  v-model="confirm"
                  placeholder="请输入..."
                  @focus="focusFn"
                  @blur="blurFn"
                  :disabled="infoItem.signImg !== null"
                ></el-input>
              </div>

              <!-- 已签署图片 -->
              <div
                v-if="infoItem.signImg !== null"
                style="position: relative;z-index: 2;"
              >
                <img
                  :src="infoItem.signImg"
                  alt=""
                />
              </div>

              <!-- 画板 -->
              <canvas
                v-else
                :width="canvasWidth"
                :height="canvasHeight"
                ref="canvas"
                style="position: relative;z-index: 2;"
                @touchstart.prevent="touchstart"
                @touchmove.prevent="touchmove"
                @touchend.prevent="touchend"
                @mousedown.prevent="onmousedown"
                @mousemove.prevent="onmousemove"
                @mouseup.prevent="onmouseup"
                @mouseover.prevent="mouseover"
              ></canvas>

              <div
                class="signHint"
                v-if="signHint && infoItem.signImg == null"
              >此处<br />签名</div>

            </div>
            <!-- 确认按钮 -->
            <div class="bottomBtn">
              <el-button
                @click="clear"
                :class="infoItem.signImg !== null ? 'bottomBtnClear clearNone' : 'bottomBtnClear'"
                :disabled="infoItem.signImg !== null"
              >清空签名</el-button>
              <el-button
                :class="infoItem.signImg !== null ? 'bottomBtnOk signImgOk' : 'bottomBtnOk'"
                @click="sureSignedFn"
                :disabled="infoItem.signImg !== null"
              >签 字</el-button>
            </div>
          </div>
        </div>

        <page-delete
          v-if="showPopover"
          :show.sync="showPopover"
          :data="popoverData"
          :scale="scale"
          @change="getCommentList(infoId)"
        />
      </div>
    </div>
  </div>
</template>
<script>
import pdf from 'vue-pdf'
import { debounce, device, throttle, base2file } from '../../assets/js/tool'
import SelectFace from '../../components/message-input/selectFace.vue'
import MsgText from '../../components/message/msg-text.vue'
import PageDelete from './pageDelete.vue'
import articleAnonymousHaed from '../../assets/images/anonymous-head.png'
export default {
  name: 'qywx-article',
  data () {
    return {
      pdfUrl: '',
      numPages: null, // pdf 总页数
      isMobile: device.isMobile,
      viewStyle: {},
      infoItem: [],
      likeList: [],
      readList: [],
      commentList: [],
      // commentVisible: 1,
      commentInput: '',
      isAnonymous: false,
      isQuote: null,
      showisPreview: false,
      // 弹窗
      showPopover: false,
      popoverData: {},

      showFace: false,
      articleAnonymousHaed,
      // 缩放
      scale: true,
      signedConcentShow: false, //签署画布展示

      ctx: null, //画布
      lastX: 0, //坐标
      lastY: 0,
      mousePressed: false, //画笔状态
      canvasHeight: 0, //画布高度
      canvasWidth: 0,//画布高度
      confirm: '', //确认签署内容
      signHint: true,

      //顶点制度
      isTopSystem: false
    }
  },
  computed: {
    infoId () {
      return Number(this.$route.params.id)
    },
    isPreview () {
      return this.$route.meta.preview
    }
  },
  methods: {
    // 计算PDF总页数
    getNumPages () {
      let loadingTask = pdf.createLoadingTask(this.pdfUrl)
      loadingTask.promise.then(pdf => {
        this.numPages = pdf.numPages
      }).catch(err => {
        console.error('pdf 加载失败', err);
      })
    },

    // 获取资讯内容
    getInfoList: throttle(async function () {
      let { result } = await this.$http({
        url: '%CRM%/hr_info_message/get_qy_message_list.sdcrm',
        data: {
          token: true,
          id: this.infoId
        }
      })
      this.infoItem = {
        ...result.records[0],
        infoVisible: !result.records[0].flag
      }
      this.isTopSystem = this.infoItem.type === 2

      if (this.infoItem.signImg) {
        this.confirm = '本人理解并接受此公司内部考核管理办法并严格遵守'
      }
      if (this.infoItem.fileUrl) {
        this.pdfUrl = this.infoItem.fileUrl
        this.getNumPages()
      }
      this.showisPreview = true
      this.getLikeList(this.infoItem.id)
      this.getCommentList(this.infoItem.id)
      this.getReadList(this.infoItem.id)
    }),
    // 获取点赞列表
    async getLikeList (id) {
      let { result } = await this.$http({
        url: '%CRM%/hr_info_message/get_qy_info_likes_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
          infoId: id
        }
      })
      if (!this.isPreview && !this.isTopSystem) {
        let width = this.$refs.readBox.getBoundingClientRect().width * 2 - 48 - 120 - `${result.length}`.length * 16
        let count = Math.ceil(width / 24)
        this.likeList =
          result
            .map(e => e.managerName)
            .filter(e => {
              count -= e.length + 1
              return count > 0
            })
            .join('、') + (count < 0 ? ` ...等${result.length}人点赞` : '')
      }
    },
    async getReadList (id) {
      let { result } = await this.$http({
        url: '%CRM%/hr_info_message/get_qy_info_read_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
          infoId: id
        }
      })

      this.readList = result.map(e => e.managerName)
    },
    // 获取评论列表
    async getCommentList (id) {
      let { result } = await this.$http({
        url: '%CRM%/hr_info_message/get_qy_info_comment_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
          infoId: id
        }
      })

      this.commentList = result.map(e => {
        return {
          ...e,
          name: e.type ? e.createrName : '匿名用户',
          commentVisible: !e.flag
        }
      })
    },
    // 设置阅读量
    async setRead () {
      await this.$http({
        url: '%CRM%/hr_info_message/set_qy_info_read.sdcrm',
        data: {
          token: true,
          infoId: this.infoId
        }
      })
    },
    // 评论点赞
    setCommentLike: throttle(async function (e) {
      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/hr_info_message/set_qy_info_comment_likes.sdcrm',
        data: {
          token: true,
          commentId: e.id,
          visible: Number(e.commentVisible)
        }
      })

      if (code !== 8200) {
        this.$message.error('点赞失败' + msg || errmsg)
        return
      }

      this.getCommentList(this.infoId)
    }),
    // 资讯点赞
    setInfoLike: throttle(async function () {
      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/hr_info_message/set_qy_info_likes.sdcrm',
        data: {
          token: true,
          infoId: this.infoId,
          visible: Number(this.infoItem.infoVisible)
        }
      })
      if (code !== 8200) {
        this.$message.error('点赞失败' + msg || errmsg)
        return
      }

      this.getInfoList()
    }),
    //聚焦
    focusInput () {
      this.showFace = false
      setTimeout(() => {
        document.scrollingElement.scrollTop = document.scrollingElement.offsetHeight
      }, 300)
    },
    // 发送评论
    send: debounce(async function () {
      if (!this.commentInput) {
        this.$message.warning('请输入评论')
        return
      }

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/hr_info_message/add_qy_info_comment.sdcrm',
        data: {
          token: true,
          quoteId: this.isQuote?.id,
          content: this.commentInput,
          type: this.isAnonymous ? 0 : 1,
          infoId: this.infoId
        }
      })

      if (code !== 8200) {
        this.$message.error('评论失败' + msg || errmsg)
        return
      }

      this.getCommentList(this.infoId)
      this.go()
      this.commentInput = ''
      this.isQuote = null
    }),
    anonymous () {
      this.isAnonymous = !this.isAnonymous
    },
    // 回复
    reply (e) {
      this.$refs.input.focus()
      this.isQuote = e
    },
    go () {
      let h = this.$refs.msgtext.$el.offsetHeight
      this.$refs.scrollbar.scrollTop(h)
    },
    popover (data) {
      if (data.createrId !== this.$store.state.managerInfo.id) {
        return
      }
      this.showPopover = true
      this.popoverData = data
    },
    inputHtml (data) {
      this.commentInput += data
      this.$refs.input.focus()
    },

    focusFn () {
      this.signHint = false
      this.$refs.canvas.style.display = "none"
    },

    blurFn () {
      this.$refs.canvas.style.display = "block"
      this.signHint = true
    },

    //验证canvas画布是否为空
    isCanvasBlank (canvas) {
      var blank = document.createElement('canvas');//系统获取一个空canvas对象
      blank.width = canvas.width;
      blank.height = canvas.height;
      blank.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
      return canvas.toDataURL() == blank.toDataURL();//比较值相等则为空
    },

    // 弹出画布
    addSignedFn () {
      this.signedConcentShow = true
      if(this.$refs.inputView) {
        this.$refs.inputView.style.display = 'none'
      }
      
      setTimeout(() => {
        if (this.infoItem.signImg == null) {
          this.ctx = this.$refs.canvas.getContext('2d')
          this.canvasHeight = this.$refs.concent.offsetHeight
          this.canvasWidth = this.$refs.concent.offsetWidth
        }
      }, 300)
    },

    // 关闭画布
    deleteSignedFn () {
      this.signedConcentShow = false
      if(this.$refs.inputView) {
        this.$refs.inputView.style.display = 'block'
      }
    },
    // 确认签字
    async sureSignedFn () {
      // if (this.confirm !== '本人理解并接受此公司内部考核管理办法并严格遵守') {
      //   this.$message.error('请输入正确文字！')
      //   return
      // }
      if (this.isCanvasBlank(this.$refs.canvas)) {
        this.$message.error('签名不可为空！')
        return
      }

      const signImg = base2file(this.$refs.canvas.toDataURL('image/png'), 'signName.png')
      // 上传签署图片
      let { result } = await this.$http({
        mode: 'form',
        url: '%CRM%/api/upload_file.sdcrm',
        data: {
          token: true,
          uploadFile: signImg
        }
      })
      // 确认签署
      let { code } = await this.$http({
        mode: 'post',
        url: '%CRM%/hr_info_message/set_qy_info_sign.sdcrm',
        data: {
          token: true,
          infoId: Number(this.$route.params.id),
          signImg: result.url
        }
      })
      if (code !== 8200) {
        this.$message.error('签署失败！')
        return
      }
      this.getInfoList()
      this.signedConcentShow = false
      this.$refs.inputView.style.display = 'block'
    },
    // 清空画布
    clear () {
      this.ctx.setTransform(1, 0, 0, 1, 0, 0)
      this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height)
      // this.signHint = true;
    },
    // 移动端touchstart事件
    touchstart (e) {
      if (e.targetTouches.length === 1) {
        e.preventDefault()
        let touch = e.targetTouches[0]
        this.mousePressed = true
        let offsetLeft = (e.view.innerWidth - 345) / 2
        const offsetTop = ((e.view.innerHeight - this.$refs.concent.scrollHeight)) / 2.51
        this.draw(touch.pageX - offsetLeft, touch.pageY - offsetTop, false)
      }
    },
    // 移动端touchmove事件
    touchmove (e) {
      // this.signHint = false;
      if (e.targetTouches.length === 1) {
        let touch = e.targetTouches[0]
        if (this.mousePressed) {
          e.preventDefault()
          let offsetLeft = (e.view.innerWidth - 345) / 2
          const offsetTop = ((e.view.innerHeight - this.$refs.concent.scrollHeight)) / 2.51
          this.draw(touch.pageX - offsetLeft, touch.pageY - offsetTop, true)
        }
      }
    },
    // 移动端touchend事件
    touchend (e) {
      if (e.targetTouches.length === 1) {
        e.preventDefault()
        this.mousePressed = false
      }
    },
    // PC端onmousedown事件
    onmousedown (e) {
      this.mousePressed = true
      this.draw(e.offsetX, e.offsetY, false)
    },
    // PC端onmousemove事件
    onmousemove (e) {
      if (this.mousePressed) {
        this.draw(e.offsetX, e.offsetY, true)
      }
    },
    // PC端onmouseup事件
    onmouseup () {
      this.mousePressed = false
    },
    // PC端mouseover事件
    mouseover () {
      this.mousePressed = false
    },
    draw (x, y, isDown) {
      if (isDown) {
        this.ctx.beginPath()
        this.ctx.strokeStyle = '#000000'
        this.ctx.lineWidth = 4
        this.ctx.lineJoin = 'round'
        this.ctx.moveTo(this.lastX, this.lastY)
        this.ctx.lineTo(x, y)
        this.ctx.closePath()
        this.ctx.stroke()
      }
      this.lastX = x
      this.lastY = y
    },
  },
  components: {
    MsgText,
    PageDelete,
    SelectFace,
    pdf
  },
  created () {
    // let d = device
    // if (d.isMobile) {
    //   import('./mobile.scss')
    // } else {
    //   import('./pc.scss')
    // }
    this.getInfoList()
    this.setRead()
  },
  destroyed () {
    document.getElementById('viewport').remove()
  }
}
</script>
<style lang="scss" scoped>
@import '../../assets/css/common.scss';
.box.mobile {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  width: 100%;
  height: 100%;
  margin: 0 auto;
  background: #fff;
  .info-box {
    width: 100%;
    height: 100%;
    .info {
      width: 100%;
      height: 100%;
      position: relative;
      /deep/ {
        .scrollbar-view {
          padding: 0 12px;
        }
      }
      .info-content {
        height: calc(100% - 60px);
        font-size: 16px;
        .content-title {
          margin-bottom: 16px;
          padding: 20px 20px 0;
          div {
            font-size: 28px;
            color: #333;
            font-weight: 600;
            margin-bottom: 6px;
          }
          .time {
            font-size: 16px;
            color: #666;
            font-weight: 400;
          }
        }

        .content {
          color: #333;
          font-size: 16px;
          overflow-x: hidden;
          /deep/ {
            img {
              max-width: 100%;
            }
            b {
              background: rgba(0, 0, 0, 0);
              color: #333;
            }
            iframe {
              width: 560px;
              height: 338px;
              left: -20px;
            }
          }
          :deep(font[size='1']) {
            font-size: 12px;
          }
          :deep(font[size='2']) {
            font-size: 14px;
          }
          :deep(font[size='3']) {
            font-size: 16px;
          }
          :deep(font[size='4']) {
            font-size: 18px;
          }
          :deep(font[size='5']) {
            font-size: 20px;
          }
          :deep(font[size='6']) {
            font-size: 22px;
          }
          :deep(font[size='7']) {
            font-size: 24px;
          }
        }

        .read {
          margin: 20px;
          padding-bottom: 20px;
          font-size: 16px;
          line-height: 20px;
          color: #999;
          border-bottom: 1px solid #e8e8e8;
          .read-list {
            margin-top: 12px;
          }
          .like {
            min-height: 18px;
            line-height: 18px;
            margin-top: 12px;
            font-size: 14px;
            color: #333333;
            position: relative;
            text-indent: 24px;
            .list {
              max-height: 36px;
            }
            &::before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              width: 18px;
              height: 18px;
              @include image(article-like, center/cover no-repeat);
            }
            .number {
              padding-right: 62px;
              background: #fff;
              text-align: left;
              position: relative;
              left: 195px;
              bottom: 21px;
            }
          }
        }

        .comment {
          padding: 20px;
          .com-item {
            margin-bottom: 20px;
            .com-head {
              display: flex;
              align-items: center;
              .com-image {
                width: 33px;
                height: 33px;
                border-radius: 50%;
                @include image(headimg_manager, center/cover no-repeat);
              }
              .com-name {
                margin-left: 10px;
                display: flex;
                flex-direction: column;
                span {
                  font-size: 12px;
                  color: #888;
                  line-height: 14px;
                  &:first-child {
                    font-size: 16px;
                    color: #333333;
                    line-height: 20px;
                    margin-bottom: 5px;
                    position: relative;
                    &::after {
                      content: '匿名';
                      opacity: 0;
                      position: absolute;
                      top: 3px;
                      width: 40px;
                      line-height: 20px;
                      border-radius: 3px;
                      background: #2f89ff;
                      color: #fff;
                      text-align: center;
                      font-size: 14px;
                      margin-left: 6px;
                    }
                    &.show {
                      &::after {
                        opacity: 1;
                      }
                    }
                  }
                }
              }
            }
            .com-content {
              font-size: 14px;
              color: #666;
              margin: 8px 0 8px 48px;
              cursor: pointer;
              .quote {
                font-size: 14px;
                color: rgba($color: #ea7500, $alpha: 0.65);
                padding: 0 0 6px 6px;
                position: relative;
                display: flex;
                line-height: 17px;
                &::before {
                  content: '';
                  position: absolute;
                  top: 0;
                  left: 0;
                  width: 2px;
                  height: 17px;
                  background: #ff8000;
                }
                span {
                  max-width: 100px;
                  font-size: 14px;
                  line-height: 17px;
                  background: rgba(#ff8000, 0.15);
                  margin-left: 10px;
                  padding: 0 4px;
                  /deep/ {
                    .msg-text {
                      @include ellipsis;
                    }
                  }
                }
              }
              .comment-content {
                line-height: 17px;
                /deep/ {
                  .face-new {
                    width: 1.4em;
                    height: 1.4em;
                  }
                }
              }
            }
            .operation {
              width: calc(100% - 55px);
              height: 20px;
              display: flex;
              align-items: center;
              justify-content: space-between;
              padding-left: 48px;
              color: #0b266f;
              font-size: 14px;
              line-height: 20px;
              div {
                cursor: pointer;
              }
              .com-like {
                font-size: 16px;
                color: #ccc;
                padding: 0 3px 0 26px;
                position: relative;
                &::before {
                  content: '';
                  position: absolute;
                  left: 0;
                  top: -2px;
                  width: 24px;
                  height: 24px;
                  @include image(comment-nolike, center/cover no-repeat);
                }
                &.tolike {
                  &::before {
                    @include image(comment-yeslike, center/cover no-repeat);
                    background-size: 80%;
                  }
                }
              }
            }
          }
        }
      }
      .fixed-input {
        width: 100%;
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        background: #fff;
        z-index: 99;
        border-top: 1px solid #f5f5f5;
        .input-box {
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 12px;
          input {
            height: 30px;
            width: calc(100% - 118px);
            font-size: 14px;
            background: #eee;
            border: 0;
            border-radius: 25px;
            padding: 0 10px;
            box-sizing: border-box;
            &::placeholder {
              margin-left: 23px;
              padding-left: 23px;
              color: #ccc;
              font-size: 16px;
              @include image(input-icon, left/contain no-repeat);
            }
            &:focus {
              &::placeholder {
                opacity: 0;
              }
            }
          }
          .fixed-operation {
            width: 100px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            .face {
              width: 24px;
              height: 24px;
              cursor: pointer;
              @include image(article-noface, center/cover no-repeat);
              &.yes-face {
                @include image(article-face, center/cover no-repeat);
              }
              &.send {
                @include image(article-send, center/cover no-repeat);
              }
              &.like {
                @include image(article-nolike, center/cover no-repeat);
                position: relative;
                &.yes-like {
                  @include image(comment-yeslike, center/cover no-repeat);
                }
                &.like-count {
                  &::after {
                    display: none;
                  }
                }
                &::after {
                  content: attr(data-text);
                  position: absolute;
                  // right: -44px;
                  // top: -8px;
                  // width: 20px;
                  // height: 10px;

                  right: -19px;
                  top: -10px;
                  width: 20px;
                  height: 22px;
                  
                  background: #e11919;
                  border-radius: 5px;
                  color: #fff;
                  text-align: center;
                }
              }
              &.no-anonymous {
                margin-right: 0;
                @include image(article-noanonymous, center/cover no-repeat);
                &.anonymous {
                  @include image(article-anonymous, center/cover no-repeat);
                }
              }
            }
          }
        }
        .quota {
          font-size: 14px;
          color: #999;
          padding: 4px 22px 1px;
        }
        .face-list {
          &.slide-enter-active,
          &.slide-leave-active {
            transition: height 0.3s;
          }
          &.slide-enter,
          &.slide-leave-to {
            height: 0 !important;
          }
          width: 100%;
          height: 120px;
          background: #fff;
          /deep/ {
            .el-scrollbar {
              height: 100%;
              .el-scrollbar__wrap {
                max-height: 100%;
              }
            }
            .face-box {
              .msg-text {
                width: 25px;
                height: 25px;
                margin-left: 10px;
                margin-bottom: 10px;
                img {
                  width: 25px;
                  height: 25px;
                }
              }
            }
          }
        }
      }
      .signed {
        position: absolute;
        right: 15px;
        top: 65%;
        text-align: center;
        cursor: pointer;
        width: 154px;
        height: 40px;
        line-height: 40px;
        background: linear-gradient(175deg, #f95d22 0%, #e7322b 100%, #e7322b 100%);
        box-shadow: 0px 1px 9px 0px rgba(232, 51, 43, 0.24);
        border-radius: 40px;
        font-size: 16px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #ffffff;
      }
      .signednone {
        background: #ccc;
        box-shadow: 0px 0px 0px 0px rgba(232, 51, 43, 0.24);
      }
      .signedconcent {
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
        height: 83vh;
        animation: mymovean 0.7s 1;
        display: flex;
        flex-direction: column;
        justify-content: space-evenly;
        z-index: 9999;
        .concent {
          width: calc(100% - 30px);
          height: calc(100% - 68px);
          margin: 0 auto;
          border-radius: 4px;
          background: #fefffe;
          overflow: hidden;
          position: relative;
          .confirm {
            font-size: 13px;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #666666;
            padding: 20px 20px 0;
            span {
              color: #027aff;
            }
            .el-input {
              margin-top: 10px;
            }
          }
        }
        .closeX {
          position: absolute;
          right: 13px;
          top: -20px;
          font-size: 20px;
          color: #fefffe;
          cursor: pointer;
        }

        .bottomBtn {
          display: flex;
          align-items: center;
          justify-content: center;
          .bottomBtnClear {
            width: 135px;
            height: 40px;
            box-shadow: 0px 1px 9px 0px rgba(232, 51, 43, 0.24);
            border-radius: 40px;
            border: 1px solid #ed4128;
            font-size: 20px;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #ed4127;
            background-color: #646564;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .bottomBtnOk {
            width: 135px;
            height: 40px;
            background: linear-gradient(175deg, #f95d22 0%, #e7322b 100%, #e7322b 100%);
            box-shadow: 0px 1px 9px 0px rgba(232, 51, 43, 0.24);
            border-radius: 20px;
            font-size: 20px;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #ffffff;
            border: 0;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .signImgOk {
            background: #ef7873;
          }
          .clearNone {
            background-color: #cccccc;
          }
        }
        .signHint {
          position: absolute;
          left: 50%;
          top: 50%;
          transform: translate(-50%, -50%);
          font-size: 85px;
          font-family: PingFangSC-Regular, PingFang SC;
          font-weight: 400;
          color: #dfdfdf;
          z-index: 1;
        }
      }
    }
    .boxShow {
      width: 100%;
      position: absolute;
      top: 0;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
    }
  }
}

.box.pc {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  width: 100%;
  height: 100%;
  margin: 0 auto;
  background: #fff;
  .info-box {
    height: 100%;
    width: 750px;
    margin: 0 auto;
    .info {
      width: 100%;
      height: 100%;
      position: relative;
      /deep/ {
        .scrollbar-view {
          padding: 0 12px;
        }
      }
      .info-content {
        height: calc(100% - 60px);
        font-size: 16px;
        .content-title {
          margin-bottom: 16px;
          padding: 20px 20px 0;
          div {
            font-size: 28px;
            color: #333;
            font-weight: 600;
            margin-bottom: 6px;
          }
          .time {
            font-size: 16px;
            color: #666;
            font-weight: 400;
          }
        }

        .content {
          color: #333;
          font-size: 16px;
          padding: 0 20px;
          overflow-x: hidden;
          /deep/ {
            img {
              max-width: 100%;
            }
            b {
              background: rgba(0, 0, 0, 0);
              color: #333;
            }
            iframe {
              width: 560px;
              height: 338px;
              left: -20px;
            }
          }
          :deep(font[size='1']) {
            font-size: 12px;
          }
          :deep(font[size='2']) {
            font-size: 14px;
          }
          :deep(font[size='3']) {
            font-size: 16px;
          }
          :deep(font[size='4']) {
            font-size: 18px;
          }
          :deep(font[size='5']) {
            font-size: 20px;
          }
          :deep(font[size='6']) {
            font-size: 22px;
          }
          :deep(font[size='7']) {
            font-size: 24px;
          }
        }

        .read {
          margin: 20px;
          padding-bottom: 20px;
          font-size: 16px;
          line-height: 20px;
          color: #999;
          border-bottom: 1px solid #e8e8e8;
          .read-list {
            margin-top: 12px;
          }
          .like {
            min-height: 18px;
            line-height: 18px;
            margin-top: 12px;
            font-size: 14px;
            color: #333333;
            position: relative;
            text-indent: 24px;
            .list {
              max-height: 36px;
            }
            &::before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              width: 18px;
              height: 18px;
              @include image(article-like, center/cover no-repeat);
            }
            .number {
              padding-right: 62px;
              background: #fff;
              text-align: left;
              position: relative;
              left: 195px;
              bottom: 21px;
            }
          }
        }

        .comment {
          padding: 20px;
          .com-item {
            margin-bottom: 20px;
            .com-head {
              display: flex;
              align-items: center;
              .com-image {
                width: 33px;
                height: 33px;
                border-radius: 50%;
                @include image(headimg_manager, center/cover no-repeat);
              }
              .com-name {
                margin-left: 10px;
                display: flex;
                flex-direction: column;
                span {
                  font-size: 12px;
                  color: #888;
                  line-height: 14px;
                  &:first-child {
                    font-size: 16px;
                    color: #333333;
                    line-height: 20px;
                    margin-bottom: 5px;
                    position: relative;
                    &::after {
                      content: '匿名';
                      opacity: 0;
                      position: absolute;
                      top: 3px;
                      width: 40px;
                      line-height: 20px;
                      border-radius: 3px;
                      background: #2f89ff;
                      color: #fff;
                      text-align: center;
                      font-size: 14px;
                      margin-left: 6px;
                    }
                    &.show {
                      &::after {
                        opacity: 1;
                      }
                    }
                  }
                }
              }
            }
            .com-content {
              font-size: 14px;
              color: #666;
              margin: 8px 0 8px 48px;
              cursor: pointer;
              .quote {
                font-size: 14px;
                color: rgba($color: #ea7500, $alpha: 0.65);
                padding: 0 0 6px 6px;
                position: relative;
                display: flex;
                line-height: 17px;
                &::before {
                  content: '';
                  position: absolute;
                  top: 0;
                  left: 0;
                  width: 2px;
                  height: 17px;
                  background: #ff8000;
                }
                span {
                  max-width: 100px;
                  font-size: 14px;
                  line-height: 17px;
                  background: rgba(#ff8000, 0.15);
                  margin-left: 10px;
                  padding: 0 4px;
                  /deep/ {
                    .msg-text {
                      @include ellipsis;
                    }
                  }
                }
              }
              .comment-content {
                line-height: 17px;
                /deep/ {
                  .face-new {
                    width: 1.4em;
                    height: 1.4em;
                  }
                }
              }
            }
            .operation {
              width: calc(100% - 55px);
              height: 20px;
              display: flex;
              align-items: center;
              justify-content: space-between;
              padding-left: 48px;
              color: #0b266f;
              font-size: 14px;
              line-height: 20px;
              div {
                cursor: pointer;
              }
              .com-like {
                font-size: 16px;
                color: #ccc;
                padding: 0 3px 0 26px;
                position: relative;
                &::before {
                  content: '';
                  position: absolute;
                  left: 0;
                  top: -2px;
                  width: 24px;
                  height: 24px;
                  @include image(comment-nolike, center/cover no-repeat);
                }
                &.tolike {
                  &::before {
                    @include image(comment-yeslike, center/cover no-repeat);
                    background-size: 80%;
                  }
                }
              }
            }
          }
        }
      }
      .fixed-input {
        width: 750px;
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        background: #fff;
        z-index: 99;
        border-top: 1px solid #f5f5f5;
        .input-box {
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 0 12px;
          input {
            height: 30px;
            width: calc(100% - 118px);
            font-size: 14px;
            background: #eee;
            border: 0;
            border-radius: 25px;
            padding: 0 10px;
            box-sizing: border-box;
            &::placeholder {
              margin-left: 23px;
              padding-left: 23px;
              color: #ccc;
              font-size: 16px;
              @include image(input-icon, left/contain no-repeat);
            }
            &:focus {
              &::placeholder {
                opacity: 0;
              }
            }
          }
          .fixed-operation {
            width: 100px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            .face {
              width: 24px;
              height: 24px;
              cursor: pointer;
              @include image(article-noface, center/cover no-repeat);
              &.yes-face {
                @include image(article-face, center/cover no-repeat);
              }
              &.send {
                @include image(article-send, center/cover no-repeat);
              }
              &.like {
                @include image(article-nolike, center/cover no-repeat);
                position: relative;
                &.yes-like {
                  @include image(comment-yeslike, center/cover no-repeat);
                }
                &.like-count {
                  &::after {
                    display: none;
                  }
                }
                &::after {
                  content: attr(data-text);
                  position: absolute;
                  // right: -44px;
                  // top: -8px;
                  // width: 20px;
                  // height: 10px;

                  right: -12px;
                  top: -8px;
                  width: 20px;
                  height: 22px;
                  
                  background: #e11919;
                  border-radius: 5px;
                  color: #fff;
                  text-align: center;
                }
              }
              &.no-anonymous {
                margin-right: 0;
                @include image(article-noanonymous, center/cover no-repeat);
                &.anonymous {
                  @include image(article-anonymous, center/cover no-repeat);
                }
              }
            }
          }
        }
        .quota {
          font-size: 14px;
          color: #999;
          padding: 4px 22px 1px;
        }
        .face-list {
          &.slide-enter-active,
          &.slide-leave-active {
            transition: height 0.3s;
          }
          &.slide-enter,
          &.slide-leave-to {
            height: 0 !important;
          }
          width: 100%;
          height: 120px;
          background: #fff;
          /deep/ {
            .el-scrollbar {
              height: 100%;
              .el-scrollbar__wrap {
                max-height: 100%;
              }
            }
            .face-box {
              .msg-text {
                width: 25px;
                height: 25px;
                margin-left: 10px;
                margin-bottom: 10px;
                img {
                  width: 25px;
                  height: 25px;
                }
              }
            }
          }
        }
      }
      .signed {
        position: absolute;
        right: 15px;
        top: 65%;
        text-align: center;
        cursor: pointer;
        width: 154px;
        height: 40px;
        line-height: 40px;
        background: linear-gradient(175deg, #f95d22 0%, #e7322b 100%, #e7322b 100%);
        box-shadow: 0px 1px 9px 0px rgba(232, 51, 43, 0.24);
        border-radius: 40px;
        font-size: 16px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #ffffff;
      }
      .signednone {
        background: #ccc;
        box-shadow: 0px 0px 0px 0px rgba(232, 51, 43, 0.24);
      }
      .signedconcent {
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
        height: 85vh;
        animation: mymovean 0.7s 1;
        display: flex;
        flex-direction: column;
        justify-content: space-evenly;
        z-index: 9999;
        .concent {
          width: calc(100% - 30px);
          height: calc(100% - 68px);
          margin: 0 auto;
          border-radius: 4px;
          background: #fefffe;
          overflow: hidden;
          position: relative;
          .confirm {
            font-size: 13px;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #666666;
            padding: 20px 20px 0;
            span {
              color: #027aff;
            }
            .el-input {
              margin-top: 10px;
            }
          }
        }
        .closeX {
          position: absolute;
          right: 13px;
          top: -20px;
          font-size: 20px;
          color: #fefffe;
          cursor: pointer;
        }

        .bottomBtn {
          display: flex;
          align-items: center;
          justify-content: center;
          .bottomBtnClear {
            width: 135px;
            height: 40px;
            box-shadow: 0px 1px 9px 0px rgba(232, 51, 43, 0.24);
            border-radius: 40px;
            border: 1px solid #ed4128;
            font-size: 20px;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #ed4127;
            background-color: #646564;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .bottomBtnOk {
            width: 135px;
            height: 40px;
            background: linear-gradient(175deg, #f95d22 0%, #e7322b 100%, #e7322b 100%);
            box-shadow: 0px 1px 9px 0px rgba(232, 51, 43, 0.24);
            border-radius: 20px;
            font-size: 20px;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #ffffff;
            border: 0;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .signImgOk {
            background: #ef7873;
          }
          .clearNone {
            background-color: #cccccc;
          }
        }

        .signHint {
          position: absolute;
          left: 50%;
          top: 50%;
          transform: translate(-50%, -50%);
          font-size: 85px;
          font-family: PingFangSC-Regular, PingFang SC;
          font-weight: 400;
          color: #dfdfdf;
          z-index: 1;
        }
      }
    }
    .boxShow {
      width: 100%;
      position: absolute;
      top: 0;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
    }
  }
}

@keyframes mymovean {
  to {
    opacity: 1;
    top: 50%;
    -webkit-transform: translate(0, 0); /* Safari */
    transform: stranslate(0, 0); /* 标准语法 */
  }
  from {
    opacity: 0;
    top: 0%;
    -webkit-transform: translate(0, 540px); /* Safari */
    transform: stranslate(0, 540px); /* 标准语法 */
  }
}
</style>
