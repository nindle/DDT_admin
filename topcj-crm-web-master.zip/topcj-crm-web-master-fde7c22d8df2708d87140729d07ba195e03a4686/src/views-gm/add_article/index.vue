<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :class="{w: showRight}"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >

      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data
          :data="tabledata"
          :agent-list="config.agentId.options"
          :isTopSystem="isTopSystem"
          :category-list="config.insType.options"
          @edit="openPopover"
          @open="openRight"
          @change="getTableData"
          @msg="popoverData = $event; showMsgList = true;"
        />
      </template>

      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="popoverData"
          :isTopSystem="isTopSystem"
          :agent-list="config.agentId.options"
          :category-list="config.insType.options"
          @change="getTableData()"
        />

        <type-list
          v-if="showTypeList"
          :show.sync="showTypeList"
          @change="getCategoryList()"
        />
        
        <msg-list
          v-if="showMsgList"
          :show.sync="showMsgList"
          :data="popoverData"
          :agent-list="config.agentId.options"
        />
      </template>

    </el-layout-pro>

    <el-layout-pro
      v-if="showRight"
      class="right"
      :loading="loadingRight"
    >
      <template #screen>
        <el-screen-pro :config="detailConfig">
          <template #close>
            <i
              class="el-icon-close"
              @click="showRight = false"
            ></i>
          </template>
        </el-screen-pro>
      </template>

      <template #scroll>
        <right-box
          :data="rightData"
          :type='rightBoxType'
          :isTopSystem="isTopSystem"
          @opensign="opensign"
        />
      </template>
    </el-layout-pro>

    <RightTableData
      v-if="signOpen"
      :show.sync="signOpen"
      :info='this.signInfo'
      :item='this.signItem'
      :list='this.signList'
      @failFn='failFn'
    />
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import TypeList from './typeList'
import EditData from './editData'
import RightBox from './rightBox.vue'
import MsgList from './msgList.vue'
import RightTableData from './rightTableData.vue'

export default {
  name: 'gm-add_article',
  data () {
    const isTopSystem = this.$route.name === 'gm-top_system'
    return {
      isTopSystem,
      //加载状态
      loading: false,
      loadingRight: false,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      //新增展示修改
      showPopover: false,
      showMsgList: false,
      //编辑数据修改
      popoverData: null,
      //表格数据
      tabledata: [],
      //筛选数据
      screen: {
        time: [],
        agentId: '',
        insType: ''
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) }
        },
        agentId: {
          type: 'select',
          options: [],
          valueKey: 'appId',
          labelKey: 'appName',
          placeholder: '应用',
          hide: isTopSystem
        },
        insType: {
          type: 'select',
          options: [],
          valueKey: 'typeId',
          labelKey: 'typeName',
          placeholder: '类别',
          hide: !isTopSystem
        },
        time: {
          type: 'date-range',
        },
        type: {
          type: 'button',
          label: '类别管理',
          click: () => { this.showTypeList = true },
          hide: !isTopSystem
        }
      },
      detailConfig: {
        split: { type: 'split' },
        close: {}
      },
      //审核相关
      selectList: [],
      showReview: false,
      reviewList: [],
      // 右边评价等页面展现
      showRight: false,
      rightData: {},
      rightBoxType: '',
      // 签署图片列表
      signOpen: false,
      signList: [],
      signInfo: {},
      signItem: {},

      showTypeList: false
    }
  },
  components: {
    TableData,
    EditData,
    RightBox,
    MsgList,
    TypeList,
    RightTableData
  },
  methods: {
    //获取表格数据
    getTableData: throttle(async function (toFirst) {
      this.loading = true

      if (toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/hr_info_message/get_qy_message_list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          agentId: this.screen.agentId ? Number(this.screen.agentId) : undefined,
          stime: this.screen.time?.[0] ?? undefined,
          etime: this.screen.time?.[1] ?? undefined,
          type: this.isTopSystem ? 2 : 1,
          insType: typeof this.screen.insType === 'number' ? this.screen.insType : undefined 
        }
      })

      this.tabledata = result.records
      this.total = result.total

      this.loading = false
    }),
    //获取应用列表
    async getAgentList () {
      let { result } = await this.$http({
        url: '%CRM%/qywx/get_qywx_app_list.sdcrm',
        data: {
          token: true,
          isPage: 0,
          isHr: this.isTopSystem ? 2 : 1
        }
      })

      this.config.agentId.options.splice(0, this.config.agentId.options.length, ...result.filter(e => e))
    },
    //获取制度类型列表
    async getCategoryList() {
      let { result } = await this.$http({
        url: '%CRM%/setting/get_types/71.sdcrm',
        mode: 'get',
        data: {
          token: true,
        }
      })

      this.config.insType.options.splice(0,this.config.insType.options.length,...result)
    },
    //打开弹框
    openPopover (data) {
      this.popoverData = data
      this.showPopover = true
    },
    openRight (data, type) {
      this.showRight = true
      this.rightData = data
      this.rightBoxType = type
    },
    // 打开签署列表信息
    opensign (e, arr, item) {
      this.signOpen = true
      this.signInfo = item
      this.signItem = e
      this.signList = arr;
    },
    // 签署不通过
    async failFn (e) {
      let { code } = await this.$http({
        url: '%CRM%/hr_info_message/send_qy_message.sdcrm',
        data: {
          token: true,
          id: this.signInfo.id,
          agentId: this.signInfo.agentId,
          title: this.signInfo.title,
          description: this.signInfo.description,
          url: `${this.SYS.BOOKURL}/qywx/article/${this.signInfo.id}`,
          picurl: this.signInfo.picurl,
          type: 1,
          managerId: e.managerId,
        }
      })
      if (code === 8200) {
        this.$message.success('操作成功')
      }
    }
  },
  created () {
    this.getAgentList()
    if(this.isTopSystem) {
      this.getCategoryList()
    }
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  display: flex;
  justify-content: space-between;
  .box {
    width: 100%;
    height: 100%;
    background: #fff;
    &.w {
      width: calc(100% - 400px);
    }
  }
  .right {
    width: 400px;
    height: 100%;
    margin-left: 24px;
    background: #fff;
    position: relative;
    .el-icon-close {
      cursor: pointer;
    }
  }
}
</style>