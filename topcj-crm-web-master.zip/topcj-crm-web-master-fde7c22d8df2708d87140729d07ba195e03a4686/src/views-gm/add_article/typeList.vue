<template>
  <el-dialog-pro 
    @close="close"
    width="620px"
    max-height
  >
    <template #title>类别列表</template>
    <el-layout-pro
      class="pro_box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <template #table>
        <el-table-pro
          :head="head"
          :data="tableData"
          class="table"
        >
        </el-table-pro>
      </template>
    </el-layout-pro>
    
    
    <template 
      #right
      v-if="showRight"
    >
      <el-form-pro
        class="right-form"
        :model="form"
        :config="config"
        ref="form"
      >
      </el-form-pro>
    </template>

    <!--底部按钮-->
    <template #footer>
      <el-button 
        v-if="!showRight"
        size="small"
        type="primary"
        @click="init()"
      >新 增</el-button>
      <el-button 
        v-if="showRight"
        size="small"
        @click="showRight = false"
      >取 消</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      showRight: false,
      loading: false,
       //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //获取数据
      tableData: [],

      head: [
        {
          key: 'typeId',
          label: '类别ID',
          minWidth: 70,
        }, 
        {
          key: 'typeName',
          label: '类别名称',
          minWidth: 140,
        },
        {
          key: 'status',
          label: '状态',
          edit: 'switch',
          change: this.editStatus,
          inactiveValue: 0,
          activeValue: 1,
          width: 44
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: e => { this.init(e) }
          }
        }
      ],
      form: {
        typeId: '',
        id: '',
        typeName: '',
      },
      config: {
        typeName: {
          type: 'input',
          label: '新增类别',
          placeholder: '输入类别，回车添加',
          change: this.submit,
        }
      }
    }
  },
  props: {
    show: Boolean
  },
  methods: {
    getTableData: throttle(async function(toFirst){
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/category/get_category_list.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          categoryId: 71
        }
      })

      this.loading = false

      this.tableData = result.records
      this.total = result.total     
    }),

    close() {
      this.$emit('update:show', false)
      this.$emit('change')
    },
    async init(data = {id: '', typeId: '', typeName: ''}) {
      this.form.id = data.id
      this.form.typeId = data.typeId
      this.form.typeName = data.typeName
      this.config.typeName.label = typeof data.id === 'number' ? '编辑类别' : '新增类别'
      this.config.typeName.placeholder = typeof data.id === 'number' ? '输入类别，回车保存' : '输入类别，回车添加'
      this.showRight = true
      await this.$nextTick()
      this.$refs.form.$el.querySelector('input')?.focus()
    },
    submit: throttle(async function() {
      if(!this.form.typeName) {
        this.$message.error('请输入类别名称')
        return
      }

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/category/category_edit.sdcrm',
        data: {
          token: true,
          id: typeof this.form.id === 'number' ? this.form.id : undefined,
          typeId: typeof this.form.typeId === 'number' ? this.form.typeId : null,
          typeName: this.form.typeName,
          categoryId: 71
        }
      })

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success(`保存成功`)
      this.showRight = false
      this.getTableData(true)
    }),
    async editStatus(row) {
      await this.$http({
        url: '%CRM%/category/set_category_status.sdcrm',
        data: {
          token: true,
          id: row.id,
          status: row.status,
        }
      })
    }
  },
  created() {
    this.getTableData()
  }
}
</script>
<style lang="scss" scoped>
.pro_box {
  height: calc(var(--scroll-height) - 27px);
}
/deep/ {
  .content-box-view {
    width: calc(100% - 40px);
    .table-box {
      // width: 100%;
      padding: 0 0 24px 0;
    }
  }
}
.right-form {
  padding: 53px 24px 0 24px;
  width: 373px;
}

</style>