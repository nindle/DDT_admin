<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-count="{ row }">
      <div
        @click="$emit('open',row,'count')"
        :style="{color: '#3089FF',}"
        style="cursor: pointer;"
      >{{ isTopSystem ? row.readCount : `${row.readCount}/${row.writeCount}/${row.likesCount}`}}</div>
    </template>

    <template #body-sign="{ row }">
      <div
        @click="$emit('open',row,'sign')"
        :style="{color: '#3089FF',}"
        style="cursor: pointer;"
      >{{`${row.inSignCount}/${row.signCount-row.inSignCount} `}}</div>
    </template>
  </el-table-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data () {
    return {
      head: [
        {
          key: 'publishTime',
          label: '发布时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd hh:mm:ss') : '--'
        },
        {
          key: 'agentId',
          label: '栏目',
          minWidth: 84,
          format: {
            list: this.agentList,
            key: 'appId',
            value: 'appName',
          },
          hide: this.isTopSystem,
        },
        {
          key: 'insType',
          label: '类别',
          minWidth: 84,
          format: {
            list: this.categoryList,
            key: 'typeId',
            value: 'typeName',
          },
          hide: !this.isTopSystem,
        },
        {
          key: 'title',
          label: '标题',
          minWidth: 100,
        },
        {
          key: 'publisher',
          label: '发布人',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.managerList,
            key: 'id',
            value: 'realName'
          },
          default: '--'
        },
        // {
        //   key: 'picurl',
        //   label: '封面',
        //   width: 44,
        //   button: {
        //     type: 'text',
        //     icon: 'el-icon-view',
        //     label: '查看',
        //     click: row => { this.$imageview({
        //       list: [row.picurl],
        //       index: 0
        //     })}
        //   }
        // },
        // {
        //   key: 'description',
        //   label: '描述',
        //   minWidth: 140
        // },
        {
          key: 'status',
          label: '状态',
          minWidth: 42,
          format: {
            '0': '未发送',
            '1': '已发送',
          }
        },
        {
          key: 'count',
          label: this.isTopSystem ? '阅读量' : '阅读/评论/点赞',
          minWidth: 98,
          // style: row => { 
          //   if(row.publisher && (row.readCount + row.writeCount + row.likesCount) !== 0) {
          //     document.getElementsByClassName('has-click')
          //   }
          // },
          // format: (a,b,c) => {return `${a || 0}/${b || 0}/${c || 0}`},
          // click: row => this.$emit('open' ,row)
        },
        {
          key: 'sign',
          label: '签署（是/否）',
          minWidth: 98,
          hide: !this.isTopSystem,
          // style: row => { 
          //   if(row.publisher && (row.readCount + row.writeCount + row.likesCount) !== 0) {
          //     document.getElementsByClassName('has-click')
          //   }
          // },
          // format: (a,b,c) => {return `${a || 0}/${b || 0}/${c || 0}`},
          // click: row => this.$emit('open' ,row)
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: row => { this.$emit('edit', row) }
          }
        },
        {
          key: 'preview',
          label: '',
          width: 44,
          button: {
            // popconfirm: '确认发布吗？',
            type: 'text',
            icon: 'el-icon-view',
            label: '预览',
            click: row => { this.$open(`${this.SYS.URL}/qywx/article/preview/${row.id}`) }
          }
        },
        {
          key: 'upload',
          label: '',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-s-promotion',
            label: '发布',
            click: row => this.uploadContent(row)
          }
        },
        {
          key: 'msglist',
          label: '',
          width: 70,
          button: {
            type: 'text',
            icon: 'el-icon-document',
            label: '发布列表',
            click: row => {
              this.$emit('msg', row)
            }
          }
        }
      ]
    }
  },
  props: {
    data: Array,
    agentList: Array,
    categoryList: Array,
    isTopSystem: Boolean
  },
  methods: {
    uploadContent: throttle(async function (row) {
      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/hr_info_message/send_qy_message.sdcrm',
        data: {
          token: true,
          id: row.id,
          url: `${this.SYS.BOOKURL}/qywx/article/${row.id}`,
          // groupList: row.join(',')
        }
      })

      if (code !== 8200) {
        this.$message.error('发布失败' + msg || errmsg)
        return
      }

      this.$message.success('发布成功')
      this.$emit('change')
    })
  }
}
</script>
<style lang="scss" scoped>
</style>