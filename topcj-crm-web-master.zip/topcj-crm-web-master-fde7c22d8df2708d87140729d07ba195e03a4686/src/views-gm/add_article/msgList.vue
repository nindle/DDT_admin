<template>
  <el-dialog-pro 
    @close="close"
    width="666px"
    max-height
  >
    <template #title>发送列表</template>
    <el-layout-pro
      class="pro_box"
      :loading="loading"
      @page-change="getTableData()"
    >
      <template #table>
        <el-table-pro
          :head="head"
          :data="tableData"
          class="table"
        ></el-table-pro>
      </template>
    </el-layout-pro>

    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >关 闭</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      loading: false,
      //获取数据
      tableData: [],

      head: [
        {
          key: 'id',
          label: '消息ID',
          minWidth: 70,
        }, 
        {
          key: 'agentId',
          label: '栏目',
          minWidth: 84,
          format: {
            list: this.agentList,
            key: 'appId',
            value: 'appName',
          }
        },
        {
          key: 'ctime',
          label: '发送时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'recallTime',
          label: '撤回时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '--'
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            popconfirm: '确定撤回吗？',
            type: 'text',
            icon: 'el-icon-back',
            label: '撤回',
            disabled: e => !!e.recallerId,
            click: this.recallMessage
          }
        }
      ]
    }
  },
  props: {
    show: Boolean,
    data: Object,
    agentList: Array
  },
  methods: {
    getTableData: throttle(async function(toFirst){
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/hr_info_message/get_recall_list.sdcrm',
        data: {
          token: true,
          isPage: 1,
          infoId: this.data.id
        }
      })

      this.loading = false

      this.tableData = result
    }),
    close() {
      this.$emit('update:show', false)
    },
    async recallMessage(row) {
      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/hr_info_message/recall_qy_message.sdcrm',
        data: {
          token: true,
          id: row.id,
        }
      })

      if(code !== 8200) {
        this.$message.error(`撤回失败：${ msg || errmsg }`)
        return
      }

      this.$message.success(`撤回成功`)
      row.recallerId = this.$store.state.managerInfo.id
      row.recallTime = Date.now()
    }
  },
  created() {
    this.getTableData()
  }
}
</script>
<style lang="scss" scoped>
/deep/ {
  .content-box-view {
    width: calc(100% - 40px);
    .table-box {
      // width: 100%;
      padding: 0;
      padding-bottom: 24px;
    }
  }
}
</style>