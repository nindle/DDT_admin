<template>
  <el-dialog-pro
    width="640px"
    @close="close"
  >

    <template #title>
      <div>{{`${item.managerName} 签字图片`}}</div>
    </template>

    <div class="signImg">
      <img
        :src="item.signImg"
        alt=""
      >
    </div>

    <template #footer>
      <el-button
        type="primary"
        size="small"
        @click="failFn"
      >重新签署</el-button>
      <el-button
        size="small"
        @click="upFn"
      >上一个</el-button>
      <el-button
        size="small"
        @click="nextFn"
      >下一个</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
export default {
  data () {
    return {}
  },
  props: {
    info: Object,
    list: Array,
    item: Object
  },
  methods: {
    close () {
      this.$emit('update:show', false)
    },

    // 下一个
    nextFn () {
      let num = this.$props.list.indexOf(this.$props.item)
      if (num === this.$props.list.length - 1) {
        this.$message.warning(`没有更多了！`)
      } else {
        this.$props.item = this.$props.list[num + 1]
      }
    },

    // 上一个
    upFn () {
      let num = this.$props.list.indexOf(this.$props.item)
      if (num == 0) {
        this.$message.warning(`没有更多了！`)
      } else {
        this.$props.item = this.$props.list[num - 1]
      }
    },

    failFn () {
      this.$emit('failFn', this.$props.item)
    }
  }
}
</script>
<style lang="scss" scoped>
.signImg {
  width: 100%;
  height: 640px;
  margin-top: -20px;
  img {
    width: 100%;
    height: 100%;
  }
}
/deep/.el-dialog__footer {
  text-align: center;
}
</style>