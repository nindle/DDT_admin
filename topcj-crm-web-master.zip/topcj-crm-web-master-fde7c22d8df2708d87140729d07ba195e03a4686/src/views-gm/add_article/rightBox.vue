<template>

  <div class="right-box">
    <div class="head">{{data.title}}</div>
    <div class="information">
      <div class="people">{{publisherName}}</div>
      <div class="time">{{data.publishTime}}</div>
    </div>

    <el-tabs
      class="tab"
      v-model="activeName"
      :stretch="true"
      @tab-click="nav"
    >
      <div class="tab-num">
        <!-- 人数信息 -->
        <div
          v-for="(e,i) in type ==='count'? tabList: signtabList"
          :key="i"
          style="cursor: pointer;"
          @click="onTabpane(i)"
          :class="{'active': e.name === activeName}"
        >
          {{`${ type === 'count' ? data[e.name] : e.name ==='inSignCount' ? data[e.name] : data['signCount'] - data['inSignCount']}`}}
        </div>
      </div>

      <el-tab-pane
        v-for="(e,i) in type ==='count' ? tabList : signtabList"
        :key="i"
        :label="e.label"
        :name="e.name"
      >
      </el-tab-pane>

    </el-tabs>

    <el-scrollbar-pro class="list">
      <div
        class="list_batch"
        v-if="activeName === 'noInSignCount'"
      >
        <el-button
          class="batch"
          @click="onBatchFn"
        >
          批量点击提醒签署
        </el-button>
        <el-button
          class='excel'
          @click="onExcel"
        >导出Excel</el-button>
      </div>
      <div
        v-for="(e,i) in infoList"
        :key="i"
        class="list-item"
      >
        <!-- 阅读点赞信息列表 -->
        <div v-if="type === 'count'">
          <div v-if="activeName === 'writeCount'">
            <div class="write-head">
              <span>{{e.type ? e.createrName : '匿名用户'}}</span>
              <span>{{e.ctime}}</span>
            </div>
            <msg-text
              v-if="activeName === 'writeCount'"
              class="write-content"
              :text="e.content"
              face
            />
            <div
              v-else
              class="write-content"
            >{{e.content}}</div>
          </div>
          <div v-else>{{e.managerName}}</div>
        </div>

        <!-- 签署信息列表 -->
        <div
          v-else
          class='signDom'
        >
          <div>{{e.managerName || e.qyUserId}}</div>
          <el-button
            class='signImg'
            v-if="activeName !== 'noInSignCount'"
            @click="openSignImgList(e)"
            icon="el-icon-view"
            type='text'
            size='small'
          > 查看图片 </el-button>

        </div>
      </div>

      <el-table-pro
        v-show="false"
        :head="head"
        :data="tableList"
      >

      </el-table-pro>
    </el-scrollbar-pro>

  </div>
</template>
<script>
import { debounce } from '../../assets/js/tool'
import MsgText from '../../components/message/msg-text.vue'
export default {
  data () {
    return {
      activeName: this.type === 'count' ? 'readCount' : 'inSignCount',
      activeIndex: 0,
      tabList: [
        { name: 'readCount', label: '阅读人数', show: true, },
        ...(this.isTopSystem ? [] : [
          { name: 'writeCount', label: '评论人数', show: true, },
          { name: 'likesCount', label: '点赞人数', show: true, },
        ])
        
      ],
      signtabList: [
        { name: 'inSignCount', label: '已签署人数', show: true, },
        { name: 'noInSignCount', label: '未签署人数', show: true, },
      ],

      infoList: [],
      head: [
        {
          key: 'corpName',
          label: '分公司',
        },
        {
          key: 'managerName',
          label: '姓名',
        },
      ],
      tableList: []
    }
  },
  computed: {
    publisherName () {
      return this.data.publisher ? this.$store.state.baseData.managerList.find(e => e.id === this.data.publisher).realName : '--'
    },

    AfterLeft () {
      let left = (this.tabList[0].label.length * 14 - 28) / 2
      let spacing = ((328 - (56 * this.tabList.length)) / 2)
      for (let i = 0; i < this.activeIndex; i++) {
        left += spacing + (this.tabList[i].label.length * 14)
      }
      return left
    }
  },
  props: {
    data: Object,
    type: String,
    isTopSystem: Boolean
  },
  methods: {
    nav (tab) {
      this.activeIndex = this.tabList.findIndex(e => e.name === tab.name)
      this.activeName = tab.name
      this.getQyInfoList(tab.name)
    },
    openSignImgList (e) {
      this.$emit('opensign', e, this.infoList, this.data)
    },
    async onBatchFn (e) {
      let { code } = await this.$http({
        url: '%CRM%/hr_info_message/send_qy_message.sdcrm',
        data: {
          token: true,
          id: this.data.id,
          agentId: this.data.agentId,
          title: this.data.title,
          description: this.data.description,
          url: `${this.SYS.BOOKURL}/qywx/article/${this.data.id}`,
          picurl: this.data.picurl,
          type: 2,
          managerId: e.managerId,
        }
      })
      if (code === 8200) {
        this.$message.success('操作成功')
      }
    },
    onTabpane (e) {
      if (this.type === 'count') {
        this.activeName = this.tabList[e].name
      } else {
        this.activeName = this.signtabList[e].name
      }
      this.getQyInfoList(this.activeName)
    },
    // 获取右侧数据
    getQyInfoList: debounce(async function (name) {
      this.infoList = []
      this.tableList = []
      if (this.type === 'count') {
        let url = name === 'readCount' ? '%CRM%/hr_info_message/get_qy_info_read_list.sdcrm' : (name === 'writeCount' ? '%CRM%/hr_info_message/get_qy_info_comment_list.sdcrm' : '%CRM%/hr_info_message/get_qy_info_likes_list.sdcrm')
        let { result } = await this.$http({
          url,
          data: {
            token: true,
            isPage: 1,
            infoId: this.data.id
          }
        })
        this.infoList = result
      } else if (this.type === 'sign') {
        let isSign = name === 'inSignCount' ? 1 : 0
        let { result } = await this.$http({
          url: '%CRM%/hr_info_message/get_qy_info_sign_list.sdcrm',
          data: {
            token: true,
            isPage: 1,
            infoId: this.data.id,
            isSign: isSign,
          }
        })

        this.infoList = result

        // 表格数据
        const list = []
        this.infoList.forEach((item) => {
          this.tableList.push({
            managerName: item.managerName, corpName: '', id: item.managerId
          })
          list.push(...this.$store.state.baseData.managerList.filter((res) => {
            return item.managerId === res.id
          }))
        })
        const groupNameList = []
        list.forEach((item) => {
          groupNameList.push(...this.$store.state.baseData.corpList.filter((res) => {
            return item.corpId === res.id
          }));
        })
        this.tableList.forEach((item, i) => {
          item.corpName = groupNameList[i].corpName
        })
      }
    }),
    // 导出Excel
    onExcel () {
      this.$copyExcel(this, `${this.data.title}文章未签署员工名单`)
    }
  },
  watch: {
    data () {
      if (this.data) {
        this.getQyInfoList(this.activeName)
      }
    },
    type () {
      if (this.type === 'count') {
        this.activeName = 'readCount'
        this.getQyInfoList('readCount')
      } else {
        this.activeName = 'inSignCount'
        this.getQyInfoList('inSignCount')
      }
    }
  },
  components: {
    MsgText,
  },
  created () {
    this.getQyInfoList(this.activeName)
  }
}
</script>
<style lang="scss" scoped>
.right-box {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .head {
    font-size: 20px;
  }
  .information {
    // color: ;
    display: flex;
    justify-content: space-between;
    padding-top: 18px;
    .people {
      color: #999999;
    }
    .time {
      font-size: 14px;
      color: #cccccc;
    }
  }

  .tab {
    width: 100%;
    height: 42px;
    line-height: 42px;
    padding-top: 57px;
    position: relative;
    z-index: 1;
    /deep/ {
      .el-tabs__content {
        position: static;
      }
    }
    .tab-num {
      width: 328px;
      height: 40px;
      display: flex;
      justify-content: space-around;
      position: absolute;
      left: 0;
      top: 28px;
      z-index: 99;
      div {
        width: calc(100% / 3);
        text-align: center;
        padding: 0 20px;
        font-size: 20px;
        &:first-child {
          padding-left: 0;
        }
        &:last-child {
          padding-right: 0;
        }
        &.active {
          color: #3089ff;
        }
      }
    }
  }

  .list {
    width: 100%;
    height: calc(778px - 250px);
    padding-top: 12px;
    .list-item {
      padding: 19px 0;
      border-bottom: 1px solid #efefef;
      &:last-child {
        border-bottom: 0;
      }

      .write-head {
        display: flex;
        justify-content: space-between;
        span {
          &:last-child {
            font-size: 14px;
            color: #999999;
          }
        }
      }
      .write-content {
        color: #666666;
        margin-top: 16px;
      }
      .signDom {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 50px;
        .signImg {
          color: #3089ff;
          cursor: pointer;
        }
      }
    }
    .list_batch {
      height: 40px;
      display: flex;
      justify-content: space-between;
      .batch {
        flex: 2;
        color: #fff;
        text-align: center;
        border-radius: 4px;
        background-color: #d9001b;
        cursor: pointer;
      }
      .excel {
        flex: 1;
        text-align: center;
        border: 1px solid #ccc;
        margin-left: 15px;
        border-radius: 4px;
        cursor: pointer;
      }
    }
  }
}
</style>