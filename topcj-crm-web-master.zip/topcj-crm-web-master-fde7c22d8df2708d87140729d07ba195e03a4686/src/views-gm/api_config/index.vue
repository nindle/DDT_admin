<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >  
      <!-- 筛选模块 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro> 
      </template>
    
      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData"
          @edit="openPopover"
          @change="getTableData()"
        />
      </template> 

      <!-- 编辑模块 -->
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          @change="getTableData()"
        />
      </template>   
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-apiconfig',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      //修改数据
      rowData: null,

      screen: {
        type: ''
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) }
        },
        type: {
          placeholder: '类型',
          type: 'select',
          options:[
            { value: 0, label: '不限制' },
            { value: 1, label: '白名单' },
            { value: 2, label: '黑名单' },
          ]
        }
      }
    }
  },
  components: {
    TableData,
    EditData
  },
  methods: {
    //数据获取
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url:'%CRM%/setting/get_api_permit_ip_list.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          type: typeof this.screen.type === 'number' ? this.screen.type : undefined
        }
      })

      this.total = result.total
      this.tableData = result.records

      this.loading = false
    }),
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    }
  }
}
</script>

<style scoped lang="scss">
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>
