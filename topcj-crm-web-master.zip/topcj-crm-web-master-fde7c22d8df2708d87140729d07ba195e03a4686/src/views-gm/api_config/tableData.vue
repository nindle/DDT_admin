<template>
  <el-table-pro
    :data="data"
    :head="head"
  ></el-table-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      head: [
        {
          key: 'apiUrl',
          label: 'API',
          minWidth: 120
        },
        {
          key: 'type',
          label: '类型',
          minWidth: 42,
          format: {
            '0': '不限制',
            '1': '白名单',
            '2': '黑名单',
          }
        },
        {
          key: 'ips',
          label: 'IP列表',
          minWidth: 120,
          copy: true
        },
        // {
        //   key: 'ctime',
        //   label: '创建时间',
        //   minWidth: 140,
        //   format: e => new Date(e).timeFormat()
        // },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            label: '编辑',
            icon: 'el-icon-edit',
            click: row => { this.$emit('edit', row) }
          }
        },
        {
          key: 'delete',
          label: '',
          width: 44,
          button: {
            type: 'text',
            label: '删除',
            icon: 'el-icon-delete',
            popconfirm: '确认删除吗？',
            click: this.deleteData
          }
        }
      ]
    }
  },
  props:{
    data:Array
  },
  methods: {
    deleteData: throttle(async function(row) {
      let { code, errmsg, msg } = await this.$http({
        url:'%CRM%/setting/api_permit_ip_delete.sdcrm',
        data:{
          token: true,
          id: row.id
        }
      })
      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        return
      }

      this.$message.success('删除成功')
      this.$emit('change')
    })
  }
}
</script>