
<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>{{data ? '编辑' : '新增'}}接口配置</template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
      <template #ips>
        <span></span>
        <el-tag
          v-for="e in form.ips"
          :key="e"
          closable
          @close="deleteIp(e)"
        >{{e}}</el-tag>
      </template>
    </el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        apiUrl: this.data?.apiUrl ?? '',
        type: this.data?.type ?? '',
        ips: (this.data?.ips ?? '').split('|').filter(e => e),
        ip: ''
      },
      config: {
        apiUrl: {
          label: 'API地址',
          type: 'input',
          rule: [
            { required: true }
          ]
        },
        type: {
          type: 'select',
          label: '类型',
          options:[
            { value: 0, label: '不限制' },
            { value: 1, label: '白名单' },
            { value: 2, label: '黑名单' },
          ],
          rule: [
            { required: true }
          ]
        },
        ips: {
          label: 'IP列表'
        },
        ip: {
          label: '添加IP',
          placeholder: '输入IP，回车添加',
          change: this.addIP
        }
      },
      loading: false
    }
  },
  props: {
    data: Object
  },
  methods: {
    //添加敏感词
    addIP() {
      let ip = this.form.ip.replace(/\s|;|\|/g, ',').split(',').map(e => e.trim()).filter(e => e && !this.form.ips.includes(e))


      this.form.ips.push(...ip)

      this.form.ip = ''
    },
    //删除敏感词
    deleteIp(ip) {
      this.form.ips.splice(this.form.ips.indexOf(ip), 1)
    },
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/setting/api_permit_ip_edit.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          apiUrl: this.form.apiUrl,
          type: this.form.type,
          ips: this.form.ips.join('|')
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>

<style scoped lang="scss">
.popover {
  .el-tag {
    margin-right: 8px;
    margin-bottom: 8px;
  }
}
</style>