<template>
  <div 
    class="control-box"
    v-if="userLevel"
  >
    <el-form-pro
      :model="data"
      :config="config"
    ></el-form-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data(){
    return{
      config: {
        allowComments: {
          label: '评论',
          type: 'switch',
          activeValue: 1,
          inactiveValue: 0,
          change: v => {
            this.setLiveData('comment', v)
          }
        },
        isNoChat: {
          label: '全员禁言',
          type: 'switch',
          activeValue: 1,
          inactiveValue: 0,
          change: v => {
            this.setLiveData('nochat', v)
          }
        },
        allowPrivateChat: {
          label: '私聊',
          type: 'switch',
          activeValue: 1,
          inactiveValue: 0,
          change: v => {
            this.setLiveData('1v1', v)
          },
          hide: true
        },
        allowSell: {
          label: '售卖',
          type: 'switch',
          activeValue: 1,
          inactiveValue: 0,
          change: v => {
            this.setLiveData('shop', v)
          }
        },
        pids: {
          label: '套餐',
          type: 'select',
          multiple: true,
          options: this.packageList,
          valueKey: 'id',
          labelKey: 'name',
          filterable: true,
          change: v => {
            this.setLiveData('package', v.join(','))
          },
          hide: () => !this.data.allowSell
        }
      }
    }
  },
  props: {
    data: Object,
    packageList: Array,
    userLevel: Number
  },
  methods: {
    //设置直播间数据
    setLiveData: throttle(async function(type, value) {
      await this.$http({
        url:'%CRM%/live/live_edit.sdcrm',
        data: {
          token: true,
          id: this.data.id,
          isNoChat: this.data.isNoChat,
          allowComments: this.data.allowComments,
          allowPrivateChat: this.data.allowPrivateChat,
          allowSell: this.data.allowSell,
          pids: this.data.pids.join(',')
        }
      })

      this.$emit('sendControlMessage', type, `${value}`)
    })
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.control-box {
  width: 512px;
  background: #FFF;
  padding: 12px 12px 1px;
  box-sizing: border-box;
}
</style>