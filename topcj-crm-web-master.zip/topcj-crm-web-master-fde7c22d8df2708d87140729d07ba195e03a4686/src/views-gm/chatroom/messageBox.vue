<template>
  <div class="message-view">
    <user-list 
      :tim="tim"
      :data="data"
      :user-im-list="userImList"
      :user-level="userLevel"
      :shutted-uin-list="shuttedUinList"
      @forbid-send-msg="forbidSendMsg"
      v-if="imready"
    />
    <el-layout-pro>
      <template #screen>
        <el-tabs v-model="activeName">
          <el-tab-pane 
            v-for="e in tabList"
            :key="e.name"
            :label="e.label" 
            :name="e.name"
          ></el-tab-pane>
        </el-tabs>
      </template>

      <template #table>
        <el-scrollbar-pro 
          class="message-scroll"
          ref="scroll"
          :style="{ height: userLevel ? 'calc(100% - 226px)' : '100%' }"
          @scroll="scroll"
          @scroll-top="getHistoryMsg"
        >
          <message
            :data="messageList"
            :message-class="e => (e.self ? 'mode-self' : 'mode-user') + ` message-type-${e.msgType}`"
            lock-image-height
          >
            <template #message-time="{ item }">
              <img 
                class="headimg"
                :src="item.avatarPath" 
              />
              <div 
                class="nickname"
                :class="`type-${item.type}`"
              >{{item.nickname}}</div>
              <div class="msgtime">{{item.lastTime | timeDistance }}</div>
            </template>
            <template #bottom="{ item }">
              <div 
                class="msg-tool"
                v-if="userLevel > 0"
              >
                <el-button
                  type="primary"
                  size="small"
                  v-if="item.type"
                  @click="referTo(item)"
                >@他</el-button>

                <el-dropdown 
                  trigger="click"
                  size="small"
                  @command="forbidSendMsg($event, item.from)"
                  v-if="item.type"
                >
                  <el-button
                    :type="shuttedUinList[item.from] ? 'danger' : 'primary'"
                    size="small"
                  >禁言{{shuttedUinList[item.from] ? '中' : ''}}</el-button>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item 
                      :command="0"
                      v-if="shuttedUinList[item.from]"
                    >解除禁言</el-dropdown-item>
                    <!-- <el-dropdown-item :command="30">禁言测试</el-dropdown-item> -->
                    <el-dropdown-item :command="3600">禁言1H</el-dropdown-item>
                    <el-dropdown-item :command="18000">禁言5H</el-dropdown-item>
                    <el-dropdown-item :command="86400">禁言24H</el-dropdown-item>
                    <el-dropdown-item :command="4294967295">永久禁言</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>              
              </div>
            </template>
          </message>
        </el-scrollbar-pro>

        <div class="message-count">
          <div 
            class="new-msg"
            v-if="newMessageList.length"
            @click="scrollToNewMsg"
          >
            <span>{{newMessageList.length}}</span>
            条新消息
            <i class="el-icon-d-arrow-right"></i>
          </div>
        </div>
        
        <message-input 
          v-if="userLevel"
          :tool="['face-55', 'image', 'clear']"
          ref="message"
        >
          <template #tool-clear>
            <el-popconfirm
              style="margin-left: auto;margin-right: 0"
              title="清空所有用户端的评论"
              @confirm="sendControlMessage('clear')"
            >
              <template #reference>
                <el-button
                  type="text"
                  size="small"
                  icon="el-icon-delete"
                >清屏</el-button>
              </template>
            </el-popconfirm>
          </template>
        </message-input>

        <el-screen-pro 
          v-if="userLevel"
          :model="model"
          :config="config"
        ></el-screen-pro>
      </template>
    </el-layout-pro>
  </div>
  
</template>

<script>
import { md5 } from '../../assets/js/crypto'
import { createLink, throttle } from '../../assets/js/tool'
import Message from '../../components/message'
import MessageInput from '../../components/message-input'
import TIM from 'tim-js-sdk'
import UserList from './userList'

export default {
  data() {
    return {
      activeName: 'group',
      tabList: [
        { label: '直播间群聊', name: 'group' },
        // { label: '直播间私聊', name: '1v1' },
      ],

      tim: null,
      //im是否创建完毕
      imready: false,

      messageList: [],
      //历史记录是否加载完毕
      historyLoadOver: false,

      model: {
        package: '',
        coupon: ''
      },
      config: {
        package: {
          type: 'select',
          placeholder: '售卖产品',
          valueKey: 'id',
          labelKey: 'name',
          options: this.packageList,
          filterable: true,
          change: () => {
            let detail = this.packageList.find(e => e.id === this.model.package)
            let time = Date.now()
            let sign = md5(`n&*t2^Vyvu1s6sjt${detail.id}0${time}`)

            let routerName = ''

            if(detail.descriptionPic) {
              routerName = 'package'
            } else {
              routerName = 'signcontract/n'
            }

            let link = createLink(`${this.SYS.WEBURL}/ns/#/${routerName}`, {
              p: detail.id,
              d: 0,
              t: time,
              sign
            }, ['mid-res-19', 'alipay', 'wxpay', 'corpId'])

            this.$refs.message.inputMessage({
              type: 'text',
              content: `产品：${detail.name}\n产品价格：${detail.money}元\n链接地址：${link}`
            })
            this.model.package = ''
          }
        },
        coupon: {
          type: 'select',
          placeholder: '优惠券',
          valueKey: 'couponId',
          labelKey: 'couponName',
          options: this.couponList,
          filterable: true,
          change: () => {
            let coupon = this.couponList.find(e => e.couponId === this.model.coupon)
            
            let link = createLink(`${this.SYS.WEBURL}/ns/#/coupon/${coupon.couponId}`, {}, ['mid-corp-19'])

            this.$refs.message.inputMessage({
              type: 'text',
              content: `优惠券名称：${coupon.couponName}\n优惠券金额：${coupon.amount}元\n优惠券链接：${link}`
            })
            this.model.coupon = ''
          }
        },
        split: { type: 'split' },
        submit: {
          label: '发送',
          type: 'button',
          buttonType: 'primary',
          click: this.sendMessageInInput
        }
      },

      //是否在浏览历史消息
      reviewHistory: false,
      //新消息列表
      newMessageList: [],

      //禁言中的名单
      shuttedUinList: {},
      updateShuttedUinListTimer: null
    }
  },
  props: {
    data: Object,
    packageList: Array,
    couponList: Array,
    userIm: Object,
    userLevel: Number,
    userImList: Array,
  },
  components: {
    Message,
    MessageInput,
    UserList
  },
  methods: {
    //获取历史消息
    getHistoryMsg: throttle(async function() {
      if(this.historyLoadOver) return

      let { result } = await this.$http({
        url: '%CRM%/chat/get_user_chat.sdcrm',
        data: {
          token: true,
          room: this.data.chatRoomGroupId,
          from: this.messageList.length,
          size: 15
        }
      })

      if(result.length < 15) {
        this.historyLoadOver = true
        result.push({
          id: Date.now(),
          msgType: 'TIMCustomElem',
          imId: '',
          ctime: '',
          icon: '',
          nickname: '',
          content: JSON.stringify({
            data: 'control',
            description: 'tips',
            extension: '已加载完，无更多消息'
          })
        })
      }

      await this.onMessageReceived({
        data: result.map(e => {
          return {
            ID: e.id,
            type: e.msgType,
            from: e.imId,
            time: new Date(e.ctime.replace(/-/g, '/')).getTime() / 1000,
            avatar: e.icon,
            nick: e.nickname,
            payload: JSON.parse(e.content)
          }
        })
      }, 'history')
    }),
    //登录IM
    async loginIM() {
      await this.tim.login({
        userID: this.userIm.userImId,
        userSig: this.userIm.userSign
      }) 

      //加入群组
      await this.tim.joinGroup({
        groupID: this.data.chatRoomGroupId,
        type: TIM.TYPES.GRP_AVCHATROOM
      })
    },
    //接收消息
    async onMessageReceived({ data }, mode = 'newmsg') {
      let scrollHeight = this.$refs.scroll.$refs.scroll.$refs.wrap.scrollHeight
      let newMessageList = []
      for(let message of data) {
        let result = this.analyMessage(message)
        
        if(!result) continue

        result.scrollTop = 0

        if(mode === 'newmsg') {
          this.messageList.push(result)
          await this.$nextTick()
          result.scrollTop = this.$refs.scroll.$refs.scroll.$refs.wrap.scrollHeight - this.$refs.scroll.$refs.scroll.$refs.wrap.clientHeight
          newMessageList.push(result)
        }else if(mode === 'history') {
          this.messageList.unshift(result)
          newMessageList.push(result)
        }
      }

      if(newMessageList.length) {
        if(mode === 'history') {
          await this.$nextTick()
          let diffHeight = this.$refs.scroll.$refs.scroll.$refs.wrap.scrollHeight - scrollHeight
          this.$refs.scroll.scrollTop(diffHeight)
          //增加历史记录后调整新消息的高度
          this.newMessageList.forEach(e => {
            e.scrollTop += diffHeight
          })
        }else if(this.reviewHistory) {
          this.newMessageList.push(...newMessageList)
        }else{
          await this.$nextTick()
          this.$refs.scroll.scrollBottom(0)
        }
      }
    },
    //解析消息
    analyMessage(message) {
      //屏蔽系统消息
      if(message.isSystemMessage) return
      //屏蔽群提醒
      if(message.type === 'TIMGroupTipElem') return

      let result = {
        id: message.ID,
        from: message.from,
        self: message.from === this.userIm.userImId,
        type: this.userImList.includes(message.from) ? 0 : 1,
        lastTime: message.time * 1000,
        avatarPath: message.avatar,
        nickname: message.nick
      }

      switch(message.type) {
        //文本消息
        case 'TIMTextElem':
          result.msgType = 'text'
          result.content = message.payload.text
          break
        //图片消息
        case 'TIMImageElem':
          result.msgType = 'image'
          result.imageUrl = message.payload.imageInfoArray.find(e => e.type === 0)?.url ?? ''
          break
        //自定义消息
        case 'TIMCustomElem':
          if(message.payload.data === 'control') {
            result.msgType = 'event'
            //清屏
            if(message.payload.description === 'clear') {
              result.content = `<span>${ message.nick }</span>发起清屏，以上内容在用户端被清空`
            }else if(message.payload.description === 'tips') {
              result.content = message.payload.extension
            }else if(message.payload.description === 'comment') {
              this.data.allowComments = Number(message.payload.extension)
              return
            }else if(message.payload.description === 'nochat') {
              this.data.isNoChat = Number(message.payload.extension)
              return
            }else if(message.payload.description === '1v1') {
              this.data.allowPrivateChat = Number(message.payload.extension)
              return
            }else if(message.payload.description === 'shop') {
              this.data.allowSell = Number(message.payload.extension)
              return
            }else if(message.payload.description === 'package') {
              this.data.pids = message.payload.extension.split(',').filter(e => e).map(e => Number(e)) ?? []
              return
            }else if(message.payload.description === 'updateshutteduinlist') {
              this.getShuttedUinList()
              return
            }else{
              return
            }
          }else if(message.payload.data === 'image') {
            result.msgType = 'image'
            result.imageUrl = message.payload.description
          }
          break
      }

      return result
    },
    //从消息框中发送消息
    sendMessageInInput() {
      let messageList = this.$refs.message.getMessage()
      if(!messageList.length) {
        this.$message.error('请输入消息')
        return
      }

      messageList.forEach(e => {
        let message
        switch (e.msgType) {
          case 'text':
            message = this.tim.createTextMessage({
              to: this.data.chatRoomGroupId,
              conversationType: TIM.TYPES.CONV_GROUP,
              payload: {
                text: e.content.replace(/(<.*?)contenteditable=".+?"(.*?>)/, '$1$2')
              }
            })
            break
          case 'image':
            message = this.tim.createCustomMessage({
              to: this.data.chatRoomGroupId,
              conversationType: TIM.TYPES.CONV_GROUP,
              payload: {
                data: 'image',
                description: e.imageUrl
              }
            })
            break
          // case 'image-base64':
          //   message = this.tim.createImageMessage({
          //     to: this.data.chatRoomGroupId,
          //     conversationType: TIM.TYPES.CONV_GROUP,
          //     payload: {
          //       file: base2file(e.imageBase64, e.fileName)
          //     }
          //   })
          //   break
        }

        if(message) {
          this.sendMessage(message)
        }
      })

      this.$refs.message.clearMessage()
    },
    //发送控制消息
    sendControlMessage(type, value) {
      let message = this.tim.createCustomMessage({
        to: this.data.chatRoomGroupId,
        conversationType: TIM.TYPES.CONV_GROUP,
        priority: TIM.TYPES.MSG_PRIORITY_HIGH,
        payload: {
          data: 'control',
          description: type,
          extension: value
        }
      })

      this.sendMessage(message)
    },
    //发送消息
    sendMessage(message) {
      if(!message) return

      this.reviewHistory = false
      this.tim.sendMessage(message).then(() => {
        //禁言上报不上传
        if(!(
          message.type === 'TIMTextElem' ||
          (message.type === 'TIMCustomElem' && message.payload.data === 'control' && message.payload.description === 'clear') ||
          (message.type === 'TIMCustomElem' && message.payload.data === 'image')
        )) return

        let type = message.type, payload = message.payload

        //图片消息整理
        if(message.type === 'TIMCustomElem' && message.payload.data === 'image') {
          type = 'TIMImageElem'
          payload = {
            imageInfoArray: [
              { type: 0, url: message.payload.description }
            ]
          }
        }

        this.$http({
          url: '%CRM%/chat/add_user_chat.sdcrm',
          data: {
            token: true,
            content: JSON.stringify(payload),
            room: this.data.chatRoomGroupId,
            nickname: message.nick,
            icon: message.avatar,
            msgType: type
          }
        })
      })
      this.onMessageReceived({
        data: [message]
      })
    },
    //修改资料
    async editProfile() {
      if(this.userLevel === 1) {
        //助理
        await this.tim.updateMyProfile({
          nick: '直播间助理',
          avatar: 'https://www.topxlc.com/images/liveroom-assistant-head.png'
        })
      }else if(this.userLevel === 2) {
        //讲师
        await this.tim.updateMyProfile({
          nick: this.$store.state.managerInfo.realName,
          avatar: this.$store.state.managerInfo.avatarPath
        })
      }else {
        //讲师
        await this.tim.updateMyProfile({
          nick: this.$store.state.managerInfo.realName,
          avatar: 'https://www.topxlc.com/images/morenicon.jpg'
        })
      }

      this.imready = true
    },
    //滚动内容
    scroll(e) {
      //当距离底部大于40的时候判断为在浏览历史消息
      if(e.scrollBottom > 40) {
        this.reviewHistory = true
      }else{
        this.reviewHistory = false
      }

      //查看新消息
      this.newMessageList = this.newMessageList.filter(i => i.scrollTop > e.scrollTop)
    },
    //滚动至新消息处
    scrollToNewMsg() {
      this.$refs.scroll.scrollTop(this.newMessageList[0].scrollTop)
    },
    //@他
    referTo(e) {
      this.$refs.message.inputMessage({
        type: 'text',
        content: `<at im="${e.from}" contenteditable="false">@${e.nickname}</at>`
      })
    },
    //禁言
    async forbidSendMsg(time, imid) {
      await this.$http({
        url: '%CRM%/live/forbid_send_msg.sdcrm',
        data: {
          token: true,
          liveId: this.data.id,
          imIds: [imid],
          shutUpTime: time
        }
      })

      this.sendControlMessage('updateshutteduinlist')
    },
    //获取禁言名单
    async getShuttedUinList() {
      clearTimeout(this.updateShuttedUinListTimer)
      let { result } = await this.$http({
        url: '%CRM%/live/get_group_shutted_uin.sdcrm',
        data: {
          token: true,
          liveId: this.data.id
        }
      })

      let list = {}

      if(!result.shuttedUinList.length) {
        this.shuttedUinList = list
        return
      }

      let minTime = Number.MAX_SAFE_INTEGER
      result.shuttedUinList.forEach(e => {
        list[e.memberAccount] = e.shuttedUntil
        minTime = Math.min(e.shuttedUntil * 1000, minTime)
      })

      //下次更新时间
      let time = minTime - Date.now() + 1000

      if(time < 24 * 60 * 60 * 1000) {
        this.updateShuttedUinListTimer = setTimeout(() => {
          this.getShuttedUinList()
        }, time)
      }

      this.shuttedUinList = list
    },
    //被踢下线
    kickedOut() {
      this.$message.error('你的账号已在用户端登录')
      this.$emit('kicked-out')
    },
    //销毁实例
    async destroy() {
      this.tim.off(TIM.EVENT.MESSAGE_RECEIVED, this.onMessageReceived)
      this.tim.off(TIM.EVENT.SDK_READY, this.editProfile)
      this.tim.off(TIM.EVENT.KICKED_OUT, this.kickedOut)
      await this.tim.destroy()
    }
  },
  created() {
    //创建实例
    this.tim = TIM.create({ SDKAppID: this.SYS.IMAPPID })
    //日志打印
    this.tim.setLogLevel(this.SYS.APIENV === 'dev' ? 0 : 1)

    //消息接收事件
    this.tim.on(TIM.EVENT.MESSAGE_RECEIVED, this.onMessageReceived)
    //修改个人信息
    this.tim.on(TIM.EVENT.SDK_READY, this.editProfile)
    //被踢下线
    this.tim.on(TIM.EVENT.KICKED_OUT, this.kickedOut)

    //登录IM
    this.loginIM()

    //获取黑名单列表
    this.getShuttedUinList()

    //获取历史消息
    this.getHistoryMsg()
  },
  beforeDestroy() {
    clearTimeout(this.updateShuttedUinListTimer)
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.message-view {
  display: flex;
  background: #FFF;
  justify-content: flex-end;
}

.layout {
  background: #FFF;
  width: calc(100% - 240px);
  height: 100%;
  /deep/ {
    .screen-box { padding: 24px 0 0;}
    .table-box { padding: 0;}
    at {
      margin: 0 6px;
      color: $--color-main;
    }
  }
  .el-tabs {
    width: 100%;
    padding: 0 24px;
    border-bottom: 1px solid #E9E9E9;
    box-sizing: border-box;
    /deep/ {
      .el-tabs__nav-next, .el-tabs__nav-prev { line-height: 22px;}
      .el-tabs__header { margin: 0; }
      .el-tabs__item { 
        font-size: 15px;
        line-height: 21px;
        height: 37px;
        padding: 0 12px;
      }
      .el-tabs__nav-wrap::after { display: none;}
      .el-tabs__item.is-top:nth-child(2), .el-tabs--top .el-tabs__item.is-bottom:nth-child(2), .el-tabs--bottom .el-tabs__item.is-top:nth-child(2), .el-tabs--bottom .el-tabs__item.is-bottom:nth-child(2) { padding-left: 0;}
      .el-tabs__item.is-top:last-child, .el-tabs--top .el-tabs__item.is-bottom:last-child, .el-tabs--bottom .el-tabs__item.is-top:last-child, .el-tabs--bottom .el-tabs__item.is-bottom:last-child { padding-right: 0;}
    }
  }
  .message-input {
    position: absolute;
    bottom: 56px;
    left: 0;
    background: #FFF;
    z-index: 1;
    box-shadow: 0px -2px 14px 0px rgba(#000, .17);
    height: 170px;
  }
  .screen {
    position: absolute;
    bottom: 0;
    left: 0;
    padding: 0 12px 12px 20px;
    box-sizing: border-box;
    background: #FFF;
    width: 100%;
    margin: 0;
    z-index: 2;
  }
  .message-box {
    /deep/ {
      .noresult { display: none;}
      .message-item {
        display: flex;
        padding: 12px 24px;
        &.mode-self {
          flex-direction: row-reverse;
          .msg-head {
            .nickname, .msgtime {
              left: auto;
              right: 52px;
              text-align: right;
            }
          }
          .msg-body,.msg-tool {
            margin: 24px 12px 20px 0;
          }
          .msg-tool {
            > * { 
              margin-left: 10px;
              margin-right: 0;
            }
          }
        }
        &.message-type-event {
          flex-direction: row;
          justify-content: center;
          .msg-head {display: none;}
          .msg-body { 
            border-radius: 19px;
            color: #999;
            font-size: 12px;
            margin: 0;
            span { 
              color: #F56C6C;
              padding-right: 6px;
            }
          }
          .msg-tool {display: none;}
        }
      }
      .msg-head {
        position: relative;
        display: block;
        .user, .icon, .manager { display: none;}
        .headimg {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          display: block;
          pointer-events: none;
        }
        .nickname {
          position: absolute;
          top: 0;
          left: 52px;
          color: #4180FC;
          font-size: 14px;
          width: 200px;
          &.type-0 { color: #F56C6C;}
          @include ellipsis;
        }
        .msgtime {
          position: absolute;
          bottom: 0;
          left: 52px;
          white-space: nowrap;
        }
      }
      .msg-body {
        margin: 24px 0 20px 12px;
        border: 1px solid #eee;
        background: #eee;
        border-radius: 4px;
        padding: 8px 12px;
        max-width: calc(60% - 52px);
      }
      .msg-tool {
        margin: 24px 0 20px 12px;
        > * { margin-right: 10px;}
      }
    }
  }
  .message-count {
    position: absolute;
    bottom: 300px;
    right: 24px;
    z-index: 9;
    .new-msg {
      display: flex;
      align-items: center;
      background: #FFF;
      font-size: 12px;
      box-shadow: 0px 0px 14px 0px rgba(#000, .1);
      padding: 3px 12px;
      border-radius: 12px;
      line-height: 18px;
      color: #333;
      cursor: pointer;
      span { 
        color: $--color-main; 
        margin-right: 3px;
      }
      .el-icon-d-arrow-right {
        color: $--color-main;
        margin-left: 3px;
        transform: rotate(90deg);
      }
    }
  }
}
</style>