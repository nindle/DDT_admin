<template>
  <div class="video-detail">
    <!-- <div class="video-name"><span>{{data.id}}</span>{{data.name}}</div> -->
    <div 
      v-if="liveStatus === 0"
      class="no-live"
      :style="{ backgroundImage: `url(${data.picPath})` }"
    ></div>
    <div 
      v-else
      class="video"
      id="live-video"
    ></div>
  </div>
</template>
<script>

export default {
  data(){
    return{
      player: null
    }
  },
  props: {
    data: Object
  },
  computed: {
    //直播状态
    liveStatus() {
      return this.data.status === 1 ? 1 : 0
    }
  },
  methods: {
    async initPlayer() {
      if(!this.liveStatus) return
      await this.$nextTick()
      this.player = new global.TcPlayer('live-video', {
        webrtc: this.data.udpPlayUrls?.[0]?.playUrl ?? '',
        width: '100%',
        height: '100%',
        live: true,
        autoplay: true,
        poster: this.data.picPath,
        listener: msg => {
          if(msg.type === 'error' && msg.detail.code === 2003) {
            this.player.destroy()
            this.player = null
            this.data.status = 0
          }
        }
      })
    },
    //销毁实例
    async destroy() {
      if(this.player) {
        await this.player.destroy()
        this.player = null
      }
    }
  },
  mounted() {
    this.initPlayer()
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.video-detail {
  width: 512px;
  background: #FFF;
  .video-name {
    font-size: 16px;
    padding: 0 12px;
    line-height: 61px;
    span {
      color: #999;
      padding-right: 24px;
    }
  }
  .video {
    width: 512px;
    height: 288px;
    background: #333;
  }
  .no-live {
    position: relative;
    width: 512px;
    height: 288px;
    @include cover;
    &::before {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background: rgba(#000, .74);
    } 
    &::after {
      content: "当前直播间还未开播";
      position: absolute;
      left: 156px;
      top: 121px;
      width: 200px;
      height: 46px;
      border: 1px solid #FFF;
      border-radius: 23px;
      line-height: 44px;
      text-align: center;
      box-sizing: border-box;
      font-size: 16px;
      color: #FFF;
    }
  }
}
</style>