<template>
  <div class="view">
    <div class="detail">
      <el-screen-pro
        class="select-live"
        :model="model"
        :config="config"
      ></el-screen-pro>
      <template v-if="liveDetail.id">
        <video-detail
          :key="`video-detail-${liveDetail.id}`"
          :data="liveDetail"
          ref="video"
        />
        <control-box
          :key="`control-box-${liveDetail.id}`"
          :data="liveDetail"
          :package-list="packageList"
          :user-level="userLevel"
          @sendControlMessage="sendControlMessage"
        />
      </template>
      
    </div>
    <template v-if="liveDetail.id">
      <message-box 
        class="message"
        :key="`message-${liveDetail.id}`"
        :data="liveDetail"
        :package-list="packageList"
        :coupon-list="couponList"
        :user-im="userIm"
        :user-level="userLevel"
        :user-im-list="userImList"
        @kicked-out="kickedOut"
        ref="message"
      />
    </template>
  </div>
</template>
<script>
import VideoDetail from './videoDetail'
import MessageBox from './messageBox'
import ControlBox from './controlBox'
// import { throttle } from '../../assets/js/tool'

export default {
  name: 'gm-chatroom-nocache',
  data() {
    return {
      model: {
        corpId: '',
        liveId: ''
      },
      config: {
        corpId: {
          type: 'select-corp',
          change: () => {
            this.config.liveId.options = this.liveList.filter(e => !this.model.corpId || !e.corpList.length || e.corpList.includes(this.model.corpId))
          }
        },
        liveId: {
          type: 'select',
          placeholder: '选择直播间',
          options: [],
          labelKey: 'newName',
          valueKey: 'id',
          clearable: false,
          change: this.getLiveData
        } 
      },

      liveList: [],

      //直播详情
      liveDetail: {},

      //套餐列表
      packageList: [],
      //优惠券列表
      couponList: [],

      //用户信息
      userIm: {},
      //用户等级 0:普通人员 1:助理 2:讲师
      userLevel: 0,
      //助理老师的im列表
      userImList: []
    }
  },
  components: {
    VideoDetail,
    MessageBox,
    ControlBox
  },
  methods:{
    //获取直播间信息
    async getLiveData() {
      let { result } = await this.$http({
        url: '%CRM%/live/get_push_flow_url.sdcrm',
        data: {
          token: true,
          liveId: this.model.liveId
        }
      })

      if(this.$refs.message) {
        await this.$refs.message.destroy()
      }
      if(this.$refs.video) {
        await this.$refs.video.destroy()
      }


      result.isNoChat = result.isNoChat ?? 0
      result.allowComments = result.allowComments ?? 0
      result.allowPrivateChat = result.allowPrivateChat ?? 0
      result.allowSell = result.allowSell ?? 0
      result.pids = result.pids.split(',').filter(e => e).map(e => Number(e)) ?? []

      this.liveDetail = result

      if(result.teacherImid === this.userIm.userImId) {
        //登录人是讲师
        this.userLevel = 2
      }else if(result.assistantImids.includes(this.userIm.userImId)) {
        //登录人是助理
        this.userLevel = 1
      }else{
        this.userLevel = 0
      }

      this.userImList = [
        result.teacherImid,
        ...result.assistantImids
      ]
    },
    sendControlMessage(type, value) {
      this.$refs.message.sendControlMessage(type, value)
    },
    //获取套餐列表
    async getPackageList() {
      let { result } = await this.$http({
        url: '%CRM%/package/get_package_list.sdcrm',
        data: {
          token: true
        }
      })

      this.packageList.splice(0, this.packageList.length, ...result.filter(e => e.status === 1))
    },
    //获取优惠券列表
    async getCouponList() {
      let { result } = await this.$http({
        url: '%CRM%/coupon/list.sdcrm',
        data: {
          token: true,
          corpId: this.$store.state.managerInfo.corpId || undefined,
          status: 1
        }
      })

      this.couponList.splice(0, this.couponList.length, ...result.filter(e => (e.endTime ? new Date(e.endTime).getTime() > Date.now() : true)))
    },
    //获取直播间列表
    async getLiveList() {
      let { result } = await this.$http({
        url: '%CRM%/live/get_live_list.sdcrm',
        data: {
          token: true,
          isvisible: 0
        }
      })

      this.liveList.splice(0, this.liveList.length, ...result.map(e => {
        e.newName = `${e.id} ${e.name}`
        e.corpList = e.userCorpIds?.split(',').filter(e => e).map(e => Number(e)) ?? []
        return e
      }))

      this.config.corpId.change()
    },
    //获取用户IM信息
    async getUserIM() {
      let { result } = await this.$http({
        url: '%CRM%/manager/get_msg_sign.sdcrm',
        data: {
          token: true
        }
      })

      this.userIm = result
    },
    //被踢下线
    async kickedOut() {
      if(this.$refs.message) {
        await this.$refs.message.destroy()
      }
      if(this.$refs.video) {
        await this.$refs.video.destroy()
      }
      this.model.liveId = ''
      this.liveDetail = {}
    }
  },
  created() {
    this.getCouponList()
    this.getPackageList()
    this.getLiveList()
    this.getUserIM()
  },
  beforeDestroy() {
    this.$refs.message?.destroy()
    this.$refs.video?.destroy()
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  display: flex;
  .detail {
    width: 512px;
    .select-live {
      width: 100%;
      background: #FFF;
      padding: 0 24px 12px;
      box-sizing: border-box;
      margin-top: 0;
      /deep/ {
        .screen-item:nth-child(2) {
          .el-select { width: 300px;}
        }
      }
    }
  }
  .message {
    margin-left: 24px;
    width: calc(100% - 512px - 24px);
  }
}
</style>