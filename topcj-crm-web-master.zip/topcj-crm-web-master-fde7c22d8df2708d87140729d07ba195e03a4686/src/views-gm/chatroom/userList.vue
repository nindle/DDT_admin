<template>
  <div class="user-list">
    <div class="top">
      在线用户 (<span> {{onlineNum}} </span>)
    </div>
    <el-scrollbar-pro @scroll-bottom="getUserList">
      <div class="list">
        <div 
          class="item"
          v-for="e in userList"
          :key="e.userID"
          v-show="!userImList.includes(e.userID)"
        >
          <div class="head">
            <img :src="e.avatar" />
          </div>
          <div class="name">{{e.nick}}</div>

          <el-popover
            placement="bottom"
            width="200"
            trigger="click"
            style="margin-left: auto;cursor: pointer;"
            v-if="userLevel > 0"
          >
            <el-dropdown 
              trigger="click"
              size="small"
              @command="$emit('forbid-send-msg', $event, e.userID)"
            >
              <el-button
                :type="shuttedUinList[e.userID] ? 'danger' : 'primary'"
                size="small"
              >
                禁言<template v-if="shuttedUinList[e.userID]">至：{{shuttedUinList[e.userID]*1000 | timeFormat}}</template>
              </el-button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item 
                  :command="0"
                  v-if="shuttedUinList[e.userID]"
                >解除禁言</el-dropdown-item>
                <!-- <el-dropdown-item :command="30">禁言30S</el-dropdown-item> -->
                <el-dropdown-item :command="3600">禁言1H</el-dropdown-item>
                <el-dropdown-item :command="18000">禁言5H</el-dropdown-item>
                <el-dropdown-item :command="86400">禁言24H</el-dropdown-item>
                <el-dropdown-item :command="4294967295">永久禁言</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <i 
              class="el-icon-more"
              slot="reference"
            ></i>
          </el-popover>
        </div>
      </div>
    </el-scrollbar-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data(){
    return{
      onlineNum: 0,
      userList: [],
      timer: null
    }
  },
  props: {
    tim: Object,
    data: Object,
    userImList: Array,
    userLevel: Number,
    shuttedUinList: Object
  },
  methods: {
    //获取用户列表
    getUserList: throttle(async function() {
      let { data } = await this.tim.getGroupMemberList({
        groupID: this.data.chatRoomGroupId,
        count: 100,
        offset: this.userList.length
      })

      this.userList.push(...data.memberList)
    }),
    //获取在线人数
    async getOnlineNum() {
      let { result } = await this.$http({
        url: '%CRM%/live/get_online_member_num.sdcrm',
        data: {
          token: true,
          liveId: this.data.id
        }
      })

      this.onlineNum = result.onlineMemberNum

      this.timer = setTimeout(() => {
        this.getOnlineNum()
      }, 10000)
    }
  },
  created() {
    this.getUserList()
    this.getOnlineNum()
  },
  beforeDestroy() {
    clearTimeout(this.timer)
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.user-list {
  width: 240px;
  height: 100%;
  border-right: 1px solid #E9E9E9;
  box-sizing: border-box;
  .top {
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #E9E9E9;
    line-height: 60px;
    text-indent: 12px;
    span { color: $--color-main;}
  }
  .scrollbar { height: calc(100% - 61px);}
  .list {
    padding: 12px;
    .item {
      display: flex;
      align-items: center;
      margin-bottom: 12px;
      .head {
        width: 40px;
        height: 40px;
        img {
          display: block;
          width: 100%;
          height: 100%;
          border-radius: 50%;
          pointer-events: none;
        }
      }
      .name {
        width: 120px;
        line-height: 40px;
        margin-left: 12px;
        @include ellipsis;
      }
    }
  }
}
</style>