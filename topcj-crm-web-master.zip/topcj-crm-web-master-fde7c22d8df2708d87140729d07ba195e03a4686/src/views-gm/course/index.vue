<template>
  <div class="view">
    <el-layout-pro 
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
    
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tabledata"
          :select-list.sync="selectList"
          @edit="openPopover"
        />
      </template>

      <template #popover>
        <edit-data 
          v-if="showPopover"
          :show.sync="showPopover" 
          :data.sync="rowData"
          @change="getTableData()"
        />

        <review 
          v-if="showReview"
          :show.sync="showReview"
          :review-list="reviewList"
          @success="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool';
import TableData from './tableData'
import EditData from './editData'
import Review from '../../components/review/index'

export default {
  name: 'gm-course',
  data() {
    return {
      //加载状态
      loading: false,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      //新增展示修改
      showPopover: false,
      //编辑数据修改
      rowData: null,
      //表格数据
      tabledata: [],
      //筛选数据
      screen: {
        status: '',
        corpId: '',
        search: ''
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) }
        },
        corpId: {
          type: 'select-corp'
        },
        status: {
          type: 'select',
          placeholder: '状态',
          options: [
            { value: 1, label: '通过' },
            { value: 0, label: '未通过' }
          ]
        },
        online: {
          type: 'button',
          label: '审核上线',
          buttonType: 'primary',
          click: () => {this.openReview(1)}
        },
        offline: {
          type: 'button',
          label: '审核下线',
          buttonType: 'primary',
          click: () => {this.openReview(0)}
        },
        split: { type: 'split' },
        search: {
          type: 'input',
          placeholder: '搜索关键字',
          changeLog: true
        }
      },
      selectList: [],

      showReview: false,
      reviewList: []
    }
  },
  components: {
    TableData,
    EditData,
    Review
  },
  methods:{
    //获取表格数据
    getTableData: throttle(async function(toFirst){
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }
      
      let { result } = await this.$http({
        url: '%CRM%/product/get_course_list.sdcrm',
        data: {
          token: true,
          status: typeof this.screen.status === 'number' ? this.screen.status : undefined,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          keyword: this.screen.search,
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }
      })
      
      this.tabledata = result.records
      this.total = result.total

      this.loading = false
    }),
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    },
    openReview(status) {
      this.reviewList = this.selectList.map(e => {
        return {
          url: '%CRM%/product/audit.sdcrm',
          data: {
            token: true,
            id: e.id,
            status
          }
        }
      })

      this.showReview = true
    },
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>