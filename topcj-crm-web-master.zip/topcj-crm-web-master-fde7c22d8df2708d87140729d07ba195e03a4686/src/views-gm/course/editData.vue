<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      {{data ? '编辑' : '新增'}}课程
    </template>

    <!-- 表单信息 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool';

export default {
  data(){
    return{
      //加载状态
      loading:false,
      //表单数据
      form: {
        name: this.data?.name ?? '',
        teacherList: this.data?.teacherList?.split(',').filter(e => e).map(e => Number(e)) ?? [],
        sort: this.data?.sort ?? '',
        keyword: this.data?.keyword ?? '',
        status: this.data?.status ?? '',
        level: this.data?.level ?? '',
        cover: this.data?.cover ?? '',
        info: this.data?.info ?? '',
        useCorpIds: this.data?.useCorpIds?.split(',').filter(e => e).map(e => Number(e)) ?? [],
        chargeType: this.data?.chargeType ?? '',
      },
      config: {
        name: {
          label: '课程名称',
          rule: [
            { required: true }
          ]
        },
        teacherList: {
          label: '投顾老师',
          type: 'select-manager',
          filter: {
            managerType: 3
          },
          multiple: true,
          rule:[
            { required: true }
          ]
        },
        // teacherId: {
        //   label: '投顾老师',
        //   type: 'select-manager',
        //   filter: {
        //     managerType: 3
        //   },
        //   rule:[
        //     { required: true }
        //   ]
        // },
        cover: {
          label: '封面',
          type: 'image'
        },
        info: {
          label: '简介',
          type: 'textarea'
        },
        sort: {
          label: '排序',
          type: 'number',
          min: 0
        },
        keyword: {
          label: '关键字',
          rule: [
            { required: true }
          ]
        },
        status: {
          label: '状态',
          type: 'select',
          options:[
            { label: '通过', value: 1 },
            { label: '未通过', value: 0 }
          ],
          rule:[
            { required: true }
          ]
        },
        level: {
          label: '等级',
          type: 'select',
          options: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(e => {
            return { label: `L${e}`, value: e }
          }),
          rule:[
            { required: true }
          ]
        },
        chargeType: {
          label: '课程性质',
          type: 'select',
          options:[
            { label: '免费', value: 0 },
            { label: '加微可看', value: 1 },
            { label: '收费可看（有试看）', value: 2 },
            { label: '收费可看（无试看）', value: 3 }
          ],
          // rule:[
          //   { required: true }
          // ]
        },
        useCorpIds: {
          type: 'select-corp',
          label: '公用总部内容',
          placeholder: '未选择则所有分公司公用总部内容',
          multiple: true,
          hide: () => this.$store.state.managerInfo.corpId !== 0
        }
      }
    }
  },
  props:{
    show: Boolean,
    data: Object
  },
  methods:{
    //提交
    submit: throttle(async function(){
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/product/course_edit.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          name: this.form.name,
          teacherList: this.form.teacherList.join(','),
          cover: this.form.cover,
          info: this.form.info,
          keyword: this.form.keyword,
          status: this.form.status,
          sort: this.form.sort ?? 0,
          level: this.form.level,
          useCorpIds: this.form.useCorpIds.join(','),
          chargeType: this.form.chargeType
        }
      })
      
      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close(){
      this.$emit('update:show', false)
    }
  }
}
</script>