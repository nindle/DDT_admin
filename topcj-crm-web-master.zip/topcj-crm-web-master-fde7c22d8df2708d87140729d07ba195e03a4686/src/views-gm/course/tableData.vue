<template>
  <el-table-pro
    :head="head"
    :data="data"
    @selection-change="$emit('update:select-list',$event)"
  >
    <template #body-operation="{ row }">
      <el-button
        type="text"
        size="small"
        icon="el-icon-edit"
        @click="$emit('edit', row)"
      >编辑</el-button>
    </template>
  </el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'id',
          label: '课程编号',
          minWidth: 60
        },
        {
          key: 'name',
          label: '课程名称',
          minWidth: 120,
          tooltip: true
        },
        {
          key: 'corpId',
          label: '归属公司',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.corpList,
            key: 'id',
            value: 'corpName'
          }
        },
        // {
        //   key: 'length',
        //   label: '时长',
        //   minWidth: 60
        // },
        {
          key: 'teacherId',
          label: '投顾老师',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.managerList.filter(e => e.managerType === 3),
            key: 'id',
            value: 'realName'
          }
        },
        // {
        //   key: 'videoCount',
        //   label: '视频总数',
        //   minWidth: 56
        // },
        // {
        //   key: 'level',
        //   label: '等级',
        //   minWidth: 28,
        //   format: 'L{level}'
        // },
        // {
        //   key: 'sort',
        //   label: '排序',
        //   minWidth: 42
        // },
        {
          key: 'ctime',
          label: '送审时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'utime',
          label: '审核时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'reviewer',
          label: '审核人',
          minWidth: 70,
          default: '--'
        },
        {
          key: 'status',
          label: '状态',
          minWidth: 42,
          format: {
            '0': '不通过',
            '1': '通过',
          }
        },
        {
          key: 'operation',
          label: '操作',
          width: 44
        }
      ]
    }
  },
  props: {
    data: Array
  }
}
</script>