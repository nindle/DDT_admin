<template>
  <el-table-pro @selection-change="$emit('update:select-list', $event)" :data="data" :head="head"> </el-table-pro>
</template>

<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'id',
          label: '编号',
          minWidth: 40,
          copy: true
        },
        {
          key: 'name',
          label: '名称',
          minWidth: 100,
          excel: false
        },
        {
          key: 'des',
          label: '介绍',
          minWidth: 160,
          copy: true
        },
        {
          key: 'radarCode',
          label: '关联战绩雷达栏目',
          minWidth: 90,
          format: {
            list: this.radarColumnList,
            key: 'code',
            value: 'name'
          }
        },
        {
          key: 'createTime',
          label: '送审时间',
          minWidth: 140,
          format: e => new Date(Number(e)).timeFormat()
        },
        {
          key: 'auditTime',
          label: '审核时间',
          minWidth: 140,
          format: e => new Date(Number(e)).timeFormat()
        },
        {
          key: 'auditStatus',
          label: '状态',
          minWidth: 62,
          format: {
            NOT_APPROVAL: '未审核',
            APPROVAL: '审核通过',
            APPROVAL_FAIL: '审核不通过'
          }
        },
        {
          key: 'operation',
          label: '操作',
          width: 40,
          excel: false
        },
        {
          key: 'edit',
          button: {
            type: 'text',
            size: 'small',
            icon: 'el-icon-edit',
            label: '编辑',
            click: row => {
              this.$emit('edit', row)
            }
          },
          excel: false
        }
      ]
    }
  },
  props: {
    data: Array,
    selectList: Array,
    radarColumnList: Array
  },
  methods: {}
}
</script>
<style lang="scss" scoped>
.image {
  width: 100px;
  height: 60px;
  display: block;
  border-radius: 8px;
  cursor: pointer;
  object-fit: cover;
}
</style>
