<template>
  <div class="view">
    <el-layout-pro class="box" :loading="loading" :total="total" :page-num.sync="pageNum" :page-size.sync="pageSize" @page-change="getTableData()">
      <!-- 筛选模块 -->
      <template #screen>
        <el-screen-pro :model="screen" :config="config" @change="getTableData(true)"></el-screen-pro>
      </template>

      <!--表格模块-->
      <template #table>
        <table-data :data="tableData" :select-list.sync="selectList" :radar-column-list="radarColumnList" @edit="openPopover" />
      </template>

      <!--添加模块-->
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :column-list="columnList"
          :radar-column-list="radarColumnList"
          :data="rowData"
          @change="getTableData()"
        />

        <review v-if="showReview" :show.sync="showReview" reviewKey="auditStatus" :review-list="reviewList" @success="getTableData()" />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'
import Review from '../../components/review/index'

export default {
  name: 'gm-news',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      //修改数据
      rowData: null,

      screen: {
        corpId: '',
        search: ''
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => {
            this.openPopover(null)
          }
        },
        corpId: {
          type: 'select-corp'
        },
        online: {
          type: 'button',
          label: '审核通过',
          buttonType: 'primary',
          click: () => {
            this.openReview('APPROVAL')
          }
        },
        offline: {
          type: 'button',
          label: '审核不通过',
          buttonType: 'primary',
          click: () => {
            this.openReview('APPROVAL_FAIL')
          }
        },
        split: {
          type: 'split'
        },
        search: {
          type: 'input',
          placeholder: '搜索关键字',
          changeLog: true
        }
      },
      showReview: false,
      selectList: [],
      reviewList: [],
      columnList: [],
      radarColumnList: []
    }
  },
  props: {
    nav: Object
  },
  components: {
    TableData,
    EditData,
    Review
  },
  methods: {
    //数据获取
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if (toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        mode: 'get',
        url: `%ZZB%/dragon/inside/option/bottom/list`,
        data: {
          search: this.screen?.search,
          page: this.pageNum,
          pageSize: this.pageSize
        }
      })
      this.total = result.total
      this.tableData = result.records

      this.loading = false
    }),
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    },

    async getColumnList() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/info/get_info_type.sdcrm',
        data: { token: true }
      })
      this.columnList.splice(0, this.columnList.length, ...result)
    },

    async getRadarColumnList() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%ZZB%/dragon/inside/stock/radar/types',
        data: { token: true }
      })
      this.radarColumnList.splice(0, this.radarColumnList.length, ...result)
    },

    //审核
    openReview(status) {
      this.reviewList = this.selectList.map(e => {
        return {
          url: '%ZZB%/dragon/inside/option/bottom/add',
          data: {
            token: true,
            id: e?.id,
            code: e?.code,
            name: e.name,
            articleTypeId: e.articleTypeId,
            des: e.des,
            radarCode: e.radarCode,
            auditStatus: status
          }
        }
      })
      this.showReview = true
    }
  },
  created() {
    this.getColumnList()
    this.getRadarColumnList()
  }
}
</script>

<style scoped lang="scss">
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #fff;
  }
}
</style>
