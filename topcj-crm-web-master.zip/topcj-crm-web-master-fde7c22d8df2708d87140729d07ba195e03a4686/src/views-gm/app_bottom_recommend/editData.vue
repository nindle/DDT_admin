<template>
  <el-dialog-pro @close="close" frame-full-screen :default-frame-full="defaultFrameFull" @full-screen="setFullscreen">
    <!-- 标题 -->
    <template #title> {{ data ? '编辑' : '新增' }}底部推荐 </template>

    <!-- 表单内容 -->
    <el-form-pro :model="form" :config="config" ref="form" />

    <!-- 底部按钮 -->
    <template #footer>
      <el-button size="small" @click="close">取 消</el-button>
      <el-button type="primary" size="small" @click="submit" :loading="loading">提交保存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle, storage } from '../../assets/js/tool'

export default {
  data() {
    return {
      preview: storage.local('gm-news-edit-preview') ?? false,
      defaultFrameFull: storage.local('gm-news-edit-full-screen') ?? false,
      loading: false,
      form: {
        name: this.data?.name ?? '',
        radarCode: this.data?.radarCode ?? '',
        des: this.data?.des ?? '',
        articleTypeId: this.data?.articleTypeId ?? ''
      },
      config: {
        name: {
          type: 'input',
          label: '名称',
          wordLimit: 8,
          rule: [{ required: true }]
        },
        radarCode: {
          type: 'select',
          label: '关联战绩雷达栏目',
          options: this.radarColumnList,
          valueKey: 'code',
          labelKey: 'name',
          rule: [{ required: true }],
          filterable: true
        },
        des: {
          type: 'textarea',
          label: '介绍',
          wordLimit: 15,
          rule: [{ required: true }]
        },
        articleTypeId: {
          type: 'select',
          label: '归属栏目',
          options: this.columnList,
          valueKey: 'id',
          labelKey: 'typeName',
          rule: [{ required: true }]
        }
      }
    }
  },
  computed: {},
  props: {
    show: Boolean,
    data: Object,
    columnList: Array,
    radarColumnList: Array
  },
  components: {},
  methods: {
    setFullscreen(full) {
      storage.local('gm-news-edit-full-screen', full)
    },
    togglePreview() {
      this.preview = !this.preview
      storage.local('gm-news-edit-preview', this.preview)
    },
    //提交
    submit: throttle(async function() {
      if (!(await this.$refs.form.check())) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: '%ZZB%/dragon/inside/option/bottom/add',
        data: {
          id: this.data?.id,
          code: this.data?.code,
          token: true,
          name: this.form.name,
          articleTypeId: this.form.articleTypeId,
          des: this.form.des,
          radarCode: this.form.radarCode,
          auditStatus: this.data?.auditStatus
        }
      })

      this.loading = false

      if (code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  },
  created() {}
}
</script>

<style lang="scss" scoped>
.other-input {
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
  /deep/ {
    .el-input-number {
      width: calc((100% - 16px) / 3);
      .el-input {
        width: 100%;
      }
    }
  }
}

.button-preview {
  position: absolute;
  top: -37px;
  right: 0;
}
.popover.full-screen {
  /deep/ {
    .el-dialog {
      width: 520px !important;
    }
    .right-form {
      width: calc(100vw - 48px - 520px);
    }
    .right-content {
      &.preview {
        .right-form {
          width: calc(100vw - 48px - 520px - 376px);
        }
      }
    }
  }
}
.right-form {
  width: 750px;
  padding: 8px 20px 20px;
  box-sizing: border-box;
  height: 100%;
  &.hide-login-lock {
    /deep/ {
      .w-e-menu-loginlock {
        display: none;
      }
    }
  }
  /deep/ {
    .el-form-item__error {
      top: -31px;
      left: 50px;
    }
    .el-form-item__label-wrap {
      float: none;
    }
    .el-form-item__content {
      margin-left: 0 !important;
      height: calc(var(--popover-height) - 28px - 40px);
    }
    /* .w-e-menu-loginlock { display: none;} */
  }
}
.phone {
  width: 375px;
  height: 100%;
  border-left: 1px solid #e9e9e9;
}

.right-content {
  display: flex;
  height: 100%;
  &.preview {
    .right-form {
      width: 375px;
    }
  }
}
</style>
