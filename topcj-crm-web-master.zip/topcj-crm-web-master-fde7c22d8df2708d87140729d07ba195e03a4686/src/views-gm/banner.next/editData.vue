<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title> {{ data ? '编辑' : '新增' }}推广策划 </template>
    <!-- 表单内容 -->
    <el-form-pro :model="form" :config="config" ref="form">
    </el-form-pro>

    <!-- 底部按钮 -->
    <template #footer>
      <el-button size="small" @click="close">取 消</el-button>
      <el-button type="primary" size="small" @click="submit" :loading="loading">确 定</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        name: this.data?.name ?? '',
        type: this.data?.type ?? '',
        resChannelId: this.data?.resChannelId ?? '',
        userGroupCode: this.data?.userGroupCode?.split(',').filter(e => e) ?? [],
        userId: this.data?.userId ?? '',
        authorId: this.data?.authorId ?? '',
        position: this.data?.position ?? '',
        pic: this.data?.pic,
        link: this.data?.link,
        ctimestamp: this.data?.ctime ? new Date(this.data.ctime).getTime() : Date.now(),
        activetime: this.data?.stime ? [new Date(this.data.stime).getTime(), new Date(this.data.etime).getTime()] : null,
        fileUrl: this.data?.fileUrl
          ? this.data.fileUrl
              .split(',')
              .filter(e => e)
              .map(e => {
                let l = e.split('/')
                return {
                  name: l[l.length - 1],
                  url: e
                }
              })
          : [],
        wxRes: this.data?.wxRes ?? 0,
        picSize: this.data?.picSize ?? 0,
        download: [],
        fileUuid: ''
      },
      config: {
        name: {
          label: '策划名称',
          rule: [{ required: true }],
          wordLimit: 20
        },
        type: {
          type: 'select',
          label: '策划类型',
          options: [
            { value: 0, label: '推广策划' },
            { value: 1, label: '营销策划' }
          ],
          rule: [{ required: true }]
        },
        resChannelId: {
          type: 'select',
          label: '投放渠道',
          options: this.$store.state.baseData.resChannelList,
          valueKey: 'id',
          labelKey: 'channelName'
        },
        userGroupCode: {
          type: 'select',
          label: '投放对象',
          options: this.tagList,
          valueKey: 'tagCode',
          labelKey: 'tagName',
          hide: this.type == 1,
          multiple: true,
          change: () => {
            this.form.userId = ''
            if (this.form.userGroupCode.includes('418566a978f046dbaf78a807556a13a0')) {
              this.form.userGroupCode.splice(0, this.form.userGroupCode.length, '418566a978f046dbaf78a807556a13a0')
              this.config.userGroupCode.options.forEach(e => {
                e.disabled = e.tagCode !== '418566a978f046dbaf78a807556a13a0'
              })
            } else if (this.form.userGroupCode.includes('c3b677f19c0d4e4aba152f253d34a5ac')) {
              this.form.userGroupCode.splice(0, this.form.userGroupCode.length, 'c3b677f19c0d4e4aba152f253d34a5ac')
              this.config.userGroupCode.options.forEach(e => {
                e.disabled = e.tagCode !== 'c3b677f19c0d4e4aba152f253d34a5ac'
              })
            } else if (this.form.userGroupCode.includes('ae09f86c4e7a43d29208d65b0f588753')) {
              this.form.userGroupCode.splice(0, this.form.userGroupCode.length, 'ae09f86c4e7a43d29208d65b0f588753')
              this.config.userGroupCode.options.forEach(e => {
                e.disabled = e.tagCode !== 'ae09f86c4e7a43d29208d65b0f588753'
              })
            } else {
              this.config.userGroupCode.options.forEach(e => {
                e.disabled = false
              })
            }
          }
        },
        userId: {
          type: 'input',
          label: '用户ID',
          rule: [{ required: true }],
          hide: () => !this.form.userGroupCode.includes('418566a978f046dbaf78a807556a13a0')
        },
        download: {
          type: 'file-list',
          label: '下载模板',
          autoUpload: false,
          accept: '.xlsx',
          disabled: false,
          template: `${this.SYS.URL}/xlsx/appUser_template.xlsx`,
          rule: [{ required: true }],
          hide: () => !this.form.userGroupCode.includes('ae09f86c4e7a43d29208d65b0f588753'),
          change: () => this.uploadFile()
        },
        authorId: {
          label: '内容作者',
          type: 'select-manager',
          filter: {
            managerType: 3
          }
        },
        wxRes: {
          type: 'switch',
          label: '微信资源',
          activeValue: 1,
          inactiveValue: 0
        },
        position: {
          type: 'textarea',
          label: '页面地址',
          disabled: !!this.data?.promotionId,
          rule: [{ required: true }]
        },
        pic: {
          type: 'image',
          label: '图片',
          fileSize: e => {
            this.form.picSize = e
          }
        },
        link: {
          type: 'input',
          label: '链接地址',
          disabled: this.data ? [2, 6, 3, 4, 5].includes(this.data.pageType) : false
        },
        ctimestamp: {
          type: 'date-time',
          label: '发布时间',
          rule: [{ required: true }]
        },
        activetime: {
          type: 'date-time-range',
          label: '活动时间',
          rule: [{ required: true }]
        },
        fileUrl: {
          label: '附件',
          type: 'file-list'
        },
      },
      loading: false,
    }
  },
  props: {
    show: Boolean,
    data: Object,
    type: Number,
    tagList: Array,
  },
  methods: {
    submit: throttle(async function() {
      if (!(await this.$refs.form.check())) return

      this.loading = true

      let { code, errmsg, msg, result } = await this.$http({
        url: '%CRM%/ad/set_ad.sdcrm',
        data: {
          token: true,
          adId: this.data?.id ?? -1,
          name: this.form.name,
          type: this.form.type,
          resChannelId: this.form.resChannelId,
          authorId: typeof this.form.authorId === 'number' ? this.form.authorId : undefined,
          pic: this.form.pic,
          link: this.form.link,
          ctimestamp: this.form.ctimestamp,
          stime: this.form.activetime[0],
          etime: this.form.activetime[1],
          fileUrl: this.form.fileUrl.map(e => e.url).join(','),
          wxRes: this.form.wxRes,
          picSize: this.form.picSize,
          userGroupCode: this.form.userGroupCode.join(','),
          userId: this.form.userId,
          position: this.form.position,
          fileUuid: this.form.fileUuid || void 0
        }
      })

      if (code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      let data = result
      if (!data) {
        this.loading = false
        return
      }
      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),

    close() {
      this.$emit('update:show', false)
    },

    async uploadFile(){
      await this.form.download
      if(this.form.download.length > 0){
        this.config.download.disabled = true
      }
      let allData = this.form.download.map(e => {
        return {
          mode: 'form',
          url: '%ZZB%/dragon/inside/upload/file',
          data: {
            token: true,
            type: 1,
            file: e.file,
          }
        }
      })

      let data = await this.$http({
        mode: 'relay',
        all: allData,
        interval: 20,
      })
      this.form.fileUuid = data[0].result
    }
  },
  beforeDestroy() {
    this.config.userGroupCode.options.forEach((e)=>{
      e.disabled = false
    })
  }
}
</script>

<style lang="scss" scoped>
.right-box {
  position: relative;
  margin-top: 54px;
  height: calc(100% - 54px);
}
.tips {
  color: #F56C6C;
}
</style>
