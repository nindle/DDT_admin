<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <!-- 筛选模块 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <!--表格模块-->
      <template #table>
        <table-data
          :data="tableData"
          :select-list.sync="selectList"
          @edit="openPopover"
          @change="getTableData"
        />
      </template>

      <!--编辑模块-->
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          :tag-list="tagList"
          @change="getTableData()"
        />
        <review
          v-if="showReview"
          :show.sync="showReview"
          :review-list="reviewList"
          @success="getTableData()"
          custom-reason
          reason
          deduct
          source="t_sd_ad"
          reviewKey="state"
        />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'
import Review from '../../components/review/index'

export default {
  name: 'gm-banner',
  data () {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      showSetGroup: false,
      //修改数据
      rowData: null,
      screen: {
        corpId: '',
        keyword: '',
        resChannelId: '',
        status: '',
      },
      tagList: [],
      config: {
        corpId: {
          type: 'select-corp'
        },
        status: {
          type: 'select',
          placeholder: '审核状态',
          options: [
            { value: 0, label: '待审核' },
            { value: 1, label: '通过' },
            { value: 2, label: '不通过' }
          ]
        },
        resChannelId: {
          placeholder: '投放渠道',
          type: 'select',
          options: this.$store.state.baseData.resChannelList,
          labelKey: 'channelName',
          valueKey: 'id'
        },
        split: { type: 'split' },
        keyword: {
          type: 'input',
          placeholder: '搜索编号',
          changeLog: true
        },
        br: { type: 'br' },
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) }
        },
        split2: { type: 'split' },
        reviewOnline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核通过',
          click: () => { this.openReview(1) }
        },
        reviewOffline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核不通过',
          click: () => { this.openReview(2) }
        },
      },
      //审核相关
      selectList: [],
      showReview: false,
      reviewList: [],
    }
  },
  components: {
    TableData,
    EditData,
    Review,
  },
  methods: {
    //数据获取
    getTableData: throttle(async function (toFirst) {
      this.loading = true

      if (toFirst) {
        this.pageNum = 1
      }
      let { result } = await this.$http({
        url: '%CRM%/ad/get_ad_search.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          companyId: this.screen.corpId,
          keyword: this.screen.keyword || undefined,
          resChannelId: typeof this.screen.resChannelId === 'number' ? this.screen.resChannelId : undefined,
          status: typeof this.screen.status === 'number' ? this.screen.status : undefined,
        }
      })

      this.total = result.total
      this.tableData = result.contents
      this.loading = false
    }),
    
    //打开弹框
    openPopover (data) {
      this.rowData = data
      this.showPopover = true
    },

    //审核
    openReview (state) {
      this.reviewList = this.selectList.map(e => {
        return {
          url: '%CRM%/ad/audit.sdcrm',
          data: {
            token: true,
            id: e.id,
            state,
            corpId: this.$store.state.managerInfo.corpId,
          }
        }
      })
      this.showReview = true
    },

    // 获取推送对象列表
    async getTagList () {
      let { result } = await this.$http({
        url: '%ZZB%/dragon/inside/message/tags',
        mode: 'get'
      })
      this.tagList.splice(0, this.tagList.length, ...result)
    },
  },
  created () {
    this.getTagList()
  }
}
</script>

<style scoped lang="scss">
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #fff;
  }
}
</style>
