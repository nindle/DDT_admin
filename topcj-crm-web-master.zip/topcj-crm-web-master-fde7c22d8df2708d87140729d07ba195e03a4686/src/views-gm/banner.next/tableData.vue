
<template>
  <el-table-pro
    :data="data"
    :head="head"
    @selection-change="$emit('update:select-list', $event)"
  >
    <template #body-fileUrl="{ row }">
      <el-button
        v-for="(e, i) in (row.fileUrl || '').split(',').filter(e => e)"
        :key="i"
        type="text"
        size="small"
        v-open="e"
        icon="el-icon-download"
        style="margin: 0 8px 0 0"
      >附件{{i + 1}}</el-button>
    </template>

    <template #body-status="{ row, content }">
      <el-popover
        :disabled="row.status !== 2"
        placement="top"
        trigger="hover"
      >
        <i class="el-icon-warning" style="color: #F56C6C; margin-right: 8px"></i>{{row.trialReason}}
        <span slot="reference">{{content}}</span>
      </el-popover>
    </template>
  </el-table-pro>
</template>

<script>

export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'id',
          label: '推广编号',
          minWidth: 60
        },
        {
          key: 'name',
          label: '策划名称',
          minWidth: 120,
          tooltip: true
        },
        {
          key: 'type',
          label: '策划类型',
          minWidth: 56,
          format: {
            '0': '推广策划',
            '1': '营销策划'
          }
        },
        {
          key: 'position',
          label: '页面位置',
          minWidth: 200,
          copy: true
        },
        {
          key: 'pic',
          label: '图片预览',
          minWidth: 60,
          button: {
            type:'text',
            size:'small',
            label: '查看',
            icon:'el-icon-picture-outline',
            disabled: row => {return !row.pic },
            click: row => { this.$imageview({
              list: row.pic.split(','),
              index: 0
            })}
          }
        }, 
        {
          key: 'ctime',
          label: '送审时间',
          minWidth: 140,
          format:e => new Date(e).timeFormat()
        },
        {
          key: 'fileUrl',
          label: '附件',
          minWidth: 140,
          default: '--'
        },
        {
          key: 'createrName',
          label: '送审人',
          minWidth: 70,
        },
        {
          key: 'firstTrial',
          label: '审核人',
          minWidth: 70
        },
        {
          key: 'status',
          label: '状态',
          minWidth: 42,
          format: {
            '0': '待审核',
            '1': '通过',
            '2': '不通过',
          }
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click:row => { this.$emit('edit', row) }
          },
          fixed: 'right'
        },
      ]
    }
  },
  props: {
    data: Array,
    selectList: Array,
  },
}
</script>
