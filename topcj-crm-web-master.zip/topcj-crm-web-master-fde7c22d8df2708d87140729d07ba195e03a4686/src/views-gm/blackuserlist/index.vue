<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >  
      <!-- 筛选模块 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
          :auto-change="false"
          ref="screen"
        ></el-screen-pro> 
      </template>
    
      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData" 
          @change="getTableData()"
        />
      </template> 

      <!--添加模块-->
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :mode="showPopoverMode"
          @change="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-blackuserlist',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      showPopoverMode: 1,
      screen: {
        corpId: '',
        blackType: '',
        mobile: ''
      },
      config: {
        corpId: {
          type: 'select',
          placeholder: '事业部',
          placeholderInLabel: '事业部',
          options: this.$store.state.baseData.corpList.filter(e => e.id),
          labelKey: 'corpName',
          valueKey: 'id'
        },
        blackType: {
          placeholder: '类型',
          placeholderInLabel: '类型',
          type: 'select',
          options:[
            { value: 0, label:'其他'},
            { value: 1, label:'普通'},
            { value: 2, label:'三级'},
            { value: 3, label:'二级'},
            { value: 4, label:'一级'}
          ]
        },
        split:{
          type:'split'
        },
        search: {
          type: 'button',
          buttonType: 'primary',
          label: '查询',
          click: () => {
            this.$refs.screen.emitModel()
            this.getTableData(true)
          }
        },
        reset: {
          type: 'button',
          label: '重置',
          click: () => {
            this.$refs.screen.resetModel()
          }
        },
        br: { type: 'br' },
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '新增',
          click: () => { 
            this.showPopoverMode = 1
            this.showPopover = true 
          }
        },
        imports: {
          type: 'button',
          buttonType: 'primary',
          label: '导入',
          click: () => { 
            this.showPopoverMode = 2
            this.showPopover = true 
          },
          hide: () => this.$store.state.managerInfo.corpId !== 0,
        },
        split2:{
          type:'split'
        },
        mobile: {
          type: 'input',
          placeholder: '手机号码',
          changeLog: true,
          change: (v) => {
            this.screen.mobile = v
            this.getTableData(true)
          }
        },
      }
    }
  },
  components:{
    TableData,
    EditData
  },
  methods: {
    //数据获取
    getTableData: throttle(async function(toFirst) {
      this.$refs.screen.cancelModel()
      
      if(!this.showPopover) this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/black/get_black_list.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          blackType: typeof this.screen.blackType === 'number' ? this.screen.blackType : undefined,
          mobile: this.screen.mobile || undefined
        }
      })

      this.total = result.total
      this.tableData = result.records
      this.loading = false
    })
  }
}
</script>

<style scoped lang="scss">

.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>
