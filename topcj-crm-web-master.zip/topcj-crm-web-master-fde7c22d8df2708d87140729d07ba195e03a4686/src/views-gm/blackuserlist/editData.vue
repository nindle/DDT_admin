
<template>
  <el-dialog-pro 
    @close="close"
    max-height
  >
    <!--标题-->
    <template #title>
      添加黑名单
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
    </el-form-pro>

    <template #right>
      <el-scrollbar-pro>
        <div class="tip-content">
          <h2>（一）一级外诉退费客户</h2>
          <p>1、投诉至证监会及其他各地派出机构的举报性质的的外诉；</p>
          <p>2、投诉至公安局、检察院、法院等有关部门并立案；</p>
          <p>3、投诉致使公司银行账户冻结或部分资金冻结；</p>
          <p>4、投诉致使顶点抖音账号（蓝V）封停；</p>
          <p>5、投诉影响到其他事业部企业微信（工作台或企微外部联系人功能）封停；</p>
          <p>6、投诉致使公司中继线停用。</p>
          <p><br></p>
          <h2>（二）二级外诉退费客户</h2>
          <p>1、投诉至中国证监会服务热线12386、中国证监会举报网站等非举报证券系外诉的情形；</p>
          <p>2、投诉至市政府热线12345、消费者举报热线12315、市场监督管理局、金融办、公检法报案查询；</p>
          <p>3、投诉至工信部、通管局等有关部门；</p>
          <p>4、投诉至公安、法院、检察院、银监会、银行等有关部门；</p>
          <p>5、投诉致使公司部分号码暂停。</p>
          <p><br></p>
          <h2>（三）三级外诉退费客户</h2>
          <p>1、投诉至支付宝、微信及银行等支付通道（金额大于3800元），出现账户风险警告、收款限制、用户投诉等情形；</p>
          <p>2、投诉至电视台、媒体平台，或因用户投诉在公众媒体曝光公司负面信息的情形。</p>
          <p><br></p>
          <h2>（四）普通退费客户</h2>
          <p>1、所有退费但无外诉的客户（定金、预存款等操作退费的行为不列入D类）。</p>
          <p><br></p>
          <h2>（五）其他</h2>
          <p>1、未成年（18周岁以下）、超龄（75周岁以上）客户；</p>
          <p>2、法律规定不能炒股的人，包括但不仅限于证券交易内幕信息的知情人；</p>
          <p>3、事业部、合规监察部部、战略运营中心提交名单（同行、维权等）</p>
          <p>4、爱理财缴费1w元以上的客户（爱理财渠道的黑名单，目前在顶点通黑名单库里显示入库时间为1970年，手机号空白或者非正常手机号显示的就是）</p>
          <p>5、其他不符合一、二、三、四类别的，均列入（五）其他类。</p>
        </div>
      </el-scrollbar-pro>
    </template>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      form: {
        corpId: this.$store.state.managerInfo.corpId || '',
        blackType: '',
        mobile: '',
        memo: '',
        fileList: []
      },
      config: {
        corpId: {
          type: 'select',
          label: '事业部',
          options: this.$store.state.baseData.corpList.filter(e => e.id),
          labelKey: 'corpName',
          valueKey: 'id',
          rule: [
            { required: true }
          ],
          disabled: this.$store.state.managerInfo.corpId !== 0
        },

        blackType: {
          hide: () => this.mode !== 1,
          label: '类型',
          type: 'select',
          options: [
            { value: 0, label:'其他'},
            { value: 1, label:'普通'},
            { value: 2, label:'三级'},
            { value: 3, label:'二级'},
            { value: 4, label:'一级'}
          ],
          rule: [
            { required: true }
          ]
        },
        mobile: {
          hide: () => this.mode !== 1,
          placeholder: '请输入手机号码，多个使用换行隔开',
          label: '手机号',
          type: 'textarea',
          rule: [
            { required: true }
          ]
        },
        memo: {
          label: '备注',
          type: 'textarea',
          hide: () => this.mode !== 1,
        },
        fileList: {
          hide: () => this.mode !== 2,
          label: '文件',
          type: 'file-list',
          autoUpload: false,
          accept: '.xlsx',
          template: `${this.SYS.URL}/xlsx/blackuser_template.xlsx`,
          rule: [
            { required: true, type: 'array' }
          ]
        }
      },
      loading: false
    }
  },
  props: {
    mode: Number
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      if(this.mode === 1) {
        await this.submitMode1()
      }else{
        await this.submitMode2()
      }
    }),
    //文本模式
    async submitMode1() {
      this.loading = true
      
      let list = this.form.mobile.split('\n').map(e => e.replace(/[^0-9]/g, '')).filter(e => e)
      let phoneList = list.filter(e => /1\d{10}/.test(e))
      let errorList = list.filter(e => !(/1\d{10}/.test(e))).map(e => `手机号格式错误：${e}`)
      let error = errorList.length
      let successCount = 0
      let errorCount = 0

      let allData = phoneList.map(e => {
        return {
          url: '%CRM%/black/insert.sdcrm',
          data: {
            token: true,
            blackType: this.form.blackType,
            mobile: e,
            corpId: this.form.corpId,
            memo: this.form.memo,
          }
        }
      })

      let data = await this.$http({
        mode: 'relay',
        all: allData,
        interval: 20,
      })

      this.loading = false

      data.map((e, i) => {
        if(e.code === 8200) {
          successCount ++
        }else{
          errorCount ++
          errorList.push(`${e.errmsg || e.msg}：${allData[i].data.mobile}`)
        }
      })

      if(error + successCount + errorCount === 1) {
        if(successCount === 1) {
          this.$message.success(`添加成功`)
          this.$emit('change')
          this.close()
        }else if(error === 1){
          this.$message.error('输入错误')
          return
        }else if(errorCount === 1){
          this.$message.error(data[0].errmsg || data[0].msg)
        }
      }else{
        this.$message.success(`添加成功${successCount}条，失败${errorCount}条，输入错误${error}条`)
        this.$emit('change')
        if(errorList.length){
          this.form.mobile = errorList.join('\n')
        }else{
          this.close()
        }
      }
    },
    //Excel模式
    async submitMode2() {
      let allData = this.form.fileList.map(e => {
        return {
          mode: 'form',
          url: '%CRM%/black/batch_insert.sdcrm',
          data: {
            token: true,
            file: e.file,
            corpId: this.form.corpId,
          }
        }
      })

      let data = await this.$http({
        mode: 'relay',
        all: allData,
        interval: 20,
      })

      let successCount = 0
      let errorCount = 0

      data.map((e, i) => {
        if(e.code === 8200) {
          successCount++
        }else{
          errorCount++
          this.form.fileList[i].del = true
        }
      })

      if(successCount + errorCount === 1) {
        if(successCount === 1) {
          this.$message.success(`添加成功`)
          this.$emit('change')
          this.close()
        }else if(errorCount === 1){
          this.$message.error(data[0].errmsg || data[0].msg)
        }
      }else{
        this.$message.success(`添加成功${successCount}个文件，失败${errorCount}个文件`)
        this.$emit('change')
        if(errorCount){
          this.form.fileList = this.form.fileList.filter(e => e.del)
        }else{
          this.close()
        }
      }
    },
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>

<style lang="scss" scoped>
.tip-content {
  padding: 24px;
  h2 {
    font-size: 18px;
    font-weight: 600;
  }
  > * {
    padding: 2px 0;
  }
}
</style>
