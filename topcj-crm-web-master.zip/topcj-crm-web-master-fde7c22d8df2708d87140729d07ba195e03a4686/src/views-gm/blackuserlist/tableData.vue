<template>
  <el-table-pro
    :data="data"
    :head="head"
  ></el-table-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: '编号',
          minWidth: 60
        },
        {
          key: 'corpId',
          label: '事业部',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.corpList,
            key: 'id',
            value: 'corpName'
          }
        },
        {
          key: 'blackType',
          label: '类型',
          minWidth: 28,
          format: {
            '0': '其他',
            '1': '普通',
            '2': '三级',
            '3': '二级',
            '4': '一级',
          }
        },
        {
          key: 'mobile',
          label: '手机号',
          minWidth: 90,
        },
        {
          key: 'ctime',
          label: '添加时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'managerId',
          label: '添加人',
          minWidth: 70,
          format: {
            list: this.$store.state.baseData.managerList,
            key: 'id',
            value: 'realName'
          }
        },
        {
          key: 'memo',
          label: '备注',
          minWidth: 70,
        },
        {
          key: 'delete',
          label: '操作',
          width: 56,
          hide: () => this.$store.state.managerInfo.corpId !== 0,
          button: {
            popconfirm: '确认删除吗？',
            label: '删除',
            click: this.deleteData,
            size: 'small',
            type: 'danger'
          }
        }
      ]
    }
  },
  props: {
    data: Array
  },
  methods: {
    //删除数据
    deleteData: throttle(async function(row) {
      let { code, errmsg, msg } = await this.$http({
        mode: 'get',
        url: '%CRM%/black/del/:id.sdcrm',
        data: {
          token: true,
          id: row.id
        }
      })

      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        return
      }

      this.$message.success('删除成功')
      this.$emit('change')
    })
  }
}
</script>
