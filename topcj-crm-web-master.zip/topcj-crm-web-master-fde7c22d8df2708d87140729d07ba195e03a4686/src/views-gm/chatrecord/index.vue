<template>
  <div class="view">
    <el-layout-pro
      class="box"
      @scroll-top="scroll(0)"
      @scroll-bottom="scroll(1)"
    >
     
      <template #screen>
        <el-screen-pro 
          :config="config"
        ></el-screen-pro>
      </template>

      <template #scroll>
        <message 
          :data="messageList"
          :text-keyword="() =>{ return $route.query.keyword }"
          ref="message"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import Message from '../../components/message'
export default {
  data() {
    return {
      total: 0,
      config: {
        label: {
          type: 'label',
          label: '聊天记录'
        },
        split: {type: 'split'},
      },
      messageList: [],
      showPopover: false,
      id: 0
    }
  },
  methods: {
    async getMsg(flag,id) {

      let { result } = await this.$http({
        url: '%CRM%/user/message/get_unsettled_msg.sdcrm',
        data: {
          token: true,
          id:id || Number(this.$route.query.id),
          qyWx: this.$route.query.qywx,
          managerUserId: this.$route.query.qwmanage,
          unsettledUserId: this.$route.query.qwuserid,
          flag,
          size: 20
        }
      })

      let list = []
      this.total = result.total
      result.content.forEach(e => {
          e.nickname = e.sfrom
          e.managerName = e.sfrom
          e.lastTime = e.msgtime
          e.msgType = e.msgtype
          e.imageUrl = e.mediaUrl
          if(e.sfrom === this.$route.query.qwuserid) {
            e.type = 1
          }else{
            e.type = 0
          }
          list.push(e)
      })

      if(!flag) {
        this.messageList.unshift(...list)
        return
      }
      this.messageList.push(...list)

    },
    scroll(flag) {
      if(this.messageList.length >= this.total) return
      if(flag) {
        this.getMsg(flag,this.messageList[this.messageList.length-1].id)
        this.messageList.pop(this.messageList[this.messageList.length - 1])
        return
      }
      this.getMsg(flag,this.messageList[0].id)

    }
  },
  watch: {
    managerList() {
      if(this.managerList && this.managerList.length) {
        this.$refs.message.messageScrollIntoView(this.$route.query.id)
      }
    }
  },
  components: { 
    Message,
  },
  created() {
    this.getMsg(0)
    this.getMsg(1)
  },
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>