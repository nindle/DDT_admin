
<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      解股
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        question: this.data?.question ?? '',
        answer: this.data?.answer ?? '',
        top: this.data?.top ?? '',
        type: this.data?.type ?? ''
      },
      config: {
        question: {
          label: '问题',
          type: 'label'
        },
        type: {
          type: 'select',
          label: '咨询类型',
          options: this.tag.t39.filter(e => e.visible),
          labelKey: 'valueName'
        },
        answer: {
          label: '回复',
          type: 'textarea',
          disabled: !!this.data.answer,
          rule: [
            { required: true, message: '请回复问题' }
          ]
        },
        top: {
          label: '是否推荐',
          type: 'switch',
          activeValue: 1,
          inactiveValue: 0
        },
      },
      loading: false
    }
  },
  props: {
    data: Object,
    screen:Object
  },
  inject: ['tag'],
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/diagnoseAskRecord/reply.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          top: this.form.top,
          answer: this.form.answer,
          type: this.form.type || undefined
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>

