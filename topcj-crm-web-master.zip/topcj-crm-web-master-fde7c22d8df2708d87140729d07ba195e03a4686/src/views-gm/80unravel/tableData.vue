<template>
  <el-table-pro
    :data="data"
    :head="head"
  >
    <template #body-operation="{ row }">
      <el-button
        type="text"
        size="small"
        icon="el-icon-edit"
        @click="$emit('edit', row)"
      >回复</el-button>
    </template>

    <template #body-userId="{ row }">
      <scratch
        :data="row.userId"
        mode="userId"
        copy
      />
    </template>
  </el-table-pro>
</template>

<script>
import Scratch from '../../components/other/scratch'

export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: '诊股编号',
          minWidth: 60
        },
        {
          key: 'userId',
          label: '查询',
          minWidth: 70
        },
        {
          key: 'ctime',
          label: '诊股时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        // {
        //   key: 'stockId',
        //   label: '股票代码',
        //   minWidth: 56
        // },
        {
          key: 'question',
          label: '问诊内容',
          minWidth: 200
        },
        {
          key: 'teacherName,status',
          label: '投顾老师',
          minWidth: 70,
          format: (a, b) => b ? a : '待分配'
        },
        {
          key: 'status',
          label: '服务状态',
          minWidth: 42,
          format: {
            '0': '未回复',
            '1': '已回复',
          }
        },
        // {
        //   key: 'top',
        //   label: '推荐',
        //   minWidth: 28,
        //   format: {
        //     '0': '否',
        //     '1': '是',
        //   }
        // },
        {
          key: 'operation',
          label: '操作',
          width: 44
        }
      ]
    }
  },
  props:{
    data:Array
  },
  components: {
    Scratch
  }
}
</script>