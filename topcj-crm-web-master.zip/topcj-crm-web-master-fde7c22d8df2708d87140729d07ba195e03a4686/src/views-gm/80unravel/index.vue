<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >  
      <!-- 筛选模块 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro> 
      </template>
    
      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData"
          @edit="openPopover"
        />
      </template> 

      <!-- 编辑模块 -->
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          @change="getTableData()"
        />
      </template>   
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-80unravel',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      //修改数据
      rowData: null,

      screen: {
        status: '',
        top: '',
        teacherId: '',
        search: ''
      },
      config: {
        status: {
          placeholder: '回复状态',
          type: 'select',
          options:[
            { value: 0, label: '未回复' },
            { value: 1, label: '已回复' },
          ]
        },
        top: {
          placeholder: '推荐状态',
          type: 'select',
          options:[
            { value: 1, label: '是' },
            { value: 0, label: '否' },
          ]
        },
        teacherId: {
          placeholder: '讲师',
          type:'select-manager',
          filter: {
            managerType: 3
          }
        },
        split:{
          type:'split'
        },
        search: {
          type: 'input',
          placeholder: '请输入搜索内容',
          changeLog: true
        },
      }
    }
  },
  props: {
    tag: Object
  },
  provide() {
    return {
      tag: this.tag
    }
  },
  components: {
    TableData,
    EditData
  },
  methods: {
    //数据获取
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url:'%CRM%/diagnoseAskRecord/list.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNumber: this.pageNum,
          teacherId: typeof this.screen.teacherId === 'number' ? this.screen.teacherId : undefined,
          top: typeof this.screen.top === 'number' ? this.screen.top : 2,
          status: typeof this.screen.status === 'number' ? this.screen.status : 2,
          keyWord: this.screen.search
        }
      })

      this.total = result.total
      this.tableData = result.contents

      this.loading = false
    }),
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    }
  }
}
</script>

<style scoped lang="scss">
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>
