<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <!-- 筛选模块 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <!--表格模块-->
      <template #table>
        <table-data
          :data="tableData"
          :select-list.sync="selectList"
          :tag-list="tagList"
          :type="type"
          @edit="openPopover"
        />
      </template>

      <!--编辑模块-->
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          :tag-list="tagList"
          :column-list="columnList"
          :type="type"
          @change="getTableData()"
        />

        <review
          v-if="showReview"
          :show.sync="showReview"
          :review-list="reviewList"
          reason
          reasonKey="trialReason"
          @success="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'
import Review from '../../components/review/index'

export default {
  name: 'gm-activity',
  data () {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      //修改数据
      rowData: null,
      screen: {
        status: undefined,
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) },
          hide: () => !this.auth.includes(2)
        },
        reviewOnline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核通过',
          click: () => { this.openReview(1) },
          hide: () => !this.auth.includes(7)
        },
        reviewOffline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核不通过',
          click: () => { this.openReview(2) },
          hide: () => !this.auth.includes(7)
        },
        status: {
          type: 'select',
          placeholder: '审核状态',
          options: [
            { value: 0, label: '待审核' },
            { value: 1, label: '审核通过' },
            { value: 2, label: '审核未通过' }
          ]
        },
        // split: { type: 'split' },
        // keyword: {
        //   type: 'input',
        //   placeholder: '搜索编号',
        //   changeLog: true
        // }
      },
      //审核相关
      selectList: [],
      showReview: false,
      reviewList: [],
      // 资源弹窗


      tagList: [], // 发送人群
      columnList: []  // 类目
    }
  },
  props: {
    type: Number,
    auth: Array

  },
  provide () {
    return {
      auth: this.auth
    }
  },
  components: {
    TableData,
    EditData,
    Review,
  },
  methods: {
    //数据获取
    getTableData: throttle(async function (toFirst) {
      this.loading = true

      if (toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%ZZB%/dragon/popup/list',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          status: this.screen.status,
        }
      })

      this.total = result.total
      this.tableData = result.records.map(e => {
        let linkState = 0
        // if (e.link && [3, 4, 5].includes(e.pageType)) {
        //   let time = Number(e.link.split(';')[1] || 0)
        //   if (now - time < 169 * 24 * 3600 * 1000) {
        //     linkState = 1
        //   } else if (now - time < 179 * 24 * 3600 * 1000) {
        //     linkState = 2
        //   } else {
        //     linkState = 3
        //   }
        // }

        return {
          ...e,
          linkState
        }
      })
      this.loading = false
    }),
    //打开弹框
    openPopover (data) {
      this.rowData = data
      this.showPopover = true
    },

    //审核
    openReview (state) {
      this.reviewList = this.selectList.map(e => {
        return {
          url: '%ZZB%/dragon/popup/edit',
          data: {
            id: e.id,
            status: state,
            reviewId: this.$store.state.managerInfo.id,
          }
        }
      })
      this.showReview = true
    },
    // 发送人群
    async getTagList () {
      let { result } = await this.$http({
        url: '%ZZB%/dragon/inside/message/tags',
        mode: 'get'
      })

      this.tagList.splice(0, this.tagList.length, ...result)
    },
    // 类目
    async getColumnList () {
      let { result } = await this.$http({
        url: '%ZZB%/dragon/inside/message/column',
        mode: 'get'
      })

      this.columnList.splice(0, this.columnList.length, ...result)
    },
  },
  created () {
    this.getTagList()
    this.getColumnList()
  }
}
</script>

<style scoped lang="scss">
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #fff;
  }
}
</style>
