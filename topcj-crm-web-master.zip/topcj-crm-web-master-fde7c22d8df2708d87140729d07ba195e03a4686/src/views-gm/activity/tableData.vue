
<template>
  <el-table-pro
    :data="data"
    :head="head"
    @selection-change="$emit('update:select-list', $event)"
  >
  </el-table-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'

export default {
  data () {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'id',
          label: 'id',
        },
        {
          key: 'title',
          label: '标题',
        },
        {
          key: 'ctime',
          label: '送审时间',
          minWidth: 100,
          format: e => new Date(Number(e)).timeFormat()
        },

        {
          key: 'createId',
          label: '创建人',
          tooltip: true,
          format: {
            list: this.$store.state.baseData.managerList,
            key: 'id',
            value: 'realName'
          }
        },
        {
          key: 'reviewId',
          label: '审核人',
          format: {
            list: this.$store.state.baseData.managerList,
            key: 'id',
            value: 'realName'
          }
        },
        {
          key: 'type',
          label: '类型',
          format: {
            '1': '公告',
            '2': '广告'
          }
        },
        {
          key: 'tagCode',
          label: '发送人群',
          format: (e) => {
            return (e ?? '').split(',').filter(e => e).map(e => this.tagList.find(a => a.tagCode === e)?.tagName).join('，')
          }
        },
        {
          key: 'stime',
          label: '活动起始时间',
          minWidth: 100,
          // format: e => new Date(Number(e)).timeFormat()
        },
        {
          key: 'etime',
          label: '活动结束时间',
          minWidth: 100,
          // format: e => new Date(Number(e)).timeFormat()
        },
        {
          key: 'status',
          label: '状态',
          format: {
            '0': '未审核',
            '1': '通过',
            '2': '未通过'
          }
        },
        {
          key: 'operation',
          label: '操作',
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: row => { this.$emit('edit', row) }
          },
          hide: () => !this.auth.includes(3)
        },
      ]
    }
  },
  props: {
    data: Array,
    selectList: Array,
    userTypeList: Array,
    pageTypeList: Array,
    categoryList: Array,
    appList: Array,
    tagList: Array,
    type: Number
  },
  methods: {
    //隐藏
    setPubStatus: throttle(async function (row) {
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/ad/set_ad.sdcrm',
        data: {
          token: true,
          adId: row.id,
          pubStatus: row.pubStatus
        }
      })
      if (code !== 8200) {
        this.$message.error(`操作失败：${errmsg || msg}`)
        return
      }

      this.$message.success('操作成功')
    })
  },
  inject: ['auth']
}
</script>
