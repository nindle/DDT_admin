<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      {{data ? '编辑' : '新增'}}APP活动策划
    </template>
    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer>
      <el-button
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button
        type="primary"
        size="small"
        @click="submit"
        :loading="loading"
      >确 定</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'


export default {
  data () {
    return {
      form: {
        title: this.data?.title,  // 标题
        pic: this.data?.pic, //图片链接
        link: this.data?.link, //超链接
        content: this.data?.content ?? '', //内容
        status: this.data?.status ?? 0, // 状态
        createId: this.data?.createId ?? this.$store.state.managerInfo.id, // 创建人id	
        reviewId: this.data?.reviewId, // 审核人id	
        trialReason: this.data?.trialReason, // 不通过原因	
        sTime: this.data?.stime, // 活动起始时间	
        eTime: this.data?.eTime, // 活动结束时间	
        type: this.data?.type, // 活动类型
        tagCode: this.data?.tagCode?.split(',').filter(e => e) ?? [],
        topPic: this.data?.topPic ?? '', // 弹窗顶部图片
        isDel: this.data?.isDel, // 0未删除 1已删除
        columnType: this.data?.columnType, // 类目
        userId: this.data?.userId, // 单人ID
        activetime: [
          new Date(this.data?.stime).getTime(),
          new Date(this.data?.etime).getTime(),
        ],
        fileUuid: '',
        download: []
      },
      config: {
        title: {
          label: '活动标题',
          rule: [
            { required: true }
          ]
        },
        content: {
          label: '内容',
        },
        type: {
          type: 'select',
          label: '类型',
          options: [
            { value: 1, label: '公告' },
            { value: 2, label: '广告' }
          ],
          rule: [
            { required: true }
          ]
        },
        tagCode: {
          type: 'select',
          label: '发送人群',
          options: this.tagList,
          valueKey: 'tagCode',
          labelKey: 'tagName',
          multiple: true,
          rule: [
            { required: true }
          ],
          change: () => {
            this.form.userId = ''
            if (this.form.tagCode.includes('418566a978f046dbaf78a807556a13a0')) {
              this.form.tagCode.splice(0, this.form.tagCode.length, '418566a978f046dbaf78a807556a13a0')
              this.config.tagCode.options.forEach(e => {
                e.disabled = e.tagCode !== '418566a978f046dbaf78a807556a13a0'
              })
            } else if (this.form.tagCode.includes('c3b677f19c0d4e4aba152f253d34a5ac')) {
              this.form.tagCode.splice(0, this.form.tagCode.length, 'c3b677f19c0d4e4aba152f253d34a5ac')
              this.config.tagCode.options.forEach(e => {
                e.disabled = e.tagCode !== 'c3b677f19c0d4e4aba152f253d34a5ac'
              })
            } else if (this.form.tagCode.includes('ae09f86c4e7a43d29208d65b0f588753')) {
              this.form.tagCode.splice(0, this.form.tagCode.length, 'ae09f86c4e7a43d29208d65b0f588753')
              this.config.tagCode.options.forEach(e => {
                e.disabled = e.tagCode !== 'ae09f86c4e7a43d29208d65b0f588753'
              })
            } else {
              this.config.tagCode.options.forEach(e => {
                e.disabled = false
              })
            }
          }
        },
        userId: {
          type: 'number',
          label: '用户ID',
          min: 0,
          rule: [
            { required: true }
          ],
          hide: () => !this.form.tagCode.includes('418566a978f046dbaf78a807556a13a0')
        },
        download: {
          type: 'file-list',
          label: '下载模板',
          autoUpload: false,
          accept: '.xlsx',
          disabled: false,
          template: `${this.SYS.URL}/xlsx/appUser_template.xlsx`,
          rule: [{ required: true }],
          hide: () => !this.form.tagCode.includes('ae09f86c4e7a43d29208d65b0f588753'),
          change: () => this.uploadFile()
        },
        columnType: {
          type: 'select',
          label: '类目',
          options: this.columnList.filter(e => e.pageCode !== '0b7d673f72e14d28b3db98bf4ab04863'),
          labelKey: 'pageName',
          valueKey: 'pageCode',
          rule: [
            { required: true }
          ],
        },
        articleId: {
          type: 'input',
          label: '文章ID',
          placeholder: '请在资讯公告中复制文章ID',
          change: (v) => {
            if (v) {
              this.form.link = `${this.SYS.ZZBURL}/#/news/detail/${v}`
              this.config.link.disabled = true
            } else {
              this.form.link = ''
              this.config.link.disabled = true
            }
          },
          hide: () => !['cf7c62d04b994dccb6822e45a2fcfe4f'].includes(this.form.columnType)
        },
        link: {
          type: 'input',
          label: '链接地址',
          rule: [
            { required: true }
          ],
          disabled: false,
          hide: () => !['cf7c62d04b994dccb6822e45a2fcfe4f'].includes(this.form.columnType)
        },
        pic: {
          type: 'image',
          label: '图片',
          fileSize: e => {
            this.form.picSize = e
          },
          hide: () => this.form.type !== 2
        },
        topPic: {
          type: 'image',
          label: '弹窗顶部图片',
          fileSize: e => {
            this.form.topPic = e
          },
          hide: () => this.form.type !== 1
        },
        activetime: {
          type: 'date-time-range',
          label: '活动时间',
          rule: [
            { required: true }
          ]
        }
      },
      loading: false
    }
  },
  props: {
    show: Boolean,
    data: Object,
    tagList: Array,
    columnList: Array,
  },
  methods: {
    close () {
      this.$emit('update:show', false)
    },
    submit: throttle(async function () {
      if (!await this.$refs.form.check()) return

      this.loading = true
      let { code, msg } = await this.$http({
        url: '%ZZB%/dragon/popup/edit',
        data: {
          id: this.data?.id,
          title: this.form.title,
          pic: this.form.pic,
          link: this.form.link,
          content: this.form.content,
          status: this.form.status,
          createId: this.form.createId,
          reviewId: this.form.reviewId,
          trialReason: this.form.trialReason,
          sTime: new Date(this.form.activetime[0]).timeFormat(),
          eTime: new Date(this.form.activetime[1]).timeFormat(),
          type: this.form.type,
          tagCode: this.form.tagCode.join(','),
          topPic: this.form.topPic,
          isDel: this.form.isDel,
          columnType: this.form.columnType,
          userId: this.form.userId,
          fileUuid: this.form.fileUuid || void 0
        }
      })

      this.loading = false

      if (code !== 8200) {
        this.$message.error(`保存失败：${msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    
    async uploadFile(){
      await this.form.download
      if(this.form.download.length > 0){
        this.config.download.disabled = true
      }
      let allData = this.form.download.map(e => {
        return {
          mode: 'form',
          url: '%ZZB%/dragon/inside/upload/file',
          data: {
            token: true,
            type: 2,
            file: e.file,
          }
        }
      })
      let data = await this.$http({
        mode: 'relay',
        all: allData,
        interval: 20,
      })
      this.form.fileUuid = data[0].result
    }
  },
  beforeDestroy() {
    this.config.tagCode.options.forEach((e)=>{
      e.disabled = false
    })
  }
}
</script>

<style lang="scss" scoped>
.right-box {
  position: relative;
  margin-top: 54px;
  height: calc(100% - 54px);
  &::before {
    content: '小程序客服消息回复有5条限制，由于初始已发送2条，请注意发送条数';
    position: absolute;
    left: 20px;
    line-height: 54px;
    top: -54px;
    font-size: 12px;
    color: #999;
  }
  .right-form {
    width: 520px;
    padding: 20px;
    box-sizing: border-box;
  }
}
</style>