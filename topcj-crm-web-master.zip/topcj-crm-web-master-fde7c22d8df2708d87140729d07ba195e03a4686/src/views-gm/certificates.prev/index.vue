<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>
      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData"
          @change="getTableData()"
        />
      </template>

      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          @change="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-certificates',
  data() {
    return {
      //加载状态
      loading: false,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      //表格数据
      tableData: [],
      //筛选数据
      screen: {
        audit: 0,
        keyword: ''
        // type: 2
      },
      config: {
        audit: {
          type: 'select',
          placeholder: '审核状态',
          options: [
            {value: 0,label: '未审核'},
            {value: 1,label: '审核通过'},
            {value: 2,label: '审核不通过'},
          ]
        },
        split: { type: 'split' },
        keyword: {
          type: 'input',
          placeholder: '搜索用户ID/姓名/证件号码'
        },
        br: { type: 'br' },
        add: {
          type: 'button',
          label: '+ 新增',
          buttonType: 'primary',
          click: () => { this.openPopover() }
        },
        // type: {
        //   type: 'select',
        //   placeholder: '证件类型',
        //   options: [
        //     { value: 1, label: '身份证' },
        //     { value: 2, label: '其他证件' },
        //   ]
        // },
        
      },
      //新增展示修改
      showPopover: false,
    }
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/user/get_id_num_list.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          audit:typeof this.screen.audit === 'number' ? this.screen.audit : undefined,
          keyword: this.screen.keyword || undefined
          // type:typeof this.screen.type === 'number' ? this.screen.type : undefined
        }
      })

      this.total = result.total
      this.tableData = result.records

      this.loading = false
    }),
    openPopover() {
      this.showPopover = true
    }
  },
  components: {
    TableData,
    EditData
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>