<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      新增证件
    </template>

    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >确 定</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      form: {
        userId: '',
        type: 2,
        name: '',
        idNum: '',
        birthday: '',
        frontUrl: '',
        backUrl: ''
      },
      config: {
        userId: {
          label: '用户ID',
          rule:[
            { required: true }
          ]
        },
        type: {
          type: 'select',
          label: '证件类型',
          options: [
            { value: 1, label: '身份证' },
            { value: 2, label: '其他证件' },
          ],
          rule: [
            { required: true }
          ],
          change: () => {
            if(this.form.type === 1) {
              this.config.frontUrl.label = '身份证人像面'
              this.config.backUrl.label = '身份证国徽面'
            }else{
              this.config.frontUrl.label = '证件正面'
              this.config.backUrl.label = '证件反面'
            }
          }
        },
        name: {
          label: '姓名',
          rule: [
            { required: true }
          ]
        },
        birthday: {
          label: '出生日期',
          type: 'date',
          rule: [
            { required: true }
          ]
        },
        idNum: {
          label: '证件号码',
          rule: [
            { required: true }
          ]
        },
        frontUrl: {
          type: 'image',
          label: '证件正面',
          rule: [
            { required: true }
          ]
        },
        backUrl: {
          type: 'image',
          label: '证件反面',
          rule: [
            { required: true }
          ]
        }
      }
    }
  },
  props: {
    show: Boolean
  },
  methods: {
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/user/set_id_num.sdcrm',
        data: {
          token: true,
          userId: this.form.userId,
          type: this.form.type,
          name: this.form.name,
          idNum: this.form.idNum,
          frontUrl: this.form.frontUrl,
          backUrl: this.form.backUrl,
          birthday: this.form.birthday,
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>