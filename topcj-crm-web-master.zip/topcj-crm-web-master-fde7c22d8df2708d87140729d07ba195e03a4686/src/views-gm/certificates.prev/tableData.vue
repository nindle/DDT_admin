<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-name="{ row }">
      <scratch
        :data="row.name"
        mode="name"
        :log="row.userId"
        show-button
      />
    </template>

    <template #body-idNum="{ row }">
      <scratch
        :data="row.idNum"
        mode="idnum"
      />
    </template>

    <template #body-operation="{ row }">
      <el-popconfirm
        title="确认通过吗？"
        v-if="row.audit === 0"
        @confirm="reviewData(row, 1)"
      >
        <el-button
          slot="reference"
          type="text"
          size="small"
          icon="el-icon-check"
        >通过</el-button>
      </el-popconfirm>
      <el-popconfirm
        style="margin-left: 12px;"
        title="确认不通过吗？"
        v-if="row.audit === 0"
        @confirm="reviewData(row, 2)"
      >
        <el-button
          slot="reference"
          type="text"
          size="small"
          icon="el-icon-close"
        >不通过</el-button>
      </el-popconfirm>
      <span v-else>{{row.audit === 1 ? '审核通过' : '审核不通过'}}</span>
    </template>
  </el-table-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import Scratch from '../../components/other/scratch'

export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: '编号',
          minWidth: 28
        },
        {
          key: 'userId',
          label: '用户ID',
          minWidth: 90,
          copy: true
        },
        {
          key: 'name',
          label: '姓名',
          minWidth: 80
        },
        {
          key: 'idNum',
          label: '特殊证件号码',
          minWidth: 140
        },
        {
          key: 'birthday',
          label: '出生日期',
          minWidth: 80,
          format: e => e ? new Date(e).timeFormat('yyyy-MM-dd') : '--'
        },
        {
          key: 'frontUrl,backUrl',
          label: '证件照片',
          minWidth: 56,
          button: {
            type: 'text',
            icon: 'el-icon-view',
            label: '查看',
            click: row => {
              this.$imageview({
                list: [row.frontUrl, row.backUrl]
              })
            }
          }
        },
        {
          key: 'auditTime',
          label: '审核时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '--'
        },
        {
          key: 'operation',
          label: '审核状态',
          width: 120
        },
      ]
    }
  },
  props: {
    data: Array
  },
  components: {
    Scratch
  },
  methods: {
    reviewData: throttle(async function(row, type) {
      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/user/set_id_num_audit.sdcrm',
        data: {
          token: true,
          id: row.id,
          audit: type
        }
      })

      if(code !== 8200) {
        this.$message.error(`审核失败：${errmsg || msg}`)
        return
      }

      this.$message.success('审核成功')
      this.$emit('change')
    })
  }
}
</script>