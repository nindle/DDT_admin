<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
    >
      <!--筛选模块-->
      <template #screen>
        <el-screen-pro 
          :config="config"
          @change="getTableData()"
        ></el-screen-pro>
      </template>

      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData" 
          @change="getTableData()"
        />
      </template>

      <!--编辑模块-->
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          @change="getTableData()"
        />
      </template>
    
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-blacklist',
  data() {
    return {
      //时间筛选
      screenTime: [],
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      //筛选数据
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.showPopover = true }
        }
      }
    }
  },
  components: {
    TableData,
    EditData
  },
  methods: {
    //数据获取
    getTableData: throttle(async function() {
      this.loading = true

      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/blacklist/get_blacklist.sdcrm',
        data: {
          token: true
        }
      })

      this.loading = false

      this.tableData = result
    })
  }
}
</script>

<style scoped lang="scss">

.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>
