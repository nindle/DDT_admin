<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      新增黑名单成员
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {   
      form: {
        managerId: ''
      },
      config: {
        managerId: {
          label: '添加员工',
          type: 'select-manager',
          placeholder: '请输入员工姓名/工号',
          rule: [
            { required: true, message: '请选择员工', type: 'number' }
          ]
        }
      },
      loading: false
    }
  },
  props: {
    show: Boolean
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url:'%CRM%/blacklist/add_blacklist.sdcrm',
        data: {
          token: true,
          managerId: this.form.managerId
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`添加失败：${errmsg || msg}`)
        return
      }

      this.$message.success('添加成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>
