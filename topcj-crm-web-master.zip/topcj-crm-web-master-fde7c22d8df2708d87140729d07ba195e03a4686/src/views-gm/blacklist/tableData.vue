<template>
  <el-table-pro
    :data="data"
    :head="head"
  >
    <template #body-operation="{ row }">
      <el-popconfirm
        title="确定删除吗？"
        @confirm="deleteData(row)"
      >
        <template #reference>
          <el-button
            type="text"
            size="small"
            icon="el-icon-delete"
          >删除</el-button>
        </template>
      </el-popconfirm>
    </template>
  </el-table-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      head: [
        {
          key: 'id',
          label: '编号',
          minWidth: 60
        },
        {
          key: 'managerId',
          label: '业务员ID',
          minWidth: 80
        },
        {
          key: 'realName',
          label: '业务员姓名',
          minWidth: 150
        },
        {
          key: 'companyName',
          label: '所属分公司',
          minWidth: 150
        },
        {
          key: 'operation',
          label: '操作',
          width: 44
        }
      ]
    }
  },
  props: {
    data: Array
  },
  methods: {
    //删除数据
    deleteData: throttle(async function(row) {
      let { code, errmsg, msg } = await this.$http({
        url:`%CRM%/blacklist/del_blacklist.sdcrm`,
        data:{
          token: true,
          id: row.id
        },
      })

      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        return
      }

      this.$message.success('删除成功')
      this.$emit('change')
    })
  }
}
</script>