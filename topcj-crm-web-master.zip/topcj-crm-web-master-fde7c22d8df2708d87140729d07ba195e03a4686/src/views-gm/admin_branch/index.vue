<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
    >
    <!-- 表格模块 -->
      <template #table>
        <table-data 
          :data="tableData"
          @edit="openPopover"
          @add="openScreen"
        />
      </template>
      <!-- 编辑模块 -->
      <template #popover>
        <edit-data
          v-if="show"
          :show.sync="show"
          :data="rowData"
          @change="getTableData()"
        />
      </template>
      <!-- 人员添加模块 -->
      <template #screen>
        <add-data
          v-if="showScreen"
          :showScreen.sync="showScreen"
        />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import editData from './editData'
import addData from './addData'

export default {
  name: 'gm-admin_branch',
  data() {
    return {
      //加载状态
      loading: false,
      //表格数据
      tableData:[],
      //展示修改
      show: false,
      showScreen:false,
      //修改数据
      rowData:null,
      // corpList:[]
    }
  },
  components:{
    TableData,
    editData,
    addData
  },
  methods: {
     //数据获取
    getTableData: throttle(async function() {
      this.loading = true

      let { result } = await this.$http({
        mode:'get',
        url:'%CRM%/res/get_corp_sales_pond_list.sdcrm',
        data: {
          token: true
        }
      })

      this.tableData = result

      this.loading = false
    }),
    //打开弹窗
    openPopover(data) {
      this.rowData = data
      this.show = true
    },
    openScreen(){
      this.showScreen = true
    }
  },
  created() {
    this.getTableData()
    // this.getCorp()
  }
}
</script>

<style scoped lang="scss">

.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
    .screen-date { margin-left: auto;}
  }
}
</style>
