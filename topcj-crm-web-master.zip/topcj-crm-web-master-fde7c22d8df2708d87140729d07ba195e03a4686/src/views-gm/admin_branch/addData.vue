<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      人员添加
    </template>
    <!--内容-->
    <el-form 
      :model="form"
      :rules="rules"
      label-width="auto" 
      @submit.native.prevent
      ref="form"
    >
      <el-form-item 
        v-for="(item,index) in dataList" 
        :key="index"
        
      >
         
        <el-tag
          v-for="(item1,index) in item"
          :key="index"
        >
          {{item1.realName}} 
        </el-tag>
         <el-radio-group v-model="radio[index+1]">
            <el-radio :label="1">有效</el-radio>
            <el-radio :label="2">无效</el-radio>
          </el-radio-group>
        <el-button 
          type="primary"
          size="small"
          @click="deleteData()"
        >删除</el-button>
      </el-form-item> 

      <el-form-item 
        label="添加员工"
        prop="search"
      >
        <el-select
          v-model="form.search"
          filterable
          remote
          placeholder="请输入员工名称/员工工号"
          :remote-method="searchManager"
          @change="addWord()"
        >
          <el-option
            v-for="e in searchList"
            :key="e.id"
            :label="`${e.realName} ${e.eid}`"
            :value="e.id"
          ></el-option>
        </el-select>
      </el-form-item>  
    </el-form>

    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return { 
      form: {
        addList:[],
        search: ''
      },
      rules: {
        search: [
          { required: true, message: '请选择员工', type: 'number' }
        ],
        addList:[
            { required: true, message: '请添加员工', type: 'array' }
        ]
      }, 
       
      dataList:[],//装所有筛选出来的corpid的数组
      radio:[
        {radio:1},
        {radio1:1},
        {radio2:1},
      ],
      searchList: [],
      loading: false,
      // name:{},
      ids:{}
    }
  },
  computed:{
    managerList(){
      return this.$store.state.baseData.managerList  
    }
  },
  props: {
    show: Boolean
  },
  methods: {
    //搜索员工
    searchManager(query) {
      if(query === '') {
        this.searchList = []
        return
      }
      this.searchList = this.managerList.filter(e => {
        e.eid = e.eid || ''
        e.realName = e.realName || ''
        return e.eid.indexOf(query) > -1 || e.realName.indexOf(query) > -1
      })
    },
 
    //添加员工
    addWord(){
      this.dataList.push(this.managerList.filter(e => e.id === this.form.search)) 
      this.ids = this.form.search
      this.form.search = ''
    },
    //删除
    deleteData(item) {
      this.dataList.splice(item,1)
    },
  
    //提交
    submit: throttle(async function() {
      // if(!await this.$refs.form.check()) return

      this.loading = true

      let { code } = await this.$http({
       url: '%CRM%/res/manager_sales_pond_edit.sdcrm',
        data: {
          token: true,
          managerId: this.ids,
          status:this.radio
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error('添加失败')
        return
      }

      this.$message.success('添加成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:showScreen', false)
    }
  }
}
</script>

<style scoped lang="scss">

</style>
