<template>
  <el-table-pro
    :data="data"
    :head="head"
  >
    <template #body-operation="{row}">
      <el-button 
        type="text"
        size="small"
        icon="el-icon-edit"
        @click="edit(row)"
      >编辑</el-button>
      <el-button 
        type="text"
        @click="add()" 
      >人员数量</el-button>
    </template>
  </el-table-pro>
</template>

<script>
export default {
   data() {
    return {
      head: [
        {
          key: 'id',
          label: '编号',
          minWidth: 60
        },
        {
          key: 'corpId',
          label: '公司',
          minWidth: 140,
          format: c => {
            for(let i in this.corpList){
              let e = this.corpList[i]
              if(e.id === c){
                return e.corpName
              }
            }
            return ''
          }
        },
        {
          key: 'dailyUpper',
          label: '数量',
          minWidth: 140
        },
        {
          key: 'operation',
          label: '操作',
          minWidth: 60
        }
      ]
    }
  },
  props: {
    data: Array
  },
  methods:{
    getCorp(){
      this.corpList = this.$store.state.baseData.corpList
    },
    edit(row){
      this.$emit('edit',row)
    },
    add(){
      this.$emit('add')
    }
  },
  created(){
    this.getCorp()
  }

}
</script>

<style>

</style>