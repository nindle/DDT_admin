<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      编辑
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        corpId: this.data?.corpId ?? '',
        dailyUpper: this.data?.dailyUpper ?? ''
      },
      config: {
        corpId: {
          label: '公司',
          disabled: true,
          type: 'select',
          options: this.$store.state.baseData.corpList,
          valueKey: 'id',
          labelKey: 'corpName',
        },
        dailyUpper: {
          label: '数量',
          rule: [
            { required: true }
          ]
        }
      },
      loading: false
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, msg } = await this.$http({
        url:'%CRM%/res/corp_sales_pond_edit.sdcrm',
        data: {
          token: true,
          id: this.data ? this.data.id : undefined,
          corpId: this.data ? this.data.corpId : undefined,
          dailyUpper:this.form.dailyUpper
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(msg)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>
