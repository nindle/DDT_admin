<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
      @layout-click="hidePopover"
    >
      <!-- 筛选 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :type="screen.type"
          :data="tableData"
          @view="openPopover"
        />
      </template>

      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          :type="screen.type"
        />
      </template>
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'

export default {
  name: 'gm-extcontact_detail',
  data() {
    return {
      // 状态更新
      loading: false,
      // 分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      // 筛选
      screen: {
        type: 2,
        corpId: '',
        time: [],
        keyword: '',
        extId: 0,
        relId: '',
      },
      config: {
        type: {
          type: 'select',
          options: [
            { value: 2, label: '业务'},
            { value: 1, label: '售后'},
          ],
          clearable: false
        },
        corpId: {
          type: 'select-corp'
        },
        time: {
          type: 'date-range',
          placeholder: ['成交日期', '结束日期']
        },
        extId: {
          type: 'select',
          options: [
            { value: 0, label: '未绑定'},
            { value: 1, label: '已绑定'},
          ],
          placeholder: '用户绑定'
        },
        relId: {
          type: 'select',
          options: [
            { value: 0, label: '未绑定'},
            { value: 1, label: '已绑定'},
          ],
          placeholder: '员工绑定'
        },
        split: {type: 'split'},
        keyword: {
          type: 'input',
          placeholder: '用户备注/昵称/实名'
        },
      },
      // 表格数据
      tableData: [],
      // 弹窗隐藏显示
      showPopover: false,
      rowData: null,
      saveRowData: null
    }
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }
      
      let { result } = await this.$http({
        url: '%CRM%/report/get_external_detail_report.sdcrm',
        data: {
          token: true,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
          keyWord: this.screen.keyword || undefined,
          attachType: this.screen.type,
          extId: typeof this.screen.extId === 'number' ? this.screen.extId : undefined,
          relId: typeof this.screen.relId === 'number' ? this.screen.relId : undefined,
        } 
      })

      this.loading = false

      this.total = result.total
      this.tableData = result.records.map(e => {
        e.showPopover = false

        return e
      })
    }),
    openPopover(data) {
      this.rowData = data
      this.showPopover = true

      this.saveRowData = this.tableData.find(e => e.showPopover)
      if(this.saveRowData) {
        this.saveRowData.showPopover = false
      }
    },
    hidePopover() {
      let lastRow = this.tableData.find(e => e.showPopover)
      if(lastRow) {
        lastRow.showPopover = false
      }
    }
  },
  components: {
    TableData,
    EditData
  },
  watch: {
    showPopover() {
      if(!this.showPopover && this.saveRowData) {
        this.saveRowData.showPopover = true
        this.saveRowData = null
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>