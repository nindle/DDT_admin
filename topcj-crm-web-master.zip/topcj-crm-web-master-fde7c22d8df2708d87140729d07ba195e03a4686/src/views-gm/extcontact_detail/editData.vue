<template>
  <el-dialog-pro 
    @close="close"
    max-height
  >
    <template #title>{{data.extName}}<span class="tip">已成交，用户ID：{{data.userId}}</span></template>

    <message 
      :data="messageList"
    ></message>

    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >关 闭</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { md5 } from '../../assets/js/crypto'
import Message from '../../components/message'

export default {
  data() {
    return {
      messageList: []
    }
  },
  props: {
    show: Boolean,
    data: Object,
    type: Number
  },
  methods: {
    close() { 
      this.$emit('update:show',false)
    },
    async getMessage() {
      const deadline = Date.now()
      const sign = md5(`075dfa7becf54cc4aff1d75080983eb9${deadline}`)

      let { result } = await this.$http({
        url: '%CRM%/external/chat_data_list.sdcrm',
        data: {
          token: true,
          userId: this.data.externalUserid,
          managerUserId: this.data.qyUserId,
          pageSize: 30,
          pageNumber: this.messageList.length,
          deadline,
          sign,
          qyWx: this.data.qyWx
        }
      })

      this.messageList = result.map(e => {
        e.managerTitle = this.type === 1 ? '售后' : '业务'
        e.nickname = this.data.extName
        e.managerName = this.data.realName
        e.type = e.sfrom === this.data.externalUserid ? 1 : 0
        e.lastTime = e.msgtime
        e.msgType = e.msgtype
        e.imageUrl = e.mediaUrl
        return e
      })
    }
  },
  components: {
    Message
  },
  created() {
    this.getMessage()
  }
}
</script>

<style lang="scss" scoped>
.tip {
  color: #999;
  font-size: 12px;
  margin-left: 12px;
}
</style>