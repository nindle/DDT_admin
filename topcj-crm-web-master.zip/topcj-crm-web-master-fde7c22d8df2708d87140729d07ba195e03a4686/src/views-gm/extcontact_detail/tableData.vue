<template>
  <el-table-pro
    :head="head"
    :data="data"
    border
  >
    <template #head-relCount>关联{{type === 1 ? '售后' : '业务'}}数量<br>(企微)</template>
    <template #head-realName>实际{{type === 1 ? '售后' : '业务'}}归属<br>(顶点通)</template>

    <template #body-relCount="{ row }">
      <el-popover
        placement="left"
        width="400"
        trigger="manual"
        :popper-options="{element: $parent.$el}"
        v-model="row.showPopover"
        ref="popover"
      >
        <el-table-pro 
          :head="childrenHead"
          :data="childrenBody"
          border
          v-if="childrenBody.length"
          :style="{ height: childrenBody.length > 3 ? '223px' : '' }"
        >
          <template #body-message="{ row }">
            <el-button
              type="text"
              size="small"
              icon="el-icon-view"
              @click="$emit('view', row)"
            >查看</el-button>
          </template>

        </el-table-pro>
        
        <el-button 
          slot="reference"
          type="text"
          size="small"
          :disabled="!row.relCount"
          @click="getQywx(row)"
        >{{row.relCount}}</el-button>
      </el-popover>
    </template>
  </el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'extName',
          label: '用户名/微信名',
          minWidth: 140
        },
        {
          key: 'userId',
          label: '顶点通ID',
          minWidth: 70
        },
        {
          key: 'lastTime',
          label: '最近联系时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '/'
        },
        {
          key: 'addTime',
          label: '添加时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '/'
        },
        {
          key: 'delTime',
          label: '删除时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '/'
        },
        {
          key: 'ctime',
          label: '成交时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '/'
        },
        {
          key: 'relCount',
          label: '关联业务数量(企微)',
          minWidth: 84
        },
        {
          key: 'realName',
          label: '实际业务归属(顶点通)',
          minWidth: 84
        },
      ],
      childrenHead: [
        {
          key: 'qyUserId',
          label: '企微账号',
          minWidth: 84
        },
        {
          key: 'wxName',
          label: '企业微信',
          minWidth: 84
        },
        {
          key: 'message',
          label: '聊天记录',
          width: 56
        }
      ],
      childrenBody: []
    }
  },
  props: {
    type: Number,
    data: Array
  },
  methods: {
    async getQywx(row) {
      let lastRow = this.data.find(e => e.showPopover)
      if(lastRow) {
        lastRow.showPopover = false
      }
      this.childrenBody = []
      let { result } = await this.$http({
        url: '%CRM%/manager/get_manager_qywx_list.sdcrm',
        data: {
          token: true,
          managerId: row.managerId
        }
      })

      this.childrenBody = result.filter(e => e.qyWx !== '0').map(e => {
        return {
          ...row,
          ...e
        }
      })

      row.showPopover = true

      await this.$nextTick()

      this.$refs.popover.updatePopper()
    }
  }
}
</script>