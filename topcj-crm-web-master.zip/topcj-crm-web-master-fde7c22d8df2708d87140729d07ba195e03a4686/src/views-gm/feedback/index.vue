<template>
  <div 
    class="view"
    :class="{ 'has-user': selectUserId }"
  >
    <el-layout-pro 
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >

      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <template #table>
        <table-data 
          :data="tableData"
          @edit="openPopover"
          @select="selectUserId = $event"
        />
      </template>

      <template #popover>
        <edit-data 
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          @change="getTableData()"
        />
      </template>

    </el-layout-pro>  

    <!--客户详情-->
    <el-layout-pro 
      class="user-box"
      v-if="selectUserId"
    >
      <template #screen>
        <el-screen-pro :config="userDetailConfig">
          <template #close>
            <i 
              class="el-icon-close"
              @click="selectUserId = 0"
            ></i>
          </template>
        </el-screen-pro>
      </template>

      <template #scroll>
        <user-detail 
          class="user-detail-box" 
          :user-id="selectUserId"
          :key="selectUserId"
        />
      </template>
    
    </el-layout-pro>
  </div>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import EditData from './editData'
import TableData from './tableData'
import UserDetail from '../../components/user-detail/index'

export default {
  name: 'gm-feedback',
  data() {
    return {
      //加载状态
      loading: false,
      //分页
      pageNum: 1,
      total: 0,
      pageSize: 10,
      //表格数据
      tableData: [],
      //筛选数据
      screen: {
        corpId: this.$store.state.managerInfo.corpId || '',
        time: [],
        state: '',
        type: '',
        keyWord: ''
      },
      config: {
        // corpId: {
        //   type: 'select-corp',
        // },
        state: {
          type: 'select',
          placeholder: '处理状态',
          options: this.tag.t38.filter(e => e.visible),
          labelKey: 'valueName'
        },
        time: {
          type: 'date-range'
        },
        type: {
          type: 'select',
          placeholder: '反馈来源',
          options: [
            {value: 0,label: '摇钱术APP'},
            {value: 2,label: '摇钱术至尊版'},
            {value: 1,label: '顶点官网'},
          ],
        },
        split: {
          type: 'split'
        },
        keyWord: {
          type: 'input',
          placeholder: '请输入用户ID/手机号/姓名',
          changeLog: true
        }
      },
      // 弹窗
      showPopover: false,
      rowData: null,

      //选择的用户ID
      selectUserId: 0,
      userDetailConfig: {
        label: {
          type: 'label',
          label: '客户资料'
        },
        split: { type: 'split' },
        close: {}
      }
    }
  },
  props: {
    tag: Object
  },
  provide() {
    return {
      tag: this.tag
    }
  },
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/user_ask_message/get_user_suggestion.sdcrm',
        data: {
          token: true,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          stime: this.screen.time?.[0],
          etime: this.screen.time?.[1],
          state: typeof this.screen.state === 'number' ? this.screen.state : undefined,
          keyWord: this.screen.keyWord ? this.screen.keyWord : undefined,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          feedbackType: typeof this.screen.type === 'number' ? this.screen.type : undefined
        }
      })
      this.tableData = result.records
      this.total = result.total
      this.loading = false
    }),
    openPopover(data) {
      this.showPopover = true
      this.rowData = data
    }
  },
  components: { 
    TableData,
    EditData,
    UserDetail
  },
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  display: flex;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
  .user-box {
    width: 350px;
    height: 100%;
    margin-left: 24px;
    background: #FFF;
    .el-icon-close { cursor: pointer; }
    /deep/ {
      .screen-box { padding: 24px;}
      .scroll-box { background: #F5F5F5;}
    }
  }
  &.has-user {
    .box { width: calc(100% - 374px);}
  }
}
</style>