<template>
  <el-dialog-pro @close="close">
    <template #title>回复内容</template>

    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
      <template #image>
        <div v-if="data.imageUrl && data.imageUrl.length">
          <img 
            v-for="(e,i) in data.imageUrl.split(',')"
            :key="i"
            :src="e"
            class="image"
            v-imageview
          />
        </div>
      </template>
    
    </el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button
        v-if="tag.v132.visible"
        size="small"
        @click="submit(2)"
      >无需处理</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit(1)"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      //加载状态
      loading: false,
      form:{
        suggestion: this.data.suggestion,
        evaluation: this.data.evaluation,
        answer: this.data.state === 1 ? this.data.answer : ''
      },
      config: {
        suggestion: {
          type: 'label',
          label: '反馈内容：'
        },
        evaluation: {
          type: 'select',
          label: '内容类型',
          options: this.tag.t37.filter(e => e.visible),
          labelKey: 'valueName'
        },
        image: {
          type: 'label',
          hide: () => !this.data.imageUrl
        },
        answer: {
          type: this.data.state === 1 ? 'label' : 'textarea',
          label: '回复内容',
          rule: [
            { required: true }
          ],
        }
      }
    }
  },
  props: {
    show: Boolean,
    data: Object
  },
  inject: ['tag'],
  methods: {
    close() {
      this.$emit('update:show', false)
    },
    submit: throttle(async function(state) {
      if(state === 1 && !await this.$refs.form.check()) return
      
      this.loading = true

      let { code,msg,errmsg } = await this.$http({
        url: '%CRM%/user_ask_message/set_user_suggestion.sdcrm',
        data: {
          token: true,
          id: this.data.id,
          answer: this.form.answer,
          state: state === 1 && !this.form.answer ? 0 : state,
          evaluation: this.form.evaluation,
          managerId: this.$store.state.managerInfo.id
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    })
  },
}
</script>
<style lang="scss" scoped>
.image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 8px ;
  margin-right: 24px;
  &:last-child {
    margin-right: 0;
  }
}
</style>