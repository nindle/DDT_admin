<template>
  <el-table-pro
    :head="head"
    :data="data"
  >
    <template #body-userId="{ row }">
      <span 
        v-if="row.userId"
        class="has-click"
        @click="$emit('select', row.userId)"
      >{{ row.userId }}</span>
      <span v-else>{{ row.connect }}</span>
    </template>

    <template #body-operation="{ row }">
      <el-button
        type="text"
        size="small"
        icon="el-icon-edit"
        v-if="row.state === 0"
        @click="$emit('edit', row)"
      >回复</el-button>
      <el-button
        type="text"
        size="small"
        v-if="row.state === 1"
        @click="$emit('edit', row)"
      >已回复</el-button>
      <span v-if="row.state === 2">无需处理</span>
    </template>
  </el-table-pro>
</template>
<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'feedbackType',
          label: '反馈来源',
          minWidth: 84,
          format: {
            '0': '摇钱术APP',
            '2': '摇钱术至尊版',
            '1': '顶点官网',
          }
        },
        {
          key: 'ctime',
          label: '反馈服务时间',
          minWidth: 140,
          format: e => new Date(e).timeFormat()
        },
        {
          key: 'userId',
          label: '反馈ID',
          minWidth: 120
        },
        // {
        //   key: 'userName',
        //   label: '归属人',
        //   minWidth: 70
        // },
        {
          key: 'corpId',
          label: '分公司',
          minWidth: 70,
          format: e => {
            for(let i in this.$store.state.baseData.corpList) {
              if(this.$store.state.baseData.corpList[i].id === e) {
                return this.$store.state.baseData.corpList[i].corpName
              }
            }
            return '--'
          }
        },
        {
          key: 'suggestion',
          label: '反馈内容',
          minWidth: 140
        },
        {
          key: 'answerName',
          label: '回复人',
          default: '--',
          minWidth: 70
        },
        {
          key: 'atime',
          label: '回复时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '--'
        },
        {
          key: 'operation',
          label: '操作',
          width: 56
        },
      ]
    }
  },  
  props: {
    data: Array
  }
}
</script>