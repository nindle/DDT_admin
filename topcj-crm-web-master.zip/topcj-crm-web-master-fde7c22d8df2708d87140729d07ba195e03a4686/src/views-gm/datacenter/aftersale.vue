<template>
  <!-- 售后 -->
  <div ref="m3item" class="item2">
    <p class="title">售后</p>
    <div class="optionBox">
      <div>
        <p>售后登录率 <span title="当日售后使用顶点通人数 除以 在职的售后人数" class="explanation"></span></p>
        <div>
          <span>
            {{(service.loginNum/service.serviceNum*100).toFixed(2)}}%
          </span>
          <div id="loginBat">

          </div>
        </div>
        <div class="optionDown">
          <span>售后人数/登录数：{{service.serviceNum+'/'+service.loginNum}}</span>
          <span>日环比：<i></i>{{(service.loginRate*100).toFixed(2)}}%</span>
        </div>
      </div>
      <div>
        <!-- 专属号添加数/服务人数 -->
        <p>专属号用户添加率<span title="在服务期内用户添加专属号数量 除以 服务期内成交用户总数" class="explanation"></span></p>
        <div>
          <span>
            {{service.extContactUserRatio ? (service.extContactUserRatio*100).toFixed(2)+'%' :'--'}}
          </span>
          <div id="qqh">

          </div>
        </div>
        <div class="optionDown">
          <span>总服务人数：{{service.serviceUserNum}}</span>
        </div>
      </div>
      <div>
        <p>用户产品月使用率<span title="近30天内有使用记录且在在服务期内的用户数量  除以 在服务期内的用户数量" class="explanation"></span></p>
        <div>
          <span>
            {{(service.useUserRatio*100).toFixed(2)}}%
          </span>
          <div id="serveruse">

          </div>
        </div>
        <div class="optionDown">
          <span>日环比：<i></i>{{(service.useRate*100).toFixed(2)}}%</span>
          
        </div>
      </div>
      <div>
        <p>售后月覆盖率<span title="近30天内有沟通记录且在服务期内的用户数量 除以 在服务期内的用户数量" class="explanation"></span></p>
        <div>
          <span>
            {{(service.serviceUserRatio*100).toFixed(2)}}%
          </span>
          <div id="useruse">

          </div>
        </div>
        <div class="optionDown">
          <span>服务内容条数：{{service.talkCount}}</span>
          <span>人均数量：<i></i>{{service.avgTalkCount ? service.avgTalkCount.toFixed(2):'--'}}</span>
        </div>
      </div>
    </div>
    <table-tab :formLists='formLists' />
  </div>
</template>
<script>
const echarts = require('echarts');
import tableTab from './aftersaleble/table'
export default {
  data(){
    return{
      service:{
        serviceUserRatio: 0,
        useUserRatio: 0,
        loginRate:0,
        loginNum:0,
        serviceNum:0,
        useRate:0,
      },
      serviceDaily:[],
      twoTime:new Date(),
      formLists:[],
      isCorp:false,
    }
  },
  props:{
    corpId:Number
  },
  created(){
    if(this.$store.state.managerInfo.corpId){
      this.isCorp = true
    }
    this.getforms()
    this.get_serviceDaily()
    this.get_service()
  },
  mounted(){
    this.drawline()
  },
  watch:{
    twoTime(){
      this.getforms()
    },
    corpId(){
      this.get_serviceDaily()
      this.get_service()
    }
  },
  components:{
    tableTab
  },
  methods:{
    async getforms(){
      let { result } = await this.$http({
        url:'%CRM%/report/get_service_data_list.sdcrm',
        data:{
          token:true,
          ctime:this.twoTime ? this.twoTime.getTime() : undefined
        }
      })
      if(this.isCorp){
        let corpName = this.$store.state.baseData.corpList.filter(e=>e.id === this.$store.state.managerInfo.corpId)[0].corpName
        this.formLists = result.filter(e=>e.corpName === corpName)
      }else{
        this.formLists = result
      }
    },
    async get_serviceDaily(){
      let { result } = await this.$http({
        url:'%CRM%/report/get_service_daily_msg.sdcrm',
        data:{
          token:true,
          corpId:typeof(this.corpId) === 'number' ? this.corpId : undefined
        }
      })
      this.serviceDaily = result
      this.drawbar()
    },
    async get_service(){
      let { result } = await this.$http({
        url:'%CRM%/report/get_service_data_basic.sdcrm',
        data:{
          token:true,
          corpId:typeof(this.corpId) === 'number' ? this.corpId : undefined
        }
      })
      this.service = result
      this.drawpre()
      this.drawpre2()
    },
    drawpre(){
      let myChart = echarts.init(document.getElementById('loginBat'))
      myChart.setOption({
        series: [
          {
            type: 'pie',
            radius: '55%',
            // center: ['50%', '60%'],
            data: [
              {
                value: this.service.loginNum,
                itemStyle: {
                    normal: {//颜色渐变
                        color: new echarts.graphic.LinearGradient(
                            0, 0, 1, 1,
                            [
                                {offset: 0, color: '#FF2AA4'},
                                {offset: 1, color: '#FF7EC9'}
                            ]
                        )
                    }
                }
              },
              {
                value: this.service.serviceNum-this.service.loginNum,
                itemStyle:{
                  normal:{
                    color:'#F1EBEF'
                  }
                }
              },
            ],
            hoverAnimation:false,
            hover:false,
            label:{
              show:false
            },
            center:['50%','40%']
         },
        ]
      })
    },
    drawpre2(){
      let myChart = echarts.init(document.getElementById('serveruse'))
      myChart.setOption({
        series: [
          {
            type: 'pie',
            radius: '55%',
            // center: ['50%', '60%'],
            data: [
              {
                value: 1,
                itemStyle:{
                  normal:{
                    color:'#F1EBEF'
                  }
                }
              },
              { 
                value: this.service.useUserRatio,
                itemStyle: {
                    normal: {//颜色渐变
                        color: new echarts.graphic.LinearGradient(
                            0, 0, 0, 1,
                            [
                                {offset: 0, color: '#F77030'},
                                {offset: 1, color: '#F0A434'}
                            ]
                        )
                    }
                }
              },
            ],
            hoverAnimation:false,
            label:{
              show:false
            },
            center:['50%','40%']
         },
        ]
      })
    },
    drawline(){
      let myChart = echarts.init(document.getElementById('qqh'))
      myChart.setOption({
        color:['#3089FF'],
        xAxis: {
          show:false,
          type: 'category',
        },
        yAxis: {
          show:false,
        },
      series: [{
        data: [20, 332, 901, 534, 1290, 330, 620],
        type: 'line',
        smooth: true,
        areaStyle: {
          normal: {
            color: {
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [{
                  offset: 0,
                  color: "#3089FF" // 0% 处的颜色
                }, {
                  offset: 0.7,
                  color: "rgba(48,137,255,0)" // 100% 处的颜色
                  }],
                  globalCoord: false // 缺省为 false
                }
              }
            },
          }]
        })
    },
    drawbar(){
      let myChart = echarts.init(document.getElementById('useruse'))
      myChart.setOption({
        color:['#09DBC7'],
        xAxis: {
          show:false,
          type: 'category',
        },
        yAxis: {
          show:false,
          type: 'value'
        },
        series: [{
          // data:this.serviceDaily,
          data: [this.serviceDaily[0].avgTalkCount,this.serviceDaily[1].avgTalkCount,this.serviceDaily[2].avgTalkCount,this.serviceDaily[3].avgTalkCount,this.serviceDaily[4].avgTalkCount,this.serviceDaily[5].avgTalkCount,this.serviceDaily[6].avgTalkCount,this.serviceDaily[7].avgTalkCount],
          type: 'bar',
          showBackground: true,
          backgroundStyle: {
              color: 'rgba(220, 220, 220, 0.8)'
          },
          barWidth: 4,
          itemStyle: {
              emphasis: {
                  barBorderRadius: 7
              },
              
              normal: {
                  barBorderRadius: 7
              }
          }
        }]
      })
    },
  }
}
</script>
<style lang="scss" scoped>
.item2{
  margin-top: 32px;
  color: #000000;
  width: 100%;
  box-sizing: border-box;
  .optionBox{
    margin-top: 20px;
    width: 100%;
    height: 200px;
    display: flex;
    justify-content: left;
    >div{
      width: calc((100% - 72px)/4);
      height: 100%;
      padding: 24px;
      box-sizing: border-box;
      border-radius:2px;
      >div{
        margin-top: 6px;
        display: flex;
        justify-content: space-between;
        >span{
          font-size: 44px;
          font-weight:400;
        }
        #loginBat{
          height: 80px;
          width: 140px;
        }
        #qqh{
          height: 80px;
          width: 140px;
        }
        #useruse{
          height: 80px;
          width: 140px;
        }
        #serveruse{
          height: 80px;
          width: 140px;
        }
      }
      .optionDown{
        margin-top: 20px;
        border-top: 1px solid #E9E9E9;
        line-height: 42px;
        span{
          font-size:14px;
        }
      }
    }
    >div:nth-child(1){
      background:rgba(254,248,252,1);
    }
    >div:nth-child(2){
      margin-left: 24px;
      background:rgba(247,249,255,1);
    }
    >div:nth-child(3){
      margin-left: 24px;
      background:rgba(243,251,250,1);
    }
    >div:nth-child(4){
      margin-left: 24px;
      background:rgba(252,247,240,1);
    }
  }
}
</style>