<template>
  <el-table-pro
    :data="data"
    :head="head"
    border
  >
  </el-table-pro>
</template>

<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'corpName',
          label: '',
          minWidth: 56,
        },
        {
          key: 'allCount',
          label: '总订单数',
          minWidth: 78,
        },
        {
          key: 'infileCount',
          label: '已成功入档数',
          minWidth: 70,
        },
        {
          key: 'infileCount,allCount',
          label: '入档率',
          minWidth: 56,
          format:(infileCount,allCount)=> (infileCount/allCount*100).toFixed(2)+'%'
        },
        {
          key: 'waitfileCount',
          label: '待提档',
          minWidth: 80,
        },
        {
          key: 'waitfileCount,allCount',
          label: '待提档率',
          minWidth: 100,
          format:(waitfileCount,allCount)=>(waitfileCount/allCount*100).toFixed(2)+'%'
        },
        {
          key: 'returnCount',
          label: '退回数',
          minWidth: 100,
        },
        {
          key: 'returnCount,allCount',
          label: '退回率',
          minWidth: 50,
          format:(returnCount,allCount)=>(returnCount/allCount*100).toFixed(2)+'%'
        },
      ],
    }
  },
  props:{
    data:Array
  }
}
</script>