<template>
  <div class="a1">
    <div id="bar">
      <p>建档流程</p>
      <div> <span>成交总数：</span> 
        <div><el-progress :percentage="100" :format="() => `${(100)}% (${archiving.orderCount})`"></el-progress></div>
      </div>
      <div> <span>已提档数：</span> 
        <div><el-progress v-if="isArchiving" :percentage="archivingList.infileCount" :format="() => `${archivingList.infileCount}%(${archiving.infileCount})`"></el-progress></div>
      </div>
      <div> <span>已通过数：</span> 
        <div><el-progress v-if="isArchiving" :percentage="archivingList.serviceCount" :format="() => `${archivingList.serviceCount}%(${archiving.serviceCount})`"></el-progress></div>
      </div>
      <div> <span>被退回数：</span> 
        <div><el-progress v-if="isArchiving" :percentage="archivingList.returnCount" :format="() => `${archivingList.returnCount}%(${archiving.returnCount})`"></el-progress></div>
      </div>
      <div> <span>退费数量：</span> 
        <div><el-progress v-if="isArchiving" :percentage="archivingList.refundCount" :format="() => `${archivingList.refundCount}%(${archiving.refundCount})`"></el-progress></div>
      </div>
    </div>
    <div id="pie">
      <p style="margin-top:15px;">建档流程</p>
      <div>
        <div>
          <p>营销审核留痕</p>
          <div>
            <div class="tits">
              <p class="radios1">待过滤数：{{archiving.waitFilter}}</p>
              <p class="radios2">待预建数：{{archiving.waiteBuild}}</p>
              <p class="radios3">待入档数：{{archiving.waitInfile	}}</p>
            </div>
            <div class="minbar">
              <div><el-progress color="#F43899" v-if="isArchiving" :percentage="archivingList.waitFilter" :format="format"></el-progress></div>
              <div><el-progress color="#FF4C62" v-if="isArchiving" :percentage="archivingList.waiteBuild" :format="format"></el-progress></div>
              <div><el-progress color="#C635DF" v-if="isArchiving" :percentage="archivingList.waitInfile" :format="format"></el-progress></div>
            </div>
          </div>
        </div>
        <div>
          <p>售后机审留痕</p>
          <div>
            <div class="tits">
              <p class="radios4">审核总数：{{archiving.macTotal}}</p>
              <p class="radios5">未通过数：{{archiving.macNoPass}}</p>
              <p class="radios6">已通过数：{{archiving.macPass}}</p>
            </div>
            <div class="minbar">
              <div><el-progress color="#73D13D" v-if="isArchiving" :percentage="archivingList.macTotal" :format="format"></el-progress></div>
              <div><el-progress color="#13C2C2" v-if="isArchiving" :percentage="archivingList.macNoPass" :format="format"></el-progress></div>
              <div><el-progress color="#40A9FF" v-if="isArchiving" :percentage="archivingList.macPass" :format="format"></el-progress></div>
            </div>
          </div>
        </div>
        <div>
          <p>售后人审留痕</p>
          <div>
            <div class="tits">
              <p class="radios7">待审核量：{{archiving.macNoPass}}</p>
              <p class="radios8">未通过数：{{archiving.artNoPass}}</p>
              <p class="radios9">已通过数：{{archiving.artPass}}</p>
            </div>
            <div class="minbar">
              <div><el-progress color="#FA8C16" v-if="isArchiving" :percentage="archivingList.macNoPass" :format="format"></el-progress></div>
              <div><el-progress color="#FA541C" v-if="isArchiving" :percentage="archivingList.artNoPass" :format="format"></el-progress></div>
              <div><el-progress color="#FAAD14" v-if="isArchiving" :percentage="archivingList.artPass" :format="format"></el-progress></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data(){
    return{
      
    }
  },
  props:["isArchiving",'archivingList',"archiving"],
  methods:{
    format(){
      return ''
    }
  }
}
</script>

<style lang="scss" scoped>
.a1{
  display: flex;
  justify-content: left;
  height: 320px;
  #bar{
    padding: 24px;
    width: 34.6%;
    border: 1px solid #E9E9E9;
    border-radius:2px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    >p{
      color: #333333;
    }
    >div{
      font-size: 14px;
      color: #999999;
      widows: 100%;
      display: flex;
      justify-content: left;
      >div{
        width: 75%;
        /deep/.el-progress__text{
          position: absolute;
          right: -12px;
          top: 3px;
        }
        /deep/.el-progress-bar{
          padding-right: 85px;
        }
      }
    }
  }
  #pie{
    padding: 24px;
    margin-left: 24px;
    width: calc(100% - 34.6% - 24px);
    border: 1px solid #E9E9E9;
    border-radius:2px;
    >p{
      color: #333333;
    }
    >div{
      width: 100%;
      margin-bottom: 8px;
      display: flex;
      justify-content: left;
      font-size: 14px;
      color: #999999;
      >div{
        font-size: 14px;
        color: #999999;
        padding: 24px;
        box-sizing: border-box;
        margin-top: 24px;
        width:calc((100% - 32px)/3);
        height:220px;
        border-radius:2px;
        >div{
          margin-top: 22px;
          display: flex;
          justify-content: space-around;
          height: calc(100% - 70px);
          .tits{
            width: 150px;
            text-indent: 14px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            p{
              position: relative;
            }
          }
          .minbar{
            // position: absolut;
            // margin-left: 20px;
            height: 100%;
            width: calc(100% - 134px);
            -webkit-transform: rotate(-90deg);
            position: relative;
            overflow: hidden;
            // left: 20px;
            // top: 0px;
            >div{
              width: 100%;
              position: absolute;
              left: -2px;
            }
            >div:nth-child(1){
              top: 15px;
            }
            div:nth-child(2){
              top: 35px;
            }
            div:nth-child(3){
              top: 55px;
            }
            /deep/.el-progress-bar__outer{
              // -webkit-transform: rotate(-90deg);
              background: none;
            }
            /deep/.el-progress-bar{
              padding: 0;
            }
          }
          .radios1::after{
            position: absolute;
            top: 8px;
            display: block;
            content: '';
            float: left;
            width: 8px;height: 8px;
            border-radius: 50%;
            background: #F43899;
          }
          .radios2::after{
            position: absolute;
            top: 8px;
            display: block;
            content: '';
            float: left;
            width: 8px;height: 8px;
            border-radius: 50%;
            background: #FF4C62;
          }
          .radios3::after{
            position: absolute;
            top: 8px;
            display: block;
            content: '';
            float: left;
            width: 8px;height: 8px;
            border-radius: 50%;
            background:#C635DF;
          }
          .radios4::after{
            position: absolute;
            top: 8px;
            display: block;
            content: '';
            float: left;
            width: 8px;height: 8px;
            border-radius: 50%;
            background:#73D13D;
          }
          .radios5::after{
            position: absolute;
            top: 8px;
            display: block;
            content: '';
            float: left;
            width: 8px;height: 8px;
            border-radius: 50%;
            background:#13C2C2;
          }
          .radios6::after{
            position: absolute;
            top: 8px;
            display: block;
            content: '';
            float: left;
            width: 8px;height: 8px;
            border-radius: 50%;
            background:#40A9FF;
          }
          .radios7::after{
            position: absolute;
            top: 8px;
            display: block;
            content: '';
            float: left;
            width: 8px;height: 8px;
            border-radius: 50%;
            background:#FA8C16;
          }
          .radios8::after{
            position: absolute;
            top: 8px;
            display: block;
            content: '';
            float: left;
            width: 8px;height: 8px;
            border-radius: 50%;
            background:#FA541C;
          }
          .radios9::after{
            position: absolute;
            top: 8px;
            display: block;
            content: '';
            float: left;
            width: 8px;height: 8px;
            border-radius: 50%;
            background:#FAAD14;
          }
        }
      }
      >div:nth-child(1){
        background:rgba(254,248,252,1);
      }
      >div:nth-child(2){
        margin-left: 16px;
        background:rgba(243,251,250,1);
      }
      >div:nth-child(3){
        margin-left: 16px;
        background:rgba(252,247,240,1);
      }
      
    }
  }
}

</style>