<template>
  <div class="a2">
    <!-- <div class="scdate"> -->
      <el-layout-pro
        class="box"
        @change="getform()"
      >  
        <!-- 筛选模块 -->
        <template #screen>
          <el-screen-pro
            :model="screen"
            :config="config"
          ></el-screen-pro> 
        </template>
      
        <!--表格模块-->
        <template #table>
          <table-data 
            :data="formList"
            ref="table"
          />
        </template>
      </el-layout-pro>

      <!-- <span>详情<i>&nbsp;(含退费用户)</i></span>
      <el-date-picker
        style="height:32px;width:180px;"
        v-model="oneTime"
        type="date"
        placeholder="选择日期"
        >
      </el-date-picker>
      <span style="color:#3089FF;padding-left: 16px;">下载详情</span> -->
    <!-- </div> -->
    <!-- <div class="form">
      <ul>
        <li></li>
        <li>总订单数</li>
        
        <li>已成功入档数</li>
        <li>入档率</li>

        <li>待提档</li>
        <li>待提档率</li>

        <li>待入档数</li>
        <li>待入档率</li>

        <li>退回数</li>
        <li>退回率</li>
      </ul>
      <ul v-for="(e,index) in formList" :key="index">
        <li>{{e.corpName}}</li>

        <li>{{e.allCount}}</li>

        <li>{{e.infileCount}}</li>
        <li>{{(e.infileCount/e.allCount*100).toFixed(2)}}%</li>

        <li>{{e.waitfileCount}}</li>
        <li>{{(e.waitfileCount/e.allCount*100).toFixed(2)}}%</li>

        <li>{{e.returnCount}}</li>
        <li>{{(e.returnCount/e.allCount*100).toFixed(2)}}%</li>
      </ul>
    </div> -->
  </div>
</template>
<script>
import tableData from './tableData'
export default {
  data(){
    return{
      screen: {
        time: new Date(),
      },
      config: {
        label: {
          type: 'label',
          label: '本月资源流转详情'
        },
        time: {
          type: 'date',
          placeholder: '选择日期',
        },
        split:{
          type:'split'
        },
        excel: {
          type: 'button',
          label: '导出excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        },
      },
      oneTime:new Date(),
      formList:[],
    }
  },
  props:[],

  created(){
    this.getform()
  },
  components:{
    tableData,
    
  },
  methods:{
    async getform(){
      let { result } = await this.$http({
        url:'%CRM%/buy/order/get_archiving_list.sdcrm',
        data:{
          token:true,
          ctime:this.oneTime ? this.oneTime.getTime() : undefined
        }
      })
      if(this.isCorp){
        this.formList = result.filter(e=>e.corpId === this.$store.state.managerInfo.corpId)
      }else{
        this.formList = result
      }
    },
  }
}
</script>

<style lang="scss" scoped>
.a2{
  border: 1px solid #E9E9E9;
  box-sizing: border-box;
  margin-top: 20px;
  line-height: 40px;
  font-size: 15px;
  padding: 20px 24px;
  color: #000000;
  .scdate{
    width: 100%;
    display: flex;
    justify-content: space-between;
    line-height: 34px;
    span{
      cursor: pointer;
      i{
        font-style: normal;
        color: #666666;
        font-size: 14px;
      }
    }
    div{
      margin-left: auto;
    }
    >span:nth-child(2){
      margin-left: 20px;
    }
  }
  .form{
    margin-top: 20px;
    border-right:1px solid #E9E9E9;
    >ul{
      display: flex;
      justify-content: space-between;
      li{
        text-align: center;
        box-sizing: border-box;
        width: 153px;
        line-height: 40px;
      }
      :nth-child(1){
        border-left:1px solid #E9E9E9;
        border-right:1px solid #E9E9E9;
      }
      :nth-child(n+1){
        // border-right:1px solid #E9E9E9;
      }
    }
    >ul:nth-child(1){
      background: #FAFAFA;
      border-top:1px solid #E9E9E9;
      border-bottom:1px solid #E9E9E9;
    }
    >ul:nth-child(n+1){
      border-bottom:1px solid #E9E9E9;
    }
  }
  /deep/.el-input__inner{
  height: 32px;
  }
  /deep/.el-input__icon{
    line-height: 32px;
  }
}
</style>