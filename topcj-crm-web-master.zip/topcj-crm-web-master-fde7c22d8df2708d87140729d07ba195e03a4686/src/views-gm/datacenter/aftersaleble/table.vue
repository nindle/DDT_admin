<template>
  <div class="a2">
    <el-layout-pro
      class="box"
      @change="getform()"
    >
      <!-- 筛选模块 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
        ></el-screen-pro> 
      </template>
      <!--表格模块-->
      <template #table>
        <table-data 
          :data="formLists"
          ref="table"
        />
      </template> 
    </el-layout-pro>
  </div>
</template>
<script>
import tableData from './tableData'
export default {
  data(){
    return{
      screen: {
        time: new Date(),
      },
      config: {
        label: {
          type: 'label',
          label: '详情'
        },
        time: {
          type: 'date',
          placeholder: '选择日期',
        },
        split:{
          type:'split'
        },
        excel: {
          type: 'button',
          label: '导出excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        },
      },
    }
  },
  components:{
    tableData
  },
  props:['formLists']
}
</script>

<style lang="scss" scoped>
.a2{
  border: 1px solid #E9E9E9;
  box-sizing: border-box;
  margin-top: 20px;
  line-height: 40px;
  font-size: 15px;
  padding: 20px 24px;
  color: #000000;
  .scdate{
    width: 100%;
    display: flex;
    justify-content: space-between;
    line-height: 34px;
    span{
      cursor: pointer;
      i{
        font-style: normal;
        color: #666666;
        font-size: 14px;
      }
    }
    div{
      margin-left: auto;
    }
    >span:nth-child(2){
      margin-left: 20px;
    }
  }
  .form{
    margin-top: 20px;
    border-right:1px solid #E9E9E9;
    >ul{
      display: flex;
      justify-content: space-between;
      li{
        text-align: center;
        box-sizing: border-box;
        width: 153px;
        line-height: 40px;
      }
      :nth-child(1){
        border-left:1px solid #E9E9E9;
        border-right:1px solid #E9E9E9;
      }
      :nth-child(n+1){
        // border-right:1px solid #E9E9E9;
      }
    }
    >ul:nth-child(1){
      background: #FAFAFA;
      border-top:1px solid #E9E9E9;
      border-bottom:1px solid #E9E9E9;
    }
    >ul:nth-child(n+1){
      border-bottom:1px solid #E9E9E9;
    }
  }
  /deep/.el-input__inner{
  height: 32px;
  }
  /deep/.el-input__icon{
    line-height: 32px;
  }
}
</style>