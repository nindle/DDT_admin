<template>
  <el-table-pro
    :data="data"
    :head="head"
    border
  >
  </el-table-pro>
</template>

<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'corpName',
          label: '',
          minWidth: 56,
        },
        {
          key: 'serviceNum',
          label: '售后人数',
          minWidth: 56,
        },
        {
          key: 'loginNum',
          label: '登录人数',
          minWidth: 56,
        },
        {
          key: 'serviceNum,loginNum',
          label: '登录率',
          minWidth: 51,
          format:(serviceNum,loginNum)=> {
            if(serviceNum || loginNum){
              return
            }
            return  (serviceNum/loginNum*100).toFixed(2)+'%'
          }
        },
        {
          key: 'serviceUserNum',
          label: '服务期用户数',
          minWidth: 84,
        },
        {
          key: 'expiredNum',
          label: '过期用户数',
          minWidth: 70,
        },
        {
          key: 'talkCount',
          label: '发布条数',
          minWidth: 56,
        },
        {
          key: 'serviceUserRatio',
          label: '发布率',
          minWidth: 50,
          format:e=>e ? e.toFixed(2)+'%' :''
        },
        {
          key: 'avgTalkCount',
          label: '人均发布条数',
          minWidth: 84,
          format:e=>e ? e.toFixed(2)+'%' :''
        },
      ],
    }
  },
  props:{
    data:Array
  }
}
</script>