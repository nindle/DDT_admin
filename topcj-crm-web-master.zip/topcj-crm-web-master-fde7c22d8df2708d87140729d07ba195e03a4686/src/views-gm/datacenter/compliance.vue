<template>
  <!-- 合规 -->
  <div ref="m2item" class="item1">
    <p class="title">合规</p>
    <div class="frombox">
      <barPie
        :archiving='archiving'
        :archivingList='archivingList'
        :isArchiving='isArchiving'
      />
      <table-ble
      />
    </div>
  </div>
</template>
<script>
// const echarts = require('echarts');
import barPie from './complianceble/barAndPie'
import tableBle from './complianceble/table'
export default {
  data(){
    return{
      archivingList:{
        orderCount:0,
        infileCount:0,
        serviceCount:0,
        returnCount:0,
        refundCount:0,
        waitFilter:0,
        waiteBuild:0,
        waitInfile:0,
        macTotal:0,
        macNoPass:0,
        macPass:0,
        artNoPass:0,
        artPass:0,
      },
      archiving:{},
      isArchiving:false,
    }
  },
  props:{
    corpId:Number
  },
  created(){
    this.get_archiving()
  },
  components:{
    barPie,
    tableBle,
  },
  watch:{
    corpId(){
      this.get_archiving()
    }
  },
  methods:{
    init(){
      this.archiving={
        orderCount:0,
        infileCount:0,
        serviceCount:0,
        returnCount:0,
        refundCount:0,
        waitFilter:0,
        waiteBuild:0,
        waitInfile:0,
        macTotal:0,
        macPass:0,
        macNoPass:0,
        artNoPass:0,
        artPass:0,
      },//合规数据
      this.archivingList = {
        orderCount:0,
        infileCount:0,
        serviceCount:0,
        returnCount:0,
        refundCount:0,
        waitFilter:0,
        waiteBuild:0,
        waitInfile:0,
        macTotal:0,
        macPass:0,
        macNoPass:0,
        artNoPass:0,
        artPass:0,
      },//计算过的合规数据
      this.service={
        serviceUserRatio: 0,
        useUserRatio: 0,
        loginRate:0,
        loginNum:0,
        serviceNum:0,
        useRate:0,
      },
      this.serviceDaily=[]
    },
    computeddata(){
      let archivingList = this.archivingList
      let archiving = this.archiving

      //总成交数
      archivingList.orderCount = archiving.orderCount/archiving.orderCount
      //已提档数
      archivingList.infileCount = Number((archiving.infileCount/archiving.orderCount*100).toFixed(2))
      //已通过数
      archivingList.serviceCount = Number((archiving.serviceCount/archiving.orderCount*100).toFixed(2))
      //被退回数
      archivingList.returnCount = Number((archiving.returnCount/archiving.orderCount*100).toFixed(2))
      //退费数量
      archivingList.refundCount = Number((archiving.refundCount/archiving.orderCount*100).toFixed(2))

      //带过滤数   /总成交数
      archivingList.waitFilter = (archiving.waitFilter/archiving.orderCount).toFixed(2)*100
      //待预建数
      archivingList.waiteBuild = (archiving.waiteBuild/archiving.orderCount).toFixed(2)*100
      //待入档数
      archivingList.waitInfile = (archiving.waitInfile/archiving.orderCount).toFixed(2)*100
      //机器服务审核 macTotal

      //,总审核数
      archivingList.macTotal = (archiving.macTotal/archiving.macTotal).toFixed(2)*100
      //未通过数
      archivingList.macNoPass = (archiving.macNoPass/archiving.macTotal).toFixed(2)*100
      //通过数
      archivingList.macPass = (archiving.macPass/archiving.macTotal).toFixed(2)*100

      let mount = archiving.macNoPass+archiving.artNoPass+archiving.artPass

      
      //
      archivingList.macNoPass = (archiving.macNoPass/mount).toFixed(2)*100

      archivingList.artNoPass = (archiving.artNoPass/mount).toFixed(2)*100

      archivingList.artPass = (archiving.artPass/mount).toFixed(2)*100
    },
    async get_archiving(){
      let { result } = await this.$http({
        url:'%CRM%/buy/order/get_archiving_count.sdcrm',
        data:{
          token:true,
          corpId:typeof(this.corpId) === 'number' ? this.corpId : undefined
        }
      })
      this.isArchiving = true
      this.archiving = result
      this.computeddata()
    },
    format(){
      return ''
    }
  }
}
</script>
<style lang="scss" scoped>
.item1{
  color: #A1A1A1;
  width: 100%;
  box-sizing: border-box;
  margin-top: 32px;
  .title{
    font-size:20px;
    color:rgba(0,0,0,0.85);
    font-weight:500;
    text-indent: 16px;
  }
  .blackbox{
    width: 100%;
    background: #F2F2F2;
    box-sizing: border-box;
    display: flex;
    justify-content: space-between;
    .today{
      margin-left: auto;
      line-height: 32px;
      width: 220px;
      display: flex;
      justify-content: space-between;
      >span{
        cursor: pointer;
      }
    }
    div:nth-child(3){
      margin-left: 20px;
    }
    /deep/.el-input__inner{
      height: 32px;
    }
    /deep/.el-input__icon{
      line-height: 32px;
    }
  }
  .frombox{
    margin-top: 24px;
  }
}
</style>