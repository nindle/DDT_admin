<template>
  <div id="datatop">
    <div v-show="topstepShow" class="topstep">
      <div class="toptab">
        <div  class="stepbox">
          <span @click="jumnp('m1')" :class="{active: kk==='m1'}">业务</span>
          <span @click="jumnp('m2') " :class="[kk==='m2'?'active':'']">合规</span>
          <span @click="jumnp('m3')" :class="{active: kk==='m3'}">售后</span>
          <span @click="jumnp('m4')">分析师</span>
          <div style="margin-left:auto;">

            <el-screen-pro
              :model="screen"
              :config="config"
              @change="watCorpId()"
            ></el-screen-pro>

            <!-- <el-select style="height:32px;width:180px" :disabled="isCorp" clearable v-model="corpId" placeholder="请选择公司">
              <el-option
                style="height:32px"
                v-for="(item,index) in corpIdList"
                :key="index"
                :label="item.corpName"
                :value="item.id">
              </el-option>
            </el-select> -->
          </div>
          <div style="width:168px;"></div>
        </div>
      </div>
    </div>

    <div class="bottomBox">
      <el-scrollbar ref="scroll" @scroll="scrolls">
        <div class="left">
          <business   ref="m1" :corpId='corpId'  v-show="businessShow" />
          <compliance ref="m2" :corpId='corpId'  v-show="complianceShow" />
          <aftersale  ref="m3" :corpId='corpId'  v-show="aftermarketShow"/>
        </div>
      </el-scrollbar>
      <div v-show="rightShow" class="right">
        <div class="heightline">
          <div @click="jumnp('m1')" :class="{ractive: kk==='m1'}" >业务</div>
          <div @click="jumnp('m2')" :class="{ractive: kk==='m2'}" >合规</div>
          <div @click="jumnp('m3')" :class="{ractive: kk==='m3'}" >售后</div>
          <div @click="jumnp('m4')" :class="{ractive: kk==='m4'}" >分析师</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import business from './business'
import compliance from './compliance'
import aftersale from './aftersale'
export default {
  name: 'gm-datacenter',
  data(){
    return{
      isCorp:false,
      corpId:null,
      kk:'',//
      //顶部tab显示控制
      topstepShow:true,
      //右侧tab显示控制
      rightShow:true,
      //业务控制显示
      businessShow:true,
      //合规控制显示
      complianceShow:true,
      //售后控制显示
      aftermarketShow:true,
      topList:[],
      
      screen: {
        corpId:null,
      },
      config:{
        corpId:{
          type:'select-corp'
        },  
      }
    }
  },
  props:{
    

  },
  created(){
    this.competence()
    // this.get_resource()
  },
  computed:{
    // corpIdList(){
    //   return this.$store.state.baseData.corpList
    // }
  },
  methods:{
    watCorpId(){
      this.corpId = this.screen.corpId
    },
    scrolls(v){
      switch(true) {
        case v.scrollTop < this.topList[0]:
          this.kk ='m1'
          break
        case v.scrollTop < this.topList[1]:
          this.kk ='m2'
          break
        case v.scrollTop < this.topList[2]:
          this.kk ='m3'
          break
      }
    },
    calcTop() {
      this.$nextTick(() => {
        let list = []

        let scrollTop = this.$refs.scroll.$refs.wrap.scrollTop
        list[0] = this.$refs.m1.getBoundingClientRect().y + scrollTop - 123
        list[1] = this.$refs.m1.getBoundingClientRect().y + scrollTop - 123
        list[2] = this.$refs.m1.getBoundingClientRect().y + scrollTop - 123
        list[3] = this.$refs.m1.getBoundingClientRect().y + scrollTop - 123

        this.topList = list
      })
    },
    jumnp(m){
      this.kk = m
      let element = this.$refs[m].$refs[`${m}item`]
      let size = element.getBoundingClientRect()
      let scrollTop = this.$refs.scroll.$refs.wrap.scrollTop
      let height = scrollTop + size.y - 123

      this.$refs.scroll.$refs.wrap.scrollTop = height

    },
    competence(){
      let infoCorpId = this.$store.state.managerInfo.corpId
      // let infoCorpId = 1
      let infoManagerType = this.$store.state.managerInfo.managerType
      // let infoManagerType = 4
      //分公司判断
      if(infoCorpId){
        this.companyId = infoCorpId
        this.isCorp = true
        
        //账号类型判断
        switch(infoManagerType){
          //合规账号
          case 4:
            this.topstepShow = false            //顶部tab显示控制
            this.rightShow = false              //右侧tab显示控制
            this.businessShow = false           //业务控制显示

            this.aftermarketShow = false        //售后控制显示
            break
          //售后账号
          case 1:
            this.topstepShow = false
            this.rightShow = false
            this.businessShow = false
            
            this.complianceShow = false         //合规控制显示
            break
          default:

            break
        }
      }
    },
  },
  components:{
    business,
    compliance,
    aftersale
  }
}
</script>

<style lang="scss" scoped>
#datatop{
  height: 100%;
  background: #fff;
  .topstep{
    line-height: 55px;
    width: 100%;
    box-sizing: border-box;
    box-shadow:0px 4px 8px 0px rgba(0,18,41,0.12);
    .stepbox{
      display: flex;
      justify-content: left;
      span{
        display: block;
        cursor: pointer;
      }
      span:nth-child(1){
        margin-left: 24px;
      }
      span:nth-child(n+2){
        margin-left: 64px;
      }
    }
    .active{
      color: #3089FF;
      font-weight:600;
      border-bottom: 3px solid #3089ff;
    }
  }
  .bottomBox{
    display: flex;
    justify-content: center;
    width: 100%;
    height: calc(100% - 50px);
    .right{
      width: 168px;
      height: 1080px;
      box-shadow:0px 4px 8px 0px rgba(0,18,41,0.12);
      border-radius:2px;
      .heightline{
        margin: 75px 0 0 32px;
        border-left: 1px solid #E9E9E9;
        >div{
          padding-left: 8px;
          font-size: 14px;
          color: #001229;
          line-height: 32px;
          position: relative;
          cursor: pointer;
        }
        .ractive{
          color:#3089FF ;
        }
        .ractive::after{
          display: block;
          content: '';
          width: 6px;
          height: 6px;
          border: 1px solid #3089FF;
          background: #fff;
          z-index: 9;
          border-radius: 50%;
          position: absolute;
          left: -4px;
          top: 12px;
        }
      }
      
    }
    .left{
      padding: 24px;
      box-sizing: border-box;
    }
  }
}
</style>