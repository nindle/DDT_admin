<template>
  <div class="showChat">
    <div class="chat1">
      <p>本月资源流转情况</p>
      <div>
        <img src="../../../assets/images/loudou.png" alt="">
        <div>
          <span class="fontTile">入库资源数</span>
          <span class="fontTile">关注工作台数</span>
          <span class="fontTile">月活跃数</span>
          <span class="fontTile">月成交数</span>
          <span class="fontTile">退费数</span>

          <span class="dotNub">{{resourceStreamList.userNum}}</span>
          <span class="dotNub">{{resourceStreamList.workNum}}</span>
          <span class="dotNub">{{resourceStreamList.activeUserNum}}</span>
          <span class="dotNub">{{resourceStreamList.payUserNum}}</span>
          <span class="dotNub">{{resourceStreamList.refundUserNum}}</span>

          <span class="scadu">{{"100"}}%</span>
          <span class="scadu">{{ resourceStreamList.workRate ? (resourceStreamList.workRate*100).toFixed(2) :'--'}}%</span>
          <span class="scadu">{{resourceStreamList.activeRate ? (resourceStreamList.activeRate*100).toFixed(2):'--'}}%</span>
          <span class="scadu">{{resourceStreamList.payRate ? (resourceStreamList.payRate*100).toFixed(2) :'--'}}%</span>
          <span class="scadu">{{resourceStreamList.refundRate ? (resourceStreamList.refundRate*100).toFixed(2):'--'}}%</span>
        </div>
      </div>
    </div>
    <div class="chat2">
      <p>本月业绩榜单</p>
      <div v-for="e in performanceList_com" :key="e.id"><i ></i><span style="margin-right:auto;">{{e.name}}</span> <span class="selieColor">{{e.money}}</span></div>
    </div>
    <div class="chat3">
      <p>服务发布情况</p>
      <div class="roundBox">
        <div class="score">
          <div class="circle">
            <el-progress :width="102" type="circle" v-if="(isTransferList)" :percentage="(transferList.sendRate)*100" color="#000"
            :show-text="false"
            ></el-progress>
          </div>
          <div class="text">
            <p><span>{{transferList.sendRate ? (transferList.sendRate*100).toFixed(2) :'--'}}</span>%</p>
            <p>用户发送率</p>
          </div>
        </div>
        <div class="score">
          <div class="circle">
            <el-progress :width="102" type="circle" v-if="(isTransferList)" :percentage="(transferList.loginRate)*100" color="#000"
            :show-text="false"
            ></el-progress>
          </div>
          <div class="text">
            <p><span>{{transferList.loginRate ? (transferList.loginRate*100).toFixed(2) :'--'}}</span>%</p>
            <p>业务登录率</p>
          </div>
        </div>
      </div>
      <div class="roundUnder">
        <div>
          <p><span>{{transferList.todayMsgNum}}</span><em  :class="{red:transferList.todayRang>0,green:transferList.todayRang<=0}">{{transferList.todayRang ? (transferList.todayRang*100).toFixed(2) :'--'}}%</em></p>
          <p>当日发送条数</p>
        </div>
        <div>
          <p ><span>{{transferList.monthMsgNum}}</span><em :class="{red:transferList.monthRang>0,green:transferList.monthRang<=0}">{{transferList.monthRang ? (transferList.monthRang*100).toFixed(2) :'--'}}%</em></p>
          <p>本月发送总数</p>
        </div>
        <div>
          <p><span>{{transferList.avgMsgNum ? transferList.avgMsgNum.toFixed(2) :'--'}}</span><em  :class="{red:transferList.avgRang>0,green:transferList.avgRang<=0}">{{transferList.avgRang ? (transferList.avgRang*100).toFixed(2) : '--'}}%</em></p>
          <p>本月人均发送数</p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{

    }
  },
  props:{
    resourceStreamList:[Array,Object],
    performanceList_com:Array,
    transferList:Object,
    isTransferList:Boolean,
  }
}
</script>
<style lang="scss" scoped>
@import "../../../assets/css/common.scss";
.showChat{
  margin-top: 7px;
  display: flex;
  justify-content: space-between;
  width: 100%;
  .chat1{
    width: 550px;
    >div{
      width: 100%;
      height: calc(100% - 32px);
      // height: 100%;
      box-sizing: border-box;
      padding:28px 50px 0px 36px;
      position: relative;
      left: 0;top: 0;
      >div{
        width: 100%;
        height: 100%;
        position: absolute;
        left: 0;top: 0;
        >span{
          position: absolute;
        }
        .fontTile{
          display: inline-block;
          width: 100px;
          text-align: center;
          color: #fff;
          left: 115px;
          font-size: 15px;
        }
        .fontTile:nth-child(1){
          top: 50px;
        }
        .fontTile:nth-child(2){
          top: 98px;
        }
        .fontTile:nth-child(3){
          top: 146px;
        }
        .fontTile:nth-child(4){
          top: 195px;
        }
        .fontTile:nth-child(5){
          top: 243px;
        }
        .dotNub{
          color: #000;
          font-size: 16px;
        }
        .dotNub:nth-child(6){
          left: 310px;
          top: 50px;
        }
        .dotNub:nth-child(7){
          left: 290px;
          top: 98px;
        }
        .dotNub:nth-child(8){
          left: 270px;
          top: 146px;
        }
        .dotNub:nth-child(9){
          left: 245px;
          top: 195px;
        }
        .dotNub:nth-child(10){
          left: 230px;
          top: 243px;
        }
        .scadu{
          display: block;
          width: 38px;
          text-align: center;
          color:#3089FF;
          font-size: 14px;
          right: 40px;
        }
        .scadu:nth-child(11){
          top: 50px
        }
        .scadu:nth-child(12){
          top: 98px;
        }
        .scadu:nth-child(13){
          top: 146px
        }
        .scadu:nth-child(14){
          top: 195px
        }
        .scadu:nth-child(15){
          top: 243px
        }
      }
    }
  }
  .chat2{
    width: 355px;
    >div{
      width: 100%;
      height: 44px;
      line-height: 44px;
      display: flex;
      justify-content: space-between;
      padding: 0 16px;
      box-sizing: border-box;
      >i{
        width: 24px;height: 24px;
        margin-top: 10px;
        margin-right: 15px;
        display: block;
      }
      .selieColor{
        margin-right: 10px;
      }
    }
    >div:nth-child(2){
      margin-top: 30px;
      background:rgba(219,166,39,0.08);
      // opacity:0.08;
      >i{
        text-decoration: none;
        margin-top: 10px;
        margin-right: 15px;
        display: block;
        width: 24px;height: 24px;
        // @include image(datacenter_Data_1,rgba(48,137,255,0.08));
        background-image: url("../../../assets/images/gm_datacenter_1st.png");
      }
      .selieColor{
        margin-right: 10px;
        color: #DBA627;
      }
    }
    >div:nth-child(n+3){
      margin-top: 8px;
      background: #FAFAFA;
    }
    >div:nth-child(3){
      background:rgba(48,137,255,0.08);
      .selieColor{
        margin-right: 10px;
        color: #3089FF;
      }
      >i{
        color: #000;
        margin-top: 10px;
        margin-right: 15px;
        display: block;
        width: 24px;height: 24px;
        // @include image(gm_datacenter_2st);
        background-image: url("../../../assets/images/gm_datacenter_2st.png");
      }
    }
    >div:nth-child(4){
      background:rgba(233,159,114,0.08);
      .selieColor{
        color: #E99F72;
        margin-right: 10px;
      }
      >i{
        margin-top: 10px;
        margin-right: 15px;
        display: block;
        width: 24px;height: 24px;
        // @include image(gm_datacenter_3st);
        background-image: url("../../../assets/images/gm_datacenter_3st.png");
      }
    }
    >div:nth-child(5){
      >i::before{
        display: block;
        width: 100%;
        height: 100%;
        line-height: 22px;
        font-style: normal;
        text-align: center;
        content: "4";
      }
    }
    >div:nth-child(6){
      >i::before{
        display: block;
        width: 100%;
        height: 100%;
        line-height: 22px;
        font-style: normal;
        text-align: center;
        content: "5";
      }
    }
  }
  .chat3{
    width: 514px;
    .roundBox{
      margin: 56px auto 0;
      width: 272px;;
      height: 104px;
      display: flex;
      justify-content: space-between;
      
      .score {
        position: relative;
        left: 0;
        top: 0;
        width: 102px;
        height: 102px;
        overflow: hidden;
        &::before {
          content: "";
          position: absolute;
          left: 0;
          top: 0;
          width: 90px;
          height: 90px;
          border: 6px solid #F5F5F5;
          border-radius: 50%;
        }
        &::after {
          content: "";
          position: absolute;
          left: 9px;
          top: 9px;
          width: 84px;
          height: 84px;
        }
        .circle {
          position: absolute;
          left: 0;
          top: 0;
          width: 102px;
          height: 102px;
          mix-blend-mode: multiply;
          background: #fff;
          /deep/ .el-progress-circle__track { display: none;}
          /deep/ .el-progress--circle {
            background: #FFF;
            mix-blend-mode: screen;
          }
          &::before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(200deg, #68CAFF, #007FFF)
          }
        }
        .text {
          position: absolute;
          width: 100%;
          left: 2px;
          top: 22px;
          z-index: 1;
          text-align: center;
          color:rgba(0,0,0,0.45);
          font-size: 16px;
          font-weight: bold;
          >p{font-size:14px;span { font-size: 28px;color: #000;}}
          
        }
      }
    }
    .roundUnder{
      margin-top: 56px;
      display: flex;
      justify-content: center;
      .green{
        color: #61C015;
        position: relative;
        left: 0;
        top: 0;
        font-style: normal;
      }
      .green::after{
        width: 0px;
        height: 0px;
        position: absolute;
        top: 4px;
        right: -10px;
        content: "";
        border-top:4px solid #61C015;
        border-left: 3px solid transparent;
        border-right: 3px solid transparent;
      }
      .red{
        color: #FF4C62;
        font-style: normal;
        position: relative;
        left: 0;
        top: 0;
      }
      .red::after{
        width: 0px;
        height: 0px;
        position: absolute;
        top: 4px;
        right: -8px;
        content: "";
        border-bottom:4px solid #FF4C62;
        border-left: 3px solid transparent;
        border-right: 3px solid transparent;
      }
      >div{
        text-align: center;
        width: 150px;
        p{
          line-height: 30px;
          font-size: 14px;
          span{
            margin-right: 10px;
            font-size: 24px;
            color: #00A5FF;
          }
        }
      }
      &>:nth-child(n+2){
        border-left:  1px solid #E9E9E9;
      }
    }
  }
  >div{
    height: 362px;
    border:1px solid rgba(233,233,233,1);
    border-radius: 2px;
    box-sizing: border-box;
    padding: 24px;
    >p{
      font-size:16px;
      font-weight:500;
      color:rgba(51,51,51,1);
      line-height:24px;
    }
  }
}
</style>