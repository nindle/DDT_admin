<template>
  <el-scrollbar class="tableScrollBox">
    <div class="headData">
      <div>
        <p>业务总数</p>
        <div>
          <span>{{headDataList.totalSalesNum}}</span>
          <img src="../../../assets/images/datatopimg.png" alt="">
        </div>
      </div>
      <div v-for="(e,index) in headCompanyList" :key="index">
        <p>{{e.corpName}}</p>
        <div>
          <span>{{e.loginRate ? (e.loginRate*100).toFixed(2) :'--'}}%</span>
          <div class="imgBox"></div>
        </div>
      </div>
    </div>
  </el-scrollbar>
</template>
<script>
import { deepcopy } from '../../../assets/js/tool'
export default {
  props:{
    headDataList:[Array,Object]
  },
  data(){
    return{
      
    }
  },
  computed:{
    headCompanyList(){
      let list = deepcopy(this.$store.state.baseData.corpList)
      let score = deepcopy(this.headDataList.list)
      let data = []
      data = list.map(e=>{
        score.map(i=>{
          if(i.corpId === e.id){
            e = {...e,...i}
            return{
              e
            }
          }
        })
        return e
      })
      return data
    }
  },
}
</script>
<style lang="scss" scoped>
@import "../../../assets/css/common.scss";
.tableScrollBox{
  margin-top: 24px;
  .headData{
    width: 1682px;
    padding-left: 4px;
    padding-top: 4px;
    // margin-top: 24px;
    height: 139px;
    display: flex;
    justify-content: left;
    >div{
      box-sizing: border-box;
      height: 122px;
      box-shadow:0px 2px 4px 0px rgba(0,18,41,0.12);
      border-radius:2px;
      box-sizing: border-box;
      padding: 24px;
      p{
        color:rgba(0,0,0,0.45);
        font-size: 14px;
        font-weight: 400;
        line-height: 22px;
      }
      >div{
        display: flex;
        justify-content: space-between;
        >span{
          font-size: 32px;
          color: #3089FF;
          font-weight: 500;
          line-height: 70px;
        }
      }
    }
    >div:nth-child(1){
      width: 288px;
      img{
        width: 73px;
        height: 71px;
        position: relative;
        top: -10px;
      }
    }
    >div:nth-child(n+2){
      margin-left: 24px;
      width: 208px;
      .imgBox{
        display: block;
        margin-top: 10px;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        
      }
    }
    >div:nth-child(2){
      .imgBox{
        background-color: rgba(254, 86, 183, 0.08);
        // @include image(datacenter_Data_5,rgba(32, 13, 24, 0.08));
        background-image: url("../../../assets/images/datacenter_Data_5.png");
        background-repeat:no-repeat;
        background-position:center;
      }
    }
    >div:nth-child(3){
      .imgBox{
        // @include image(datacenter_Data_1,rgba(48,137,255,0.08));
        background-color: rgba(48,137,255,0.08);
        background-image: url("../../../assets/images/datacenter_Data_1.png");
        background-repeat:no-repeat;
        background-position:center;
        
      }
    }
    >div:nth-child(4){
      .imgBox{
        background-image: url("../../../assets/images/datacenter_Data_2.png");
        background-color: rgba(23,217,229,0.08);
        // @include image(datacenter_Data_2,rgba(23,217,229,0.08));
        background-repeat:no-repeat;
        background-position:center;
      }
    }
    >div:nth-child(5){
      .imgBox{
        background-image: url("../../../assets/images/datacenter_Data_3.png");
        background-color: rgba(245,127,49,0.08);
        // @include image(datacenter_Data_3,rgba(245,127,49,0.08));
        background-repeat:no-repeat;
        background-position:center;
      }
    }
    >div:nth-child(6){
      .imgBox{
        background-image: url("../../../assets/images/datacenter_Data_4.png");
        background-color: rgba(186,59,255,0.08);
        // @include image(datacenter_Data_4,rgba(186,59,255,0.08));
        background-repeat:no-repeat;
        background-position:center;
      }
    }
    >div:nth-child(7){
      .imgBox{
        background-image: url("../../../assets/images/datacenter_Data_5.png");
        // @include image(datacenter_Data_5,rgba(254,86,183,0.08));
        background-color: rgba(254,86,183,0.08);
        background-repeat:no-repeat;
        background-position:center;
      }
    }
    >div:nth-child(8){
      .imgBox{
        background-image: url("../../../assets/images/datacenter_Data_1.png");
        background-color: rgba(48,137,255,0.08);
        // @include image(datacenter_Data_1,rgba(48,137,255,0.08));
        background-repeat:no-repeat;
        background-position:center;
      }
    }
  }
}
</style>