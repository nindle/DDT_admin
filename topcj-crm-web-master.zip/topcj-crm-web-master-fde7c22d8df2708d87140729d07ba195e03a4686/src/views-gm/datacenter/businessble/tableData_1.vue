<template>
  <el-table-pro
    :data="data"
    :head="head"
    border
  >
  </el-table-pro>
</template>

<script>
export default {
  data() {
    return {
      head: [
        {
          key: 'cdate',
          label: '',
          minWidth: 140,
        },
        {
          key: 'newUser',
          label: '当日入库数',
          minWidth: 78,
        },
        {
          key: 'newWorkUser',
          label: '新增关注工作台数',
          minWidth: 70,
          tooltip: true
        },
        {
          key: 'newOrder',
          label: '当日成交量',
          minWidth: 56,
        },
        {
          key: 'money',
          label: '当日成交额',
          minWidth: 80,
          tooltip: true
        },
        {
          key: 'moneyMonth',
          label: '近1月入库资源产生业绩',
          minWidth: 100,
        },
        {
          key: 'moneyQuarter',
          label: '近3月入库资源产生业绩',
          minWidth: 100,
        },
        {
          key: 'internalUser',
          label: '内诉数',
          minWidth: 50,
        },
        {
          key: 'externalUser',
          label: '外诉数',
          minWidth: 50,
        },
        {
          key: 'refundUser',
          label: '退费用户数',
          minWidth: 50,
        },
        {
          key: 'refund',
          label: '退费金额',
          minWidth: 50,
        }
      ],
    }
  },
  props:{
    data:Array
  }
}
</script>