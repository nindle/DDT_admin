<template>
  <el-table-pro
    :data="data"
    :head="head"
    border
  >
  </el-table-pro>
</template>

<script>
export default {
  data() {
    return {
      head:[
        {
          key: 'cdate',
          label: '',
          minWidth: 140,
        },
        {
          key: 'workUser',
          label: '工作台客户数',
          minWidth: 78,
        },
        {
          key: 'newWorkUser',
          label: '每日增加客户数',
          minWidth: 78,
        },
        {
          key: 'monthWorkUser',
          label: '本月增加客户数',
          minWidth: 78,
        },
        {
          key: 'activeUser',
          label: '活跃客户数',
          minWidth: 78,
        },
        {
          key: 'activeRate',
          label: '活跃比',
          minWidth: 78,
          format: e => `${(e*100).toFixed(2)}%`
        },
      ],
    }
  },
  props:{
    data:Array
  }
}
</script>