<template>
  <div class="formTable">
    <div class="table1">
      <el-layout-pro
        class="box"
        :loading="loading"
        @change="getDailyAchievement();getWorkActive()"
      >  
        <!-- 筛选模块 -->
        <template #screen>
          <el-screen-pro
            :model="screen"
            :config="config"
          ></el-screen-pro> 
        </template>
      
        <!--表格模块-->
        <template #table>
          <table-data 
            :data="dailyAchievementList"
            ref="table"
          />
        </template> 
      </el-layout-pro>
    </div>
    <div class="table2">
      <el-layout-pro
        class="box"
        :loading="loading"
      >  
        <!-- 筛选模块 -->
        <template #screen>
          <el-screen-pro
            :model="screen2"
            :config="config2"
          ></el-screen-pro> 
        </template>
      
        <!--表格模块-->
        <template #table>
          <table-data2 
            :data="workActiveList_com"
            ref="table2"
          />
        </template> 
      </el-layout-pro>
    </div>
  </div>
</template>
<script>
import tableData from './tableData_1'
import tableData2 from './tableData_2'
export default {
  data(){
    return{
      loading:false,
      screen: {
        time: new Date(),
        label:'本月资源流转详情'
      },
      screen2: {
        label:'服务发布情况详情'
      },
      config: {
        time: {
          type: 'date',
          placeholder: '选择日期',
        },
        label:{
          type:'label'
        },
        split:{
          type:'split'
        },
        excel: {
          type: 'button',
          label: '导出excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        },
      },
      config2: {
        label:{
          type:'label'
        },
        split:{
          type:'split'
        },
        excel: {
          type: 'button',
          label: '导出excel',
          click: () => { this.$copyExcel(this, this.nav.title)}
        },
      },

      
      //本月资源流转详情
      dailyAchievementList:[],
      //服务发布情况详情
      workActiveList_com:[],

    }
  },
  components:{
    tableData,
    tableData2,
  },
  created(){
    this.getWorkActive()
    this.getDailyAchievement()
  },
  methods:{
     //服务发布情况详情
    async getWorkActive(){
      this.loading = true
      let { result } = await this.$http({
        url:'%CRM%/report/get_work_active.sdcrm',
        data:{
          token:true,
          corpId:typeof(this.corpId) ==='number' ? this.corpId : undefined,
          etime:this.screen.time ? new Date(this.screen.time).getTime() : undefined
        }
      })
      this.workActiveList_com = result
      this.loading = false
    },
    //本月资源流转详情
    async getDailyAchievement(){
      this.loading = true
      let { result } = await this.$http({
        url:'%CRM%/report/get_daily_achievement.sdcrm',
        data:{
          token:true,
          corpId:typeof(this.corpId) ==='number' ? this.corpId : undefined,
          etime:this.screen.time ? new Date(this.screen.time).getTime() : undefined 
        }
      })
      this.dailyAchievementList = result
      this.loading = false
    },
  }
}
</script>
<style lang="scss" scoped>
@import "../../../assets/css/common.scss";
  .formTable{
    .downloadFont::before{
      content: '';
      display: block;
      float: left;
      width: 16px;
      height: 16px;
      margin-top: 8px;
      margin-right: 2px;
      // @include image(download);
      background-image: url("../../../assets/images/download.png");
    }
    margin-top: 24px;
    display: flex;
    justify-content: space-between;
    .table1{
      width: 927px;
    }
    .table2{
      width:514px;
    }
    >div{
      border-radius:2px;
      border:1px solid rgba(233,233,233,1);
      box-sizing: border-box;
      padding: 24px;
      .selectTop{
        line-height: 32px;
        display: flex;
        justify-content: space-between;
        :nth-child(n+2){
          margin-left:24px;
        }
        .autoRight{
          margin-left: auto;
            /deep/ .el-input__inner {
              padding-left: 80px;
            }
        }
        span{
          font-size:16px;
          font-weight:500;
          color:rgba(51,51,51,1);
        }
        .blue{
          cursor: pointer;
          color: #3089FF;
        }
      }
      .formList{
        margin-top: 20px;
        >ul{
          width: 100%;
          line-height:44px;
          display: flex;
          font-size: 14px;
          justify-content: space-between;
          border-bottom: 1px solid #E9E9E9;
          >li{
            text-align: center;
            &:nth-child(1){
              width: 64px;
            }
            &:nth-child(2){
              width: 78px;
            }
            &:nth-child(3){
              width: 70px;
            }
            &:nth-child(4){
              width: 56px;
            }
            &:nth-child(5){
              width: 80px;
            }
            &:nth-child(6){
              width: 100px;
            }
            &:nth-child(7){
              width: 100px;
            }
            &:nth-child(8){
              width: 62px;
            }
            &:nth-child(9){
              width: 50px;
            }
            &:nth-child(10){
              width: 50px;
            }
            &:nth-child(11){
              width: 50px;
            }
            &:nth-child(12){
              width: 56px;
            }
            &:nth-child(1){
              width: 70px;
            }
          }
        }
        .Listhead{
          line-height: 22px;
        }
        >ul:nth-child(1){
          background:rgba($color: #000000, $alpha: 0.02);
          border-top: 1px solid #E9E9E9;
        }
      }
    }
  }
</style>