<template>
<!-- 业务 -->
  <div class="item3" ref="m1item" >
    <p class="title">业务</p>

    <data-head 
      :headDataList='headDataList'
    />
    
    <img-message
      :resourceStreamList='resourceStreamList'
      :performanceList_com='performanceList_com'
      :transferList='transferList'
      :isTransferList='isTransferList'
    />
    
    <doubleTable/>
  </div>  
</template>
<script>
import doubleTable from "./businessble/table"
import dataHead from './businessble/dataHead'
import imgMessage from './businessble/imgMessage'
export default {
  data(){
    return{
      //资源流转情况
      resourceStreamList:[],
      //业绩排行
      performanceList_com:[],
      //月报发布情况
      transferList:{},
      
      // 合规表头数据
      headDataList:{
        list:[]
      },
      timerMon:new Date(),
      isTransferList:false,
      
    }
  },
  props:{
    corpId:Number,
  },
  created(){
    //数据头
    this.getHeadData()
    //资源流转情况 (梯形)
    this.getResource()
    //业绩排行
    this.getPerformance()
    //月服务发布情况 (圆)
    this.getTransfer()
    //每日业绩情况
    // this.getDailyAchievement()
    // //服务发布情况详情
    // this.getWorkActive()
  },
  watch:{
    timerMon(){
      // this.getDailyAchievement()
      this.getWorkActive()
    },
    corpId(){
      this.getResource()
      this.getPerformance()
      this.getTransfer()
      // this.getDailyAchievement()
      this.getWorkActive()
    }
  },
  components:{
    doubleTable,
    dataHead,
    imgMessage
  },
  methods:{
    //资源流转情况 (梯形)
    async getResource(){
      let { result } = await this.$http({
        url:'%CRM%/report/get_resource_transfer.sdcrm',
        data:{
          token:true,
          corpId:typeof(this.corpId) ==='number' ? this.corpId : undefined,
        }
      })
      if(result.length>1){
        alert("error695")
      }
      this.resourceStreamList = result[0]
    },
    //业绩排行
    async getPerformance(){
      let { result } = await this.$http({
        url:'%CRM%/report/get_performance_bulletin.sdcrm',
        data:{
          token:true,
          // 是分公司 则 传corpid 没传corpid 是否为总公司数据
          corpId:typeof(this.corpId) ==='number' ? this.corpId : undefined,
          size:5
        }
      })
      this.performanceList_com = result
    },
    //月服务发布情况 (圆)
    async getTransfer(){
      let { result } = await this.$http({
        url:'%CRM%/report/get_sales_services.sdcrm',
        data:{
          token:true,
          corpId:typeof(this.corpId) ==='number' ? this.corpId : undefined,
        }
      })
      if(result.length>1){
        alert("error695")
      }
      this.isTransferList = true
      this.transferList = result[0]
    },
    //业务数据头
    async getHeadData(){
      let { result } = await this.$http({
        url:'%CRM%/report/get_login_summary.sdcrm',
        data:{
          token:true,
        }
      })
      this.headDataList = result
    },
  }
}
</script>
<style lang="scss" scoped>
@import "../../assets/css/common.scss";
.item3{
  .title{
    font-size:20px;
    color:rgba(0,0,0,0.85);
    font-weight:500;
    text-indent: 16px;
  }
}
</style>