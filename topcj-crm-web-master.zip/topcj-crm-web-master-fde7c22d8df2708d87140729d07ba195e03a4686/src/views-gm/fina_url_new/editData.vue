<template>
  <el-dialog-pro @close="close">
    <template #title>购买信息</template>
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
      <template #orderId-unit>
        <span style="color: #F56C6C;margin-left: 12px">{{content}}</span>
      </template>
      <template #hasBuyOrderId>
        <div v-if="hasBuyOrder.length">
          <div 
            v-for="e in hasBuyOrder"
            :key="e.id"
          >{{e.nameFormat}}</div>
        </div>
        <span v-else></span>
      </template>
      <template #tip="{ model: { tip } }">
        <span style="color: #F56C6C">{{tip}}</span>
      </template>

      <template #processed="{ model: { imageList } }">
        <div 
          v-for="(e, i) in imageList"
          :key="i"
          class="input-image large"
          @click="viewProcessed(i)"
        >
          <img 
            class="processed-img"
            :class="{ h: (e.rotate % 360 + 360) % 180 !== 0 }"
            :style="{ transform: `rotate(${e.rotate}deg)` }"
            :src="e.url"
          />
        </div>
      </template>


    </el-form-pro>
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >提 交</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle, debounce } from '../../assets/js/tool'
export default {
  data() {
    return {
      userId: null,
      // 状态更新
      loading: false,
      // 筛选
      form: {
        userId: '',
        hasBuyOrderId: [],
        managerId: '',
        orderId: '',
        hasMoney: '',
        signPath: '',
        imageList: [],
        money: this.data.reduce((pre, e) => e.balance + pre, 0) + '元',
        price: '--元',
        tip: ''
      },
      config: {
        userId: {
          type: 'input',
          label: '客户ID/手机',
          rule: [
            { required: true }
          ],
          change: () => {
            this.getOrderList()
            this.getHasBuyOrderList()
          }
        },
        managerId: {
          type: 'select',
          label: '业绩归属',
          options: this.$store.state.baseData.managerList.filter(e => {
            if(this.$store.state.managerInfo.corpId === 0) {
              return e.isLock === 0 && [1,2].includes(e.managerType)
            }
            return e.isLock === 0 && [1,2].includes(e.managerType) && this.$store.state.managerInfo.corpId === e.corpId
          }),
          labelKey: 'realName',
          valueKey: 'id',
          filterable: true,
          rule: [
            { required: true }
          ]
        },
        orderId: {
          type: 'select',
          label: '签约产品',
          options: [],
          labelKey: 'packageName',
          valueKey: 'id',
          rule: [
            { required: true }
          ],
          change: this.getPrice
        },
        hasBuyOrderId: {
          type: 'label',
          label: '客户抵扣套餐',
          hide: true,
          // rule: [
          //   { required: true }
          // ],
          // change: this.getTips
        },
        money: {
          type: 'label',
          label: '订单余额',
        },
        price: {
          type: 'label',
          label: '产品价格',
          hide: true
        },
        voucherprice: {
          type: 'label',
          label: '代金券',
          hide: true
        },
        hasMoney: {
          type: 'label',
          label: '补差价金额',
          hide: true
        },
        signPath: {
          type: 'image',
          label: '签署图片',
          hideButton: true,
          placeholder: '未签署',
          hide: () => !this.form.signPath
        },
        processed: {
          type: 'image',
          label: '证件照片',
          hide: () => !this.form.imageList.length
        },
        // processedBackUrl: {
        //   type: 'image',
        //   label: '',
        //   hideButton: true,
        //   placeholder: '无',
        //   hide: () => !this.form.processedBackUrl
        // },
        tip: {
          type: 'label',
          hide: () => !this.form.tip
        }
      },
      hasBuyOrder: [],
      hasBuyOrderList: [],
      content: ''
    }
  },
  props: {
    show: Boolean,
    data: Array,
  },
  methods: {
    close() { 
      this.$emit('update:show',false)
    },
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return
      if(this.form.tip) return
      this.loading = true
      let item = this.config.orderId.options.find(e => e.id === this.form.orderId)
      let record = {
        sn: item.sn,
        userId: item.userId,
        packageId: item.packageId,
        money: item.money,
        payStatus: item.payStatus,
        buyStatus: item.buyStatus,
        payType: item.payType,
        tradeNumber: item.tradeNumber,
        classId: item.classId,
        companyId: item.companyId,
        corp: item.corp,
        corpSn: item.corpSn,
        giftDays: item.giftDays,
        id: item.id,
        couponId: item.couponId
      }
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/offline/new_offline_pay.sdcrm',
        data: {
          token: true,
          ids: this.data.map(e => e.id),
          managerId: this.form.managerId,
          record,
          orderIds: this.form.hasBuyOrderId && this.form.hasBuyOrderId.length ? this.form.hasBuyOrderId : undefined,
        }
      })
      this.loading = false
      if(code !== 8200) {
        this.$message.error(`购买失败：${errmsg || msg}`)
        return
      }
      this.$message.success('购买成功')
      this.$emit('change')
      this.close()
    }),
    //获取签约记录
    async getOrderList() {
      let { code, result } = await this.$http({
        url: '%CRM%/offline/get_order_list.sdcrm',
        data: {
          token: true,
          userId: this.form.userId,
          agreementStatus: 1,
          pageNum: 1,
          pageSize: 30
        }
      })
      this.form.orderId = ''
      this.form.price = '--元'
      this.form.tip = ''
      this.form.signPath = ''
      if(code !== 8200 || !result.records.length) {
        this.config.orderId.options = []
        return
      }
      
      this.config.orderId.options = result.records
      this.getProfile(result.records[0].userId)
    },
    // async getProfile(userId) {
    //   let result = await this.$store.dispatch('getUserDetail', userId)
    //   let tip = []
    //   if(typeof result.riskType !== 'number') {
    //     tip.push('风险测评')
    //   }
    //   if(!result.idNum) {
    //     tip.push('实名认证')
    //   }
    //   if(tip.length) {
    //     this.form.tip = `该用户未完成${tip.join('、')}`
    //   }
    // },
    async getProfile(userId) {
      let result = await this.$store.dispatch('getUserDetail', userId)
      let riskTip = ''
      if(typeof result.riskType !== 'number') {
        riskTip = '风险测评'
      }

      let { result: status } = await this.$http({
        url: '%CRM%/user/get_id_num_status.sdcrm',
        data: {
          token: true,
          userId: userId
        }
      })

      if(status === 0) {
        if(riskTip) {
          this.form.tip = `该用户未完成${riskTip}`
        }
      }else if(status === 1) {
        if(riskTip) {
          this.form.tip = `该用户未完成${riskTip}，且特殊证件已上传但还没有审核`
        }else{
          this.form.tip = '该特殊证件已上传但还没有审核'
        }
      }else if(status === 2) {
        if(riskTip) {
          this.form.tip = `该用户未完成${riskTip}，且特殊证件未通过审核`
        }else{
          this.form.tip = '该特殊证件未通过审核'
        }
      }else if(status === 3) {
        if(riskTip) {
          this.form.tip = `该用户未完成${riskTip}，实名认证`
        }else{
          this.form.tip = '该用户未完成实名认证'
        }
      }
    },
    async getPrice() {
      let detail = this.config.orderId.options.find(e => e.id === this.form.orderId)
      this.getTips(detail)
      if(detail) {
        this.form.price = `${detail.money - detail.actualMoney}元`
        this.form.voucherprice = `${detail.actualMoney ?? 0}元（已支付）`
        this.config.voucherprice.hide = !detail.actualMoney 
        this.form.signPath = detail.signPath
        this.userId = detail.userId
        this.form.imageList = [
          {
            url: detail.processedFrontUrl,
            rotate: detail.frontAngle
          },
          {
            url: detail.processedBackUrl,
            rotate: detail.backAngle
          }
        ]
      }else{
        this.userId = null
        this.config.voucherprice.hide = true
        this.form.price = '--元'
        this.form.signPath = ''
        this.form.imageList = []
      }
    },
    //获取已购买记录
    async getHasBuyOrderList() {
      let { code, result } = await this.$http({
        url: '%CRM%/user/get_order_list.sdcrm',
        data: {
          token: true,
          userId: this.form.userId,
          pageNum: 1,
          pageSize: 30,
          buyStatus: 1,
          notExpired: 1
        }
      })
      this.hasBuyOrderList = []
      if(code !== 8200 || !result.records.length) {
        this.hasBuyOrderList = []
        return
      }
      
      this.hasBuyOrderList = result.records.map(e => {
        let time = new Date(e.ctime)
        e.nameFormat = `${time.timeFormat('yyyy.MM.dd')} ${e.packageName} 已开通${Math.ceil((Date.now() - time.getTime()) / ( 24 * 60 * 60 * 1000 ))}天`
        return e
      })
    },
    async getTips(data) {
      // if(!this.form.hasBuyOrderId.length) return
      let { result } = await this.$http({
          url: '%CRM%/offline/get_order.sdcrm',
          data: {
            token: true,
            recordId: this.form.orderId
          }
      })
      this.form.hasBuyOrderId = []
      if(!result || !result.length) {
        this.config.price.hide = false
        this.config.hasMoney.hide = true
        this.config.hasBuyOrderId.hide = true
        // this.$message.error('该订单为新单，并非补差价购买，请确认后点击购买按钮操作。')
        this.content = '该订单为普通单'
        return
      }
      this.config.price.hide = true
      this.config.hasMoney.hide = false
      this.config.hasBuyOrderId.hide = false
      this.content = '该订单为升级单'
      this.hasBuyOrder = result.map(e => {
        this.hasBuyOrderList.forEach(item => {
          if(item.id === e.id) {
            let time = new Date(item.ctime)
            e.nameFormat = `${item.packageName}(到期: ${new Date(time.getTime() + (item.serviceDay * 24 * 60 * 60 * 1000)).timeFormat('yyyy-MM-dd')})`
          }
        })
        return e
      })
      this.form.hasBuyOrderId = this.hasBuyOrder.map(e => e.id)
      
      if(data) {
        this.form.hasMoney = `${data.money}元`
      }
    },
    viewProcessed(index) {
      this.$imageview({
        list: this.form.imageList,
        index,
        onRotate: debounce(async (index, rotate) => {
          if(index === 0 && rotate === this.form.imageList[0].rotate) return
          if(index === 1 && rotate === this.form.imageList[1].rotate) return

          await this.$http({
            url: '%CRM%/user/set_id_card_angle.sdcrm',
            data:{
              token: true,
              userId: this.userId,
              type: index,
              angle: rotate % 360
            }
          })

          this.form.imageList[index].rotate = rotate
        }, 300)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.processed-img {
  width: 256px;
  height: 144px;
  object-fit: cover;
  &.h {
    position: relative;
    width: 144px;
    height: 256px;
    left: 56px;
    top: -56px;
  }
}
.input-image {
  &:last-child {
    margin-top: 22px;
  }
}
</style>