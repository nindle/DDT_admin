<template>
  <el-dialog-pro @close="close">
    <template #title>购买信息</template>
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
    </el-form-pro>

    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >提 交</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      // 状态更新
      loading: false,
      // 筛选
      form: {
        userId: '',
        managerId: '',
        orderId: '',
        voucherprice: '',
        money: this.data.reduce((pre, e) => e.balance + pre, 0) + '元',
      },
      config: {
        userId: {
          type: 'input',
          label: '客户ID/手机',
          rule: [
            { required: true }
          ],
        },
        managerId: {
          type: 'select',
          label: '业绩归属',
          options: this.$store.state.baseData.managerList.filter(e => {
            if(this.$store.state.managerInfo.corpId === 0) {
              return e.isLock === 0 && [1,2].includes(e.managerType)
            }
            return e.isLock === 0 && [1,2].includes(e.managerType) && this.$store.state.managerInfo.corpId === e.corpId
          }),
          labelKey: 'realName',
          valueKey: 'id',
          filterable: true,
          rule: [
            { required: true }
          ]
        },
        orderId: {
          type: 'select',
          label: '购买代金券',
          options: [],
          labelKey: 'couponName',
          valueKey: 'couponId',
          rule: [
            { required: true }
          ],
          change: ()=>{ 
            this.form.voucherprice = `${this.config.orderId.options.find(e => e.couponId == this.form.orderId)?.money}元`
          }
        },
        voucherprice: {
          type: 'label',
          label: '代金券价格',
          hide: () => !this.form.orderId
        },
        money: {
          type: 'label',
          label: '订单余额',
        },
      },
    }
  },
  props: {
    show: Boolean,
    data: Array,
  },
  methods: {
    close() { 
      this.$emit('update:show',false)
    },
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return
      this.loading = true

      if(this.data.reduce((p, e) => p + e.balance, 0) < this.config.orderId.options.find(e => e.couponId == this.form.orderId).money){
        this.$message.error('订单金额不足')
        return
      }
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/offline/offline_pay_coupon.sdcrm',
        data: {
          token: true,
          offlineIds: this.data.map(e => e.id),
          userId: this.form.userId,
          managerId: this.form.managerId,
          couponId: this.form.orderId,
        }
      })

      this.loading = false
      if(code !== 8200) {
        this.$message.error(`购买失败：${errmsg || msg}`)
        return
      }
      this.$message.success('购买成功')
      this.$emit('change')
      this.close()
    }),

    //获取签约记录
    async getVoucherList() {
      let { code, result } = await this.$http({
        url: '%CRM%/coupon/get_coupon_pay_list.sdcrm',
        data: {
          token: true,
        }
      })
      if(code === 8200) {
        this.config.orderId.options = result.reverse()
      }
    },
  },
  created(){
    this.getVoucherList()
  }
}
</script>