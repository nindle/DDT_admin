<template>
  <el-table-pro
    :data="data"
    :head="head"
    @selection-change="$emit('update:select-list', $event)"
  >
    <template #body-fileUrl="{row}">
      <el-button
        v-for="(e, i) in row.fileUrl"
        :key="e.url"
        type="text"
        size="small"
        v-open="e.url"
        icon="el-icon-download"
        style="margin: 0 8px 0 0"
      >附件{{i + 1}}</el-button>
    </template>

    <template #body-operation="{ row }">
      <el-button
        type="text"
        size="small"
        icon="el-icon-edit"
        @click="$emit('edit', row)"
      >编辑</el-button>
    </template>

    <template #body-delete="{ row }">
      <el-popconfirm
        title="确定删除吗？"
        @confirm="deleteData(row)"
      >
        <template #reference>
          <el-button
            type="text"
            size="small"
            icon="el-icon-delete"
          >删除</el-button>
        </template>
      </el-popconfirm>
    </template>
  </el-table-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'id',
          label: '编号',
          minWidth: 60
        },
        {
          key: 'classifyId',
          label: '合规分类',
          minWidth: 84,
          format: {
            list: this.typeList,
            key: 'typeId',
            value: 'typeName'
          },
          hide: () => this.routeClassifyId
        },
        {
          key: 'title',
          label: '文件名称',
          minWidth: 300
        },
        {
          key: 'recivewer',
          label: '审核人',
          minWidth: 120
        },
        {
          key: 'trailTime',
          label: '审核时间',
          minWidth: 90,
          format:e => new Date(e).timeFormat('yyyy-MM-dd')
        }, 
        {
          key: 'ntime',
          label: '执行时间',
          minWidth: 90,
          format:e => new Date(e).timeFormat('yyyy-MM-dd')
        }, 
        {
          key: 'effect',
          label: '执行情况',
          minWidth: 56,
        },
        {
          key: 'fileUrl',
          label: '附件数量',
          minWidth: 120
        },
        {
          key: 'operation',
          label: '操作',
          width: 44
        },
        {
          key: 'delete',
          width: 44
        }
      ]
    }
  },
  props: {
    data: Array,
    typeList: Array,
    selectList: Array,
    routeClassifyId: [Number, String]
  },
  methods: {
    //删除数据
    deleteData: throttle(async function(row) {
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/compliance/set_compliance.sdcrm',
        data: {
          token: true,
          id: row.id,
          visible: 0
        },
      })

      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        return
      }

      this.$message.success('删除成功')

      this.$emit('change')
    })
  }
}
</script>
