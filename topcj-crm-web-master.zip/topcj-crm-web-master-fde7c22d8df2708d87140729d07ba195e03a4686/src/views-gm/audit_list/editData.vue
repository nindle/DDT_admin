
<template>
  <el-dialog-pro @close="close">
    <!--标题-->
    <template #title>
      {{data ? '编辑' : '新增'}}数据
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        title: this.data?.title ?? '',
        classify: this.data?.classify ?? '',
        classifyId: this.data?.classifyId ?? this.routeClassifyId,
        recivewer: this.data?.recivewer ?? '',
        trailTime: this.data ? new Date(this.data.trailTime).getTime() : null,
        ntime: this.data ? new Date(this.data.ntime).getTime() : null,
        effect: this.data?.effect ?? '',
        fileUrl: this.data?.fileUrl ?? [],
        legality: this.data?.legality ?? ''
      },
      config: {
        title: {
          label: '文件名称',
          rule: [
            { required: true }
          ]
        },
        classify: {
          label: '分类',
          rule: [
            { required: true }
          ]
        },
        classifyId: {
          label: '合规分类',
          type: 'select',
          options: this.typeList,
          valueKey: 'typeId',
          labelKey: 'typeName',
          rule: [
            { required: true }
          ],
          hide: () => this.routeClassifyId
        },
        recivewer: {
          label: '审核人',
          rule: [
            { required: true }
          ]
        },
        legality: {
          label: '状态',
          type: 'select',
          options: (this.tag.t24 || this.tag.t25 || this.tag.t26).filter(e => e.visible),
          labelKey: 'valueName'
        },
        trailTime: {
          label: '审核时间',
          type:'date-time',
          rule: [
            { required: true }
          ]
        },
        ntime: {
          label: '执行时间',
          type: 'date-time',
          rule: [
            { required: true }
          ]
        },
        effect: {
          label: '执行情况',
          rule: [
            { required: true }
          ]
        },
        fileUrl: {
          label: '附件',
          type: 'file-list'
        },
      },
      loading: false
    }
  },
  props: {
    show: Boolean,
    data: Object,
    typeList: Array,
    routeClassifyId: [Number, String]
  },
  inject: ['tag'],
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/compliance/set_compliance.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          title: this.form.title,
          classifyId: this.form.classifyId,
          effect: this.form.effect,
          fileUrl: JSON.stringify(this.form.fileUrl),
          ntime: this.form.ntime,
          trailTime: this.form.trailTime,
          classify: this.form.classify,
          recivewer: this.form.recivewer,
          legality: this.form.legality || undefined
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>

