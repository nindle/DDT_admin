<template>
  <index :tag="tag"/>
</template>

<script>
import Index from './index.vue'

export default {
  name:'gm-audit_list-type-4',
  props: {
    tag: Object
  },
  components: {
    Index
  }
}
</script>