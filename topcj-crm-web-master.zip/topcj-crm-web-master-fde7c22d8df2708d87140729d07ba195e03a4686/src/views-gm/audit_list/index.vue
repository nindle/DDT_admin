<template>
  <div class="view">
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >  
      <!-- 筛选模块 -->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro> 
      </template>
    
      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData"
          :type-list="config.classifyId.options"
          :select-list.sync="selectList"
          :route-classify-id="routeClassifyId"
          @change="getTableData()"
          @edit="openPopover"
        />
      </template> 

      <!--编辑模块-->
      <template #popover>
        <edit-data
          v-if="showPopover"
          :show.sync="showPopover"
          :data="rowData"
          :type-list="config.classifyId.options"
          :route-classify-id="routeClassifyId"
          @change="getTableData()"
        />
        <review 
          v-if="showReview"
          :show.sync="showReview"
          :review-list="reviewList"
          source="t_sd_compliance"
          idKey="complianceId"
          corpKey="meta.corpId"
          reason
          deduct
          @success="getTableData()"
        />
      </template>
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import EditData from './editData'
import Review from '../../components/review/index'

export default {
  name: 'gm-audit_list',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      //修改数据
      rowData: null,
      
      screen: {
        corpId: '',
        classifyId: this.$route.meta?.type ?? ''
      },
      config: {
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增',
          click: () => { this.openPopover(null) }
        },
        corpId: {
          type:'select-corp',
          hide: () => this.screen.classifyId === 1
        },
        classifyId: {
          placeholder: '合规分类',
          type: 'select',
          options: [],
          valueKey: 'typeId',
          labelKey: 'typeName',
          hide: () => this.routeClassifyId
        },
        reviewOnline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核通过',
          click: () => { this.openReview(1) }
        },
        reviewOffline: {
          type: 'button',
          buttonType: 'primary',
          label: '审核不通过',
          click: () => { this.openReview(2) }
        },
      },
      //审核相关
      selectList: [],
      showReview: false,
      reviewList: []
    }
  },
  computed: {
    routeClassifyId() {
      return this.$route.meta?.type ?? ''
    }
  },
  props: {
    tag: Object
  },
  provide() {
    return {
      tag: this.tag
    }
  },
  components:{
    TableData,
    EditData,
    Review
  },
  methods: {
    //获取筛选数据
    async getTypeList() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/setting/get_types/43.sdcrm',
        data: {
          token: true
        }
      })

      this.config.classifyId.options.splice(0, this.config.classifyId.options.length, ...result)
    },
    //数据获取
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/compliance/get_compliance_search.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          corpId: typeof this.screen.corpId === 'number' ? this.screen.corpId : undefined,
          classifyId: typeof this.screen.classifyId === 'number' ? this.screen.classifyId : undefined,
          visible: 1
        }
      })

      this.total = result.total
      this.tableData = result.contents.map(e => {
        if(!e.fileUrl) {
          e.fileUrl = []
          return e
        }
        if(e.fileUrl.indexOf('[') === 0) {
          e.fileUrl = JSON.parse(e.fileUrl)
        }else{
          e.fileUrl = e.fileUrl.split(',').filter(e => e).map((e, i) => {
            return {
              name: '附件' + (i + 1),
              url: e
            }
          })
        }
        return e
      })

      this.loading = false
    }),
    //打开弹框
    openPopover(data) {
      this.rowData = data
      this.showPopover = true
    },
    //审核
    openReview(status) {
      this.reviewList = this.selectList.map(e => {
        return {
          url: '%CRM%/compliance/set_compliance_trial.sdcrm',
          data: {
            token: true,
            complianceId: e.id,
            status
          },
          meta: {
            corpId: e.corpId
          }
        }
      })

      this.showReview = true
    }
  },
  created(){
    this.getTypeList()
  }
}
</script>

<style scoped lang="scss">

.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
}
</style>
