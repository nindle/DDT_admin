<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title> 
      {{ editType == 'edit' ? '编辑' : editType== 'review'? '审核' : '新增' }}员工信息 
    </template>
    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <template #left>
      <el-scrollbar-pro class="left-box">
        <div
          class="item"
          @click="scrollIntoView(1, 5)"
        >员工信息</div>
        <div
          class="item"
          @click="scrollIntoView(1, 8)"
        >账号权限</div>
        <div
          class="item"
          @click="scrollIntoView(1, 10)"
          v-if="form.managerType === 3"
        >讲师信息</div>
        <div class="block"></div>
        <div
          class="item"
          @click="scrollIntoView(2, 1)"
        >基本信息</div>
        <div
          class="item"
          @click="scrollIntoView(2, 2)"
        >户籍信息</div>
        <div
          class="item"
          @click="scrollIntoView(2, 6)"
        >合同信息</div>
        <div
          class="item"
          @click="scrollIntoView(2, 3)"
        >证书信息</div>
        <div
          class="item"
          @click="scrollIntoView(2, 4)"
        >紧急联系人</div>
        <div
          class="item"
          @click="scrollIntoView(2, 7)"
        >学历信息</div>
        <div
          class="item"
          @click="scrollIntoView(2, 9)"
        >其他信息</div>
      </el-scrollbar-pro>
    </template>

    <template #right>
      <el-scrollbar-pro class="right-box">
        <el-form-pro
          class="right-form"
          :model="form"
          :config="configRight"
          ref="rightForm"
        ></el-form-pro>
      </el-scrollbar-pro>
    </template>

    <!-- 底部按钮 -->
    <template #footer>
      <el-button
        v-if="form.auditStatus == 2 || !data"
        size="small"
        @click="close"
      >取 消</el-button>

      <el-button
        v-if="form.auditStatus !== 2 && data"
        type="danger"
        size="small"
        @click="returnFn"
        :loading="loading"
      >退回修改</el-button>

      <el-button
        :type="data ? form.auditStatus !==2 ? 'success' : 'primary' : 'primary'"
        size="small"
        @click="getNewEid"
        :loading="loading"
      >
      {{ data ? form.auditStatus !==2 ? '审核通过' : '保存' : '保存'}}
      </el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data () {
    return {
      loading: false,
      form: {
        avatarPath: '',
        realName: '',
        anotherName: '',
        officeArea: '',
        isLock: this.$store.state.managerInfo.corpId !== 0 ? 1 : 0,
        joinHis: '',
        jobType: '',
        jobLevel: '',
        managerTitle: '',
        rotaPositionType: '',
        rotaType: '',
        rotaCorpId: '',
        userName: '',
        loginType: '',
        password: '',
        passwordreset: '',
        managerType: 2,
        groupId: '',
        assignedGroupIds: [],
        dataGroupId: '',
        corpId: this.$store.state.managerInfo.corpId,
        userTypeId: '',
        isLeader: false,
        videoAuditor: 0,
        articleAuditor: 0,
        roleIds: [],
        sign: '',
        introduction: '',
        cover: '',
        backgroundPath: '',
        gender: 0,
        telephone: '',
        address: '',
        politicalStatus: '',
        maritalStatus: '',
        idCardName: '',
        idNumber: '',
        frontUrl: '',
        backUrl: '',
        nation: '',
        householdType: '',
        nativePlace: '',
        registeredResidence: '',
        contractType: '',
        rotaStartTime: '',
        probationPeriod: '',
        probationStaffAppraisalUrl: '',
        planPositiveTime: '',
        positiveTime: '',
        contractLife: '',
        contractExpTime: '',
        contractUrl: '',
        ndaUrl: '',
        letterOfCommitmentUrl: '',
        rotaEndTime: '',
        certificateType: 0,
        certificateNo: '',
        certificatePath: '',
        attachmentUrl: '',
        certificateTime: '',
        certificateTopcjTime: '',
        certificateEndTime: '',
        emergencyContact: '',
        emergencyRelation: '',
        emergencyContactNumber: '',
        education: '',
        graduateSchool: '',
        major: '',
        graduationCertificateUrl: '',
        userId: '',
        agentNumber: '',
        agentNumberSec: '',
        scrmMobile: '',
        workwxDepartId: '',
        wechatAccountId: '',
        accountNumber: '',
        accountsBank: '',
        remark: '',
        photo: '',
        auditStatus: 0
      },
      config: {
        split5: {
          type: 'split',
          text: '员工信息'
        },
        avatarPath: {
          type: 'image',
          label: '头像',
        },
        realName: {
          label: '展示称呼',
          rule: [{ required: true }]
        },
        anotherName: {
          type: 'input',
          label: '昵称',
        },
        officeArea: {
          type: 'input',
          label: '办公地区',
        },
        isLock: {
          type: 'select',
          label: '启用状态',
          options: [
            { value: 0, label: '在职', disabled: this.$store.state.managerInfo.corpId !== 0 },
            { value: 1, label: '入职中' },
            { value: 2, label: '离职' }
          ]
        },
        joinHis: {
          type: 'textarea',
          label: '入离职历史'
        },
        jobType: {
          type: 'select',
          label: '用工状态',
          options: [
            { value: 1, label: '全职' },
            { value: 2, label: '兼职' },
          ]
        },
        jobLevel: {
          type: 'select',
          label: '职级',
          options: [
            { value: 1, label: '员工' },
            { value: 2, label: '管理' },
          ]
        },
        managerTitle: {
          type: 'input',
          label: '职务',
          rule: [{ required: true }]
        },
        rotaPositionType: {
          type: 'select',
          label: '岗位类型',
          options: [
            { value: 1, label: '证券分析师' },
            { value: 2, label: '证券投资顾问' },
            { value: 3, label: '合规人员' },
            { value: 4, label: '销售人员' },
            { value: 5, label: '客服人员' },
            { value: 99, label: '其他岗位' }
          ],
          rule: this.editType ? [{ required: true }] : [{ required: false }]
        },
        rotaType: {
          type: 'select',
          label: '花名册类型',
          options: [
            { value: 1, label: '花名册' },
            { value: 2, label: '财务资料' }
          ]
        },
        rotaCorpId: {
          type: 'select-corp',
          label: '公司'
        },

        split8: {
          type: 'split',
          text: '账号权限'
        },
        userName: {
          type: 'input',
          label: '账号',
          disabled: true
        },
        loginType: {
          label: '账号密码登录',
          type: 'switch',
          activeValue: 1,
          inactiveValue: 0
        },
        password: {
          label: '初始密码',
          type: 'input',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
          hide: () => this.form.loginType !== 1 || this.data
        },
        passwordreset: {
          label: '重置密码',
          type: 'input',
          hide: () => this.form.loginType !== 1 || !this.data
        },
        managerType: {
          type: 'select',
          label: '账号类型',
          options: [
            { value: 0, label: '普通账号' },
            { value: 1, label: '售后' },
            { value: 2, label: '业务' },
            { value: 3, label: '讲师' },
            { value: 4, label: '监察' }
          ]
        },
        groupId: {
          type: 'select-tree',
          options: this.$store.state.baseData.corpGroupTree,
          labelKey: 'groupName',
          childrenKey: 'groupChildren',
          valueKey: 'id',
          label: '主部门',
          filterable: true,
          change: () => {
            if (this.isEqual) {
              this.form.dataGroupId = this.form.groupId
            } else if (this.form.dataGroupId === this.form.groupId) {
              this.isEqual = true
            }
          },
          rule: [{ required: true }]
        },
        assignedGroupIds: {
          type: 'select-tree',
          options: this.$store.state.baseData.corpGroupTree,
          labelKey: 'groupName',
          childrenKey: 'groupChildren',
          valueKey: 'id',
          label: '其他部门',
          filterable: true,
          multiple: true
        },
        dataGroupId: {
          type: 'select-tree',
          options: this.$store.state.baseData.corpGroupTree,
          labelKey: 'groupName',
          childrenKey: 'groupChildren',
          valueKey: 'id',
          label: '查看权限',
          filterable: true,
          change: () => {
            this.isEqual = this.form.dataGroupId === this.form.groupId
          },
          rule: this.editType ? [{ required: true }] : [{ required: false }]
        },
        corpId: {
          type: 'select-corp',
          label: '管理范围',
          isCorp: false,
          disabled: this.$store.state.managerInfo.corpId !== 0,
          rule: this.editType ? [{ required: true }] : [{ required: false }]
        },
        userTypeId: {
          label: '推广商',
          type: 'select',
          options: this.userTypeList,
          valueKey: 'id',
          labelKey: 'resName',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
          hide: () => this.form.corpId !== 101
        },
        isLeader: {
          label: '可分配资源',
          type: 'switch'
        },
        videoAuditor: {
          label: '视频审核员',
          type: 'switch',
          activeValue: 1,
          inactiveValue: 0
        },
        articleAuditor: {
          label: '证券审核员',
          type: 'switch',
          activeValue: 1,
          inactiveValue: 0
        },
        roleIds: {
          type: 'select',
          label: '角色选择',
          options: [],
          labelKey: 'roleName',
          valueKey: 'id',
          filterable: true,
          multiple: true,
          rule: [{ required: true, message: '至少选择一个角色' }]
        },




        split10: {
          type: 'split',
          text: '讲师信息',
          hide: () => this.form.managerType !== 3,
        },
        sign: {
          type: 'input',
          label: '签名',
          hide: () => this.form.managerType !== 3,
          placeholder: '请输入签名',
          rule: [{ required: true, message: '请填写讲师的签名' }]
        },
        introduction: {
          type: 'input',
          label: '简介',
          hide: () => this.form.managerType !== 3,
          placeholder: '请输入简介',
          rule: [{ required: true, message: '请填写讲师的简介' }]
        },
        cover: {
          type: 'image',
          label: '讲师封面',
          hide: () => this.form.managerType !== 3,
          rule: [{ required: true, message: '请上传讲师的封面' }]
        },
        backgroundPath: {
          type: 'image',
          label: '背景图片',
          hide: () => this.form.managerType !== 3,
          rule: [{ required: true, message: '请上传讲师的背景图片' }]
        }
      },
      configRight: {
        split1: {
          type: 'split',
          text: '基本信息'
        },
        photo: {
          type: 'image',
          label: '员工照片',
        },
        gender: {
          type: 'select',
          label: '性别',
          options: [
            { value: 0, label: '未知' },
            { value: 1, label: '男' },
            { value: 2, label: '女' }
          ],
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        telephone: {
          type: 'input',
          label: '手机号',
          placeholder: '请输入员工手机号',
          rule: [{ required: true }]
        },
        address: {
          type: 'input',
          label: '联系地址',
          placeholder: '请输入员工联系地址',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        politicalStatus: {
          type: 'select',
          label: '政治面貌',
          options: [
            { value: 1, label: '群众' },
            { value: 2, label: '入党积极分子' },
            { value: 3, label: '预备党员' },
            { value: 4, label: '党员' },
            { value: 5, label: '团员' },
          ],
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        maritalStatus: {
          type: 'select',
          label: '婚否',
          options: [
            { value: 0, label: '否' },
            { value: 1, label: '是' }
          ]
        },


        split2: {
          type: 'split',
          text: '户籍信息'
        },
        idCardName: {
          type: 'input',
          label: '身份证姓名',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        idNumber: {
          type: 'input',
          label: '身份证号码',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
          change: e => {
            const n = Number(e.substring(16, 17) || 'X')
            if(Number.isNaN(n)) {
              if(!this.form.gender) {
                this.form.gender = 0
              }
            }else{
              this.form.gender = n % 2 ? 1 : 2
            }
          }
        },
        frontUrl: {
          type: 'image',
          label: '身份证正面',
        },
        backUrl: {
          type: 'image',
          label: '身份证反面',
        },
        nation: {
          type: 'input',
          label: '民族',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        householdType: {
          type: 'select',
          label: '户口类型',
          options: [
            { value: 1, label: '本地城镇' },
            { value: 2, label: '本地农村' },
            { value: 3, label: '外地城镇' },
            { value: 4, label: '外地农村' },
          ],
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        nativePlace: {
          type: 'input',
          label: '籍贯',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        registeredResidence: {
          type: 'input',
          label: '户籍地址',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },


        split6: {
          type: 'split',
          text: '合同信息'
        },
        contractType: {
          type: 'select',
          label: '合同类型',
          options: this.tag.t17.filter(e => e.visible),
          labelKey: 'valueName',
          valueKey: 'value',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        rotaStartTime: {
          type: 'date-time',
          label: '合同签署日期（入职时间）',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        probationPeriod: {
          type: 'number',
          label: '试用期（月）'
        },
        probationStaffAppraisalUrl: {
          type: 'image',
          label: '试用期考核表'
        },
        planPositiveTime: {
          type: 'date-time',
          label: '拟转正日期',
        },
        positiveTime: {
          type: 'date-time',
          label: '转正日期',
        },
        contractLife: {
          type: 'number',
          label: '合同期限（月）'
        },
        contractExpTime: {
          type: 'date-time',
          label: '合同到期日期',
        },
        contractUrl: {
          type: 'image',
          label: '合同协议'
        },
        ndaUrl: {
          type: 'image',
          label: '保密协议'
        },
        letterOfCommitmentUrl: {
          type: 'image',
          label: '员工手册承诺书'
        },
        rotaEndTime: {
          type: 'date-time',
          label: '离职时间'
        },


        split3: {
          type: 'split',
          text: '证书信息'
        },
        certificateType: {
          type: 'select',
          label: '证书类型',
          options: [
            { value: 0, label: '无证书' },
            { value: 1, label: '一般证券业务' },
            { value: 2, label: '证券投资咨询业务' }
          ],
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        certificateNo: {
          type: 'input',
          label: '证书编号',
          hide: () => !this.form.certificateType,
          placeholder: '请输入证书编号',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        certificatePath: {
          type: 'image',
          hide: () => !this.form.certificateType,
          label: '证书图片',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        attachmentUrl: {
          type: 'file',
          hide: () => !this.form.certificateType,
          label: '证书附件'
        },
        certificateTime: {
          type: 'date-time',
          hide: () => !this.form.certificateType,
          label: '证书取得日期'
        },
        certificateTopcjTime: {
          type: 'date-time',
          hide: () => !this.form.certificateType,
          label: '证书顶点登记日期',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        certificateEndTime: {
          type: 'date-time',
          hide: () => this.form.isLock !== 2 || !this.form.certificateType,
          label: '销证时间',
          rule: [{ required: true, message: '请填写销证时间' }]
        },


        split4: {
          type: 'split',
          text: '紧急联系人'
        },
        emergencyContact: {
          type: 'input',
          label: '紧急联系人',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        emergencyRelation: {
          type: 'input',
          label: '和本人关系',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        emergencyContactNumber: {
          type: 'input',
          label: '电话',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },


        split7: {
          type: 'split',
          text: '学历信息'
        },
        education: {
          type: 'select',
          label: '学历',
          options: [
            { value: 1, label: '小学' },
            { value: 2, label: '初中' },
            { value: 3, label: '中专' },
            { value: 4, label: '高中' },
            { value: 5, label: '大专' },
            { value: 6, label: '本科' },
            { value: 7, label: '硕士研究生' },
            { value: 8, label: '博士' },
          ],
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        graduateSchool: {
          type: 'input',
          label: '毕业院校',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        major: {
          type: 'input',
          label: '专业',
          rule: this.editType ? [{ required: true }] : [{ required: false }],
        },
        graduationCertificateUrl: {
          type: 'image',
          label: '毕业证书'
        },


        split9: {
          type: 'split',
          text: '其他信息'
        },
        userId: {
          type: 'input',
          label: '用户ID号',
          placeholder: '请输入员工授道注册ID'
        },
        agentNumber: {
          type: 'input',
          label: '分机号',
          placeholder: '请输入员工分机号'
        },
        agentNumberSec: {
          type: 'input',
          label: '备用分机号',
          placeholder: '请输入员工备用分机号'
        },
        scrmMobile: {
          type: 'input',
          label: 'SCRM手机号',
          placeholder: '9分售后通话同步scrm用',
          hide: () => this.$store.state.managerInfo.corpId !== 0 && this.$store.state.managerInfo.corpId !== 19
        },
        workwxDepartId: {
          type: 'input',
          label: '企微部门ID',
          placeholder: '请输入企业微信部门ID'
        },
        wechatAccountId: {
          type: 'select',
          label: '微营销账号',
          options: this.accountList,
          labelKey: 'name',
          valueKey: 'wechatAccountId'
        },
        accountNumber: {
          type: 'input',
          label: '银行卡号',
        },
        accountsBank: {
          type: 'input',
          label: '开户行名称',
        },
        remark: {
          type: 'textarea',
          label: '备注',
        },
      },
      isEqual: true
    }
  },
  inject: ['tag'],
  props: {
    show: Boolean,
    data: Object,
    corpRoleList: Array,
    accountList: Array,
    allRole: Array,
    userTypeList: Array,
    editType: String,
  },
  methods: {
    init () {
      this.config.roleIds.options.splice(0, this.config.roleIds.options.length, ...this.allRole)
      let group = []
      const sortGourp = function (data, lv) {
        for (let i in data) {
          if (!data[i]) {
            return
          }

          let e = data[i]
          group.push({
            id: e.id,
            name: `${''.padStart(lv, '-')}${e.groupName}`
          })
          if (e.groupChildren && e.groupChildren.length) {
            sortGourp(e.groupChildren, lv + 1)
          }
        }
      }

      sortGourp(this.$store.state.baseData.corpGroupTree, 0)

      if (!this.data) {
        return
      }
      this.getManager(this.data.id)
    },
    async getManager (id) {
      let { result } = await this.$http({
        url: '%CRM%/manager/get_manager.sdcrm',
        data: {
          token: true,
          id
        }
      })

      this.form = result
      this.form.rotaStartTime = result.rotaStartTime ? new Date(result.rotaStartTime).getTime() : null
      this.form.planPositiveTime = result.planPositiveTime ? new Date(result.planPositiveTime).getTime() : null
      this.form.positiveTime = result.positiveTime ? new Date(result.positiveTime).getTime() : null
      this.form.contractExpTime = result.contractExpTime ? new Date(result.contractExpTime).getTime() : null
      this.form.rotaEndTime = result.rotaEndTime ? new Date(result.rotaEndTime).getTime() : null
      this.form.certificateTime = result.certificateTime ? new Date(result.certificateTime).getTime() : null
      this.form.certificateTopcjTime = result.certificateTopcjTime ? new Date(result.certificateTopcjTime).getTime() : null
      this.form.certificateEndTime = result.certificateEndTime ? new Date(result.certificateEndTime).getTime() : null

      this.form.secondTrialCorp = result.secondTrialCorp?.split(',').map(e => Number(e)) ?? []
      this.form.assignedGroupIds = result.assignedGroupIds?.filter(e => e !== result.groupId) ?? []

      this.isEqual = result.groupId === result.dataGroupId
    },
    async getNewEid () {
      if (this.data && this.data.userName) {
        this.submit(2)
        return
      }
      let { result } = await this.$http({
        url: '%CRM%/manager/get_new_eid.sdcrm',
        data: {
          token: true
        }
      })

      this.form.userName = result.eid
      this.submit(0)
    },
    close () {
      this.$emit('update:show', false)
    },
    submit: throttle(async function (auditStatus) {
      if (!(await this.$refs.form.check())) return
      if (!(await this.$refs.rightForm.check())) return

      let accessKey = null
      if (this.form.wechatAccountId) {
        for (let i in this.accountList) {
          let e = this.accountList[i]
          if (e.wechatAccountId === this.form.wechatAccountId) {
            accessKey = e.secret
            break
          }
        }
      }
      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/manager/manager_edit.sdcrm',
        data: {
          token: true,
          id: this.form.id ? this.form.id : 0,

          avatarPath: this.form.avatarPath ? this.form.avatarPath : null,
          realName: this.form.realName,
          anotherName: this.form.anotherName,
          officeArea: this.form.officeArea,
          isLock: typeof this.form.isLock === 'number' ? this.form.isLock : 1,
          joinHis: this.form.joinHis,
          jobType: typeof this.form.jobType === 'number' ? this.form.jobType : 1,
          jobLevel: typeof this.form.jobLevel === 'number' ? this.form.jobLevel : 1,
          managerTitle: this.form.managerTitle,
          rotaPositionType: this.form.rotaPositionType || null,
          rotaType: this.form.rotaType || null,
          rotaCorpId: typeof this.form.rotaCorpId === 'number' ? this.form.rotaCorpId : null,
          userName: this.form.userName,
          loginType: this.form.loginType,
          password: this.form.passwordreset || this.form.password || '',
          managerType: typeof this.form.managerType === 'number' ? this.form.managerType : 2,
          groupId: this.form.groupId,
          assignedGroupIds: this.form.assignedGroupIds,
          dataGroupId: this.form.dataGroupId,
          corpId: this.form.corpId,
          photo: this.form.photo,
          userTypeId: this.form.userTypeId,
          isLeader: this.form.isLeader,
          videoAuditor: this.form.videoAuditor,
          articleAuditor: this.form.articleAuditor,
          roleIds: this.form.roleIds,
          sign: this.form.sign,
          introduction: this.form.introduction,
          cover: this.form.cover,
          backgroundPath: this.form.backgroundPath,
          gender: typeof this.form.gender === 'number' ? this.form.gender : 0,
          telephone: this.form.telephone,
          address: this.form.address,
          politicalStatus: typeof this.form.politicalStatus === 'number' ? this.form.politicalStatus : null,
          maritalStatus: typeof this.form.maritalStatus === 'number' ? this.form.maritalStatus : null,
          idCardName: this.form.idCardName,
          idNumber: this.form.idNumber,
          frontUrl: this.form.frontUrl,
          backUrl: this.form.backUrl,
          nation: this.form.nation,
          householdType: typeof this.form.householdType === 'number' ? this.form.householdType : null,
          nativePlace: this.form.nativePlace,
          registeredResidence: this.form.registeredResidence,
          contractType: typeof this.form.contractType === 'number' ? this.form.contractType : null,
          rotaStartTime: this.form.rotaStartTime ? this.form.rotaStartTime : null,
          probationPeriod: this.form.probationPeriod || null,
          probationStaffAppraisalUrl: this.form.probationStaffAppraisalUrl,
          planPositiveTime: this.form.planPositiveTime ? this.form.planPositiveTime : null,
          positiveTime: this.form.positiveTime ? this.form.positiveTime : null,
          contractLife: this.form.contractLife || null,
          contractExpTime: this.form.contractExpTime ? this.form.contractExpTime : null,
          contractUrl: this.form.contractUrl,
          ndaUrl: this.form.ndaUrl,
          letterOfCommitmentUrl: this.form.letterOfCommitmentUrl,
          rotaEndTime: this.form.rotaEndTime || null,
          certificateType: typeof this.form.certificateType === 'number' ? this.form.certificateType : 0,
          certificateNo: this.form.certificateNo,
          certificatePath: this.form.certificatePath,
          attachmentUrl: this.form.attachmentUrl,
          certificateTime: this.form.certificateTime || null,
          certificateTopcjTime: this.form.certificateTopcjTime || null,
          certificateEndTime: this.form.certificateEndTime || null,
          emergencyContact: this.form.emergencyContact,
          emergencyRelation: this.form.emergencyRelation,
          emergencyContactNumber: this.form.emergencyContactNumber,
          education: typeof this.form.education === 'number' ? this.form.education : null,
          graduateSchool: this.form.graduateSchool,
          major: this.form.major,
          graduationCertificateUrl: this.form.graduationCertificateUrl,
          userId: this.form.userId,
          agentNumber: this.data ? this.form.agentNumber === '' ? 0 : this.form.agentNumber : null,
          agentNumberSec: this.form.agentNumberSec,
          scrmMobile: this.form.scrmMobile,
          workwxDepartId: this.form.workwxDepartId,
          wechatAccountId: this.form.wechatAccountId,
          accountNumber: this.form.accountNumber,
          accountsBank: this.form.accountsBank,
          remark: this.form.remark,

          weixin: this.form.weixin,
          accessKey: this.form.accessKey ? this.form.accessKey : accessKey,
          eid: this.form.userName,

          rotaDepartment: this.form.rotaDepartment ? this.form.rotaDepartment : null,
          secondTrialCorp: this.form.secondTrialCorp ? this.form.secondTrialCorp.join(',') : null,
          auditStatus: auditStatus
        }
      })

      if (code !== 8200) {
        this.$message.error('保存失败：' + msg || errmsg)
        return
      }
      if (auditStatus !== 3) {
        this.$message.success('保存成功')
      }
      this.$emit('change')
      this.close()
    }),
    scrollIntoView (form, id) {
      if (form === 1) {
        this.$refs.form.scrollIntoView(`split${id}`)
      } else {
        this.$refs.rightForm.scrollIntoView(`split${id}`)
      }
    },
    async returnFn () {
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/manager/send_improve_data_msg.sdcrm',
        data: {
          token: true,
          managerId: this.form.id
        }
      })

      if (code !== 8200) {
        this.$message.error('发送失败' + msg || errmsg)
        return
      }
      await this.submit(3)
      this.$message.success('已退回，请让入职员工补充信息')
      this.close()
      this.$emit('change')
    }
  },
  created () {
    this.init()
  }
}
</script>
<style lang="scss" scoped>
.right-box {
  margin-top: 54px;
  height: calc(100% - 54px);
  .right-form {
    width: 620px;
    padding: 20px;
    box-sizing: border-box;
  }
}
.left-box {
  width: 100px;
  .item {
    &:first-child {
      padding-top: 54px;
    }
    padding: 6px 12px;
    cursor: pointer;
  }
  .block {
    height: 54px;
  }
}
</style>
