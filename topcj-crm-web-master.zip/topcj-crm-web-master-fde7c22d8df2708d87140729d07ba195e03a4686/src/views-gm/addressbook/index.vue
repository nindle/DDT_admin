<template>
  <div class="view">
    <div class="box">
      <el-layout-pro class="left-box">
        <!-- 筛选 -->
        <template #screen>
          <el-screen-pro
            :model="screen"
            :config="config"
          ></el-screen-pro>
        </template>
        <!-- 列表 -->
        <template #scroll>
          <el-tree 
            class="tree"
            draggable
            :data="groupList"
            :props="defaultProps"
            node-key="id"
            :default-expanded-keys="[1]"
            :highlight-current="true"
            :expand-on-click-node="false"
            :filter-node-method="filterNode"
            @node-click="handleNodeClick"
            @node-contextmenu="handleNodeMenu"
            @node-drop="handleDrop"
            ref="tree"
          ></el-tree>
        </template>

        <!-- 弹窗 -->
        <template #popover>
          <edit-name 
            v-if="showPopover"
            :show.sync="showPopover"
            :data="popoverData"
            :type="nameType"
            :nodes.sync="nodes"
            @success="moveEdit"
          />
        </template>
      </el-layout-pro>
      <right-box 
        ref="right"
        :group-list="groupList"
        :keyword="screen.keyword"
      />
    </div>
  </div>
</template>
<script>
// import { throttle } from '../../assets/js/tool'
import RightBox from './rightBox.vue'
import EditName from './editName.vue'

export default {
  name: 'gm-addressbook',
  data() {
    return {
      //仅提供绑定企微功能
      onlyBindQywx: this.$store.state.managerInfo.roleList.findIndex(e => e.id === 369) !== -1,
      // 筛选
      screen: {
        keyword: ''
      },
      config: {
        keyword: {
          type: 'input',
          placeholder: '输入部门名称/员工名称',
          change: () => {
            this.$refs.right.search(this.screen.keyword)
            this.$refs.tree.filter(this.screen.keyword)
          }
        },
        split: {
          type: 'split'
        },
        all: {
          type: 'button',
          buttonType: 'primary',
          label: '所有员工',
          click: () => { 
            this.screen.keyword = ''
            this.$refs.right.groupId = ''
            this.$refs.right.getTableData()
            this.$refs.tree.filter(this.screen.keyword)
            this.$refs.right.search()
          }
        }
      },
      defaultProps: {
        children: 'groupChildren',
        label: 'groupName',
      },
      // 弹窗
      showPopover: false,
      nameType: '',
      popoverData: {},
      nodes: {}
    }
  },
  computed: {
    groupList() {
      return this.$store.state.baseData.corpGroupTree
    },
    parentGmlistId() {
      return this.$store.state.baseData.groupList[0].id
    }
  },
  props: {
    tag: Object
  },
  provide() {
    return {
      tag: this.tag,
      onlyBindQywx: this.onlyBindQywx
    }
  },
  methods: {
    // 树节点 单击
    handleNodeClick(data) {
      this.$refs.right.groupId = data.id
      this.$refs.right.getTableData(true)

      this.$contextmenu({})
    },
    // 树节点 鼠标右键点击
    handleNodeMenu(event,node,nodes) {
      if(this.onlyBindQywx) return

      if(this.parentGmlistId === node.id) {
        this.$contextmenu({
          event,
          menu: [
            {
              icon: 'el-icon-plus',
              title: '添加子部门',
              handler: () => {
                this.popoverData = node
                this.nameType = 'add'
                this.showPopover = true
              }
            }
          ]
        })
        return
      }

      this.$contextmenu({
        event,
        menu: [
          {
            icon: 'el-icon-plus',
            title: '添加子部门',
            handler: () => {
              this.popoverData = node
              this.nameType = 'add'
              this.showPopover = true
            }
          },
          {
            icon: 'el-icon-edit',
            title: '修改部门名称',
            handler: () => {
              this.popoverData = node
              this.nodes = nodes
              this.nameType = 'edit',
              this.showPopover = true
            }
          },
          {
            icon: 'el-icon-delete',
            title: '删除部门',
            handler: () => { this.deleteGroup(node) }
          }
        ]
      })
    },
    // 树节点删除
    async deleteGroup(node) {
      if(node.managerList.length || node.groupChildren.length) {
        this.$message.error('删除前请先确定该部门下无人员或部门')
        return
      }

      let { code,msg,errmsg } = await this.$http({
        url: '%CRM%/manager/group_delete.sdcrm',
        data: {
          token: true,
          id: node.id
        }
      })

      if(code !== 8200) {
        this.$message.error('删除失败'+msg || errmsg)
        return
      }

      this.$message.success('删除成功')
      this.$store.dispatch('getManagerList')
      this.$refs.right.groupId = ''
      this.$refs.right.getTableData(true)
    },
    findParentData(id,groupList = this.groupList){
      for(let item of groupList){
        if(item.id === id){
          return item
        }else{
          let res = this.findParentData(id,item.groupChildren)
          if(res) return res 
        }
      }
    },
    // 树节点拖拽成功完成时
    handleDrop(draggingNode,dropNode,type) { 
      if(dropNode.data.id === this.parentGmlistId) {
        this.$store.dispatch('getManagerList')
        this.$message.error('无法操作')
        return
      }

      let sort = 10000
      let parentData = this.findParentData(dropNode.data.parentId)
      let data = {
        id: draggingNode.data.id,
        groupName: draggingNode.data.groupName,
        parentId: dropNode.data.parentId,
        corpId: draggingNode.data.corpId,
        isshow: true
      }
      let nodeIndex = parentData.groupChildren.findIndex(e => e.id === dropNode.data.id)

      if(type === 'after') {
        if(nodeIndex+2 === parentData.groupChildren.length) {
          data.groupSort = dropNode.data.groupSort - 100
        } else {
          data.groupSort = parseInt((dropNode.data.groupSort+parentData.groupChildren[nodeIndex+2].groupSort)/2)
        }
        draggingNode.data.groupSort = sort
      } else if(type === 'before') {
        if(nodeIndex-1 === 0) {
          data.groupSort = dropNode.data.groupSort + 100
        } else {
          data.groupSort = parseInt((dropNode.data.groupSort+parentData.groupChildren[nodeIndex-2].groupSort)/2)
        }
        draggingNode.data.groupSort = sort
      } else if(type === 'inner') {
        data.parentId = dropNode.data.id
        data.groupSort = sort
      }

      this.moveEdit(data,{},'drop')

    },
    // 修改部门
    async moveEdit(data,form,type) {
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/manager/group_edit.sdcrm',
        data: {
          token: true,
          id:type === 'add' ? null : data.id,
          parentId: type === 'edit' ? form.parent : (type === 'add' ? data.id : data.parentId),
          groupName:type === 'drop' ? data.groupName : form.name,
          groupSort:type === 'add' ? 10000 : data.groupSort,
          isshow: type === 'edit' ? data.isshow : true,
          status: true,
          managerId: this.$store.state.managerInfo.id,
          corpId: data.corpId,
        }
      })

      if(code !==8200){
        this.$message.error(msg || errmsg)
        this.$store.dispatch('getManagerList')
        return
      }

      if(type === 'add') {
        this.$message.success('添加成功')
        this.$store.dispatch('getManagerList')
        return
      } else if(type === 'edit') {
        this.$message.success('修改成功')
        this.nodes.data.groupName = form.name
      }
    },
    // 部门列表筛选
    filterNode(value,data) {
      if(!value) return true
      return String(data.groupName).includes(value)
    }
  },
  components: {
    RightBox,
    EditName,
  },
}
</script>
<style lang="scss" scoped>
.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
    display: flex;
    .left-box {
      width: 386px;
      .tree {
        padding: 24px;
      }
    }
    .right-box {
      width: calc(100% - 386px);
    }
  }
}
</style>