<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>
      {{type === 'add' ? '新增' : '修改'}}部门名称
    </template>
    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      form: {
        name: this.type === 'edit'?this.data.groupName : '',
        parent: this.data.parentId
      },
      config: {
        parent: {
          type: 'select-group',
          label: '父级部门',
          hide: () => this.type !== 'edit',
          rule: [
            { required: true, message: '请选择父级部门' }
          ]
        },
        name: {
          type: 'input',
          label: '名称'
        }
      }
    }
  },
  props: {
    show: Boolean,
    data: Object,
    type: String,
    nodes: Object
  },
  computed: {
    parentList() {
      return this.$store.state.managerInfo.corpId ? this.$store.state.baseData.groupList.filter(e=>e.corpId === this.$store.state.managerInfo.corpId) : this.$store.state.baseData.groupList
    }
  },
  methods: {
     //提交
    submit: throttle(async function(){
      if(!await this.$refs.form.check()) return

      // this.loading = true

      // let { code, errmsg, msg } = await this.$http({
      //   url: '%CRM%/manager/group_edit.sdcrm',
      //   data: {
      //     token: true,
      //     id: this.type === 'edit' ? this.data.id : null,
      //     parentId: this.type === 'edit' ? this.form.parentId : this.data.id,
      //     groupName: this.form.name,
      //     groupSort: this.type === 'edit' ? this.data.groupSort : 10000,
      //     isshow: this.type === 'edit' ? this.data.isshow : true,
      //     status: true,
      //     managerId: this.$store.state.managerInfo.id,
      //     corpId: this.data.corpId,
      //   }
      // })
      
      // this.loading = false

      // if(code !== 8200) {
      //   this.$message.error(`保存失败：${errmsg || msg}`)
      //   return
      // }
      
      // this.$message.success('保存成功')
      // if(this.type === 'add') {
      //   this.$store.dispatch('getManagerList')
      //   this.close()
      //   return
      // }
      // this.nodes.data.groupName = this.form.name
      // this.$emit('update:nodes',this.nodes)
      this.$emit('success',this.data,this.form,this.type)
      this.close()
    }),
    close(){
      this.$emit('update:show', false)
    }
  },
  created() {
    this.config.parent.options = this.parentList
  },
}
</script>
<style lang="scss" scoped>

</style>