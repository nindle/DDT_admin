<template>
  <el-dialog-pro 
    width="880px"
    @close="close"
  >
    <!-- 标题 -->
    <template #title>绑定企业微信</template>

    <el-table-pro
      :head="head"
      :data="tableData"
    ></el-table-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        type="primary"
        size="small"
        @click="addData"
        style="float: left;"
      >添 加</el-button>

      <el-button 
        size="small"
        @click="close"
      >关 闭</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      qywxList: [],
      head: [
        {
          key: 'qyWx',
          label: '企业微信',
          edit: 'select',
          editItem: row => {
            return {
              label: '企业微信',
              options: this.qywxList,
              labelKey: 'wxName',
              valueKey: 'qyWx',
              disabled: this.qywxList.find(e => e.qyWx === row.qyWx)?.disabled ?? false
            }
          }
        },
        {
          key: 'qyUserId',
          label: '企业微信账号',
          edit: 'input',
          editItem: row => {
            return {
              label: '企业微信账号',
              disabled: this.qywxList.find(e => e.qyWx === row.qyWx)?.disabled ?? false,
            }
          }
        },
        {
          key: 'resDepartId',
          label: '部门ID',
          edit: 'input',
          editItem: row => {
            return {
              label: '部门ID',
              disabled: this.qywxList.find(e => e.qyWx === row.qyWx)?.disabled ?? false
            }
          }
        },
        {
          key: 'scrmMobile',
          label: 'SCRM工作手机号',
          edit: 'input',
          editItem: row => {
            return {
              label: 'SCRM工作手机号',
              disabled: this.qywxList.find(e => e.qyWx === row.qyWx)?.disabled ?? false
            }
          }
        },
        {
          key: 'save',
          label: '',
          button: {
            type: 'text',
            label: '保存',
            icon: 'el-icon-document-checked',
            size: 'small',
            click: this.submit,
            disabled: row => row.save === row.qyWx + ',' + row.qyUserId + ',' + row.resDepartId + ',' + row.scrmMobile || !row.qyWx || !row.qyUserId
          },
          width: 44
        },
        {
          key: 'status',
          label: '状态',
          edit: 'switch',
          editItem: row => {
            return {
              activeValue: 1,
              inactiveValue: 0,
              disabled: (this.qywxList.find(e => e.qyWx === row.qyWx)?.disabled ?? false) || !row.id
            }
          },
          change: this.setStatus,
          width: 40
        }
      ],
      tableData: [],
    }
  },
  props: {
    data: Object
  },
  methods: {
    async getQywxList(){
      let { result } = await this.$http({
        url:'%CRM%/setting/get_qy_wx.sdcrm',
        mode:'get',
        data:{
          token:true,
        },
      })
      this.qywxList.splice(0, 0, ...result.map(e => {
        return {
          ...e,
          disabled: !e.corpId
        }
      }))
    },
    // 获取个人绑定的企业微信
    async getData(){
      let { result } = await this.$http({
        url:'%CRM%/manager/get_manager_qywx_list.sdcrm',
        data:{
          token: true,
          managerId: this.data.id
        },
      })

      this.tableData = result.map(e => {
        e.qyWx = e.qyWx ?? ''
        e.qyUserId = e.qyUserId ?? ''
        e.resDepartId = e.resDepartId ?? ''
        e.scrmMobile = e.scrmMobile ?? ''
        return {
          ...e,
          save: e.qyWx + ',' + e.qyUserId + ',' + e.resDepartId + ',' + e.scrmMobile,
        }
      })
    },
    //新增一条数据
    addData() {
      this.tableData.push({
        qyWx: '',
        qyUserId: '',
        resDepartId: '',
        scrmMobile: '',
        status: 1,
        save: ',,,',
      })
    },
    //提交
    submit: throttle(async function(item){
      if(!item.qyUserId) {
        this.$message.warning('企业微信账号不能为空')
        return
      }
      if(!item.qyWx) {
        this.$message.warning('企业微信不能为空')
        return
      }

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/manager/manager_qywx_edit.sdcrm',
        data: {
          token: true,
          id: item.id,
          qyWx: item.qyWx,
          managerId: this.data.id,
          qyUserId: item.qyUserId,
          resDepartId: item.resDepartId,
          scrmMobile: item.scrmMobile,
        }
      })
            
      if(code !== 8200) {
        this.$message.error('保存失败：'+ msg || errmsg)
        return
      }

      await this.getData()
      this.$message.success('保存成功')
    }),
    //设置状态
    setStatus: throttle(async function(item){
      if(!item.id) {
        this.$message.warning('请先保存')
        return
      }

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/manager/set_manager_qywx_status.sdcrm',
        data: {
          token: true,
          id: item.id,
          status: item.status
        }
      })
            
      if(code !== 8200) {
        this.$message.error('设置失败：'+ msg || errmsg)
        item.status = item.status ? 0 : 1
        return
      }
      
      this.$message.success('设置成功')
    }),
    close(){
      this.$emit('update:show', false)
    }
  },
  created() {
    this.getQywxList()
    this.getData()
  },
}
</script>