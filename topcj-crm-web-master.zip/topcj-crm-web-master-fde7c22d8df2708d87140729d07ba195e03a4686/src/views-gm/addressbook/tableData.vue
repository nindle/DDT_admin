<template>
  <el-table-pro :head="head" :data="data" @selection-change="$emit('update:select-list', $event)">
    <template #body-orgQwStatus="{ row }">
      <i v-if="row.orgQwStatus" class="qywx"></i>
      <i v-else class="block"></i>
      <i v-if="row.isLeader" class="el-icon-user-solid"></i>
      <i v-else class="block"></i>
    </template>
    <template #body-operation="{ row }">
      <el-button 
        type="primary" 
        size="small"
        @click="changeFn(row, 'review')" 
        v-if="row.auditStatus == 1"
      >
        审核
      </el-button>
      
      <el-button 
        type="success" 
        size="small" 
        v-if="[0, 3].includes(row.auditStatus)" 
        @click="sendFn(row.id)"
      >
        发送链接
      </el-button>

      <el-button 
        type="info" 
        size="small" 
        @click="changeFn(row, 'edit')" 
        v-if="row.auditStatus == 2"
      >
        编辑
      </el-button>
    </template>

    <template #body-back="{ row }">
      <el-popconfirm
        title="确定删除该员工吗？"
        @confirm="backData(row)"
        v-if="[0,1,3].includes(row.auditStatus)" 
      >
        <template #reference>
          <el-button 
            type="danger" 
            size="small" 
          >删除</el-button>
        </template>
      </el-popconfirm>
    </template>
  </el-table-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'

export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14,
          hide: () => this.onlyBindQywx
        },
        {
          key: 'id',
          label: 'ID',
          minWidth: 42
        },
        {
          key: 'orgQwStatus',
          width: 36
        },
        {
          key: 'realName',
          label: '姓名',
          minWidth: 70
        },
        {
          key: 'idCardName',
          label: '员工',
          minWidth: 70
        },
        {
          key: 'anotherName',
          label: '昵称',
          minWidth: 70
        },
        {
          key: 'groupId',
          label: '部门',
          minWidth: 120,
          format: {
            list: this.$store.state.baseData.groupList,
            value: 'groupName',
            key: 'id'
          }
        },
        {
          key: 'isLock',
          label: '状态',
          minWidth: 42,
          format: {
            '0': '在职',
            '1': '入职中',
            '2': '离职',
            '3': '已冻结'
          }
        },
        {
          key: 'auditStatus',
          label: '操作状态',
          minWidth: 56,
          format: {
            '0': '待发送',
            '1': '待审核',
            '2': '',
            '3': '待完善'
          },
          tag: {
            '0': 'success',
            '1': 'primary',
            '2': '',
            '3': 'warning',
          }
        },
        {
          key: 'edphone',
          label: '手机串号',
          width: 74,
          button: {
            type: 'text',
            icon: 'el-icon-mobile-phone',
            label: '查看/修改',
            click: e => {
              this.$emit('edphone', e)
            }
          },
          hide: () => this.onlyBindQywx
        },
        {
          key: 'qywx',
          label: '绑定企微',
          width: 70,
          button: {
            type: 'text',
            icon: 'el-icon-connection',
            label: '绑定企微',
            click: e => {
              this.$emit('qywx', e)
            }
          }
        },
        {
          key: 'operation',
          label: '操作',
          width: 80,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click: e => {
              this.$emit('edit', e)
            }
          },
          fixed: 'right',
          hide: () => this.onlyBindQywx
        },
        {
          key: 'back',
          label: '',
          width: 56,
          fixed: 'right',
          hide: () => this.onlyBindQywx
        }
      ]
    }
  },
  props: {
    data: Array
  },
  methods: {
    changeFn(e, name) {
      this.$emit('edit', { data: e, key: name })
    },
    sendFn: throttle(async function(e) {
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/manager/send_improve_data_msg.sdcrm',
        data: {
          token: true,
          managerId: e
        }
      })

      if (code !== 8200) {
        this.$message.error('发送失败' + msg || errmsg)
        return
      }

      this.$message.success('发送成功')
      this.$emit('change')
    }),
    backData: throttle(async function(row) {
      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/manager/manager_delete.sdcrm',
        data: {
          token: true,
          id: row.id
        }
      })

      if (code !== 8200) {
        this.$message.error('撤回失败' + msg || errmsg)
        return
      }

      this.$message.success('撤回成功')
      this.$emit('change')
    })
  },
  inject: ['onlyBindQywx']
}
</script>
<style lang="scss" scoped>
@import '../../assets/css/common.scss';

.qywx {
  display: inline-block;
  vertical-align: middle;
  width: 18px;
  height: 18px;
  @include image(qywx, center/100% no-repeat);
}
.block {
  display: inline-block;
  vertical-align: middle;
  width: 18px;
  height: 18px;
}
.el-icon-user-solid {
  position: relative;
  display: inline-block;
  vertical-align: middle;
  width: 14px;
  height: 14px;
  padding: 2px;
  color: #3089ff;
  left: 10px;
}
</style>
