<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>手机串号</template>
    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    >
      <template #phone="{ model,index }">
        <div class="phone-form">
          <el-input-pro 
            :model="model[index]"
            k="imei"
            :item="{placeholder: '绑定手机号'}"
          />
          <el-select-pro
            :model="model[index]"
            k="type"
            :item="{options: typeList}"
          ></el-select-pro>
          <div>
            <span style="margin-right:10px">使用状态</span>
            <el-switch-pro 
              :model="model[index]"
              k="status"
              :item="{disabled: false}"
            ></el-switch-pro>
          </div>
          <el-button
            type="text"
            size="small"
            icon="el-icon-delete"
            style="margin-left: 8px"
            @click="delet(index,model[index].id)"
          >删除</el-button>
        </div>
        
      </template>
    </el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import ElInputPro from '../../plugin/el-form-pro/input'
import ElSelectPro from '../../plugin/el-form-pro/select'
import ElSwitchPro from '../../plugin/el-form-pro/switch'
export default {
  data() {
    return {
      loading: false,
      form: {
        phone: []
      },
      config: {
        phone: {
          each: true,
        },
        add: {
          type: 'button',
          buttonType: 'primary',
          buttonLabel: '添加',
          click: () => { 
            this.form.phone.push({
              imei: '',
              type: 0,
              status: 0
            })
           }
        }
      },
      typeList:[
        {
          value:0,
          label:'业务类'
        },
        {
          value:1,
          label:'客诉专线'
        }
      ],
    }
  },
  props: {
    data: Object
  },
  methods: {
    async getTagList(e){
      let { result } = await this.$http({
        url:'%CRM%/manager/get_manager_imei_list.sdcrm',
        data:{
          token:true,
          managerId:e.id
        },
      })
      this.form.phone = result
      this.form.phone.map(e=>e.status = Boolean(e.status))
      
    },
    //提交
    submit: throttle(async function(){
      let rule = 0

      this.form.phone.forEach(e => {
        if(!e.imei || typeof e.type !== 'number') {
          rule++
        }
      })

      if(rule) {
        this.$message.warning("手机号或者业务不能为空。")
        return
      }
      this.loading = true

      let all = []

      this.form.phone.forEach(item => {
        all.push({
          url: '%CRM%/manager/manager_imei_edit.sdcrm',
          data: {
            token: true,
            managerId: this.data.id,
            id: item.id,
            imei: item.imei,
            status: Number(item.status),
            type: item.type
          }
        })
      })

      let data = await this.$http({
        mode: 'relay',
        all
      })

      this.loading = false

      let succ = 0
      let err = 0
      data.forEach(e => {
        if(e.code === 8200){
          succ++
          return
        }
        err++
      })

      if(err) {
        this.$message.error(`保存成功${succ}，保存失败${err}个`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    async delet(i,id){
      if(!id){
        this.form.phone.splice(i,1)
        return
      }
      let { code,msg,errmsg } = await this.$http({
        url:'%CRM%/manager/manager_imei_delete.sdcrm',
        data:{
          token:true,
          id:id
        },
      })

      if(code === 8200){
        this.form.phone.splice(i,1)
        this.$message.success('删除成功')
      }else{
        this.$message.error(msg ? msg : errmsg)
      }
    },
    close(){
      this.$emit('update:show', false)
    }
  },
  components: { 
    ElInputPro,
    ElSelectPro,
    ElSwitchPro
  },
  created() {
    this.getTagList(this.data)
  },
}
</script>
<style lang="scss" scoped>
.phone-form {
  display: flex;
  justify-content: space-between;
  /deep/ {
    .el-input {
      width: calc(((100% - 43px) / 3) + 40px);
      .el-input__inner {
        width: 100%;
      }
    }

    .el-select {
      width: calc(((100% - 43px) / 3) - 40px);
      .el-input {
        width: 100%;
        .el-input__inner {
          width: 100%;
        }
      }
    }
  }
}
</style>