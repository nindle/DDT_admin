<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>分公司角色</template>
    <!-- 表单内容 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      form: {
        role: this.roleList
      },
      config: {
        role: {
          type: 'check-list',
          label: '角色选择',
          options: this.allRole,
          labelKey: 'roleName',
          valueKey: 'id',
          rule: [
            { required: true, message: '至少选择一个角色' }
          ]
        }
      }
    }
  },
  props: {
    show: Boolean,
    roleList: Array,
    allRole: Array,
  },
  methods: {
     //提交
    submit: throttle(async function(){
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, errmsg, msg } = await this.$http({
        url: '%CRM%/role/set_corp_allow_roles.sdcrm',
        data: {
          token: true,
          roleIds: this.form.role
        }
      })
      
      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close(){
      this.$emit('update:show', false)
    }
  },
}
</script>
<style lang="scss" scoped>

</style>