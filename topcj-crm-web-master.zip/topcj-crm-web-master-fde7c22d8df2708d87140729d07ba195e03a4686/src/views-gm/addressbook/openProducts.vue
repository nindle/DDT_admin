<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title>开通套餐</template>

    <!-- 表单信息 -->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>

    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >开 通</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      form: {
        packageId: ''
      },
      config: {
        packageId: {
          type: 'select',
          label: '套餐',
          options: [],
          labelKey: 'name',
          valueKey: 'id',
          filterable: true,
          rule: [
            { required: true}
          ]
        }
      },

    }
  },
  props: {
    show: Boolean,
    data: Array
  },
  methods: {
    async getProductList() {
      let { result } = await this.$http({
        url: '%CRM%/package/get_package_list.sdcrm',
        data: {
          token: true,
          status: 1,
          show_status: 0
        }
      })

      this.config.packageId.options = result
    },
    //提交
    submit: throttle(async function(){
      if(!await this.$refs.form.check()) return

      let managerIds = this.data.map(e => e.id)

      let { code,msg,errmsg } = await this.$http({
        url: '%CRM%/offline/test_notify_callback.sdcrm',
        data: {
          token: true,
          managerIds,
          packageId: this.form.packageId
        }
      })

      if(code !== 8200) {
        this.$message.error('保存失败'+msg || errmsg)
        return
      }

      this.$message.success('保存成功,账号为手机号，密码为手机号后6位')
      this.$emit('change')
      this.close()
    }),
    close(){
      this.$emit('update:show', false)
    }
  },
  created() {
    this.getProductList()
  }
}
</script>