<template>
  <el-layout-pro class="right-box" :loading="loading" :total="total" :page-num.sync="pageNum" :page-size.sync="pageSize">
    <!--筛选模块-->
    <template #screen>
      <el-screen-pro 
        :model="screen" 
        :config="config" 
        @change="getTableData(true)"
        :auto-change="false"
        ref="screen"
      ></el-screen-pro>
    </template>
    <!--表格模块-->
    <template #table>
      <table-data :data="tableData" :select-list.sync="selectList" @edit="popover" @edphone="phonePopover" @qywx="qywxPopover" @change="getTableData()" />
    </template>

    <!-- 弹窗 -->
    <template #popover>
      <edit-data
        v-if="showPopover"
        :show.sync="showPopover"
        :data="popoverData"
        :account-list="accountList"
        :user-type-list="userTypeList"
        :all-role="roleList"
        :edit-type="editType"
        @change="getTableData()"
      />

      <corp-role v-if="showCorpRole" :show.sync="showCorpRole" :all-role="roleList" />

      <bind-phone v-if="showPhone" :show.sync="showPhone" :data="phoneData" />
      <bind-qywx v-if="showQywx" :show.sync="showQywx" :data="qywxData" />
      <open-products v-if="showProduct" :show.sync="showProduct" :data="selectList" />
    </template>
  </el-layout-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
import EditData from './editData.vue'
import TableData from './tableData.vue'
import CorpRole from './corpRole.vue'
import BindPhone from './bindPhone.vue'
import BindQywx from './bindQywx.vue'
import OpenProducts from './openProducts.vue'
export default {
  data() {
    return {
      //加载状态
      loading: false,
      //分页
      pageNum: 1,
      pageSize: 10,
      // 筛选
      screen: {
        isLock: 0
      },
      config: {
        isLock: {
          type: 'select',
          options: [
            { value: 0, label: '在职' },
            { value: 1, label: '入职中' },
            { value: 2, label: '离职' },
            { value: 3, label: '已冻结' }
          ]
        },
        split1: {
          type: 'split',
        },
        search: {
          type: 'button',
          buttonType: 'primary',
          label: '查询',
          click: () => {
            this.$refs.screen.emitModel()
            this.getTableData(true)
          }
        },
        reset: {
          type: 'button',
          label: '重置',
          click: () => {
            this.$refs.screen.resetModel()
          }
        },
        br:{ type: 'br' },
        add: {
          type: 'button',
          buttonType: 'primary',
          label: '+ 新增员工',
          click: () => {
            this.popover(null)
          },
          hide: () => this.onlyBindQywx
        },
        // quit: {
        //   type: 'popconfirm',
        //   title: '确定要更改离职状态？',
        //   label: '批量离职',
        //   click: () => { this.deleteUser() }
        // },
        enable: {
          type: 'button',
          label: '批量启用',
          click: () => {
            this.onlineIslock()
          },
          hide: () => this.onlyBindQywx || this.$store.state.managerInfo.corpId !== 0
        },
        addGQywx: {
          type: 'button',
          label: '创建企微',
          click: () => {
            this.addGroupQywx()
          },
          hide: () => this.onlyBindQywx
        },
        deleteQW: {
          type: 'popconfirm',
          title: '删除企微账号后，员工聊天信息将无法找回，确定删除吗？',
          buttonType: 'primary',
          label: '删除企微',
          click: () => {
            this.deletQywx()
          },
          hide: () => this.onlyBindQywx
        },
        openProductAuth: {
          type: 'button',
          buttonType: 'primary',
          label: '开通产品权限',
          click: () => {
            this.proPopover()
          },
          hide: () => this.onlyBindQywx
        },
        split: {
          type: 'split',
          hide: () => this.onlyBindQywx
        },
        // role: {
        //   type: 'button',
        //   buttonType: 'primary',
        //   label: '设置分公司角色',
        //   hide: this.$store.state.managerInfo.corpId !== 0,
        //   click: () => { this.showCorpRole = true }
        // },
        
        excel: {
          type: 'button',
          buttonType: 'primary',
          label: '导出Excel',
          click: throttle(async () => {
            let data = await this.$http({
              url: '%CRM%/manager/exp_manager_list_excel.sdcrm',
              data: {
                $set: {
                  responseType: 'blob'
                },
                token: true,
                corpId: this.$store.state.managerInfo.corpId || undefined
              }
            })

            let url = URL.createObjectURL(data)
            let link = document.createElement('a')
            link.setAttribute('href', url)
            link.setAttribute('download', '员工列表' + ' - ' + new Date().timeFormat('yyyy_MM_dd hh_mm') + '.xlsx')
            link.style.display = 'none'
            document.body.appendChild(link)
            link.click()
            URL.revokeObjectURL(url)
            document.body.removeChild(link)
          }),
          hide: () => this.onlyBindQywx
        }
      },
      // 表格
      tableDataList: [],
      showManagerIdList: [],

      selectList: [],
      groupId: '',
      // 弹窗
      showPopover: false,
      popoverData: {},
      // corpRoleList: [],
      roleList: [],
      accountList: [],
      userTypeList: [],
      showCorpRole: false,
      // 手机串号
      showPhone: false,
      phoneData: {},
      // 绑定企微
      showQywx: false,
      qywxData: {},
      // 开通套餐
      showProduct: false,

      keyword: '',
      // 编辑状态
      editType: ''
    }
  },
  computed: {
    searchData() {
      let list = [...this.tableDataList]

      list = list.filter(e => {
        return this.showManagerIdList.includes(e.id) || String(e.userName).includes(this.keyword) || String(e.realName).includes(this.keyword)
      })

      return list
    },
    tableData() {
      return this.searchData.slice(this.pageNum * this.pageSize - this.pageSize, this.pageNum * this.pageSize)
    },
    total() {
      return this.searchData.length
    }
  },
  inject: ['onlyBindQywx'],
  methods: {
    getTableData: throttle(async function(toFirst) {
      this.loading = true

      if (toFirst) {
        this.pageNum = 1
      }

      let { result } = await this.$http({
        url: '%CRM%/manager/get_manager_list.sdcrm',
        data: {
          token: true,
          isLock: this.screen.isLock,
          groupIds: this.groupId ? [this.groupId] : undefined
        }
      })

      if (this.$store.state.managerInfo.corpId) {
        this.tableDataList = result.filter(e => e.corpId === this.$store.state.managerInfo.corpId)
      } else {
        this.tableDataList = result
      }
      this.tableDataList.sort((a, b) => b.isLeader - a.isLeader)
      this.tableDataList.sort((a, b) => { 
        let auditStatusA = a.auditStatus === 3 ? 1.5 : a.auditStatus
        let auditStatusB = b.auditStatus === 3 ? 1.5 : b.auditStatus
        return auditStatusA - auditStatusB
      })
      this.loading = false
    }),
    // 获取微营销账号列表
    async getAccountList() {
      let { result } = await this.$http({
        mode: 'get',
        url: '%CRM%/manager/get_account_list.sdcrm',
        data: {
          token: true
        }
      })

      this.accountList =
        result?.map(e => {
          e.name = `${e.realName} ${e.userName}`
          return e
        }) ?? []
    },
    //获取推广商
    async getUserTypeList() {
      let { result } = await this.$http({
        url: '%CRM%/lvm_user_type/get_lvm_user_type_search.sdcrm',
        data: {
          token: true,
          isPage: 1
        }
      })

      this.userTypeList.splice(0, this.userTypeList.length, ...result)
    },
    // 获取分公司角色
    // async getCorpRoleList() {
    //   let { result } = await this.$http({
    //     url: '%CRM%/role/get_corp_allow_roles.sdcrm',
    //     data: {
    //       token: true,

    //     }
    //   })

    //   this.corpRoleList = result.map(e => e.roleId)
    // },
    // 获取所有的角色
    async getRole() {
      let { result } = await this.$http({
        url: '%CRM%/role/get_role_list.sdcrm',
        data: {
          token: true,
          modeLevel: this.$store.state.sysMode === 2 ? 2 : undefined,
          // corpId: this.$store.state.managerInfo.corpId
          managerCorpId: this.$store.state.managerInfo.corpId
        }
      })

      this.roleList = result
    },
    // 新增/编辑
    popover(data) {
      this.showPopover = true
      this.popoverData = data?.data
      this.editType = data?.key
    },
    // 手机串号
    phonePopover(data) {
      this.showPhone = true
      this.phoneData = data
    },
    // 绑定企微
    qywxPopover(data) {
      this.showQywx = true
      this.qywxData = data
    },
    // 开通产品权限
    proPopover: throttle(async function() {
      if (!this.selectList.length) {
        this.$message.warning('请选择员工')
        return
      }

      let all = this.selectList.map(e => {
        return {
          url: '%CRM%/manager/get_manager.sdcrm',
          data: {
            token: true,
            id: e.id
          }
        }
      })

      let data = await this.$http({
        mode: 'relay',
        all
      })

      let proNum = []
      data.forEach(e => {
        if (e.result.telephone && e.result.telephone.length === 11) {
          return
        }

        proNum.push({
          name: e.result.realName,
          telephone: e.result.telephone ? e.result.telephone : null
        })
      })

      let no = []
      let standard = []

      if (proNum && proNum.length) {
        proNum.forEach(e => {
          if (e.telephone) {
            standard.push(e.name)
            return
          }
          no.push(e.name)
        })

        this.$copy(`无手机号员工:${no.length ? no.join(',') : '无'}; 手机号不规范员工: ${standard.length ? standard.join(',') : '无'}`, () => {
          this.$message.error(`开通对象中包含手机号不符合规范有${standard.length}个,无手机号的员工有${no.length}个,请核查后再开通,已复制该员工信息`)
        })
        return
      }

      this.showProduct = true
    }),
    // 批量启用
    onlineIslock: throttle(async function() {
      if (!this.selectList.length) {
        this.$message.warning('请选择员工')
        return
      }

      let all = this.selectList.map(e => {
        return {
          url: '%CRM%/manager/set_manager_status.sdcrm',
          data: {
            token: true,
            id: e.id
          }
        }
      })

      let data = await this.$http({
        mode: 'relay',
        all
      })

      let successCount = 0
      let errorCount = 0
      let dataList = []
      data.forEach((e, i) => {
        if (e.code === 8200) {
          successCount++
          return
        }
        errorCount++
        dataList.push(`ID:${this.selectList[i].id},错误信息:${e.msg || e.errmsg}`)
      })

      if (data.length === 1) {
        if (errorCount) {
          this.$message.error('启用失败' + data[0].msg || data[0].errmsg)
        } else {
          this.$message.success('启用成功')
        }
      } else {
        if (errorCount) {
          this.$copy(
            dataList.join('\n'),
            () => {
              this.$message.error(`启用成功${successCount}条,启用失败${errorCount}条,失败信息已复制`)
            },
            false
          )
        } else {
          this.$message.success(`启用成功${successCount}条,启用失败${errorCount}条`)
        }
      }
      this.selectList = []
      this.getTableData()
    }),
    // 创建集团企微
    addGroupQywx: throttle(async function() {
      if (!this.selectList.length) {
        this.$message.warning('请选择员工')
        return
      }
      let all = this.selectList.map(e => {
        return {
          url: '%CRM%/manager/qy_user_update.sdcrm',
          data: {
            token: true,
            managerId: e.id,
            updateAndCreate: true
          }
        }
      })
      let data = await this.$http({
        mode: 'relay',
        all
      })

      let successCount = 0
      let errorCount = 0
      let dataList = []
      data.forEach((e, i) => {
        if (e.code === 8200) {
          successCount++
          return
        }
        errorCount++
        dataList.push(`ID:${this.selectList[i].id},错误信息:${e.msg || e.errmsg}`)
      })

      if (data.length === 1) {
        if (errorCount) {
          this.$message.error('创建企微失败' + data[0].msg || data[0].errmsg)
        } else {
          this.$message.success('创建企微成功')
        }
      } else {
        if (errorCount) {
          this.$copy(
            dataList.join('\n'),
            () => {
              this.$message.error(`创建企微成功${successCount}条,创建企微失败${errorCount}条,失败信息已复制`)
            },
            false
          )
        } else {
          this.$message.success(`创建企微成功${successCount}条,创建企微失败${errorCount}条`)
        }
      }
      this.selectList = []
      this.getTableData()
    }),
    // 批量离职
    deleteUser: throttle(async function() {
      if (!this.selectList.length) {
        this.$message.warning('请选择员工')
        return
      }

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/manager/manager_batch_leave.sdcrm',
        data: {
          token: true,
          managerIds: this.selectList.map(e => e.id)
        }
      })

      if (code !== 8200) {
        this.$message.error('离职失败' + msg || errmsg)
        return
      }

      this.$message.success('离职成功')
      this.selectList = []
      this.getTableData()
    }),
    // 删除企业微信
    deletQywx: throttle(async function() {
      if (!this.selectList.length) {
        this.$message.warning('请选择员工')
        return
      }

      let all = this.selectList.map(e => {
        return {
          url: '%CRM%/manager/qy_user_delete.sdcrm',
          data: {
            token: true,
            managerId: e.id
          }
        }
      })

      let data = await this.$http({
        mode: 'relay',
        all
      })

      let successCount = 0
      let errorCount = 0
      let dataList = []
      data.forEach((e, i) => {
        if (e.code === 8200) {
          successCount++
          return
        }
        errorCount++
        dataList.push(`ID:${this.selectList[i].id},错误信息:${e.errmsg || e.msg}`)
      })

      if (data.length === 1) {
        if (errorCount) {
          this.$message.error('删除失败' + data[0].errmsg || data[0].msg)
        } else {
          this.$message.success('删除成功')
        }
      } else {
        if (errorCount) {
          this.$copy(
            dataList.join('\n'),
            () => {
              this.$message.error(`删除成功${successCount}条,删除失败${errorCount}条,失败信息已复制`)
            },
            false
          )
        } else {
          this.$message.success(`删除成功${successCount}条,删除失败${errorCount}条`)
        }
      }
      this.selectList = []
      this.getTableData()
    }),
    // 搜索
    search: throttle(async function(keyword) {
      if (keyword) {
        this.keyword = keyword
        let { result } = await this.$http({
          url: '%CRM%/manager/get_managers_by_qy_user.sdcrm',
          data: {
            token: true,
            keyword
          }
        })

        this.showManagerIdList = result || []
      } else {
        this.keyword = ''
        this.showManagerIdList = []
      }
    })
  },
  components: {
    TableData,
    EditData,
    CorpRole,
    BindPhone,
    BindQywx,
    OpenProducts
  },
  created() {
    // this.getCorpRoleList()
    this.getAccountList()
    this.getRole()
    this.getUserTypeList()
  }
}
</script>
<style lang="scss" scoped>
.right-box {
  height: 100%;
  width: calc(100% - 384px);
  border-left: 1px solid #f0f2f5;
}
</style>
