<template>
  <el-table-pro
    :head="head"
    :data="data"
    ref="table"
    default-sort-key="0"
    @sort="$emit('change', $event)"
    @selection-change="$emit('update:select-list', $event)"
  >
    <template #body-phone="{ row }"> 
      <callphone
        :user-id="row.userId"
        @call="selectUser(row)"
      />
    </template>

    <template #body-realname="{ row }">
      <scratch
        v-if="row.realname"
        :data="row.realname"
        mode="name"
        :log="row.userId"
        show-button
      />
      <span v-else>未实名</span>
    </template>
  </el-table-pro>
</template>
<script>
import Scratch from '../../components/other/scratch'
import Callphone from '../../components/other/callphone'

export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'userId',
          label: '用户编号',
          click: this.selectUser,
          minWidth: 70
        },
        {
          key: 'phone',
          label: '',
          width: 30,
          excel: false
        },
        {
          key: 'realname',
          label: '客户姓名',
          minWidth: 120,
        },
        {
          key: 'serviceManagerName',
          label: '当前客服',
          minWidth: 100
        },
        {
          key: 'firstDealTime',
          label: '首次成交时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '--',
          sort: '1'
        },
        {
          key: 'lastDealTime',
          label: '最近成交时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '--',
          sort: '2'
        },
        {
          key: 'expTime',
          label: '服务到期时间',
          minWidth: 140,
          format: e => e ? new Date(e).timeFormat() : '--',
          sort: '3'
        },
        {
          key: 'lastCost',
          label: '最近一次成交金额',
          minWidth: 112
        },
        {
          key: 'totalCost',
          label: '累计成交金额',
          minWidth: 112
        },
        {
          key: 'totalRefundAmount',
          label: '累计退费金额',
          minWidth: 112
        },
        {
          key: 'lastCalltime',
          label: '最近一次通话时间',
          minWidth: 160,
          format: e => e ? new Date(e).timeFormat() : '--',
          sort: '4'
        },
        {
          key: 'userType',
          label: '客户分类',
          minWidth: 120,
          edit: 'select',
          labelKey: 'typeName',
          valueKey: 'typeId',
          options: this.userType,
          change: this.updateUserType,
          excel: {
            list: this.userType,
            key: 'typeId',
            value: 'typeName',
          }
        },
        {
          key: 'fundType',
          label: '资金分类',
          minWidth: 120,
          edit: 'select',
          labelKey: 'typeName',
          valueKey: 'typeId',
          options: this.fundType,
          placeholder: '选择资金',
          change: this.updateFundType,
          excel: {
            list: this.fundType,
            key: 'typeId',
            value: 'typeName',
          }
        }
      ],
    }
  },
  props: {
    data: Array,
    userType: Array,
    fundType: Array
  },
  components: {
    Scratch,
    Callphone
  },
  methods: {
    async updateUserType(row, update = true) {
      await this.$http({
        url: '%CRM%/user/set_corp_user_type.sdcrm',
        data: {
          token: true,
          userId: row.userId,
          userType: row.userType,
        }
      })

      if(update) {
        this.updateUserDetailTag(row)
      }
    },
    async updateFundType(row, update = true) {
      await this.$http({
        url: '%CRM%/user/set_corp_fund_type.sdcrm',
        data: {
          token: true,
          userId: row.userId,
          fundType: row.fundType,
        }
      })

      if(update) {
        this.updateUserDetailTag(row)
      }
    },
    selectUser(row) {
      this.updateUserDetailTag(row)
      this.$emit('select', row.userId)
    },
    updateUserDetailTag(row) {
      const userTypeTags = this.userType.map(e => {
        return {
          id: e.typeId,
          tagTitle: e.typeName,
          active: false,
          type: 'user'
        }
      })

      const fundTypeTags = this.fundType.map(e => {
        return {
          id: e.typeId,
          tagTitle: e.typeName,
          active: false,
          type: 'fund'
        }
      })
      
      const userTypeItem = userTypeTags.find(e => e.id === row.userType)
      const fundTypeItem = fundTypeTags.find(e => e.id === row.fundType)
      userTypeItem.active = true
      if(fundTypeItem) {
        fundTypeItem.active = true
      }
      

      const userTypeTag = {
        tagTitle: userTypeItem.tagTitle
      }
      const fundTypeTag = {
        tagTitle: fundTypeItem?.tagTitle ?? ''
      }

      const userTag = []

      if(userTypeItem) {
        userTag.push(userTypeTag)
      }
      if(fundTypeItem) {
        userTag.push(fundTypeTag)
      }

      this.$emit('update-tag', {
        userTag: userTag,
        tagList: [
          {
            tagGroupName: '客户分类',
            tagGroupType: 1,
            tags: userTypeTags
          },
          {
            tagGroupName: '资金分类',
            tagGroupType: 1,
            tags: fundTypeTags
          }
        ],
        tagChange: async (data) => {
          switch(data.type) {
            case 'user': {
              data.active = true
              userTypeTag.tagTitle = data.tagTitle
              row.userType = data.id
              this.updateUserType(row, false)
              break
            }
            case 'fund': {
              data.active = true
              fundTypeTag.tagTitle = data.tagTitle
              row.fundType = data.id
              if(userTag.length === 1) {
                userTag.push(fundTypeTag)
              }
              this.updateFundType(row, false)
              break
            }
          }
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
@import "../../assets/css/common.scss";

.el-table {
  /deep/ {
    .edit-cell .el-input__inner{
      color: #3089FF;
    }
  }
}
</style>