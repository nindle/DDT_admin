<template>
  <el-dialog-pro 
    @close="close"
    width="360px"
  >
    <template #title>分配客户</template>
    
    <el-form-pro
      :model="form"
      :config="config"
    >
      <template #span>
        您已选中{{data.length}}人，请选择要分配的员工
      </template>
    </el-form-pro>
    
    <!-- 底部按钮 -->
    <template #footer> 
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      loading: false,
      form: {
        span: '',
        id: ''
      },
      config: {
        span: {},
        id: {
          type: 'select-manager',
          label: '',
          placeholder: '请选择要分配的员工',
          filter: () => {
            if(this.$store.state.managerInfo.managerType === 1) {
              if(this.$store.state.managerInfo.isLeader) {
                const groupList = [this.$store.state.baseData.groupList.find(e => e.id === this.$store.state.managerInfo.dataGroupId)]
                const managerIds = []
                const search = (list) => {
                  list.map(e => {
                    if(e.managerList.length) {
                      managerIds.push(...e.managerList.map(e => e.id))
                    }
                    if(e.groupChildren.length) {
                      search(e.groupChildren)
                    }
                  })
                }
                search(groupList)

                return {
                  id: managerIds,
                  managerType: 1,
                  corpId: 19
                }
              }

              return {
                id: this.$store.state.managerInfo.id,
                managerType: 1,
                corpId: 19
              }
            }
            return {
              corpId: 19,
              managerType: 1,
            }
          }
        }
      },
      
    }
  },
  props: {
    data: Array,
    show: Boolean
  },
  methods: {
    close() {
      this.$emit('update:show', false)
    },
    submit:throttle(async function() {
      if(!this.form.id) {
        this.$message.error('请选择要分配的员工')
        return
      }
      this.loading = true

      let { code,msg,errmsg } = await this.$http({
        url: '%CRM%/user/user_batch_distribute.sdcrm',
        data: {
          token: true,
          managerId: this.form.id,
          attachType: 1,
          userIds: this.data.map(item => item.userId)
        }
      })

      if(code === 8200) {
        this.$message.success('分配成功')
      } else {
        this.$message.error(msg || errmsg)
      }

      this.loading = false
      this.close()
      this.$emit('change')
    }),
  }
}
</script>