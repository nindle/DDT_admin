<template>
  <div 
    class="view"
    :class="{ 'has-user': selectUserId }"
  >
    <el-layout-pro
      class="box"
      :loading="loading"
      :total="total"
      :page-num.sync="pageNum"
      :page-size.sync="pageSize"
      @page-change="getTableData()"
    >
      <!--筛选模块-->
      <template #screen>
        <el-screen-pro
          :model="screen"
          :config="config"
          @change="getTableData(true)"
        ></el-screen-pro>
      </template>

      <!--表格模块-->
      <template #table>
        <table-data 
          :data="tableData" 
          @select="selectUserId = $event"
          @update-tag="selectUserTag = $event"
          :select-list.sync="selectList"
          :user-type="config.userType.options"
          :fund-type="config.fundType.options"
          @change="getTableData(true, $event)"
        />
      </template>

      <!--编辑模块-->
      <template #popover>
        <batch-distribute 
          v-if="showPopover"
          :show.sync="showPopover"
          :data="selectList"
          @change="getTableData"
        />
      </template>
    
    </el-layout-pro>

    <!--客户详情-->
    <el-layout-pro 
      class="user-box"
      v-if="selectUserId"
    >
      <template #screen>
        <el-screen-pro :config="userDetailConfig">
          <template #close>
            <i 
              class="el-icon-close"
              @click="selectUserId = 0"
            ></i>
          </template>
        </el-screen-pro>
      </template>

      <template #scroll>
        <user-detail 
          class="user-detail-box" 
          :user-id="selectUserId"
          :key="selectUserId"
          :customTag="selectUserTag"
        />
      </template>
    
    </el-layout-pro>
  </div>
</template>

<script>
import { throttle } from '../../assets/js/tool'
import TableData from './tableData'
import UserDetail from '../../components/user-detail/index'
import BatchDistribute from './batchDistribute.vue'

export default {
  name: 'gm-refund',
  data() {
    return {
      //分页
      total: 0,
      pageNum: 1,
      pageSize: 10,
      //加载状态
      loading: false,
      //表格数据
      tableData: [],
      //展示修改
      showPopover: false,
      //筛选数据
      screen: {
        time: [],
        managerId: '',
        serviceStatus: '',
        userType: '',
        fundType: '',
        keyword: '',
      },
      config: {
        time: {
          type: 'date-range',
          placeholder: ['成交时间', '结束时间']
        },
        managerId: {
          type: 'select-manager',
          placeholder: '售后归属人',
          filter: () => {
            if(this.$store.state.managerInfo.managerType === 1) {
              if(this.$store.state.managerInfo.isLeader) {
                const groupList = [this.$store.state.baseData.groupList.find(e => e.id === this.$store.state.managerInfo.dataGroupId)]
                const managerIds = []
                const search = (list) => {
                  list.map(e => {
                    if(e.managerList.length) {
                      managerIds.push(...e.managerList.map(e => e.id))
                    }
                    if(e.groupChildren.length) {
                      search(e.groupChildren)
                    }
                  })
                }
                search(groupList)

                return {
                  id: managerIds,
                  managerType: 1,
                  corpId: 19
                }
              }

              return {
                id: this.$store.state.managerInfo.id,
                managerType: 1,
                corpId: 19
              }
            }
            return {
              corpId: 19,
              managerType: 1,
            }
          }
        },
        serviceStatus: {
          type: 'select',
          placeholder: '服务状态',
          options: [
            { value: 1, label: '服务期内' },
            { value: 2, label: '已到期' },
            { value: 3, label: '退费' },
          ]
        },
        userType: {
          type: 'select',
          placeholder: '客户类型',
          options: [],
          valueKey: 'typeId',
          labelKey: 'typeName',
        },
        fundType: {
          type: 'select',
          placeholder: '资金分类',
          options: [],
          valueKey: 'typeId',
          labelKey: 'typeName',
        },
        split: {
          type: 'split'
        },
        keyword: {
          type: 'input',
          placeholder: '输入编号/昵称/备注/名称/手机号',
          changeLog: true
        },
        br: { type: 'br' },
        single: {
          type: 'button',
          buttonType: 'primary',
          label: '批量分配单员工',
          click: () => { !this.selectList.length ?  this.$message.warning('请选择客户') : this.showPopover = true}
        },
        split2: {
          type: 'split'
        },
        excel: {
          type: 'button',
          label: '导出Excel',
          buttonType: 'primary',
          click: throttle(async () => {
            let data = await this.$http({
              url: '%CRM%/user/exp_corp_user_list_excel.sdcrm',
              data: {
                $set: {
                  responseType: 'blob'
                },
                token: true,
                startDealTime: this.screen.time?.[0],
                endDealTime: this.screen.time?.[1],
                serviceManagerId: this.screen.managerId || void 0,
                serviceStatus: this.screen.serviceStatus || void 0,
                userType: this.screen.userType || void 0,
                fundType: this.screen.fundType || void 0,
                keyword: this.screen.keyword || void 0,
                orderColumn: Number(this.sortData.key),
                oderType: this.sortData.type === 'desc' ? 1 : 0
              }
            })

            let url = URL.createObjectURL(data)
            let link = document.createElement('a')
            link.setAttribute('href', url)
            link.setAttribute('download', '元和客户列表' + ' - ' + new Date().timeFormat('yyyy_MM_dd hh_mm') + '.xlsx')
            link.style.display = 'none'
            document.body.appendChild(link)
            link.click()
            URL.revokeObjectURL(url)
            document.body.removeChild(link)
          }),
          hide: () => !this.auth.includes(8)
        },
      },
      selectList: [],

      //选择的用户ID
      selectUserId: 0,
      selectUserTag: null,
      userDetailConfig: {
        label: {
          type: 'label',
          label: '客户资料'
        },
        split: { type: 'split' },
        close: {}
      },

      sortData: { key: '0', type: 'desc' }
    }
  },
  props: {
    nav: Object,
    auth: Array
  },
  components: {
    TableData,
    UserDetail,
    BatchDistribute
  },
  methods: {
    //数据获取
    getTableData: throttle(async function(toFirst, sort) {
      this.loading = true

      if(toFirst) {
        this.pageNum = 1
      }

      if(sort) {
        this.sortData = sort
      }

      let { result } = await this.$http({
        url: '%CRM%/user/get_corp_user_list.sdcrm',
        data: {
          token: true,
          pageSize: this.pageSize,
          pageNum: this.pageNum,
          startDealTime: this.screen.time?.[0],
          endDealTime: this.screen.time?.[1],
          serviceManagerId: this.screen.managerId || void 0,
          serviceStatus: this.screen.serviceStatus || void 0,
          userType: this.screen.userType || void 0,
          fundType: this.screen.fundType || void 0,
          keyword: this.screen.keyword || void 0,
          orderColumn: Number(this.sortData.key),
          oderType: this.sortData.type === 'desc' ? 1 : 0
        }
      })

      this.total = result.total
      this.tableData = result.records.map(e => {
        if(e.fundType === 0) {
          e.fundType = ''
        }
        return e
      })

      this.loading = false
    }),
    //获取客户类型
    async getUserTypeList() {
      let { result } = await this.$http({
        url: '%CRM%/setting/get_types/74.sdcrm',
        mode: 'get',
        data: {
          token: true,
        }
      })

      this.config.userType.options.splice(0,this.config.userType.options.length,...result)
    },
    //获取资金分类
    async getFundTypeList() {
      let { result } = await this.$http({
        url: '%CRM%/setting/get_types/75.sdcrm',
        mode: 'get',
        data: {
          token: true,
        }
      })

      this.config.fundType.options.splice(0,this.config.fundType.options.length,...result)
    },
  },
  created() {
    this.getUserTypeList()
    this.getFundTypeList()
  }
}
</script>

<style scoped lang="scss">

.view {
  width: 100%;
  height: 100%;
  padding: 24px;
  box-sizing: border-box;
  display: flex;
  .box {
    width: 100%;
    height: 100%;
    background: #FFF;
  }
  .user-box {
    width: 350px;
    height: 100%;
    margin-left: 24px;
    background: #FFF;
    .el-icon-close { cursor: pointer; }
    /deep/ {
      .screen-box { padding: 24px;}
      .scroll-box { background: #F5F5F5;}
      .detail-box .step { display: none;}
    }
  }
  &.has-user {
    .box { width: calc(100% - 374px);}
  }
}
</style>
