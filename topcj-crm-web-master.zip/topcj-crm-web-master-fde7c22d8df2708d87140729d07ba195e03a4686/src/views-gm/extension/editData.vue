<template>
  <el-dialog-pro @close="close">
    <!-- 标题 -->
    <template #title> {{ data ? '编辑' : '新增' }}推广策划 </template>
    <!-- 表单内容 -->
    <el-form-pro :model="form" :config="config" ref="form">
      <template #aidTips>
        <div class="tips">该小程序没有对应的备用小程序

          <el-button
            size="small"
            type="text"
            icon="el-icon-right"
            @click="setApp"
          >去设置</el-button>
        </div>
      </template>
    </el-form-pro>

    <template #right v-if="[4, 7, 8, 10, 11].includes(form.pageType)">
      <el-scrollbar-pro class="right-box">
        <el-form-pro 
          class="right-form" 
          :class="`page-type-${form.pageType}`"
          :model="form" 
          :config="configRight" 
          ref="rightForm"
        ></el-form-pro>
      </el-scrollbar-pro>
    </template>

    <!-- 底部按钮 -->
    <template #footer>
      <el-button size="small" @click="close">取 消</el-button>
      <el-button type="primary" size="small" @click="submit" :loading="loading">确 定</el-button>
    </template>
  </el-dialog-pro>
</template>
<script>
import { createLink, json2search, search2json, throttle } from '../../assets/js/tool'

const reissueType = [
  { value: 1, label: '文案' },
  { value: 2, label: '图片' },
  { value: 3, label: '文案+图片' }
]

const getReissueTime = function() {
  return Array.from({ length: 31 }).map((e, i) => {
    let label = [`${Math.floor(i / 2) + 7}`, `${(i % 2) * 30}`.padStart(2, '0')].join(':')
    return {
      label,
      value: label,
      disabled: false
    }
  })
}

const defaultReissueTime = ['12:00', '15:00', '21:30']

export default {
  data() {
    let sendAgainTimes = this.data?.sendAgainTimes ? JSON.parse(this.data.sendAgainTimes) : ''

    let sendAgainTimesForm = {}

    for (let i = 0; i < 3; i++) {
      if (sendAgainTimes) {
        sendAgainTimesForm[`reissueTime${i + 1}`] = sendAgainTimes[i]?.sendTime ?? ''
        sendAgainTimesForm[`reissueType${i + 1}`] = sendAgainTimes[i]?.type ?? ''
        sendAgainTimesForm[`reissueContent${i + 1}`] = sendAgainTimes[i]?.content ?? ''
        sendAgainTimesForm[`reissueImage${i + 1}`] = sendAgainTimes[i]?.imgUrl ?? ''
      } else {
        sendAgainTimesForm[`reissueTime${i + 1}`] = defaultReissueTime[i]
        sendAgainTimesForm[`reissueType${i + 1}`] = 2
        sendAgainTimesForm[`reissueContent${i + 1}`] = ''
        sendAgainTimesForm[`reissueImage${i + 1}`] = ''
      }
    }
    let wxkfData = {
      jumpType: this.data?.jumpType ?? '',
      replyType: this.data?.replyType ?? '',
      jumpReplyContent: this.data?.jumpReplyContent ?? '',
      jumpContent: this.data?.jumpContent?.replace(/\n/g, '<br/>') ?? '',
      replyContent: this.data?.replyContent?.replace(/\n/g, '<br/>') ?? '',
    }
    if(wxkfData.jumpContent && wxkfData.jumpType === 1) {
      wxkfData.jumpContent = wxkfData.jumpContent.replace(/__URL__/g, wxkfData.jumpReplyContent)
    }
    if(wxkfData.jumpContent) {
      wxkfData.jumpContent = `<p>${wxkfData.jumpContent}</p>`
    }
    if(wxkfData.replyContent) {
      wxkfData.replyContent = `<p>${wxkfData.replyContent}</p>`
    }

    return {
      form: {
        promotionId: this.data?.promotionId ?? '',
        groupId: this.data?.groupId ?? '',
        userTypeId: this.data?.userTypeId ?? '',
        name: this.data?.name ?? '',
        type: this.data?.type ?? '',
        pageType: this.data?.pageType ?? '',
        resChannelId: this.data?.resChannelId ?? '',
        userGroupCode: this.data?.userGroupCode?.split(',').filter(e => e) ?? [],
        userId: this.data?.userId ?? '',
        aid: this.data?.aid ?? '',
        wxkfId: this.data?.wxkfId ?? '',
        dzhTips: '大智慧固定为股海实战策略小程序（九分主体）',
        wxType: this.data?.wxType ?? 0,
        dupMode: this.data?.dupMode ?? 0,
        authorId: this.data?.authorId ?? '',
        position: this.data?.position ?? '',
        resTag: this.data?.resTag ?? '',
        pic: this.data?.pic,
        link: this.data?.link,
        ctimestamp: this.data?.ctime ? new Date(this.data.ctime).getTime() : Date.now(),
        activetime: this.data?.stime ? [new Date(this.data.stime).getTime(), new Date(this.data.etime).getTime()] : null,
        // qrCodeId: this.data?.qrCodeId ?? '',
        pageId: this.data?.pageId ?? '',
        fileUrl: this.data?.fileUrl
          ? this.data.fileUrl
              .split(',')
              .filter(e => e)
              .map(e => {
                let l = e.split('/')
                return {
                  name: l[l.length - 1],
                  url: e
                }
              })
          : [],
        wxRes: this.data?.wxRes ?? 0,
        pageStyle: this.data?.pageStyle ?? '',
        qrcodeType: this.data?.qrcodeType ?? 0,
        pubStatus: this.data?.pubStatus ?? 0,

        picSize: this.data?.picSize ?? 0,

        //补发相关配置
        ...sendAgainTimesForm,

        ...wxkfData,


        jumpContentLabel: '配置默认发送内容（第一次发送）',
        replyTypeLabel: '配置回复互动内容（客户回复任意消息后）',
        reissueMsgLabel: '手动补发（未加粉成功的用户）',
        reissueMsgType: '',
        reissueMsgContent: '',
        reissueMsgImgUrl: '',
      },
      config: {
        promotionId: {
          type: 'select',
          label: '模板',
          options: this.promotionList,
          valueKey: 'id',
          labelKey: 'promotionName',
          disabled: !!this.data,
          filterable: true,
          change: value => {
            let item = this.config.promotionId.options.find(e => e.id === value)
            if (item) {
              this.form.name = item.promotionName
              this.form.pageType = item.skipType
              if ([4, 7, 8, 10, 11].includes(item.skipType)) {
                this.config.qrcodeType.disabled = false
              } else {
                this.config.qrcodeType.disabled = true
                this.form.qrcodeType = 0
              }
              this.form.position = `${this.SYS.WEBSPREADURL}/#/spread/page/${value}?adId=${this.data?.id ?? '%ID%'}`
              this.config.pageType.disabled = true
              this.config.position.disabled = true
              this.config.link.disabled = [2, 6, 3, 4, 5].includes(item.skipType)
              if ([2, 6, 3, 4, 5].includes(item.skipType)) {
                this.form.aid = 1
              }
            } else {
              this.form.name = ''
              this.form.pageType = ''
              this.form.position = ''
              this.config.qrcodeType.disabled = true
              this.form.qrcodeType = 0
              this.config.pageType.disabled = false
              this.config.position.disabled = false
              this.config.link.disabled = false
              this.form.aid = ''
            }
          }
        },
        name: {
          label: '策划名称',
          rule: [{ required: true }],
          wordLimit: 20
        },
        type: {
          type: 'select',
          label: '策划类型',
          options: [
            { value: 0, label: '推广策划' },
            { value: 1, label: '营销策划' }
          ],
          rule: [{ required: true }]
        },
        pageType: {
          type: 'select',
          label: '页面类型',
          options: this.pageTypeList,
          disabled: !!this.data?.promotionId,
          change: this.init
        },
        aid: {
          type: 'select',
          label: '跳转小程序',
          hide: () => ![2, 6, 3, 4, 5].includes(this.form.pageType) || this.form.userTypeId === 87,
          rule: [{ required: true }],
          options: this.appList,
          valueKey: 'id',
          labelKey: 'appName',
          change: () => {
            this.checkApp()
          }
        },
        aidTips: {
          label: '',
          hide: () => {
            return ![2, 6, 3, 4, 5].includes(this.form.pageType) || this.form.userTypeId === 87 || !this.showAidTips
          }
        },
        dzhTips: {
          type: 'label',
          label: '跳转小程序',
          hide: () => ![2, 6, 3, 4, 5].includes(this.form.pageType) || this.form.userTypeId !== 87
        },
        wxkfId: {
          type: 'select',
          label: '跳转客服',
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType),
          rule: [{ required: true }],
          options: this.wxkfList,
          valueKey: 'id',
          labelKey: 'memo'
        },
        qrcodeType: {
          type: 'select',
          label: '二维码类型',
          options: [
            { value: 0, label: '普通' },
            { value: 1, label: '有底图' }
          ],
          disabled: true
        },
        userTypeId: {
          type: 'select',
          label: '推广公司',
          options: this.userTypeList,
          filterable: true,
          labelKey: 'resName',
          valueKey: 'id',
        },
        resChannelId: {
          type: 'select',
          label: '投放渠道',
          options: this.$store.state.baseData.resChannelList,
          valueKey: 'id',
          labelKey: 'channelName'
        },
        pageStyle: {
          type: 'select',
          label: '页面内容风格',
          options: this.categoryList,
          valueKey: 'typeId',
          labelKey: 'typeName',
        },
        wxType: {
          type: 'select',
          label: '推广轮询方式',
          options: [
            { value: 0, label: '默认方式' },
            { value: 1, label: '企业微信方式' },
            { value: 2, label: '外部联系人方式' },
            { value: 3, label: '活码分组方式' },
          ],
          rule: [{ required: true }],
          change: () => {
            this.form.groupId = ''
          }
        },
        groupId: {
          type: 'select',
          label: '活码分组',
          options: this.groupList,
          labelKey: 'groupName',
          valueKey: 'id',
          hide: () =>  this.form.wxType !== 3,
          rule: [{ required: true }],
        },
        dupMode: {
          type: 'select',
          label: '唯一性时长',
          options: [
            { value: 0, label: '48小时' },
            { value: 1, label: '永久' },
            { value: 2, label: '展示归属二维码' }
          ],
          rule: [{ required: true }],
        },
        resTag: {
          label: 'SCRM标签',
        },
        authorId: {
          label: '内容作者',
          type: 'select-manager',
          filter: {
            managerType: 3
          }
        },
        wxRes: {
          type: 'switch',
          label: '微信资源',
          activeValue: 1,
          inactiveValue: 0
        },
        position: {
          type: 'textarea',
          label: '页面地址',
          disabled: !!this.data?.promotionId,
          rule: [{ required: true }]
        },
        pic: {
          type: 'image',
          label: '图片',
          fileSize: e => {
            this.form.picSize = e
          }
        },
        link: {
          type: 'input',
          label: '链接地址',
          disabled: this.data ? [2, 6, 3, 4, 5].includes(this.data.pageType) : false
        },
        ctimestamp: {
          type: 'date-time',
          label: '发布时间',
          rule: [{ required: true }]
        },
        activetime: {
          type: 'date-range',
          label: '活动时间',
          rule: [{ required: true }]
        },
        fileUrl: {
          label: '附件',
          type: 'file-list'
        },
        pubStatus: {
          label: '推广状态',
          type: 'switch',
          placeholder: '推广状态',
          activeValue: 1,
          inactiveValue: 0
        }
      },
      configRight: {
        jumpContentLabel: {
          type: 'label',
          label: '',
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType)
        },
        jumpContent: {
          type: 'richtext',
          label: '',
          placeholder: '请输入内容',
          hideTool: [
            'bold',
            'italic',
            'underline',
            'strikeThrough',
            'indent',
            'foreColor',
            'backColor',
            'justify',
            'quote',
            'clean',
            'image',
            'video',
            'undo',
            'redo',
            'html',
            'loginlock'
          ],
          rule: [{ required: true }],
          menuClick: () => {
            setTimeout(() => {
              const dom = document.querySelector('.w-e-icon-link + .w-e-panel-container input:nth-child(2)')
              if(dom) {
                if([7, 8].includes(this.form.pageType)) {
                  dom.setAttribute('placeholder', '请输入客户自动回复内容') 
                }
                if([10, 11].includes(this.form.pageType)) {
                  dom.value = '__URL__'
                  dom.setAttribute('style', 'display: none;') 
                }
              }
            }, 100)
          },
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType)
        },
        split01: { 
          type: 'split',
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType) 
        },
        replyTypeLabel: {
          type: 'label',
          label: '',
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType)
        },
        replyType: {
          type: 'select',
          label: '',
          placeholder: '回复类型',
          options: [
            { value: 0, label: '文字' },
            { value: 1, label: '文字+二维码' },
          ],
          rule: [{ required: true }],
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType)
        },
        replyContent: {
          type: 'richtext',
          rule: [{ required: true }],
          placeholder: '请输入内容',
          label: '',
          hideTool: [
            'bold',
            'italic',
            'underline',
            'strikeThrough',
            'indent',
            'foreColor',
            'backColor',
            'justify',
            'quote',
            'clean',
            'image',
            'video',
            'undo',
            'redo',
            'html',
            'loginlock'
          ],
          menuClick: () => {
            setTimeout(() => {
              const dom = document.querySelector('.w-e-icon-link + .w-e-panel-container input:nth-child(2)')
              if(dom) {
                if([10, 11, 7, 8].includes(this.form.pageType)) {
                  dom.value = '__URL__'
                  dom.setAttribute('style', 'display: none;') 
                }
              }
            }, 100)
          },
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType)
        },
        split02: { 
          type: 'split',
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType) || !this.data
        },
        reissueMsgLabel: {
          type: 'label',
          label: '',
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType) || !this.data
        },
        reissueMsgType: {
          type: 'select',
          placeholder: '补发类型',
          options: [
            { value: 1, label: '文字' },
            { value: 2, label: '图片' },
            // { value: 3, label: '二维码' },
          ],
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType) || !this.data
        },
        reissueMsgContent: {
          type: 'richtext',
          rule: [{ required: true }],
          placeholder: '请输入补发内容',
          label: '',
          hideTool: [
            'bold',
            'italic',
            'underline',
            'strikeThrough',
            'indent',
            'foreColor',
            'backColor',
            'justify',
            'quote',
            'clean',
            'image',
            'video',
            'undo',
            'redo',
            'html',
            'loginlock'
          ],
          menuClick: () => {
            setTimeout(() => {
              const dom = document.querySelector('.w-e-icon-link + .w-e-panel-container input:nth-child(2)')
              if(dom) {
                if([10, 11, 7, 8].includes(this.form.pageType)) {
                  dom.value = '__URL__'
                  dom.setAttribute('style', 'display: none;') 
                }
              }
            }, 100)
          },
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType) || this.form.reissueMsgType !== 1 || !this.data
        },
        reissueMsgImgUrl: {
          label: '',
          type: 'image',
          placeholder: '请上传补发图片',
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType) || this.form.reissueMsgType !== 2 || !this.data
        },
        reissueMsgButton: {
          label: '',
          type: 'button',
          buttonType: 'primary',
          buttonLabel: '发送',
          click: this.reissueMsg,
          hide: () => ![7, 8, 10, 11].includes(this.form.pageType) || typeof this.form.reissueMsgType !== 'number' || !this.data
        },


        reissueTime1: {
          label: '补发1时间',
          type: 'select',
          options: getReissueTime(),
          change: this.updateReissueTime,
          hide: () => ![4].includes(this.form.pageType)
        },
        reissueType1: {
          label: '补发1类型',
          type: 'select',
          options: reissueType,
          hide: () => !this.form.reissueTime1 || ![4].includes(this.form.pageType)
        },
        reissueContent1: {
          label: '补发1文案',
          type: 'textarea',
          placeholder: '未填写则使用默认文案',
          hide: () => ![1, 3].includes(this.form.reissueType1) || !this.form.reissueTime1 || ![4].includes(this.form.pageType)
        },
        reissueImage1: {
          label: '补发1图片',
          type: 'image',
          placeholder: '未上传则使用上次发送的二维码',
          hide: () => ![2, 3].includes(this.form.reissueType1) || !this.form.reissueTime1 || ![4].includes(this.form.pageType)
        },
        split1: { 
          type: 'split',
          hide: () => ![4].includes(this.form.pageType)
        },
        reissueTime2: {
          label: '补发2时间',
          type: 'select',
          options: getReissueTime(),
          change: this.updateReissueTime,
          hide: () => ![4].includes(this.form.pageType)
        },
        reissueType2: {
          label: '补发2类型',
          type: 'select',
          options: reissueType,
          hide: () => !this.form.reissueTime2 || ![4].includes(this.form.pageType)
        },
        reissueContent2: {
          label: '补发2文案',
          type: 'textarea',
          placeholder: '未填写则使用默认文案',
          hide: () => ![1, 3].includes(this.form.reissueType2) || !this.form.reissueTime2 || ![4].includes(this.form.pageType)
        },
        reissueImage2: {
          label: '补发2图片',
          type: 'image',
          placeholder: '未上传则使用上次发送的二维码',
          hide: () => ![2, 3].includes(this.form.reissueType2) || !this.form.reissueTime2 || ![4].includes(this.form.pageType)
        },
        split2: { 
          type: 'split',
          hide: () => ![4].includes(this.form.pageType)
        },
        reissueTime3: {
          label: '补发3时间',
          type: 'select',
          options: getReissueTime(),
          change: this.updateReissueTime,
          hide: () => ![4].includes(this.form.pageType)
        },
        reissueType3: {
          label: '补发3类型',
          type: 'select',
          options: reissueType,
          hide: () => !this.form.reissueTime3 || ![4].includes(this.form.pageType)
        },
        reissueContent3: {
          label: '补发3文案',
          type: 'textarea',
          placeholder: '未填写则使用默认文案',
          hide: () => ![1, 3].includes(this.form.reissueType3) || !this.form.reissueTime3 || ![4].includes(this.form.pageType)
        },
        reissueImage3: {
          label: '补发3图片',
          type: 'image',
          placeholder: '未上传则使用上次发送的二维码',
          hide: () => ![2, 3].includes(this.form.reissueType3) || !this.form.reissueTime3 || ![4].includes(this.form.pageType)
        }
      },
      loading: false,
      showAidTips: false
    }
  },
  props: {
    show: Boolean,
    data: Object,
    promotionList: Array,
    userTypeList: Array,
    pageTypeList: Array,
    categoryList: Array,
    appList: Array,
    wxkfList: Array,
    groupList: Array
  },
  methods: {
    submit: throttle(async function() {
      if (!(await this.$refs.form.check())) return
      if (this.$refs.rightForm && !(await this.$refs.rightForm.check())) return

      this.loading = true

      let position = this.form.position

      {
        //创建链接
        let [l1, l2] = this.form.position.split('#')
        let [path, query] = l1.split('?')
        let [hash, hashquery] = l2?.split('?') ?? []
        if (query || (!query && !hashquery)) {
          query = this.setQuery(query)
        }
        if (hashquery) {
          hashquery = this.setQuery(hashquery)
        }
        if (hash) {
          hash = `#${hash}`
        }
        position = `${path}${query || ''}${hash || ''}${hashquery || ''}`
      }
      let data = await this.save(this.data?.id, { position })
      if (!data) {
        this.loading = false
        return
      }
      if ((position.indexOf('%ID%') > -1 || this.checkChange())) {
        position = position.replace(/%ID%/, data)
        let link = this.form.link

        //生成小程序链接
        if (this.checkChange()) {
          let { result } = await this.$http({
            url: '%CRM%/wx/generate_urllink.sdcrm',
            data: {
              aid: this.form.aid,
              path: 'pages/nspread/index',
              query: json2search({
                adId: this.data?.id ?? data,
                referer: '',
                resType: typeof this.form.userTypeId === 'number' ? this.form.userTypeId : 0,
                resChannelId: typeof this.form.resChannelId === 'number' ? this.form.resChannelId : 0,
                url: '',
                remark: '',
                keyword: '',
                sourceId: 0,
                pageId: this.form.promotionId
              }).substring(1),
              isExpire: true,
              expireType: 1,
              expireInterval: this.SYS.APIENV === 'dev' ? 10 : 179
            }
          })

          link = `${result.urlLink};${Date.now()}`
          //   let { result } = await this.$http({
          //     url: '%CRM%/wx/generate_scheme.sdcrm',
          //     data: {
          //       aid: this.form.aid,
          //       path: 'pages/nspread/index',
          //       query: json2search({
          //         adId: this.data?.id ?? data,
          //         referer: '',
          //         resType: typeof this.form.userTypeId === 'number' ? this.form.userTypeId : 0,
          //         resChannelId: typeof this.form.resChannelId === 'number' ? this.form.resChannelId : 0,
          //         url: '',
          //         remark: '',
          //         keyword: '',
          //         sourceId: 0,
          //         pageId: this.form.promotionId,
          //       }).substring(1),
          //       isExpire: true,
          //       // expireType: 1,
          //       // expireInterval: this.SYS.APIENV === 'dev' ? 10 : 179
          //       expireTime: Math.floor(Date.now() / 1000) + (this.SYS.APIENV === 'dev' ? 10 : 179) * 24 * 60 * 60
          //     }
          //   })

          //   link = result.openlink
        }

        data = await this.save(data, { position, link })
      }

      this.loading = false
      if (!data) return

      this.loading = false
      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    async save(id = -1, otherData) {
      //补发逻辑储存
      let sendAgainTimes = []

      if ([4, 7, 8, 10, 11].includes(this.form.pageType)) {
        for (let i = 1; i <= 3; i++) {
          if (this.form[`reissueTime${i}`]) {
            sendAgainTimes.push({
              sendTime: this.form[`reissueTime${i}`],
              type: this.form[`reissueType${i}`] || 2,
              content: [1, 3].includes(this.form[`reissueType${i}`]) ? this.form[`reissueContent${i}`] : '',
              imgUrl: [2, 3].includes(this.form[`reissueType${i}`]) ? this.form[`reissueImage${i}`] : ''
            })
          }
        }
      }

      //微信客服配置
      let wxkfData = {}
      if ([7, 8, 10, 11].includes(this.form.pageType)) {
        wxkfData.replyType = this.form.replyType
        wxkfData.jumpType = [7, 8].includes(this.form.pageType) ? 1 : 0
        wxkfData.replyContent = this.form.replyContent.replace(/<\/p>/g, '\n').replace(/<br\/>/g, '\n').replaceAll(/<(\/?)(.*?)>/g, e => {
          if(e === '</a>') {
            return '</a>'
          }
          if(e.indexOf('<a ') === 0) {
            return '<a href="__URL__">' 
          }

          return ''
        }).replace(/&gt;/g, '>').replace(/&lt;/g, '<').replace(/&nbsp;/g, ' ').replace(/\n*$/, '')
        
        wxkfData.jumpContent = this.form.jumpContent.replace(/<\/p>/g, '\n').replace(/<br\/>/g, '\n').replaceAll(/<(\/?)(.*?)>/g, e => {
          if(e === '</a>') {
            return '</a>'
          }
          if(e.indexOf('<a ') === 0) {
            const match = e.match(/<a.*?href="(.+?)".*?>/)
            if(match) {
              wxkfData.jumpReplyContent = match[1]
            }

            return '<a href="__URL__">' 
          }

          return ''
        }).replace(/&gt;/g, '>').replace(/&lt;/g, '<').replace(/&nbsp;/g, ' ').replace(/\n*$/, '')
        if(wxkfData.jumpType === 0) {
          wxkfData.jumpReplyContent = ''
        }
      }

      let { code, errmsg, msg, result } = await this.$http({
        url: '%CRM%/ad/set_ad.sdcrm',
        data: {
          token: true,
          adId: id,
          name: this.form.name,
          type: this.form.type,
          promotionId: typeof this.form.promotionId === 'number' ? this.form.promotionId : undefined,
          pageType: typeof this.form.pageType === 'number' ? this.form.pageType : undefined,
          resChannelId: this.form.resChannelId,
          wxType: this.form.wxType,
          userTypeId: this.form.userTypeId,
          authorId: typeof this.form.authorId === 'number' ? this.form.authorId : undefined,
          pic: this.form.pic,
          wxkfId: this.form.wxkfId,
          link: this.form.link,
          dupMode: this.form.dupMode,
          ctimestamp: this.form.ctimestamp,
          resTag: this.form.resTag,
          stime: this.form.activetime[0],
          etime: this.form.activetime[1],
          fileUrl: this.form.fileUrl.map(e => e.url).join(','),
          pageId: 1,
          pageStyle: typeof this.form.pageStyle === 'number' ? this.form.pageStyle : undefined,
          wxRes: this.form.wxRes,
          qrcodeType: this.form.qrcodeType,
          pubStatus: this.form.pubStatus,
          groupId: this.form.groupId,
          aid: this.form.aid,
          picSize: this.form.picSize,
          sendAgainTimes: JSON.stringify(sendAgainTimes),
          userGroupCode: this.form.userGroupCode.join(','),
          userId: this.form.userId,
          ...otherData,
          ...wxkfData
        }
      })

      if (code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      return result
    },
    //检查参数有没有变化
    checkChange() {
      //暂时隐藏
      // return false
      if (![3, 4, 5].includes(this.form.pageType)) {
        return false
      }
      if (this.form.userTypeId === 87) {
        return false
      }
      if (!this.form.link) {
        return true
      }

      let time = Number(this.form.link.split(';')[1] || 0)
      let now = Date.now()

      if (now - time > 169 * 24 * 3600 * 1000) {
        return true
      }

      if (
        this.form.userTypeId === (this.data?.userTypeId ?? '') &&
        this.form.promotionId === (this.data?.promotionId ?? '') &&
        this.form.aid === (this.data?.aid ?? '') &&
        this.form.resChannelId === (this.data?.resChannelId ?? '')
      ) {
        return false
      }

      return true
    },
    setQuery(query = '') {
      query = search2json(query || '')
      query.adId = this.data?.id ?? '%ID%'
      query.resType = typeof this.form.userTypeId === 'number' ? this.form.userTypeId : undefined
      query.channelId = typeof this.form.resChannelId === 'number' ? this.form.resChannelId : undefined
      // query.resTag = this.form.resTag || undefined
      query.clickType = this.$store.state.baseData.resChannelList.find(e => e.id === this.form.resChannelId)?.clickType || undefined
      return createLink('', query, [this.form.pageType === 6 ? 'spread-wxpay' : ''])
    },
    close() {
      this.$emit('update:show', false)
    },
    init() {
      if ([4,7,8,10,11].includes(this.form.pageType)) {
        this.updateReissueTime()
        this.config.qrcodeType.disabled = false
        return
      }

      this.config.qrcodeType.disabled = true
      this.form.qrcodeType = 0
    },
    //更新补发时间
    updateReissueTime() {
      let list = [...this.configRight.reissueTime1.options, ...this.configRight.reissueTime2.options, ...this.configRight.reissueTime3.options]
      list.forEach(e => {
        e.disabled = e.value === this.form.reissueTime1 || e.value === this.form.reissueTime2 || e.value === this.form.reissueTime3
      })
    },
    //检查小程序是否有备用小程序
    async checkApp() {
      if(typeof this.form.aid !== 'number') {
        this.showAidTips = false
        return
      }
      let { result } = await this.$http({
        url:'%CRM%/ad/get_ad_wxapp_list.sdcrm',
        data: {
          token: true,
          aid: this.form.aid
        }
      })

      if(result.length) {
        this.showAidTips = false
        return
      }

      this.showAidTips = true
    },
    setApp() {
      this.$router.push({
        name: 'gm-res_app_list',
        query: {
          ...this.$route.query
        },
        params: {
          aid: this.form.aid
        }
      })
    },
    //补发消息
    reissueMsg: throttle(async function() {
      switch(this.form.reissueMsgType) {
        case 1: {
          if(!this.form.reissueMsgContent) {
            this.$message.warning('请填写补发文案')
            return
          }
          break
        }
        case 2: {
          if(!this.form.reissueMsgImgUrl) {
            this.$message.warning('请上传补发图片')
            return
          }
          break
        }
      }

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/ad/send_wxkf_msg.sdcrm',
        data: {
          token: true,
          adId: this.data.id,
          type: this.form.reissueMsgType,
          content: this.form.reissueMsgContent.replace(/<\/p>/g, '\n').replace(/<br\/>/g, '\n').replaceAll(/<(\/?)(.*?)>/g, e => {
            if(e === '</a>') {
              return '</a>'
            }
            if(e.indexOf('<a ') === 0) {
              return '<a href="__URL__">' 
            }

            return ''
          }).replace(/&gt;/g, '>').replace(/&lt;/g, '<').replace(/&nbsp;/g, ' ').replace(/\n*$/, ''),
          imgUrl: this.form.reissueMsgImgUrl
        }
      })

      if(code !== 8200) {
        this.$message.error(`发送失败：${ msg || errmsg }`)
        return
      }

      this.$message.success(`发送成功`)
      this.form.reissueMsgContent = ''
      this.form.reissueMsgImgUrl = ''
      this.form.reissueMsgType = ''
    })
  },
  created() {
    this.init()
    this.checkApp()
  }
}
</script>

<style lang="scss" scoped>
.right-box {
  position: relative;
  margin-top: 54px;
  height: calc(100% - 54px);
  // &::before {
  //   content: '小程序客服消息回复有5条限制，由于初始已发送2条，请注意发送条数';
  //   position: absolute;
  //   left: 20px;
  //   line-height: 54px;
  //   top: -54px;
  //   font-size: 12px;
  //   color: #999;
  // }
  .right-form {
    width: 520px;
    padding: 20px;
    box-sizing: border-box;
    /deep/ {
      .form-item-replyTypeLabel, .form-item-jumpContentLabel, .form-item-reissueMsgLabel {
        margin-bottom: 0
      }
    }
    &.page-type-7,
    &.page-type-8 {
      /deep/ {
        .form-item-replyContent .el-form-richtext-toolbar { display: none;}
        .form-item-reissueMsgContent .el-form-richtext-toolbar { display: none;}
      }
    }
  }
}
.tips {
  color: #F56C6C;
}
</style>
