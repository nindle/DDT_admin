
<template>
  <el-table-pro
    :data="data"
    :head="head"
    @selection-change="$emit('update:select-list', $event)"
  >
    <template #body-id="{ row }">
      <el-tooltip 
        v-if="[2,3].includes(row.linkState)"
        :content="row.linkState === 2 ? '小程序直达链接有效期小于10天，重新保存进行更换' : '小程序直达链接已失效，重新保存进行更换'" 
        placement="right"
        :style="{ marginRight: '6px', color: row.linkState === 2 ? '#E6A23C' : '#F56C6C' }"
      >
        <span class="el-icon-question"></span>
      </el-tooltip>
      <span>{{row.id}}</span>
    </template>

    <template #body-fileUrl="{ row }">
      <el-button
        v-for="(e, i) in (row.fileUrl || '').split(',').filter(e => e)"
        :key="i"
        type="text"
        size="small"
        v-open="e"
        icon="el-icon-download"
        style="margin: 0 8px 0 0"
      >附件{{i + 1}}</el-button>
    </template>

    <template #body-status="{ row, content }">
      <el-popover
        :disabled="row.status !== 2"
        placement="top"
        trigger="hover"
      >
        <i class="el-icon-warning" style="color: #F56C6C; margin-right: 8px"></i>{{row.trialReason}}
        <span slot="reference">{{content}}</span>
      </el-popover>
    </template>

    <!-- <template #body-visible="{ row }">
      <el-button
        type="text"
        size="small"
        @click="hideData(row)"
        icon="el-icon-view"
      >{{row.visible ? '隐藏' : '显示'}}</el-button>
    </template> -->

  
  </el-table-pro>
</template>

<script>
import { throttle, json2search } from '../../assets/js/tool'

export default {
  data() {
    return {
      head: [
        {
          key: 'selection',
          type: 'selection',
          width: 14
        },
        {
          key: 'id',
          label: '推广编号',
          minWidth: 60
        },
        {
          key: 'name',
          label: '策划名称',
          minWidth: 120,
          tooltip: true
        },
        {
          key: 'pageType',
          label: '页面类型',
          minWidth: 100,
          format: {
            list: this.pageTypeList,
            key: 'value',
            value: 'label'
          }
        },
        {
          key: 'qrcodeType',
          label: '二维码类型',
          minWidth: 70,
          format: {
            '0': '普通',
            '1': '带底图',
          }
        },
        {
          key: 'userTypeId',
          label: '推广公司',
          minWidth: 100,
          format: id => this.userTypeList.find(e => e.id === id)?.resName ?? ''
        },
        
        {
          key: 'resChannelId',
          label: '投放渠道',
          minWidth: 100,
          format: {
            list: this.$store.state.baseData.resChannelList,
            key: 'id',
            value: 'channelName'
          }
        },
        {
          key: 'wxType',
          label: '推广轮询方式',
          minWidth: 98,
          format: {
            '0': '默认方式',
            '1': '企业微信方式',
            '2': '外部联系人方式',
            '3': '活码分组方式',
          }
        },
        {
          key: 'pageStyle',
          label: '页面内容风格',
          minWidth: 84,
          format: {
            list: this.categoryList,
            key: 'typeId',
            value: 'typeName'
          }
        },
        {
          key: 'position',
          label: '页面位置',
          minWidth: 200,
          copy: true
        },
        // {
        //   key: 'dzhlink',
        //   prop: 'this',
        //   label: '大智慧推广链接',
        //   minWidth: 98,
        //   copy: true,
        //   format: (e) => {
        //     if(![3,4,5].includes(e.pageType)) return ''

        //     let path = `pages/nspread/index${json2search({
        //       adId: e.id,
        //       referer: '',
        //       resType: typeof e.userTypeId === 'number' ? e.userTypeId : 0,
        //       resChannelId: typeof e.resChannelId === 'number' ? e.resChannelId : 0,
        //       url: '',
        //       remark: '',
        //       keyword: '',
        //       sourceId: 0,
        //       pageId: e.promotionId,
        //     })}`

        //     return `dzh_browser_url&goto=0&screen=331&wx_pid=gh_5feaaac8ba3c&wx_path=${window.btoa(path)}`
        //   },
        //   headtip: '大智慧推广链接只能跳转顶点财经小程序',
        //   tooltip: true
        // },
        {
          key: 'dzhlink',
          label: '大智慧推广链接',
          minWidth: 98,
          button: {
            type:'text',
            size:'small',
            label: '复制',
            icon:'el-icon-link',
            disabled: e => !([3,4,5].includes(e.pageType) && e.userTypeId === 87),
            click: e => {
              let path = `pages/nspread/index${json2search({
                adId: e.id,
                referer: '',
                resType: typeof e.userTypeId === 'number' ? e.userTypeId : 0,
                resChannelId: typeof e.resChannelId === 'number' ? e.resChannelId : 0,
                url: '',
                remark: '',
                keyword: '',
                sourceId: 0,
                pageId: e.promotionId,
              })}`

              this.$copy(`dzh_browser_url&goto=0&screen=331&wx_pid=gh_5b661292a9ee&wx_path=${window.btoa(path)}`)
            }
          },
          headtip: '大智慧推广链接只能跳转股海实战策略小程序（九分主体）',
        },
        {
          key: 'link',
          label: '小程序直达链接',
          minWidth: 98,
          button: {
            type:'text',
            size:'small',
            label: '复制',
            icon:'el-icon-link',
            disabled: e => !(e.link && [3,4,5].includes(e.pageType) && e.userTypeId !== 87),
            click: e => { this.$copy(e.link.split(';')[0])}
          },
          headtip: '小程序直达链接自创建日起179天有效',
        },
        {
          key: 'minilink',
          label: '小程序原生链接',
          minWidth: 98,
          button: {
            type:'text',
            size:'small',
            label: '复制',
            icon:'el-icon-link',
            disabled: e => !(e.link && [3,4,5].includes(e.pageType) && e.userTypeId !== 87),
            click: e => {
              let path = `pages/nspread/index${json2search({
                adId: e.id,
                referer: '',
                resType: typeof e.userTypeId === 'number' ? e.userTypeId : 0,
                resChannelId: typeof e.resChannelId === 'number' ? e.resChannelId : 0,
                url: '',
                remark: '',
                keyword: '',
                sourceId: 0,
                pageId: e.promotionId,
              })}`

              this.$copy(path)
            }
          },
          headtip: '小程序原生链接只能在公众号文章中跳转小程序使用',
        },
        {
          key: 'pic',
          label: '图片预览',
          minWidth: 56,
          button: {
            type:'text',
            size:'small',
            label: '查看',
            icon:'el-icon-picture-outline',
            disabled: row => {return !row.pic },
            click: row => { this.$imageview({
              list: row.pic.split(','),
              index: 0
            })}
          }
        }, 
        // {
        //   key: 'qrCodeId',
        //   label: '默认二维码',
        //   format: {
        //     list: this.codeList,
        //     value: 'name',
        //     key: 'id'
        //   }
        // },
        {
          key: 'ctime',
          label: '送审时间',
          minWidth: 140,
          format:e => new Date(e).timeFormat()
        },
        {
          key: 'createrName',
          label: '送审人',
          minWidth: 70
        },
        // {
        //   key: 'authorName',
        //   label: '内容作者',
        //   minWidth: 70
        // },
        {
          key: 'firstTrial',
          label: '审核人',
          minWidth: 70
        },
        // {
        //   key: 'secondTrial',
        //   label: '复审人',
        //   minWidth: 70
        // },
        {
          key: 'status',
          label: '状态',
          minWidth: 42,
          format: {
            '0': '待审核',
            '1': '通过',
            '2': '不通过',
          }
        },
        {
          key: 'pubStatus',
          label: '推广状态',
          minWidth: 56,
          edit: 'switch',
          inactiveValue: 0,
          activeValue: 1,
          change: this.setPubStatus,
          fixed: 'right'
        },
        {
          key: 'obj',
          label: '资源接受对象',
          minWidth: 94,
          button: {
            type: 'text',
            icon: 'el-icon-paperclip',
            label: '添加资源对象',
            click: e => { this.$emit('resources', e) }
          },
          fixed: 'right'
        },
        {
          key: 'operation',
          label: '操作',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-edit',
            label: '编辑',
            click:row => { this.$emit('edit', row) }
          },
          fixed: 'right'
        },
        {
          key: 'copy',
          width: 67,
          button: {
            type: 'text',
            icon: 'el-icon-link',
            label: '复制链接',
            disabled: row => {return !row.position.substr(0,5).includes('http')},
            click:row => { this.$copy(row.position) }
          },
          fixed: 'right'
        },
        {
          key: 'open',
          width: 44,
          button: {
            type: 'text',
            icon: 'el-icon-view',
            label: '预览',
            disabled: row => {return !row.position.substr(0,5).includes('http')},
            click:row => { this.$open(row.position) }
          },
          fixed: 'right'
        },
        {
          key: 'visible',
          width: 44,
          button: {
            popconfirm: '确认删除吗？',
            type: 'text',
            icon: 'el-icon-close',
            label: '删除',
            click: this.setVisible
          },
          fixed: 'right'
        }
      ]
    }
  },
  props: {
    data: Array,
    selectList: Array,
    userTypeList: Array,
    pageTypeList: Array,
    categoryList: Array,
    appList: Array,
    type: Number
  },
  methods: {
    //隐藏
    setPubStatus: throttle(async function(row){
      let { code, errmsg, msg } = await this.$http({
        url:'%CRM%/ad/set_ad.sdcrm',
        data:{
          token: true,
          adId: row.id,
          pubStatus: row.pubStatus
        }
      })
      if(code !== 8200) {
        this.$message.error(`操作失败：${errmsg || msg}`)
        return
      }

      this.$message.success('操作成功')
    }),
    setVisible: throttle(async function(row){
      let { code, errmsg, msg } = await this.$http({
        url:'%CRM%/ad/set_ad.sdcrm',
        data:{
          token: true,
          adId: row.id,
          visible: 0
        }
      })
      if(code !== 8200) {
        this.$message.error(`删除失败：${errmsg || msg}`)
        return
      }

      this.$message.success('删除成功')
      this.$emit('change')
    })
  }
}
</script>
