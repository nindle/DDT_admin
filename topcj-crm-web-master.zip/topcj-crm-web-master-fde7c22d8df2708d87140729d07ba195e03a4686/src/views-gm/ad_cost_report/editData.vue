
<template>
  <el-dialog-pro 
    @close="close"
    width="296px"
  >
    <!--标题-->
    <template #title>
      备注
    </template>
    <!--内容-->
    <el-form-pro
      :model="form"
      :config="config"
      ref="form"
    ></el-form-pro>
    
    <!--底部按钮-->
    <template #footer>
      <el-button 
        size="small"
        @click="close"
      >取 消</el-button>
      <el-button 
        type="primary" 
        size="small"
        @click="submit"
        :loading="loading"
      >保 存</el-button>
    </template>
  </el-dialog-pro>
</template>

<script>
import { throttle } from '../../assets/js/tool'
export default {
  data() {
    return {
      form: {
        memo: this.data?.memo ?? ''
      },
      config: {
        memo: {
          label: '',
          placeholder: '请输入备注',
          type: 'textarea'
        },
      },
      loading: false
    }
  },
  props: {
    data: Object,
  },
  methods: {
    //提交
    submit: throttle(async function() {
      if(!await this.$refs.form.check()) return

      this.loading = true

      let { code, msg, errmsg } = await this.$http({
        url: '%CRM%/ad/report/set_cost_report.sdcrm',
        data: {
          token: true,
          id: this.data?.id,
          memo: this.form.memo
        }
      })

      this.loading = false

      if(code !== 8200) {
        this.$message.error(`保存失败：${errmsg || msg}`)
        return
      }

      this.$message.success('保存成功')
      this.$emit('change')
      this.close()
    }),
    close() {
      this.$emit('update:show', false)
    }
  }
}
</script>

