<template>
  <el-table-pro
    :data="data"
    :head="head"
    border
    custom-head
    default-sort-key="cost"
    @sort="$emit('change', $event)"
    summary
  ></el-table-pro>
</template>
<script>

export default {
  data() {
    return {
      head: [
        {
          key: 'advertiserId',
          label: '账号ID',
          minWidth: 200,
          excel: `'{advertiserId}`,
          customHead: false,
          summary: (data) => {
            return `汇总：${data.length}`
          },
          copy: true
          // format: {
          //   list: this.accountList,
          //   key: 'advertiserId',
          //   value: 'advertiserName'
          // }
        },
        // {
        //   key: 'date',
        //   label: '日期',
        //   minWidth: 80,
        //   format: e => new Date(e).timeFormat('yyyy-MM-dd'),
        //   customHead: false,
        //   summary: (data) => {
        //     return `汇总：${data.length}`
        //   },
        //   copy: true
        // },
        {
          key: 'type',
          label: '类型',
          minWidth: 56,
          format: {
            '0': '头条',
            '1': '广点通',
            '2': '百度',
          },
          customHead: false,
          summary: '--',
          copy: true
        },
        {
          key: 'lvmUserTypeId',
          label: '推广公司',
          minWidth: 120,
          format: {
            list: this.lvmUserTypeList,
            key: 'id',
            value: 'resName',
          },
          customHead: ['hide'],
          summary: '--',
          copy: true
        },
        // {
        //   key: 'advertiserId',
        //   label: '账号ID',
        //   minWidth: 200,
        //   excel: `'{advertiserId}`,
        //   customHead: false,
        //   summary: '--',
        //   copy: true
        //   // format: {
        //   //   list: this.accountList,
        //   //   key: 'advertiserId',
        //   //   value: 'advertiserName'
        //   // }
        // },
        {
          key: 'accMemo',
          label: '账号备注',
          minWidth: 120,
          summary: '--',
          copy: true
        },
        {
          key: 'qrCode',
          label: '对应活码',
          minWidth: 120,
          summary: '--',
          copy: true
        },
        {
          key: 'cost',
          label: '消耗',
          minWidth: 100,
          format: e => Number(e || 0).toFixed(2),
          sort: 'cost',
          summary: 2,
          copy: true
        },
        {
          key: 'balance',
          label: '余额',
          minWidth: 100,
          format: e => Number(e || 0).toFixed(2),
          sort: 'balance',
          summary: (_e, { $count, $sum }) => {
            const l = $count('date')
            if(l === 1) {
              return $sum(e => Number(e.balance)).toFixed(2)
            }else{
              return '--'
            }
          },
          copy: true
        },
        {
          key: 'shows',
          label: '展示量',
          minWidth: 100,
          format: e => Number(e || 0),
          sort: 'shows',
          summary: 0,
          copy: true
        },
        {
          key: 'click',
          label: '点击量',
          minWidth: 100,
          format: e => Number(e || 0),
          sort: 'click',
          summary: 0,
          copy: true
        },
        {
          key: 'ctr',
          label: '点击率',
          minWidth: 80,
          format: e => Number(e || 0).toFixed(2) + '%',
          sort: 'ctr',
          summary: (_e, { shows, click, $sum }) => {
            if(typeof shows === 'undefined') {
              shows = $sum(e => Number(e.shows))
            }
            if(typeof click === 'undefined') {
              click = $sum(e => Number(e.click))
            }
            if(shows == 0) {
              return '0.00%'
            }
            return (click / shows * 100).toFixed(2) + '%'
          },
          copy: true
        },
        {
          key: 'avgClickCost',
          label: '点击均价',
          minWidth: 100,
          format: e => Number(e || 0).toFixed(2),
          sort: 'avg_click_cost',
          summary: (_e, { cost, click, $sum }) => {
            if(typeof cost === 'undefined') {
              cost = $sum(e => Number(e.cost))
            }
            if(typeof click === 'undefined') {
              click = $sum(e => Number(e.click))
            }

            if(click == 0) {
              return '0.00'
            }
            return (cost / click).toFixed(2)
          },
          copy: true
        },
        {
          key: 'converts',
          label: '转化数',
          minWidth: 100,
          format: e => Number(e || 0),
          sort: 'converts',
          summary: 0,
          copy: true
        },
        {
          key: 'convertCost',
          label: '转化成本',
          minWidth: 100,
          format: e => Number(e || 0).toFixed(2),
          sort: 'convert_cost',
          summary: (_e, { cost, converts, $sum }) => {
            if(typeof cost === 'undefined') {
              cost = $sum(e => Number(e.cost))
            }
            if(typeof converts === 'undefined') {
              converts = $sum(e => Number(e.converts))
            }
            if(converts == 0) {
              return '0.00'
            }
            return (cost / converts).toFixed(2)
          },
          copy: true
        },
        // {
        //   key: 'edit',
        //   label: '',
        //   width: 44,
        //   button: {
        //     type: 'text',
        //     icon: 'el-icon-edit',
        //     label: '编辑',
        //     click: e => {
        //       this.$emit('edit', e)
        //     }
        //   },
        //   editLabel: '编辑',
        //   customHead: ['hide'],
        //   summary: '--',
        //   excel: false
        // }
      ],
    }
  },
  props:{
    data:Array,
    accountList: Array,
    lvmUserTypeList: Array
  }
}
</script>