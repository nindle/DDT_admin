<template>
  <Example 
    title="post/get/form/all/relay"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]/*post*/
this.$http.post('url', {})
//第一参数为 请求链接
//第二参数为 请求数据


/*get*/
this.$http.get('url', {})
//第一参数为 请求链接
//第二参数为 请求数据


/*form*/
this.$http.form('url', {})
//第一参数为 请求链接
//第二参数为 请求数据


/*all*/
this.$http.form([
  { 
    mode: 'post',
    url: 'url',
    data: {}
  },
  { 
    mode: 'get',
    url: 'url',
    data: {}
  }
])
//第一参数为 请求配置数组（详细见简写）


/*relay*/
this.$http.form([
  { 
    mode: 'post',
    url: 'url',
    data: {}
  },
  { 
    mode: 'get',
    url: 'url',
    data: {}
  }
], 20, function() {})
//第一参数为 请求配置数组（详细见简写）
//第二参数为 请求间隔
//第三参数为 每个请求成功后的回调方法
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>