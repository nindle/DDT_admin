<template>
  <Example 
    title="引入"
    :script="script"
  />
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]//已挂载至VUE实例this中
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>