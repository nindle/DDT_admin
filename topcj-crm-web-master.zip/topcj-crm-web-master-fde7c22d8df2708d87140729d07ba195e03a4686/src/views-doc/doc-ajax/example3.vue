<template>
  <Example 
    title="数据填充"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]/*请求域名填充*/
this.$http({
  url: '%CRM%/xxxx.sdcrm',
  data: {}
})
//%CRM% => CRM接口域名
//%TES% => TES接口域名
//%SD% => SD接口域名
//%CC% => CC接口域名


/*token填充*/
this.$http({
  url: '%CRM%/xxxx.sdcrm',
  data: {
    token: true
  }
})
//data中token=true时自动填充token


/*路径填充*/
this.$http({
  url: '%CRM%/:id/xxxx.sdcrm',
  data: {
    token: true,
    id: 123
  }
})
//url中:xx会被替换为data中对应的值
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>