<template>
  <Example 
    title="简写"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]this.$http({
  mode: 'post', //请求模式，默认值为post
  url: 'url', //请求链接
  data: {}, //请求参数
  all: [], //请求配置列表，仅all/relay可用 
  interval: 0, //请求间隔，仅relay可用 
  step: function() {} //每个请求回调，仅relay可用 
})
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>