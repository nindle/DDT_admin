<template>
  <pre><code :class="type"><slot></slot></code></pre>
</template>

<script>
import highlight from 'highlight.js'
import 'highlight.js/styles/github.css'

export default {
  props: {
    type: String
  },
  mounted() {
    this.setHighlight()
  },
  methods: {
    setHighlight() {
      let blocks = this.$el.querySelectorAll('pre code')
      blocks.forEach(e => {
        highlight.highlightBlock(e)
      })
    }
  }
}
</script>

<style>
pre, code {
  font-size: 14px;
  font-family: Consolas;
}
</style>