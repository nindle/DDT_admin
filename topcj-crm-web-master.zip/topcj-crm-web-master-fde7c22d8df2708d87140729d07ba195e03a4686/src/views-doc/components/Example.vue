<template>
  <div class="example">
    <div class="title">{{title}}</div>
    <div class="box">
      <div 
        class="slot"
        v-if="$slots.default"
      >
        <slot />
      </div>
      <Highlight
        v-if="script"
        :type="scriptType"
      >{{scriptText}}</Highlight>
      <Table
        v-if="table"
        :table="table"
      ></Table>
    </div>
    
  </div>
</template>

<script>
import Highlight from './Highlight'
import Table from './Table'

export default {
  data() {
    return {
      scriptType: '',
      scriptText: ''
    }
  },
  props: {
    title: String,
    script: String,
    table: Object
  },
  created() {
    let reg = /^(\[(.*?)\])?(.*)$/s

    let result = reg.exec(this.script)
    this.scriptType = result[2] ?? ''
    this.scriptText = result[3]
  },
  components: {
    Highlight,
    Table
  }
}
</script>

<style scoped lang="scss">
.example {
  padding: 0 20px 20px;
  .title {
    font-size: 22px;
    line-height: 60px;
    color: #333;
  }
  .box {
    padding: 20px;
    background: #FFF;
    box-shadow: 0 2px 12px 0 rgba(#000, 0.1);
    border-radius: 2px;
    .slot { padding-bottom: 20px;}
  }
}
</style>