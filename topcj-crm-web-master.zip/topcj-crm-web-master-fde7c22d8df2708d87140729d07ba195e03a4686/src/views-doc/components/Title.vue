<template>
  <div class="title">{{title}}<span>{{subtitle}}</span></div>
</template>

<script>
export default {
  props: {
    title: String,
    subtitle: String
  }
}
</script>

<style scoped lang="scss">
.title {
  font-size: 28px;
  line-height: 80px;
  color: #333;
  span {
    font-size: 20px;
    color: #BBB;
    margin-left: 20px;
  }
}
</style>