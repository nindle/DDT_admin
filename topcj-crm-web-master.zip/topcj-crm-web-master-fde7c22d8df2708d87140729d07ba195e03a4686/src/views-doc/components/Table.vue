<template>
  <div class="table">
    <table>
      <thead>
        <tr>
          <td
            v-for="(e, i) in table.head"
            :key="i"
          >{{e}}</td>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="(e, i) in table.body"
          :key="i"
        >
          <td
            v-for="(e, i) in e"
            :key="i"
          >{{e}}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  props: {
    table: Object
  }
}
</script>

<style scoped lang="scss">
.table {
  table {
    width: 100%;
    font-size: 14px;
    line-height: 21px;
    color: #333;
    td { 
      padding: 12px;
      border-bottom: 1px solid #EEE;
    }
    thead { 
      color: #999;
      white-space: nowrap;
    }
  }
}
</style>