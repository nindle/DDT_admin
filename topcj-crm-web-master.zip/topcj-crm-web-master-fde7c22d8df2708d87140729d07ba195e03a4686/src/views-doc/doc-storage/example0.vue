<template>
  <Example 
    title="引入"
    :script="script"
  />
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]import { storage } from '../../assets/js/tool'
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>