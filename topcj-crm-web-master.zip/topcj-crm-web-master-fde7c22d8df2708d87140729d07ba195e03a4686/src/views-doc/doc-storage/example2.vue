<template>
  <Example 
    title="永久/临时"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]/*永久*/
const content = 'xxxxxxx'
storage.local('name', content)


/*临时*/
storage.session('name', content)
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>