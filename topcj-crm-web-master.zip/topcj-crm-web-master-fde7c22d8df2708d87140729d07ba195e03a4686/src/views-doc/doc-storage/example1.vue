<template>
  <Example 
    title="储存/获取/删除"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]/*储存*/
const content = 'xxxxxxx'
storage.local('name', content)


/*获取*/
const _content = storage.local('name')


/*删除*/
storage.local('name', null)
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>