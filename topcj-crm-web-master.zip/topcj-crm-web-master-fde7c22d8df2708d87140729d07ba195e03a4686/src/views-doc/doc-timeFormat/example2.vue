<template>
  <Example 
    title="使用方法"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]/*默认*/
new Date().timeFormat()
// => ${new Date().timeFormat()}


/*格式参数*/
new Date().timeFormat('yyyy/MM/dd')
// => ${new Date().timeFormat('yyyy/MM/dd')}
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>