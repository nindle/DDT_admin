<template>
  <Example 
    title="使用过滤器"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<!--默认-->
<div>{{ Date.now() | timeFormat }}</div>
<div>${new Date().timeFormat()}</div>


<!--格式参数-->
<div>{{ Date.now() | timeFormat('yyyy/MM/dd') }}</div>
<div>${new Date().timeFormat('yyyy/MM/dd')}</div>
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>