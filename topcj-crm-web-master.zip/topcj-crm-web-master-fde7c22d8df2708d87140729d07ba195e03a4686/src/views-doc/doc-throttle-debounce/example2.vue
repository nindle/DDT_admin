<template>
  <Example 
    title="防抖"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]//触发后再设定时间内为再次触发，再执行方法
const fn = debounce(function() {}, 300)
//第一参数为 执行方法
//第二参数为 限制时间 （默认值： 0）
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>