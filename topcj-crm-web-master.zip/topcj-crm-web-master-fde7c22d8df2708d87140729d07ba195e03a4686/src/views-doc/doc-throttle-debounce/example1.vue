<template>
  <Example 
    title="节流"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]//在设定时间内触发，仅触发第一次
const fn = throttle(function() {}, 300)
//第一参数为 执行方法
//第二参数为 限制时间 （默认值： 0）


//对于async函数，实际限制时间为 函数执行时间+限制时间
const fn2 = throttle(async function() {}, 300)
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>