<template>
  <Example 
    title="监听滚动到底部事件"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<el-scrollbar-pro @scroll-bottom="scrollBottom">
  滚动内容
</el-scrollbar-pro>
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>