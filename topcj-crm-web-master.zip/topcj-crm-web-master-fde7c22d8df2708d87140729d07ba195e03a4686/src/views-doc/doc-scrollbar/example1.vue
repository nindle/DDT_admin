<template>
  <Example 
    title="基础用法"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<el-scrollbar-pro>
  滚动内容
</el-scrollbar-pro>
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>