<template>
  <Example 
    title="可滚动的内容区域"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<el-layout-pro @scroll-bottom="scrollBottom">
  <template #screen>筛选模块</template>
  <template #scroll>可滚动的内容模块</template>
  <template #popover>弹框模块</template>
</el-layout-pro>
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>