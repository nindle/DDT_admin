<template>
  <div>
    <Title 
      title="分页布局"
      subtitle="layout"
    />
    <Example0 />
    <Example1 />
    <Example2 />
  </div>
</template>

<script>
import Title from '../components/Title'
import Example0 from './example0'
import Example1 from './example1'
import Example2 from './example2'

export default {
  components: {
    Title,
    Example0,
    Example1,
    Example2,
  }
}
</script>

<style scoped lang="scss">
</style>
