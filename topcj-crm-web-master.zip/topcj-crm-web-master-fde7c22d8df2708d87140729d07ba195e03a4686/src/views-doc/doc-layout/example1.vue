<template>
  <Example 
    title="基础用法"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<!--无分页-->
<el-layout-pro :loading="loading">
  <template #screen>筛选模块</template>
  <template #table>表格模块</template>
  <template #popover>弹框模块</template>
</el-layout-pro>

<!--有分页-->
<el-layout-pro 
  :loading="loading"
  :total="total"
  :page-num="pageNum"
  :page-size="pageSize"
  @page-change="pageChange"
>
  <template #screen>筛选模块</template>
  <template #table>表格模块</template>
  <template #popover>弹框模块</template>
</el-layout-pro>
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>