<template>
  <Example 
    title="订阅/取消订阅"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]/*订阅*/
const handel = function() {}

bus.$on('name', handel)
//第一参数为 订阅名
//第二参数为 执行方法

//注意：不可使用以下写法
bus.$on('name', function() {})


/*取消订阅*/
bus.$off('name', handel)
//第一参数为 订阅名
//第二参数为 执行方法
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>