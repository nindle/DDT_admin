<template>
  <Example 
    title="发布"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]/*订阅*/
bus.$emit('name', 'arguments')
//第一参数为 订阅名
//第二参数为 参数
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>