<template>
  <Example 
    title="引入"
    :script="script"
  />
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]import bus from '../../assets/js/bus'
//bus为公共性质的方法，非公共性质的逻辑不可使用bus
//页面内跨组件可以使用provide/inject
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>