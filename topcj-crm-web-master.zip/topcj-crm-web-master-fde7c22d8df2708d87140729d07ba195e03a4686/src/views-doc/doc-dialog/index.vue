<template>
  <div>
    <Title 
      title="弹框"
      subtitle="dialog"
    />
    <Example0 />
    <Example1 />
    <Example2 />
    <Example3 />
  </div>
</template>

<script>
import Title from '../components/Title'
import Example0 from './example0'
import Example1 from './example1'
import Example2 from './example2'
import Example3 from './example3'

export default {
  components: {
    Title,
    Example0,
    Example1,
    Example2,
    Example3,
  }
}
</script>

<style scoped lang="scss">
</style>
