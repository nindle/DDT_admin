<template>
  <Example 
    title="全屏/默认最高/自定义大小"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<el-dialog-pro 
  @close="close"
  fullScreen
  maxHeight
  width="520px"
  top="10vh"
>
  <template #title>标题</template>
  内容
  <template #footer>底部按钮</template>
</el-dialog-pro>

<!-- fullScreen 显示可放大按钮 -->
<!-- maxHeight 默认最大高度 -->
<!-- width 自定义宽度 -->
<!-- top 自定义距离顶部距离 -->
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>