<template>
  <Example 
    title="扩展"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<el-dialog-pro @close="close">
  <template #title>标题</template>
  内容
  <template #footer>底部按钮</template>
  <template #left>左侧扩展</template>
  <template #right>右侧扩展</template>
</el-dialog-pro>
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>