<template>
  <Example 
    title="使用"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]const content = {
  a: 1,
  b: '1',
  c: true,
  d: Symbol(1),
  e: 100000000000000n,
  f: null,
  g: undefined,
  h: function() {},
  i: async function() {},
  j: [
    {
      k: new Date(),
      l: /\\s/g,
      m: new RegExp('\\s', 'g'),
      n: new Set(),
      o: new Map(),
    }
  ],
}

const _content = deepcopy(content)
//深拷贝涉及循环递归，非必要情况不可使用
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>