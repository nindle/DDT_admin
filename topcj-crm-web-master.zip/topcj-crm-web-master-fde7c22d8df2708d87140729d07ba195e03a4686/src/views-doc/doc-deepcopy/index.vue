<template>
  <div>
    <Title 
      title="深拷贝"
      subtitle="deepcopy"
    />
    <Example0 />
    <Example1 />
  </div>
</template>

<script>
import Title from '../components/Title'
import Example0 from './example0'
import Example1 from './example1'

export default {
  components: {
    Title,
    Example0,
    Example1,
  }
}
</script>

<style scoped lang="scss">
</style>
