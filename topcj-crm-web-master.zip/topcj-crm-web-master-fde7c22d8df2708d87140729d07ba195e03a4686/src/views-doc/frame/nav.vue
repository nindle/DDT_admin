<!--导航-->
<template>
  <div class="nav">
    <div 
      class="background" 
      :style="{ '--top': activeTop }"
    ></div>

    <div class="list">
      <div
        class="item"
        v-for="(e, i) in navList"
        :key="i"
      >
        <div class="title">{{ e.title }}</div>
        <router-link 
          class="children"
          v-for="c in e.children" 
          :key="c.routeName"
          :to="{ name: c.routeName }"
        >
          <span>{{ c.title }}</span>
          <span>{{ c.subTitle }}</span>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      navList: [
        {
          title: '组件/方法列表',
          children: [
            {
              title: '方法-事件总线',
              subTitle: 'bus',
              routeName: 'doc-bus'
            },
            {
              title: '方法-MD5加密',
              subTitle: 'md5',
              routeName: 'doc-md5'
            },
            {
              title: '方法-数据储存',
              subTitle: 'storage',
              routeName: 'doc-storage'
            },
            {
              title: '方法-节流/防抖',
              subTitle: 'throttle/debounce',
              routeName: 'doc-throttle-debounce'
            },
            {
              title: '方法-深拷贝',
              subTitle: 'deepcopy',
              routeName: 'doc-deepcopy'
            },
            {
              title: '方法-接口请求',
              subTitle: 'ajax',
              routeName: 'doc-ajax'
            },
            {
              title: '方法-时间格式化',
              subTitle: 'timeFormat',
              routeName: 'doc-timeFormat'
            },
            {
              title: '方法-拷贝至剪贴板',
              subTitle: 'copy',
              routeName: 'doc-copy'
            },
            {
              title: '方法-新窗口打开',
              subTitle: 'open',
              routeName: 'doc-open'
            },
            {
              title: '方法-图片预览',
              subTitle: 'imageview',
              routeName: 'doc-imageview'
            },
            {
              title: '组件-滚动条',
              subTitle: 'scrollbar',
              routeName: 'doc-scrollbar'
            },
            {
              title: '组件-分页布局',
              subTitle: 'layout',
              routeName: 'doc-layout'
            },
            {
              title: '组件-弹框',
              subTitle: 'dialog',
              routeName: 'doc-dialog'
            },
            {
              title: '组件-表格',
              subTitle: 'table',
              routeName: 'doc-table'
            },
          ]
        }
      ]
    }
  },
  computed: {
    activeTop() {
      let height = 0
      for(let i = 0, l = this.navList.length; i < l; i++){
        height += 55
        for(let j = 0, l2 = this.navList[i].children.length; j < l2; j++) {
          let e = this.navList[i].children[j]
          if(this.$route.name === e.routeName) {
            return height
          }
          height += 40
        }
        height += 5
      }
      return 0
    }
  }
}
</script>

<style scoped lang="scss">
.nav {
  position: relative;
  width: 300px;
  height: 100%;
  box-shadow: 0 2px 12px 0 rgba(#000, 0.1);
  overflow: hidden;
  .background {
    position: absolute;
    top: calc(var(--top) * 1px);
    left: 0;
    width: 100%;
    height: 40px;
    background: #FFF;
    transition: top .3s;
    &::before {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 40px;
      border-left: 4px solid #409EFF;
      background: rgba(#409EFF, .1);
      box-sizing: border-box;
    }
  }
  .list { 
    width: 100%;
    .item {
      background: #FAFAFA;
      .title {
        position: relative;
        width: 100%;
        height: 50px;
        line-height: 50px;
        font-size: 16px;
        color: #333;
        text-indent: 40px;
        background: #FFF;
        z-index: 1;
      }
      .children {
        position: relative;
        display: flex;
        justify-content: space-between;
        width: 100%;
        height: 40px;
        line-height: 40px;
        &.router-link-active {
          span:nth-child(1) { color: #409EFF;}
        }
        &:first-of-type { padding-top: 5px;}
        &:last-of-type { padding-bottom: 5px;}
        span {
          &:nth-child(1) {
            padding-left: 40px;
            font-size: 14px;
            color: #333;
          }
          &:nth-child(2) {
            padding-right: 20px;
            font-size: 14px;
            color: #BBB;
          }
        }
      }
    }
  }
}
</style>