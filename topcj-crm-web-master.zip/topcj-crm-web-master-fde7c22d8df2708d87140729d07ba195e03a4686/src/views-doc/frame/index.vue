<template>
  <div class="index">
    <el-scrollbar-pro class="page">
      <router-view class="content" />
    </el-scrollbar-pro>
    <Nav />
  </div>
</template>

<script>
import Nav from './nav'

export default {
  components: {
    Nav
  }
}
</script>

<style scoped lang="scss">
.index {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: row-reverse;
  .page {
    height: 100%;
    width: calc(100% - 300px);
    background: #FAFAFA;
    .content {
      padding: 0 20px;
      max-width: 1000px;
    }
  }
}
</style>
