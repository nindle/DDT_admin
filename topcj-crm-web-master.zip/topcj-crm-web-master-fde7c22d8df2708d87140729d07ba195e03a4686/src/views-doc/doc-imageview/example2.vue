<template>
  <Example 
    title="使用指令"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<!--普通标签-->
<div v-imageview="value">图片1</div>
<!-- value 图片链接 -->


<!--图片标签-->
<img v-imageview :src="value" />
<!-- 图片标签中默认值会获取src中的值 -->

<!--列表-->
<div v-imageview:group="value">图片1</div>
<div v-imageview:group="value">图片2</div>
<!-- 使用:xxx 来定义图片所属的列表 -->
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>