<template>
  <Example 
    title="使用方法"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]this.$imageview({
  list: [
    'https://xxx.xxx.xxx/xxx1.jpg', 
    'https://xxx.xxx.xxx/xxx2.jpg'
  ],
  index: 0
})
//list 为图片列表
//index 为打开时的图片索引
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>