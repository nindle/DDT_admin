<template>
  <Example 
    title="使用指令"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<!--打开对应链接-->
<div v-open="'url'">打开</div>
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>