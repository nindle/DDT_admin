<template>
  <Example 
    title="使用方法"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]/*打开*/
this.$open('url')
//第一参数为 打开的链接
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>