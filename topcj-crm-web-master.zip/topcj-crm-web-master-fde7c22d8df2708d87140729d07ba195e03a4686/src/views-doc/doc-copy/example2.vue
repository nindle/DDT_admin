<template>
  <Example 
    title="使用指令"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<!--拷贝元素内的内容-->
<div v-copy>拷贝内容</div>


<!--拷贝自定义内容内容-->
<div v-copy="'拷贝内容'">拷贝</div>
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>