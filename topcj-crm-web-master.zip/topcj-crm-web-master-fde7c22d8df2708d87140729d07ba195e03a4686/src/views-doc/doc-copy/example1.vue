<template>
  <Example 
    title="使用方法"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]/*拷贝*/
this.$copy('text', function() {}, true)
//第一参数为 拷贝的文本
//第二参数为 成功的回调方法（默认弹出成功消息）
//第三参数为 是否上报拷贝信息（默认true）
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>