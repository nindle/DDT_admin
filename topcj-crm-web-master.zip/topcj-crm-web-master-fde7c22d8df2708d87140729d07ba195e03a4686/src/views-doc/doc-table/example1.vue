<template>
  <Example 
    title="基础用法"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[html]<el-table-pro 
  :data="data" 
  :head="head"
></el-table-pro>

<script>
export default {
  data() {
    return {
      data: [
        //数据
      ],
      head: [
        {
          //键值（唯一值）
          key: 'id',
          //标题文字
          label: '编号',
          //最小宽度（在宽度多余时会自动分配剩余宽度）
          minWidth: 60,
          //对齐方式（默认值:left）
          align: 'center',
          //默认值
          default: '--',
          //文本超出时鼠标悬停提示
          tooltip: true,
          //数据键值（默认值为设置的key值）
          prop: 'id'
        },
        //
        {
          //宽
          //格式化
          format: '{id}',
          //隐藏列
          hide: true
        }
      ]
    }
  }
}
<script>
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>