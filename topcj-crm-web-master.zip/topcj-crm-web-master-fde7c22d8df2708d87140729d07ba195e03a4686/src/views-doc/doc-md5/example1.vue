<template>
  <Example 
    title="使用"
    :script="script"
  ></Example>
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]const content = 'xxxxxxx'
const sign = md5(content)
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>