<template>
  <Example 
    title="引入"
    :script="script"
  />
</template>

<script>
import Example from '../components/Example'

const script = 
`[javascript]import { md5 } from '../../assets/js/crypto'
`

export default {
  data() {
    return {
      script
    }
  },
  components: {
    Example
  }
}
</script>